/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

process.on('uncaughtException', (err) => {
	console.error('Caught exception:', err);
});

import './settings.js';
import './lib/function.js';
import { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, fetchLatestWaWebVersion, DisconnectReason, downloadContentFromMessage, jidDecode, Browsers, delay, generateWAMessageFromContent, prepareWAMessageMedia, makeCacheableSignalKeyStore } from '@whiskeysockets/baileys';
import { makeInMemoryStore } from './lib/store.js'
import { handleGroupUpdate } from './src/plugins.js'

const LOCK_FILE = path.join(process.cwd(), '.bot.lock');
if (fs.existsSync(LOCK_FILE)) {
	try {
		const oldPid = parseInt(fs.readFileSync(LOCK_FILE, 'utf-8').trim(), 10);
		if (oldPid && oldPid !== process.pid) {
			process.kill(oldPid, 0); 
			console.error(`[LOCK ERROR] Bot sudah berjalan pada PID ${oldPid}. Batalkan eksekusi di sesi ini.`);
			process.exit(1);
		}
	} catch (e) {
		
	}
}
fs.writeFileSync(LOCK_FILE, process.pid.toString(), 'utf-8');

const cleanupLock = () => {
	try {
		if (fs.existsSync(LOCK_FILE)) {
			const pid = parseInt(fs.readFileSync(LOCK_FILE, 'utf-8').trim(), 10);
			if (pid === process.pid) {
				fs.unlinkSync(LOCK_FILE);
			}
		}
	} catch (e) {}
};

process.on('exit', cleanupLock);
process.on('SIGINT', () => { cleanupLock(); process.exit(0); });
process.on('SIGTERM', () => { cleanupLock(); process.exit(0); });
process.on('SIGHUP', () => { cleanupLock(); process.exit(0); });

import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import path from 'path';
import readline from 'readline';
import qrcode from 'qrcode-terminal';
import { fileTypeFromBuffer } from 'file-type';
import NodeCache from 'node-cache';
import os from 'os';
const speed = () => performance.now();
import moment from 'moment-timezone';
import crypto from 'crypto';
import { spawn } from 'child_process';
import http from 'http';
import logger from './lib/logger.js';

const { randomBytes } = await import('crypto');
global.customId = () => 'A5' + randomBytes(15).toString('hex').toUpperCase();

import { getActiveThumbBase64 } from './lib/thumb.js';
global.getThumbBuffer = () => getActiveThumbBase64();

const timestamp = speed();
const latensi = speed() - timestamp;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import { handler_cmd } from './src/handler.js';
import { loadPlugins, startWatcher } from './src/plugins.js';
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid } from './lib/webp.js';
import ConfigBaileys from './lib/config.js';
import { initDb, getSettings, getGroup } from './lib/database.js';
import makeHelper from './lib/helper-bails.js';
import { startGroupScheduler } from './core/groupScheduler.js';

async function InputNumber(promptText) {
	const rl = readline.createInterface({
		input: process.stdin,
		output: process.stdout,
	});
	return new Promise((resolve) => {
		rl.question(promptText, (answer) => {
			rl.close();
			resolve(answer);
		});
	});
}

const formatUptime = (seconds) => {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor(seconds % (3600 * 24) / 3600);
  const m = Math.floor(seconds % 3600 / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
};

const toSHA256 = (data) => {
  return crypto.createHash('sha256').update(String(data)).digest('hex');
};

const displayBanner = (conn) => {
  if (global.displayedBanner) return;
  global.displayedBanner = true;

  const botMode = (global.mode || 'public') === 'self' ? "Self Mode" : "Public Mode";
  console.log(chalk.yellow(`
# Time WIB: ${chalk.green(moment().tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY"))}
# Platform: ${chalk.green(os.platform())} (${os.arch()})
# Memory: ${chalk.green(((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(2))}% used
# Uptime: ${chalk.green(formatUptime(os.uptime()))}
# Node.js: ${chalk.green(process.version)}
# Mode: ${chalk.green(botMode)}
# Creator: ${chalk.green(`${(global.owner?.find(o => Array.isArray(o) ? o[2] !== false : true) || ["?","Owner"])[1] || global.namaOwner || 'Owner'}`)}
`));
};

const store = makeInMemoryStore();

const groupCache = new NodeCache({
	stdTTL: 5 * 60,
	useClones: false,
});

await initDb();

const FILEGUARD_ROOT = __dirname;
const FILEGUARD_EXCLUDE_DIRS = new Set([
	'node_modules', '.git', 'Auth', 'data', '.npm-global',
	'build', 'tmp', '.cache', 'dist'
]);
const FILEGUARD_BAK_EXT = ['.bak', '.backup', '.old', '.orig'];
const FILEGUARD_MIN_SIZE = 16; 

const fileGuardWalk = (dir, out = []) => {
	let entries = [];
	try {
		entries = fs.readdirSync(dir, { withFileTypes: true });
	} catch {
		return out;
	}
	for (const entry of entries) {
		if (entry.name.startsWith('.') && entry.name !== '.env') continue;
		const full = path.join(dir, entry.name);
		if (entry.isDirectory()) {
			if (FILEGUARD_EXCLUDE_DIRS.has(entry.name)) continue;
			fileGuardWalk(full, out);
		} else if (entry.isFile()) {
			out.push(full);
		}
	}
	return out;
};

const fileGuardHash = (filePath) => {
	try {
		return crypto.createHash('md5').update(fs.readFileSync(filePath)).digest('hex');
	} catch {
		return null;
	}
};

const fileGuardScan = () => {
	const files = fileGuardWalk(FILEGUARD_ROOT);
	const hashMap = new Map();
	const deleted = [];

	for (const file of files) {
		const ext = path.extname(file).toLowerCase();
		if (FILEGUARD_BAK_EXT.includes(ext)) {
			try {
				fs.unlinkSync(file);
				deleted.push({ type: 'bak', file: path.relative(FILEGUARD_ROOT, file) });
			} catch {}
		}
	}

	for (const file of files.filter(f => fs.existsSync(f))) {
		let stat;
		try {
			stat = fs.statSync(file);
		} catch {
			continue;
		}
		if (!stat.isFile() || stat.size < FILEGUARD_MIN_SIZE) continue;

		const hash = fileGuardHash(file);
		if (!hash) continue;

		if (hashMap.has(hash)) {
			try {
				fs.unlinkSync(file);
				deleted.push({ type: 'dobel', file: path.relative(FILEGUARD_ROOT, file), duplicateOf: path.relative(FILEGUARD_ROOT, hashMap.get(hash)) });
			} catch {}
		} else {
			hashMap.set(hash, file);
		}
	}

	if (deleted.length) {
		console.log(chalk.magentaBright(`  🧹 (｡•̀ᴗ-)✧ ${deleted.length} file sampah berhasil dibersihkan:`));
		for (const d of deleted) {
			console.log(chalk.dim(`    • [${d.type}] ${d.file}${d.duplicateOf ? ' (dobel dari ' + d.duplicateOf + ')' : ''}`));
		}
	}

	return deleted;
};

fileGuardScan();
setInterval(fileGuardScan, 20 * 60 * 1000);

const panelPort = process.env.PORT || process.env.SERVER_PORT;
if (panelPort) {
	try {
		const server = http.createServer((req, res) => {
			res.writeHead(200, { 'Content-Type': 'text/plain' });
			res.end(`Hirara AI WhatsApp Bot is active & healthy on Pterodactyl Panel Node.js!\nUptime: ${process.uptime().toFixed(2)}s\nRAM Usage: ${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB\n`);
		});
		server.listen(Number(panelPort), '0.0.0.0', () => {
			console.log(chalk.green(`🌐 [PTERODACTYL PANEL] Web server / health check active on 0.0.0.0:${panelPort}`));
		});
	} catch (errPanel) {
		console.warn('[PTERODACTYL PANEL] Failed to bind panel port:', errPanel.message);
	}
}

const startOptimizer = () => {
	try {
		const pythonBin = process.platform === 'win32' ? 'python' : 'python3';
		const optPath = path.join(process.cwd(), 'optimizer.py');
		if (!fs.existsSync(optPath)) return;

		const optProc = spawn(pythonBin, [optPath], {
			detached: true,
			stdio: 'ignore'
		});
		optProc.unref();
		console.log(chalk.cyan(`⚡ [OPTIMIZER] Python System Optimizer running in background (PID: ${optProc.pid}).`));
	} catch (errOpt) {
		console.warn('[OPTIMIZER WARNING] Could not auto-start optimizer.py:', errOpt.message);
	}
};
startOptimizer();

const botSet = await getSettings();
global.mode = botSet.mode || (botSet.public === 0 ? 'self' : 'public');
global.public = global.mode === 'public';
global.prefix = botSet.prefix;
global.multiprefix = botSet.multiprefix === 1;
global.menuType = botSet.menuType || 1;
global.db = { users: {}, groups: {}, settings: {} };

async function startBot() {
	const isPairing = (typeof global.useQr !== 'undefined' ? !global.useQr : true) && !process.argv.includes('--qr');
	const { state, saveCreds } = await useMultiFileAuthState('Auth');
	const { version: v, isLatest } = await fetchLatestWaWebVersion().catch(() => fetchLatestBaileysVersion());
	
	const sock = makeWASocket({
		printQRInTerminal: !isPairing,
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
		},
		version: v,
		browser: Browsers.ubuntu('Chrome'),
		syncFullHistory: false,
		connectTimeoutMs: 60000,
		defaultQueryTimeoutMs: 0,
		keepAliveIntervalMs: 30000,
		markOnlineOnConnect: false,

		cachedGroupMetadata: async (jid) => {
			return groupCache.get(jid);
		},

		getMessage: async (key) => {
			if (store) {
				const msg = store.loadMessage(key.remoteJid, key.id);
				return msg?.message || undefined;
			}
			return undefined;
		},

		logger: pino({ level: 'silent' }),
	});

	sock.conn = sock;
	sock.sock = sock;
	global.conn = sock;
	global.sock = sock;
	makeHelper(sock);

	sock.ev.on('creds.update', saveCreds);
    
	store.bind(sock.ev)
	global.store = store
	
	console.clear();
    
	let isConnectionOpened = false;
	let connectionTimer = null;
	let animInterval = null;

	const stopAnim = () => {
		if (animInterval) {
			clearInterval(animInterval);
			animInterval = null;
		}
	};

	const startConnectingAnim = (text = 'Connecting to WhatsApp') => {
		stopAnim();
		const frames = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
		let i = 0;
		animInterval = setInterval(() => {
			const frame = chalk.magenta(frames[i++ % frames.length]);
			if (process.stdout.isTTY) {
				process.stdout.clearLine(0);
				process.stdout.cursorTo(0);
				process.stdout.write(`  ${frame}  ${chalk.dim(text)}...`);
			}
		}, 80);
	};

	const resetConnectionTimeout = () => {
		if (connectionTimer) clearTimeout(connectionTimer);
		connectionTimer = setTimeout(async () => {
			if (!isConnectionOpened) {
				stopAnim();
				console.log(chalk.yellow('\n  [!] Connection timeout (device delayed/unresponsive).'));
				console.log(chalk.magenta('  [~] Re-establishing fresh connection...\n'));
				try {
					await sock.ws?.close();
				} catch {}
				await startBot();
			}
		}, 180000); 
	};

	resetConnectionTimeout();
    
	if (isPairing && !sock.authState.creds.registered) {
		let phoneNumber = global.nomerBot
			? global.nomerBot.replace(/[^0-9]/g, '')
			: (await InputNumber(chalk.cyan.bold('[!] -  Enter your number (with country code, e.g. 22371495144 or 628xxx):\n'))).replace(/[^0-9]/g, '');
		const customCode = (global.pairing || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
		setTimeout(async () => {
			try {
				let code;
				try {
					code = await sock.requestPairingCode(phoneNumber, customCode || undefined);
				} catch (err) {
					// Jika custom code gagal/dinolak server WA, coba request tanpa custom code
					if (customCode) {
						console.log(chalk.yellow('[!] Custom pairing code gagal, mencoba tanpa custom code...'));
						code = await sock.requestPairingCode(phoneNumber);
					} else {
						throw err;
					}
				}
				if (code) {
					const pair = code.slice(0, 4) + '-' + code.slice(4, 8);
					console.clear();
					await console.log(`${chalk.white.bold('[✓] - Your code')} : ${chalk.green.bold(pair)}`);
				}
			} catch (err) {
				console.error(chalk.red('\n[❌] Gagal meminta Pairing Code dari WhatsApp:'), err.message || err);
				console.log(chalk.yellow('[💡] Tips:'));
				console.log(chalk.yellow(' 1. Hapus folder Auth (rm -rf Auth) lalu coba lagi.'));
				console.log(chalk.yellow(' 2. Pastikan nomor aktif & dapat menerima SMS/OTP WhatsApp.'));
				console.log(chalk.yellow(' 3. Jika baru saja minta pairing berulang kali, tunggu 30-60 menit (Rate Limit WhatsApp).'));
			}
		}, 5000);
	}

	sock.ev.on('groups.update', async ([event]) => {
		try {
			const metadata = await sock.groupMetadata(event.id);
			groupCache.set(event.id, metadata);
		} catch {}
	});
	
    sock.ev.on('group-participants.update', async (event) => {
      try {
        const metadata = await sock.groupMetadata(event.id).catch(() => null); 
        if (metadata) groupCache.set(event.id, metadata);
      } catch {}
      await handleGroupUpdate(event, sock).catch(e => console.error('[GROUP_UPDATE] Error:', e.message || e));
    });

	sock.ev.on('group.join-request', async (event) => {
		try {
			const { id, participant } = event;
			const groupDb = await getGroup(id);
			if (groupDb?.autoacc === 1) {
				await sock.groupRequestParticipantsUpdate(id, [participant], 'approve');
			}
		} catch (e) {
			console.error('[AUTO_ACC] Error:', e.message || e);
		}
	});

	sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
		if (qr && !isPairing) {
			stopAnim();
			console.log(chalk.cyan.bold('\n  [!] SCAN QR CODE IN WHATSAPP:\n'));
			qrcode.generate(qr, { small: true });
		}
		if (connection === 'connecting' && sock.authState.creds.registered) {
			startConnectingAnim('Authenticating with WhatsApp server');
		}
		if (connection === 'close') {
			stopAnim();
			if (connectionTimer) clearTimeout(connectionTimer);
			const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
			console.error('[DISCONNECT]', lastDisconnect?.error);

			try {
				sock.ev.removeAllListeners();
				await sock.ws?.close();
			} catch {}

			switch (reason) {
				case DisconnectReason.badSession:
					console.log('Bad Session File, Please Delete Session and Scan Again');
					try { fs.rmSync('Auth', { recursive: true, force: true }); } catch {}
					process.exit(1);
				case DisconnectReason.connectionClosed:
					console.log('[SYSTEM] Connection closed, reconnecting...');
					setTimeout(() => startBot(), 3000);
					break;
				case DisconnectReason.connectionLost:
					console.log('[SYSTEM] Connection lost, trying to reconnect...');
					setTimeout(() => startBot(), 3000);
					break;
				case DisconnectReason.connectionReplaced:
					console.log('[SYSTEM] Connection replaced, exiting...');
					process.exit(0);
					break;
				case DisconnectReason.restartRequired:
					console.log('Restart Required...');
					setTimeout(() => startBot(), 2000);
					break;
				case DisconnectReason.loggedOut:
					console.log('Device Logged Out, Please Scan Again And Run.');
					try { fs.rmSync('Auth', { recursive: true, force: true }); } catch {}
					process.exit(1);
				case DisconnectReason.timedOut:
					console.log('Connection TimedOut, Reconnecting...');
					setTimeout(() => startBot(), 3000);
					break;

				default:
					const errorMsg = lastDisconnect?.error?.message || '';

					if (errorMsg.includes('Stream Errored (unknown)') || errorMsg.includes('restart required')) {
						console.log('[SYSTEM] Reconnecting...');
						setTimeout(() => startBot(), 3000);
					} else if (reason === 401 || errorMsg.includes('conflict') || errorMsg.includes('device_removed')) {
						console.log('[SYSTEM] Device removed/conflict detected. Resetting session...');
						try { fs.rmSync('Auth', { recursive: true, force: true }); } catch {}
						process.exit(1);
					} else {
						console.error(`[SYSTEM] Disconnect Reason (Unhandled): ${reason} - ${lastDisconnect?.error}`);
						setTimeout(() => startBot(), 3000);
					}
			}
		} else if (connection === 'open') {
			isConnectionOpened = true;
			stopAnim();
			if (connectionTimer) clearTimeout(connectionTimer);
			console.clear();
			setTimeout(() => {
				sock.insertAllGroup().catch(() => {});
			}, 3000);
			global.mainSock = sock;
			global.conn = sock;
			global.sock = sock;

			const _border = chalk.magenta('─'.repeat(48));
			const _row = (key, val, kColor = chalk.dim, vColor = chalk.whiteBright) =>
				`  ${chalk.magenta('│')}  ${kColor(key.padEnd(14))} ${chalk.magenta('›')} ${vColor(val)}`;

			console.log(`\n  ${chalk.magenta('┌')}${_border}${chalk.magenta('┐')}`);
			console.log(`  ${chalk.magenta('│')}  ${chalk.bold.magentaBright('HIRARA AI')} ${chalk.dim('• SYSTEM ONLINE')}${' '.repeat(21)}${chalk.magenta('│')}`);
			console.log(`  ${chalk.magenta('├')}${_border}${chalk.magenta('┤')}`);

			process.stdout.write(`  ${chalk.magenta('│')}  ${chalk.yellow('•')} ${chalk.dim('Database       ')} ${chalk.dim('loading...')}`);
			await delay(600);
			if (process.stdout.isTTY) { process.stdout.clearLine(0); process.stdout.cursorTo(0); }
			console.log(`  ${chalk.magenta('│')}  ${chalk.green('✔')} ${chalk.dim('Database       ')} ${chalk.greenBright('Ready')}${' '.repeat(23)}${chalk.magenta('│')}`);

			process.stdout.write(`  ${chalk.magenta('│')}  ${chalk.yellow('•')} ${chalk.dim('Plugins        ')} ${chalk.dim('loading...')}`);
			const loaded = await loadPlugins();
			if (process.stdout.isTTY) { process.stdout.clearLine(0); process.stdout.cursorTo(0); }
			console.log(`  ${chalk.magenta('│')}  ${chalk.green('✔')} ${chalk.dim('Plugins        ')} ${chalk.greenBright(loaded.length + ' loaded')}${' '.repeat(20)}${chalk.magenta('│')}`);

			console.log(`  ${chalk.magenta('├')}${_border}${chalk.magenta('┤')}`);

			const botNumber = sock?.user?.id?.split(':')[0] || sock?.user?.jid?.replace('@s.whatsapp.net', '') || 'Unknown';
			const botName   = sock?.user?.name || 'Hirara';
			const now       = new Date().toLocaleString('id-ID', { hour12: false });

			console.log(_row('Bot Name',   botName,                chalk.dim, chalk.whiteBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('Bot Number', botNumber,              chalk.dim, chalk.yellowBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('Developer',  global.namaOwner,       chalk.dim, chalk.whiteBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('Mode',       global.public ? 'Public' : 'Self', chalk.dim, global.public ? chalk.greenBright : chalk.yellowBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('RAM Usage',  formatp(os.totalmem()), chalk.dim, chalk.whiteBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('Uptime',     runtime(os.uptime()),   chalk.dim, chalk.whiteBright).padEnd(59) + chalk.magenta('│'));
			console.log(_row('Time',       now,                    chalk.dim, chalk.cyanBright).padEnd(59) + chalk.magenta('│'));
			console.log(`  ${chalk.magenta('└')}${_border}${chalk.magenta('┘')}\n`);

			startWatcher();
			startGroupScheduler();

			setTimeout(async () => {
				try {
					const restartFile = './tmp/restart.json';
					if (fs.existsSync(restartFile)) {
						const data = JSON.parse(fs.readFileSync(restartFile, 'utf-8'));
						fs.unlinkSync(restartFile);
						const timeTaken = ((Date.now() - (data.time || Date.now())) / 1000).toFixed(2);
						const pageUrl = global.website || 'https://api.kyzzz.xyz';
						const botName = global.namaBot || 'Hirara AI';
						const ownerName = global.namaOwner || 'Mommy kyu';

						const feedbackText = `${pageUrl}\n\n` +
							`🌸 *ʙᴏᴛ sᴜᴅᴀʜ ᴏɴʟɪɴᴇ ʟᴀɢɪ!* 🌸\n\n` +
							`✨ *sᴛᴀᴛᴜs:* sɪᴀᴘ ᴅɪɢᴜɴᴀᴋᴀɴ ᴋᴇᴍʙᴀʟɪ 🎀\n` +
							`⚡ *ᴡᴀᴋᴛᴜ ʀᴇsᴛᴀʀᴛ:* ${timeTaken} ᴅᴇᴛɪᴋ\n` +
							`💖 *sᴇʟᴀᴍᴀᴛ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ ᴀᴋᴛɪᴠɪᴛᴀs ʏᴀᴀ!*`;

						let thumbBuf = null;
						try {
							const { getActiveThumbBuffer } = await import('./lib/thumb.js');
							thumbBuf = await getActiveThumbBuffer();
						} catch (_) {}

						await sock.sendMessage(data.chat, {
							text: feedbackText,
							mentions: data.sender ? [data.sender] : [],
							linkPreview: {
								'matched-text': pageUrl,
								title: `🌸 ${botName} • System Online!`,
								description: `© ${ownerName} • Restart Berhasil (${timeTaken}s)`,
								previewType: 0,
								...(thumbBuf ? { jpegThumbnail: thumbBuf } : {}),
								linkPreviewMetadata: {
									linkMediaDuration: 0,
									socialMediaPostType: 4
								}
							}
						}).catch(() => {});
					}
				} catch (e) {
					console.error('[RESTART NOTIFICATION FAIL]', e);
				}
			}, 3000);

		}
	});

	sock.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			if (chatUpdate.type !== 'notify') return;
			const msg = chatUpdate.messages[0];
			if (!msg.message) return;
            if (msg.key.fromMe && !global.bot) return;
			const m = await ConfigBaileys(sock, msg);
			logger(m).catch(() => {});
			await handler_cmd(sock, m, chatUpdate);
		} catch (err) {
			console.error('Error on message:', err);
		}
	});

	sock.ev.on('messages.upsert', async ({ messages }) => {
		try {
			const m = messages?.[0];
			if (!m || m.messageStubType == null) return;

			await sock.sendMessage(m.key.remoteJid, {
				react: {
					text: '😻',
					key: m.key
				}
			});
		} catch (e) {
			console.error(e);
		}
	});

	sock.decodeJid = (jid) => {
		if (!jid) return jid;
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {};
			return (decode.user && decode.server && decode.user + '@' + decode.server) || jid;
		} else return jid;
	};

	sock.insertAllGroup = async () => {
		const groups = (await sock.groupFetchAllParticipating().catch(() => null)) || {};
		for (const jid in groups) {
			groupCache.set(jid, groups[jid]);
		}
	};

	sock.getJid = (jid) => {
	if (!jid?.endsWith('@lid')) return jid;

	for (const key of groupCache.keys()) {
		const group = groupCache.get(key);

		const user = group?.participants?.find(
			(p) => p.lid === jid || p.id === jid
		);

		if (user) {
			return user.phoneNumber || user.jid || user.id;
		}
	}

	return jid;
};

	sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
		try {
			const quoted = message.msg ? message.msg : message;
			const mime = (message.msg || message).mimetype || '';
			const messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];

			const Randoms = Date.now();
			const fil = Randoms;

			if (!fs.existsSync('./data/trash')) {
				fs.mkdirSync('./data/trash', { recursive: true });
			}

			const stream = await downloadContentFromMessage(quoted, messageType);
			let buffer = Buffer.from([]);

			for await (const chunk of stream) {
				buffer = Buffer.concat([buffer, chunk]);
			}

			const type = (await fileTypeFromBuffer(buffer)) || { ext: 'bin', mime: 'application/octet-stream' };
			const trueFileName = attachExtension ? `./data/trash/${fil}.${type.ext}` : filename || `./data/trash/${fil}.${type.ext}`;

			fs.writeFileSync(trueFileName, buffer);

			return trueFileName;
		} catch (err) {
			console.error('Error saat download media:', err);
			return null;
		}
	};

	sock.downloadM = async (m, type, filename = '') => {
		if (!m || !(m.url || m.directPath)) return Buffer.alloc(0);
		const stream = await downloadContentFromMessage(m, type);
		let buffer = Buffer.from([]);
		for await (const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk]);
		}
		if (filename) await fs.promises.writeFile(filename, buffer);
		return filename && fs.existsSync(filename) ? filename : buffer;
	};

	sock.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		let buffer;
		if (options && (options.packname || options.author)) {
			buffer = await writeExifImg(buff, options);
		} else {
			buffer = await imageToWebp(buff);
		}

		await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	sock.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		let buffer;
		if (options && (options.packname || options.author)) {
			buffer = await writeExifVid(buff, options);
		} else {
			buffer = await videoToWebp(buff);
		}

		await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	sock.getFile = async (PATH, save) => {
		let res;
		let filename;
		let data = Buffer.isBuffer(PATH)
			? PATH
			: /^data:.*?\/.*?;base64,/i.test(PATH)
				? Buffer.from(PATH.split`,`[1], 'base64')
				: /^https?:\/\//.test(PATH)
					? await (res = await getBuffer(PATH))
					: fs.existsSync(PATH)
						? ((filename = PATH), fs.readFileSync(PATH))
						: typeof PATH === 'string'
							? PATH
							: Buffer.alloc(0);

		let type = (await fileTypeFromBuffer(data)) || {
			mime: 'application/octet-stream',
			ext: 'bin',
		};

		filename = path.join(__filename, './data/trash/' + new Date() * 1 + '.' + type.ext);
		if (data && save) fs.promises.writeFile(filename, data);
		return {
			res,
			filename,
			size: await getSizeMedia(data),
			...type,
			data,
		};
	};

	sock.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
		let type = await sock.getFile(path, true);
		let { res, data: file, filename: pathFile } = type;

		if ((res && res.status !== 200) || file.length <= 65536) {
			try {
				throw {
					json: JSON.parse(file.toString()),
				};
			} catch (e) {
				if (e.json) throw e.json;
			}
		}

		let opt = {
			filename,
		};

		if (quoted) opt.quoted = quoted;
		if (!type) options.asDocument = true;

		let mtype = '',
			mimetype = type.mime,
			convert;

		if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
		else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
		else if (/video/.test(type.mime)) mtype = 'video';
		else if (/audio/.test(type.mime)) {
			convert = await (ptt ? toPTT : toAudio)(file, type.ext);
			file = convert.data;
			pathFile = convert.filename;
			mtype = 'audio';
			mimetype = 'audio/ogg; codecs=opus';
		} else mtype = 'document';

		if (options.asDocument) mtype = 'document';

		delete options.asSticker;
		delete options.asLocation;
		delete options.asVideo;
		delete options.asDocument;
		delete options.asImage;

		let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
		let m;

		try {
			m = await sock.sendMessage(jid, message, { ...opt, ...options });
		} catch (e) {
			m = null;
		} finally {
			if (!m) m = await sock.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
			file = null;
			return m;
		}
	};

	sock.getCachedGroupMetadata = async (jid) => {
		let metadata = groupCache.get(jid);

		if (!metadata) {
			metadata = await sock.groupMetadata(jid);
			groupCache.set(jid, metadata);
		}

		return metadata;
	};

	sock.sendContact = async (jid, kon = [], name, desk = 'Developer Bot', quoted = '', opts = {}) => {
		const list = kon.map((i) => ({
			displayName: typeof name !== 'undefined' ? name : 'Unknown',
			vcard:
				'BEGIN:VCARD\n' +
				'VERSION:3.0\n' +
				`N:;${name || 'Unknown'};;;\n` +
				`FN:${name || 'Unknown'}\n` +
				'ORG:Unknown\n' +
				'TITLE:\n' +
				`item1.TEL;waid=${i}:${i}\n` +
				'item1.X-ABLabel:Ponsel\n' +
				`X-WA-BIZ-DESCRIPTION:${desk}\n` +
				`X-WA-BIZ-NAME:${name || 'Unknown'}\n` +
				'END:VCARD',
		}));

		await sock.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted });
	};
}

const runStartupAnimation = async () => {
  const gradient = (await import('gradient-string')).default;
  const animeTheme = gradient(['#f77062', '#fe5196', '#9055ff', '#00c6ff']);

  console.clear();

  const frames = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];
  const steps = [
    { label: 'Loading configurations', color: chalk.cyanBright },
    { label: 'Initializing Database  ', color: chalk.yellowBright },
    { label: 'Preparing Baileys Socket', color: chalk.magentaBright },
    { label: 'Registering Bot Plugins ', color: chalk.greenBright },
  ];

  const art = [
    '   ┌─────────────────────────────────────────────────┐',
    '   │   ██╗  ██╗██╗██████╗  █████╗ ██████╗  █████╗    │',
    '   │   ██║  ██║██║██╔══██╗██╔══██╗██╔══██╗██╔══██╗   │',
    '   │   ███████║██║██████╔╝███████║██████╔╝███████║   │',
    '   │   ██╔══██║██║██╔══██╗██╔══██║██╔══██╗██╔══██║   │',
    '   │   ██║  ██║██║██║  ██║██║  ██║██║  ██║██║  ██║   │',
    '   │   ╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   │',
    '   └─────────────────────────────────────────────────┘',
    `     ${chalk.dim('Version:')} ${chalk.magentaBright('v' + (global.versi || '5.0.0'))}  ${chalk.dim('•')}  ${chalk.dim('Creator:')} ${chalk.whiteBright(global.namaOwner || 'Mommy kyu')}`,
  ];

  for (const line of art) {
    process.stdout.write(animeTheme(line) + '\n');
    await new Promise(r => setTimeout(r, 35));
  }

  console.log('');

  for (const step of steps) {
    let i = 0;
    const interval = setInterval(() => {
      if (process.stdout.isTTY) {
        process.stdout.clearLine(0);
        process.stdout.cursorTo(0);
        process.stdout.write(`   ${chalk.magenta(frames[i++ % frames.length])}  ${chalk.dim(step.label)}...`);
      }
    }, 80);
    await new Promise(r => setTimeout(r, 450));
    clearInterval(interval);
    if (process.stdout.isTTY) { process.stdout.clearLine(0); process.stdout.cursorTo(0); }
    console.log(`   ${chalk.greenBright('✔')}  ${chalk.white(step.label)}`);
  }

  const border = chalk.magenta('─'.repeat(49));
  console.log(`\n   ${border}`);
  console.log(`   ${chalk.bold.magentaBright(global.namaBot || 'HIRARA AI')} ${chalk.dim('—')} ${chalk.white('Next Generation WhatsApp Assistant')}`);
  console.log(`   ${border}\n`);
};

await runStartupAnimation();
startBot();

fs.watchFile(__filename, () => {
	fs.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});
