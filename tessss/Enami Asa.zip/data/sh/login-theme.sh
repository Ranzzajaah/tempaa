#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

cd /var/www/pterodactyl || exit

mkdir -p public/branding

cat << 'EOF_CSS' > public/branding/kyzz_login_theme.css
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

body {
  font-family: 'Plus Jakarta Sans', sans-serif !important;
  background-color: #0b0f19 !important;
  background-image: radial-gradient(circle at 50% 0%, rgba(37, 99, 235, 0.22), transparent 75%) !important;
  color: #f8fafc !important;
}

div[class*="LoginContainer"], div[class*="login"], .bg-neutral-900, .bg-neutral-800 {
  background: rgba(15, 23, 42, 0.88) !important;
  backdrop-filter: blur(20px) !important;
  -webkit-backdrop-filter: blur(20px) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  border-radius: 20px !important;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.6) !important;
  padding: 40px !important;
}

input[type="text"], input[type="password"], input[type="email"] {
  background-color: rgba(10, 15, 26, 0.8) !important;
  border: 1px solid rgba(255, 255, 255, 0.12) !important;
  border-radius: 10px !important;
  color: #ffffff !important;
  transition: all 0.3s ease !important;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
  border-color: #2563eb !important;
  box-shadow: 0 0 15px rgba(37, 99, 235, 0.4) !important;
}

button[type="submit"] {
  background: linear-gradient(135deg, #2563eb, #7c3aed) !important;
  color: #ffffff !important;
  border: none !important;
  border-radius: 10px !important;
  font-weight: 700 !important;
  letter-spacing: 0.5px !important;
  box-shadow: 0 6px 20px rgba(37, 99, 235, 0.4) !important;
  transition: all 0.3s ease !important;
}

button[type="submit"]:hover {
  transform: translateY(-2px) !important;
  box-shadow: 0 10px 25px rgba(37, 99, 235, 0.6) !important;
}

.kyzz-login-header {
  text-align: center;
  margin-bottom: 25px;
}

.kyzz-login-header img {
  width: 95px;
  height: 95px;
  border-radius: 50%;
  margin: 0 auto 12px auto;
  box-shadow: 0 0 25px rgba(37, 99, 235, 0.5);
  border: 2px solid rgba(37, 99, 235, 0.7);
  object-fit: cover;
}

.kyzz-login-header h2 {
  color: #ffffff;
  font-size: 24px;
  font-weight: 800;
  margin: 0;
  letter-spacing: -0.5px;
}

.kyzz-login-header p {
  color: #94a3b8;
  font-size: 13px;
  margin-top: 4px;
  font-weight: 500;
}
EOF_CSS

python3 -c "
with open('resources/views/templates/wrapper.blade.php', 'r') as f:
    c = f.read()

if 'kyzz_login_theme.css' not in c:
    tag = '<link rel=\"stylesheet\" href=\"/branding/kyzz_login_theme.css\">\n<script>document.addEventListener(\"DOMContentLoaded\",function(){var l=document.createElement(\"div\");l.className=\"kyzz-login-header\";l.innerHTML=\"<img src=\\\"/branding/kyzz_logo.jpg\\\" onerror=\\\"this.src=\'https://i.pinimg.com/originals/a0/78/3a/a0783a54b38d38e21975e54c9657053e.jpg\'\\\"><h2>Kyzz APIs</h2><p>Pterodactyl Game Server Panel</p>\";var f=document.querySelector(\"form\");if(f){f.parentNode.insertBefore(l,f);}});</script>\n'
    c = c.replace('</head>', tag + '</head>')
    with open('resources/views/templates/wrapper.blade.php', 'w') as f:
        f.write(c)
" || true

rm -f storage/framework/down || true

php artisan view:clear || true
php artisan config:clear || true
php artisan up || true

systemctl restart nginx || true
systemctl restart php8.3-fpm || systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || true

chown -R www-data:www-data /var/www/pterodactyl/*

exit 0
