#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

cd /var/www/pterodactyl || exit

mkdir -p public/branding

cat << 'EOF_CSS' > public/branding/kyzz_cozy_anime.css
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Press+Start+2P&display=swap');

:root {
  --kyzz-bg-purple: #130f26;
  --kyzz-card-bg: rgba(23, 18, 43, 0.78);
  --kyzz-border: rgba(196, 181, 253, 0.22);
  --kyzz-lavender: #c4b5fd;
  --kyzz-pink: #f472b6;
  --kyzz-cream: #fdf4ff;
  --kyzz-purple-btn: linear-gradient(135deg, #8b5cf6, #7c3aed);
  --kyzz-purple-hover: linear-gradient(135deg, #a78bfa, #8b5cf6);
}

body {
  font-family: 'Plus Jakarta Sans', sans-serif !important;
  background-color: var(--kyzz-bg-purple) !important;
  background-image: linear-gradient(to bottom, rgba(19, 15, 38, 0.55), rgba(19, 15, 38, 0.85)), url('/branding/kyzz_cozy_bg.jpg') !important;
  background-size: cover !important;
  background-position: center !important;
  background-attachment: fixed !important;
  background-repeat: no-repeat !important;
  color: var(--kyzz-cream) !important;
}

div[class*="LoginContainer"], div[class*="login"], .bg-neutral-900, .bg-neutral-800 {
  background: var(--kyzz-card-bg) !important;
  backdrop-filter: blur(24px) !important;
  -webkit-backdrop-filter: blur(24px) !important;
  border: 1px solid var(--kyzz-border) !important;
  border-radius: 24px !important;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), inset 0 0 20px rgba(196, 181, 253, 0.05) !important;
  padding: 42px !important;
}

.kyzz-cozy-header {
  text-align: center;
  margin-bottom: 28px;
}

.kyzz-mascot-wrapper {
  position: relative;
  display: inline-block;
  margin-bottom: 12px;
}

.kyzz-mascot-wrapper img {
  width: 85px;
  height: 85px;
  border-radius: 20px;
  box-shadow: 0 8px 25px rgba(139, 92, 246, 0.35);
  border: 2px solid var(--kyzz-border);
  object-fit: cover;
  image-rendering: pixelated !important;
}

.kyzz-brand-title {
  font-family: 'Press Start 2P', cursive;
  font-size: 14px;
  color: var(--kyzz-lavender);
  letter-spacing: 1px;
  margin-bottom: 8px;
  text-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
}

.kyzz-greeting-title {
  color: #ffffff;
  font-size: 26px;
  font-weight: 800;
  margin: 0;
  letter-spacing: -0.5px;
}

.kyzz-greeting-subtitle {
  color: var(--kyzz-lavender);
  font-size: 13px;
  margin-top: 6px;
  font-weight: 500;
}

input[type="text"], input[type="password"], input[type="email"] {
  background-color: rgba(13, 10, 26, 0.75) !important;
  border: 1px solid var(--kyzz-border) !important;
  border-radius: 12px !important;
  color: #ffffff !important;
  font-size: 14px !important;
  transition: all 0.3s ease !important;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
  border-color: var(--kyzz-lavender) !important;
  box-shadow: 0 0 16px rgba(196, 181, 253, 0.3) !important;
}

button[type="submit"] {
  background: var(--kyzz-purple-btn) !important;
  color: #ffffff !important;
  border: 1px solid rgba(255, 255, 255, 0.2) !important;
  border-radius: 12px !important;
  font-weight: 700 !important;
  letter-spacing: 0.5px !important;
  box-shadow: 0 8px 25px rgba(139, 92, 246, 0.4) !important;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
}

button[type="submit"]:hover {
  background: var(--kyzz-purple-hover) !important;
  transform: translateY(-2px) !important;
  box-shadow: 0 12px 30px rgba(139, 92, 246, 0.6) !important;
}

.kyzz-star-sparkle {
  position: absolute;
  pointer-events: none;
  animation: floatSparkle 3s ease-in-out infinite alternate;
}

@keyframes floatSparkle {
  0% { transform: translateY(0px) rotate(0deg); opacity: 0.7; }
  100% { transform: translateY(-8px) rotate(15deg); opacity: 1; }
}
EOF_CSS

python3 -c "
with open('resources/views/templates/wrapper.blade.php', 'r') as f:
    c = f.read()

if 'kyzz_cozy_anime.css' not in c:
    tag = '''<link rel=\"stylesheet\" href=\"/branding/kyzz_cozy_anime.css\">
<script>
document.addEventListener(\"DOMContentLoaded\", function() {
    var userObj = window.PterodactylUser || null;
    var username = (userObj && (userObj.username || userObj.first_name)) ? (userObj.username || userObj.first_name) : null;
    
    var header = document.createElement(\"div\");
    header.className = \"kyzz-cozy-header\";
    
    var mascotHtml = '<div class=\"kyzz-mascot-wrapper\"><img src=\"/branding/kyzz_mascot.jpg\" onerror=\"this.src=\\'https://i.pinimg.com/originals/a0/78/3a/a0783a54b38d38e21975e54c9657053e.jpg\\'\"><span class=\"kyzz-star-sparkle\" style=\"top:-5px;right:-5px;\">✨</span></div>';
    var brandHtml = '<div class=\"kyzz-brand-title\">Kyzz Themes</div>';
    
    if (username) {
        header.innerHTML = mascotHtml + brandHtml + '<h2 class=\"kyzz-greeting-title\">Welcome, ' + username + '!</h2><p class=\"kyzz-greeting-subtitle\">Nice to see you again.</p>';
    } else {
        header.innerHTML = mascotHtml + brandHtml + '<h2 class=\"kyzz-greeting-title\">Welcome Back!</h2><p class=\"kyzz-greeting-subtitle\">Please sign in to continue to your panel.</p>';
    }
    
    var form = document.querySelector(\"form\");
    if (form) {
        form.parentNode.insertBefore(header, form);
    } else {
        var container = document.querySelector(\"[class*='LoginContainer']\") || document.querySelector(\"body > div\");
        if (container) container.insertBefore(header, container.firstChild);
    }
});
</script>
'''
    c = c.replace('</head>', tag + '</head>')
    with open('resources/views/templates/wrapper.blade.php', 'w') as f:
        f.write(c)
" || true

rm -f storage/framework/down || true

php artisan view:clear || true
php artisan config:clear || true
php artisan up || true

systemctl restart nginx || true
systemctl restart php8.3-fpm || systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || true

chown -R www-data:www-data /var/www/pterodactyl/*

exit 0
