#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

cd /var/www/pterodactyl || exit

mkdir -p public/branding

cat << 'EOF_CSS' > public/branding/kyzz_pink_theme.css
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Press+Start+2P&display=swap');

:root {
  --kyzz-bg-pink: #fff5f8;
  --kyzz-card-bg: rgba(255, 255, 255, 0.88);
  --kyzz-border: rgba(244, 114, 182, 0.3);
  --kyzz-pink-main: #f472b6;
  --kyzz-pink-dark: #db2777;
  --kyzz-lavender: #c4b5fd;
  --kyzz-text-main: #475569;
  --kyzz-text-dark: #1e293b;
  --kyzz-btn-gradient: linear-gradient(135deg, #f472b6, #ec4899);
  --kyzz-btn-hover: linear-gradient(135deg, #f43f5e, #db2777);
}

body {
  font-family: 'Plus Jakarta Sans', sans-serif !important;
  background-color: var(--kyzz-bg-pink) !important;
  background-image: linear-gradient(to bottom, rgba(255, 245, 248, 0.4), rgba(255, 245, 248, 0.75)), url('/branding/kyzz_pink_bg.jpg') !important;
  background-size: cover !important;
  background-position: center !important;
  background-attachment: fixed !important;
  background-repeat: no-repeat !important;
  color: var(--kyzz-text-main) !important;
}

div[class*="LoginContainer"], div[class*="login"], .bg-neutral-900, .bg-neutral-800 {
  background: var(--kyzz-card-bg) !important;
  backdrop-filter: blur(20px) !important;
  -webkit-backdrop-filter: blur(20px) !important;
  border: 2px solid var(--kyzz-border) !important;
  border-radius: 24px !important;
  box-shadow: 0 20px 45px rgba(244, 114, 182, 0.2), inset 0 0 20px rgba(255, 255, 255, 0.9) !important;
  padding: 42px !important;
}

.kyzz-pink-header {
  text-align: center;
  margin-bottom: 28px;
}

.kyzz-mascot-wrapper {
  position: relative;
  display: inline-block;
  margin-bottom: 12px;
}

.kyzz-mascot-wrapper img {
  width: 90px;
  height: 90px;
  border-radius: 22px;
  box-shadow: 0 8px 25px rgba(244, 114, 182, 0.35);
  border: 3px solid #ffffff;
  object-fit: cover;
  image-rendering: pixelated !important;
}

.kyzz-brand-title {
  font-family: 'Press Start 2P', cursive;
  font-size: 14px;
  color: var(--kyzz-pink-dark);
  letter-spacing: 1px;
  margin-bottom: 8px;
}

.kyzz-greeting-title {
  color: var(--kyzz-text-dark);
  font-size: 26px;
  font-weight: 800;
  margin: 0;
  letter-spacing: -0.5px;
}

.kyzz-greeting-subtitle {
  color: #9d4edd;
  font-size: 13px;
  margin-top: 6px;
  font-weight: 600;
}

input[type="text"], input[type="password"], input[type="email"] {
  background-color: rgba(255, 255, 255, 0.9) !important;
  border: 1px solid var(--kyzz-border) !important;
  border-radius: 12px !important;
  color: #1e293b !important;
  font-size: 14px !important;
  transition: all 0.3s ease !important;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
  border-color: var(--kyzz-pink-main) !important;
  box-shadow: 0 0 16px rgba(244, 114, 182, 0.4) !important;
}

button[type="submit"] {
  background: var(--kyzz-btn-gradient) !important;
  color: #ffffff !important;
  border: none !important;
  border-radius: 12px !important;
  font-weight: 700 !important;
  letter-spacing: 0.5px !important;
  box-shadow: 0 8px 25px rgba(244, 114, 182, 0.4) !important;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
}

button[type="submit"]:hover {
  background: var(--kyzz-btn-hover) !important;
  transform: translateY(-2px) !important;
  box-shadow: 0 12px 30px rgba(244, 114, 182, 0.6) !important;
}

.kyzz-sakura-sparkle {
  position: absolute;
  pointer-events: none;
  animation: floatSakura 3s ease-in-out infinite alternate;
}

@keyframes floatSakura {
  0% { transform: translateY(0px) rotate(0deg); opacity: 0.8; }
  100% { transform: translateY(-8px) rotate(20deg); opacity: 1; }
}
EOF_CSS

python3 -c "
with open('resources/views/templates/wrapper.blade.php', 'r') as f:
    c = f.read()

if 'kyzz_pink_theme.css' not in c:
    tag = '''<link rel=\"stylesheet\" href=\"/branding/kyzz_pink_theme.css\">
<script>
document.addEventListener(\"DOMContentLoaded\", function() {
    var userObj = window.PterodactylUser || null;
    var username = (userObj && (userObj.username || userObj.first_name)) ? (userObj.username || userObj.first_name) : null;
    
    var header = document.createElement(\"div\");
    header.className = \"kyzz-pink-header\";
    
    var mascotHtml = '<div class=\"kyzz-mascot-wrapper\"><img src=\"/branding/kyzz_pink_mascot.jpg\" onerror=\"this.src=\\'https://i.pinimg.com/originals/a0/78/3a/a0783a54b38d38e21975e54c9657053e.jpg\\'\"><span class=\"kyzz-sakura-sparkle\" style=\"top:-5px;right:-5px;\">🌸</span></div>';
    var brandHtml = '<div class=\"kyzz-brand-title\">Kyzz Themes</div>';
    
    if (username) {
        header.innerHTML = mascotHtml + brandHtml + '<h2 class=\"kyzz-greeting-title\">Welcome, ' + username + '!</h2><p class=\"kyzz-greeting-subtitle\">Nice to see you again.</p>';
    } else {
        header.innerHTML = mascotHtml + brandHtml + '<h2 class=\"kyzz-greeting-title\">Welcome Back!</h2><p class=\"kyzz-greeting-subtitle\">Please sign in to continue to your panel.</p>';
    }
    
    var form = document.querySelector(\"form\");
    if (form) {
        form.parentNode.insertBefore(header, form);
    } else {
        var container = document.querySelector(\"[class*='LoginContainer']\") || document.querySelector(\"body > div\");
        if (container) container.insertBefore(header, container.firstChild);
    }
});
</script>
'''
    c = c.replace('</head>', tag + '</head>')
    with open('resources/views/templates/wrapper.blade.php', 'w') as f:
        f.write(c)
" || true

rm -f storage/framework/down || true

php artisan view:clear || true
php artisan config:clear || true
php artisan up || true

systemctl restart nginx || true
systemctl restart php8.3-fpm || systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || true

chown -R www-data:www-data /var/www/pterodactyl/*

exit 0
