const htmlPayload = `<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; box-sizing: border-box; }
body { margin: 0; background: #09090b; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #fff; touch-action: none; overflow: hidden; }
.game-container { width: 100%; max-width: 440px; margin: auto; padding: 8px; }
.card-wrapper { background: rgba(255,255,255,0.06); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.18); border-radius: 20px; overflow: hidden; box-shadow: 0 12px 40px rgba(0,0,0,0.5); position: relative; }
.header-bar { padding: 12px 16px; border-bottom: 1px solid rgba(255,255,255,0.12); display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.3); }
.brand-sub { font-size: 9px; letter-spacing: 1.5px; color: rgba(255,255,255,0.55); font-weight: 800; text-transform: uppercase; display: flex; align-items: center; gap: 4px; }
.brand-title { font-size: 18px; font-weight: 900; color: #fff; letter-spacing: -0.5px; display: flex; align-items: center; gap: 6px; }
.score-box { text-align: right; }
.score-val { font-size: 18px; font-weight: 900; color: #ffd166; text-shadow: 0 0 12px rgba(255,209,102,0.6); }
.best-val { font-size: 10px; color: rgba(255,255,255,0.55); font-weight: 700; margin-top: 1px; }

.canvas-wrapper { position: relative; width: 100%; padding: 8px; }
canvas#game { width: 100%; height: auto; border-radius: 14px; display: block; background: #70c5ce; border: 1px solid rgba(255,255,255,0.18); touch-action: none; box-shadow: inset 0 0 20px rgba(0,0,0,0.2); }

.controls-bar { display: flex; gap: 10px; padding: 6px 10px 12px; }
.ctrl-btn { flex: 1; background: linear-gradient(180deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.08) 100%); border: 1px solid rgba(255,255,255,0.25); color: #fff; padding: 14px 0; border-radius: 14px; font-size: 15px; font-weight: 900; text-align: center; cursor: pointer; user-select: none; transition: transform 0.08s, background 0.08s; box-shadow: 0 6px 16px rgba(0,0,0,0.25); display: flex; align-items: center; justify-content: center; gap: 6px; }
.ctrl-btn:active, .ctrl-btn.active { transform: scale(0.95); background: rgba(255,255,255,0.3); }
.ctrl-btn.brake { background: linear-gradient(180deg, rgba(239,68,68,0.4) 0%, rgba(185,28,28,0.6) 100%); border-color: rgba(248,113,113,0.5); }
.ctrl-btn.gas { background: linear-gradient(180deg, rgba(34,197,94,0.4) 0%, rgba(21,128,61,0.6) 100%); border-color: rgba(74,222,128,0.5); }

.overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.9); backdrop-filter: blur(8px); display: flex; flex-direction: column; justify-content: center; align-items: center; gap: 12px; z-index: 10; padding: 16px; text-align: center; border-radius: 20px; }
.overlay.hidden { display: none !important; }
.title-main { font-size: 24px; font-weight: 900; color: #ffd166; letter-spacing: -0.5px; text-shadow: 0 4px 16px rgba(255,209,102,0.5); margin: 0; display: flex; align-items: center; gap: 8px; }
.subtitle-main { font-size: 12px; color: rgba(255,255,255,0.75); font-weight: 600; margin-top: -4px; }
.btn-action { background: linear-gradient(180deg, #ffe066 0%, #ffd166 100%); color: #0f172a; border: none; font-size: 14px; font-weight: 900; padding: 12px 32px; border-radius: 24px; cursor: pointer; box-shadow: 0 6px 22px rgba(255,209,102,0.45); transition: transform 0.1s; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 8px; }
.btn-action:active { transform: scale(0.94); }
.sound-toggle { position: absolute; top: 14px; right: 14px; background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.25); color: #fff; border-radius: 50%; width: 32px; height: 32px; font-size: 14px; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 12; }
</style>

<body>
<div class="game-container">
  <div class="card-wrapper">
    <div class="header-bar">
      <div>
        <div class="brand-sub">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2v20M2 12h20"/></svg>
          HIRARA ARCADE 2D
        </div>
        <div class="brand-title">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="#ffd166"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-4h14v4z"/></svg>
          HILL CLIMB RACING
        </div>
      </div>
      <div class="score-box">
        <div id="score" class="score-val">0000m</div>
        <div id="best" class="best-val">BEST 0000m</div>
      </div>
    </div>

    <div class="canvas-wrapper">
      <canvas id="game" width="380" height="220"></canvas>

      <!-- Start Overlay -->
      <div id="startOverlay" class="overlay">
        <h1 class="title-main">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="#ffd166"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99z"/></svg>
          HILL CLIMB RACING
        </h1>
        <div class="subtitle-main">Rumah, Rintangan, Ramp & Suspensi Mentul!</div>
        <div id="startBest" style="font-size: 13px; color: #ffd166; font-weight: 800;">BEST: 0m</div>
        <button id="btnStart" class="btn-action" type="button">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          START DRIVE
        </button>
      </div>

      <!-- Game Over Overlay -->
      <div id="gameOverOverlay" class="overlay hidden">
        <h1 class="title-main" style="color: #ef4444;">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="#ef4444"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
          CRASHED!
        </h1>
        <div id="finalScore" style="font-size: 20px; font-weight: 900; color: #fff;">DISTANCE: 0m</div>
        <div id="finalBest" style="font-size: 13px; color: #ffd166; font-weight: 800;">BEST: 0m</div>
        <button id="btnRetry" class="btn-action" type="button">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
          RETRY
        </button>
      </div>

      <button id="btnSound" class="sound-toggle" type="button" title="Mute/Unmute">🔊</button>
    </div>

    <!-- Touch Controls -->
    <div class="controls-bar">
      <div id="btnBrake" class="ctrl-btn brake">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
        BRAKE
      </div>
      <div id="btnGas" class="ctrl-btn gas">
        GAS
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
      </div>
    </div>
  </div>
</div>

<script>
(function() {
  const c = document.getElementById('game');
  const ctx = c.getContext('2d');
  const scoreEl = document.getElementById('score');
  const bestEl = document.getElementById('best');
  const startBestEl = document.getElementById('startBest');
  const finalScoreEl = document.getElementById('finalScore');
  const finalBestEl = document.getElementById('finalBest');
  const startOverlay = document.getElementById('startOverlay');
  const gameOverOverlay = document.getElementById('gameOverOverlay');
  const btnStart = document.getElementById('btnStart');
  const btnRetry = document.getElementById('btnRetry');
  const btnBrake = document.getElementById('btnBrake');
  const btnGas = document.getElementById('btnGas');
  const btnSound = document.getElementById('btnSound');

  const WIDTH = c.width;
  const HEIGHT = c.height;

  // Web Audio API
  let audioCtx = null;
  let isMuted = false;

  function initAudio() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) audioCtx = new AudioContextClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playTone(freq, type, duration, startVol = 0.12) {
    if (isMuted) return;
    initAudio();
    if (!audioCtx) return;
    try {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(startVol, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch(e) {}
  }

  btnSound.addEventListener('click', (e) => {
    e.stopPropagation();
    isMuted = !isMuted;
    btnSound.textContent = isMuted ? '🔇' : '🔊';
  });

  // Storage Best Score
  function loadBest() {
    let vals = [];
    try { let v = localStorage.getItem('hcr_best'); if (v) vals.push(parseInt(v, 10)); } catch(e) {}
    try { let v = sessionStorage.getItem('hcr_best'); if (v) vals.push(parseInt(v, 10)); } catch(e) {}
    return vals.length ? Math.max(...vals.filter(v => !isNaN(v))) : 0;
  }

  function saveBest(v) {
    let val = String(Math.floor(v));
    try { localStorage.setItem('hcr_best', val); } catch(e) {}
    try { sessionStorage.setItem('hcr_best', val); } catch(e) {}
  }

  let bestScore = loadBest();
  bestEl.textContent = 'BEST ' + bestScore + 'm';
  startBestEl.textContent = 'BEST: ' + bestScore + 'm';

  // Game Physics & Active Bouncy Suspension State
  let chassis, wheelF, wheelR, fuel, distance, coins, currentCoins, particles = [];
  let suspOffsetF = 0, suspOffsetR = 0; // Dynamic spring bounce offsets!
  let suspVelF = 0, suspVelR = 0;
  let isPlaying = false;
  let isGameOver = false;
  let isGasPressed = false;
  let isBrakePressed = false;
  let animId = null;
  let lastTime = 0;
  let cameraX = 0, cameraY = 0;
  let items = [];

  // Rich Terrain with Houses, Ramps, Bumps & Crates
  function getTerrainHeight(px) {
    if (px < 80) return 160;
    
    // Base Rolling Hills
    let baseH = 160 + Math.sin(px * 0.006) * 30 + Math.sin(px * 0.014) * 12;

    // 1. House Obstacles (Width ~70px, Height ~32px pitched roof)
    const houseIndex = Math.floor(px / 800);
    const houseStart = houseIndex * 800 + 650;
    if (px >= houseStart && px <= houseStart + 70) {
      const progress = (px - houseStart) / 70;
      baseH -= Math.sin(progress * Math.PI) * 32;
    }

    // 2. Stunt Ramps (Width ~45px, Height ~26px)
    const rampIndex = Math.floor(px / 550);
    const rampStart = rampIndex * 550 + 380;
    if (px >= rampStart && px <= rampStart + 45) {
      const progress = (px - rampStart) / 45;
      baseH -= Math.sin(progress * Math.PI) * 26;
    }

    // 3. Stone & Rock Bumps (Width ~24px, Height ~14px)
    const rockIndex = Math.floor(px / 320);
    const rockStart = rockIndex * 320 + 200;
    if (px >= rockStart && px <= rockStart + 24) {
      const progress = (px - rockStart) / 24;
      baseH -= Math.sin(progress * Math.PI) * 14;
    }

    return baseH;
  }

  function getTerrainSlope(px) {
    const dx = 8;
    return Math.atan2(getTerrainHeight(px + dx) - getTerrainHeight(px - dx), dx * 2);
  }

  function populateItems(startX, endX) {
    for (let px = startX; px < endX; px += 130 + Math.random() * 150) {
      if (px < 220) continue;
      const type = Math.random() < 0.2 ? 'fuel' : 'coin';
      items.push({ x: px, y: getTerrainHeight(px) - 20, type, collected: false });
    }
  }

  function initGame() {
    const startH = getTerrainHeight(100);
    chassis = { x: 100, y: startH - 18, vx: 0, vy: 0, angle: 0, vAngle: 0 };
    wheelF = { x: 120, y: startH - 8, rot: 0 };
    wheelR = { x: 80, y: startH - 8, rot: 0 };
    suspOffsetF = 0; suspOffsetR = 0;
    suspVelF = 0; suspVelR = 0;
    fuel = 100;
    distance = 0;
    coins = 0;
    currentCoins = 0;
    particles = [];
    isGasPressed = false;
    isBrakePressed = false;
    isGameOver = false;
    cameraX = 0;
    cameraY = 0;
    items = [];
    populateItems(220, 2500);
  }

  function update(dt) {
    if (!isPlaying || isGameOver) return;

    if (isGasPressed) fuel -= 0.05 * dt;
    else fuel -= 0.008 * dt;
    fuel = Math.max(0, fuel);

    if (fuel <= 0 && Math.abs(chassis.vx) < 0.15) {
      triggerGameOver();
      return;
    }

    chassis.vy += 0.28 * dt;
    chassis.vAngle *= 0.92;

    const enginePower = 0.14;
    if (isGasPressed && fuel > 0) {
      chassis.vx += Math.cos(chassis.angle) * enginePower * dt;
      chassis.vy += Math.sin(chassis.angle) * enginePower * dt;
      chassis.vAngle += 0.004 * dt;
      wheelF.rot += chassis.vx * 0.15;
      wheelR.rot += chassis.vx * 0.15;
    }
    if (isBrakePressed) {
      chassis.vx -= Math.cos(chassis.angle) * (enginePower * 0.5) * dt;
      chassis.vAngle -= 0.006 * dt;
      wheelF.rot += chassis.vx * 0.08;
      wheelR.rot += chassis.vx * 0.08;
    }

    chassis.x += chassis.vx * dt;
    chassis.y += chassis.vy * dt;
    chassis.angle += chassis.vAngle * dt;

    const cosA = Math.cos(chassis.angle);
    const sinA = Math.sin(chassis.angle);

    // Active Bouncy Spring Suspension Physics
    const springK = 0.25;
    const damping = 0.75;

    suspVelF += (-suspOffsetF) * springK * dt;
    suspVelF *= damping;
    suspOffsetF += suspVelF * dt;

    suspVelR += (-suspOffsetR) * springK * dt;
    suspVelR *= damping;
    suspOffsetR += suspVelR * dt;

    // Anchor Wheels to Chassis with Spring Displacement
    wheelF.x = chassis.x + cosA * 20 - sinA * (10 + suspOffsetF);
    wheelF.y = chassis.y + sinA * 20 + cosA * (10 + suspOffsetF);
    wheelR.x = chassis.x - cosA * 20 - sinA * (10 + suspOffsetR);
    wheelR.y = chassis.y - sinA * 20 + cosA * (10 + suspOffsetR);

    const wheelR_radius = 10;

    // Front Wheel Terrain Collision & Spring Compression
    const thF = getTerrainHeight(wheelF.x);
    if (wheelF.y + wheelR_radius > thF) {
      const overlap = (wheelF.y + wheelR_radius) - thF;
      chassis.y -= overlap * 0.6;
      suspOffsetF -= overlap * 0.4;
      suspVelF -= overlap * 0.3;
      chassis.vy *= 0.2;
      chassis.vx *= 0.985;
      chassis.vAngle += (getTerrainSlope(wheelF.x) - chassis.angle) * 0.08 * dt;
    }

    // Rear Wheel Terrain Collision & Spring Compression
    const thR = getTerrainHeight(wheelR.x);
    if (wheelR.y + wheelR_radius > thR) {
      const overlap = (wheelR.y + wheelR_radius) - thR;
      chassis.y -= overlap * 0.6;
      suspOffsetR -= overlap * 0.4;
      suspVelR -= overlap * 0.3;
      chassis.vy *= 0.2;
      chassis.vx *= 0.985;
      chassis.vAngle += (getTerrainSlope(wheelR.x) - chassis.angle) * 0.08 * dt;
    }

    // Clamp Suspension Limits so vehicle stays solid
    suspOffsetF = Math.max(-5, Math.min(5, suspOffsetF));
    suspOffsetR = Math.max(-5, Math.min(5, suspOffsetR));

    // Re-anchor Wheels
    wheelF.x = chassis.x + cosA * 20 - sinA * (10 + suspOffsetF);
    wheelF.y = chassis.y + sinA * 20 + cosA * (10 + suspOffsetF);
    wheelR.x = chassis.x - cosA * 20 - sinA * (10 + suspOffsetR);
    wheelR.y = chassis.y - sinA * 20 + cosA * (10 + suspOffsetR);

    const normalizedAngle = Math.abs(Math.atan2(Math.sin(chassis.angle), Math.cos(chassis.angle)));
    const headY = chassis.y - cosA * 14;
    const headX = chassis.x + sinA * 14;
    if (normalizedAngle > 2.2 && headY > getTerrainHeight(headX) - 2) {
      triggerGameOver();
      return;
    }

    distance = Math.max(distance, (chassis.x - 100) / 10);
    if (distance > bestScore) {
      bestScore = Math.floor(distance);
      saveBest(bestScore);
    }

    scoreEl.textContent = String(Math.floor(distance)).padStart(4, '0') + 'm';
    bestEl.textContent = 'BEST ' + Math.floor(bestScore) + 'm';

    items.forEach(it => {
      if (!it.collected && Math.hypot(chassis.x - it.x, chassis.y - it.y) < 24) {
        it.collected = true;
        if (it.type === 'coin') {
          coins += 5;
          currentCoins += 5;
          playTone(880, 'sine', 0.1, 0.15);
        } else {
          fuel = Math.min(100, fuel + 45);
          playTone(1200, 'triangle', 0.2, 0.15);
        }
      }
    });

    if (chassis.x + 500 > items[items.length - 1]?.x) {
      populateItems(items[items.length - 1].x + 120, items[items.length - 1].x + 1800);
    }
  }

  function triggerGameOver() {
    isGameOver = true;
    playTone(160, 'sawtooth', 0.35, 0.2);
    finalScoreEl.textContent = 'DISTANCE: ' + Math.floor(distance) + 'm';
    finalBestEl.textContent = 'BEST: ' + Math.floor(bestScore) + 'm';
    gameOverOverlay.classList.remove('hidden');
  }

  // Draw Coiling Spring Suspension Graphic
  function drawSpring(x1, y1, x2, y2) {
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    
    const dx = x2 - x1;
    const dy = y2 - y1;
    const steps = 6;
    const nx = -dy * 0.25;
    const ny = dx * 0.25;

    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const side = (i % 2 === 0) ? 1 : -1;
      const px = x1 + dx * t + nx * side;
      const py = y1 + dy * t + ny * side;
      ctx.lineTo(px, py);
    }
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }

  function draw() {
    ctx.clearRect(0, 0, WIDTH, HEIGHT);

    if (!isPlaying) return;

    cameraX += (chassis.x - 120 - cameraX) * 0.1;
    cameraY += (chassis.y - 140 - cameraY) * 0.1;

    const cosA = Math.cos(chassis.angle);
    const sinA = Math.sin(chassis.angle);

    if (isGasPressed && Math.random() < 0.6) {
      particles.push({
        x: chassis.x - cosA * 22 + sinA * 4,
        y: chassis.y - sinA * 22 - cosA * 4,
        vx: -cosA * 2 + (Math.random() - 0.5),
        vy: -sinA * 2 + (Math.random() - 0.5) - 0.4,
        r: 2.5,
        alpha: 0.7
      });
    }

    ctx.save();
    ctx.translate(-cameraX, -cameraY);

    // Sky & Clouds
    ctx.fillStyle = '#70c5ce';
    ctx.fillRect(cameraX, cameraY, WIDTH, HEIGHT);
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    for (let px = cameraX - (cameraX % 200); px < cameraX + WIDTH + 200; px += 150) {
      ctx.beginPath(); ctx.arc(px, 40, 14, 0, Math.PI * 2); ctx.arc(px + 10, 36, 18, 0, Math.PI * 2); ctx.arc(px + 24, 40, 12, 0, Math.PI * 2); ctx.fill();
    }

    // Dirt Earth Base
    ctx.fillStyle = '#5d4037'; ctx.beginPath(); ctx.moveTo(cameraX - 20, cameraY + HEIGHT);
    for (let px = cameraX - 20; px < cameraX + WIDTH + 20; px += 10) ctx.lineTo(px, getTerrainHeight(px));
    ctx.lineTo(cameraX + WIDTH + 20, cameraY + HEIGHT); ctx.fill();

    // Grass Top Layer
    ctx.fillStyle = '#39b54a'; ctx.beginPath(); ctx.moveTo(cameraX - 20, cameraY + HEIGHT);
    for (let px = cameraX - 20; px < cameraX + WIDTH + 20; px += 10) ctx.lineTo(px, getTerrainHeight(px));
    ctx.lineTo(cameraX + WIDTH + 20, getTerrainHeight(cameraX + WIDTH + 20) + 7);
    for (let px = cameraX + WIDTH + 20; px >= cameraX - 20; px -= 10) ctx.lineTo(px, getTerrainHeight(px) + 7);
    ctx.fill();

    // DRAW TERRAIN OBSTACLES (Houses, Stunt Ramps, Stone Rocks, Wooden Crates)
    for (let px = cameraX - 40; px < cameraX + WIDTH + 40; px += 20) {
      // 1. Houses at px % 800 === 650
      const houseIndex = Math.floor(px / 800);
      const houseStart = houseIndex * 800 + 650;
      if (Math.abs(px - houseStart) < 10) {
        const th = getTerrainHeight(houseStart + 35);
        // Red Brick Wall Base
        ctx.fillStyle = '#b91c1c';
        ctx.fillRect(houseStart + 10, th + 8, 50, 24);
        ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 1.5; ctx.strokeRect(houseStart + 10, th + 8, 50, 24);
        // House Window & Door
        ctx.fillStyle = '#fef08a'; ctx.fillRect(houseStart + 18, th + 14, 10, 10);
        ctx.fillStyle = '#78350f'; ctx.fillRect(houseStart + 38, th + 16, 12, 16);
        // Pitched Roof
        ctx.fillStyle = '#7c2d12';
        ctx.beginPath();
        ctx.moveTo(houseStart + 5, th + 8);
        ctx.lineTo(houseStart + 35, th - 16);
        ctx.lineTo(houseStart + 65, th + 8);
        ctx.closePath(); ctx.fill(); ctx.stroke();
      }

      // 2. Wooden Stunt Ramps at px % 550 === 380
      const rampIndex = Math.floor(px / 550);
      const rampStart = rampIndex * 550 + 380;
      if (Math.abs(px - rampStart) < 10) {
        const th = getTerrainHeight(rampStart + 22);
        ctx.fillStyle = '#d97706';
        ctx.beginPath();
        ctx.moveTo(rampStart, th + 14);
        ctx.lineTo(rampStart + 45, th - 12);
        ctx.lineTo(rampStart + 45, th + 14);
        ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#78350f'; ctx.lineWidth = 1.5; ctx.stroke();
        // Yellow Hazard Stripes
        ctx.fillStyle = '#facc15';
        ctx.fillRect(rampStart + 28, th, 12, 3);
      }

      // 3. Stone Boulder Rocks at px % 320 === 200
      const rockIndex = Math.floor(px / 320);
      const rockStart = rockIndex * 320 + 200;
      if (Math.abs(px - rockStart) < 10) {
        const th = getTerrainHeight(rockStart + 12);
        ctx.fillStyle = '#64748b';
        ctx.beginPath();
        ctx.arc(rockStart + 12, th + 4, 10, Math.PI, 0);
        ctx.fill();
        ctx.strokeStyle = '#334155'; ctx.lineWidth = 1.5; ctx.stroke();
      }
    }

    // Collectible Items
    items.forEach(it => {
      if (it.collected) return;
      if (it.x < cameraX - 20 || it.x > cameraX + WIDTH + 20) return;
      ctx.save(); ctx.translate(it.x, it.y);
      if (it.type === 'coin') {
        ctx.fillStyle = '#facc15'; ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#ca8a04'; ctx.lineWidth = 1.5; ctx.stroke();
      } else {
        ctx.fillStyle = '#ef4444'; ctx.fillRect(-5, -8, 10, 14);
      }
      ctx.restore();
    });

    // Exhaust Smoke Render
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.r += 0.15;
      p.alpha -= 0.03;
      if (p.alpha <= 0) { particles.splice(i, 1); continue; }
      ctx.fillStyle = 'rgba(210, 210, 220, ' + p.alpha + ')';
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
    }

    // Draw Active Bouncy Suspension Coiling Springs
    drawSpring(chassis.x - cosA * 18, chassis.y - sinA * 18, wheelR.x, wheelR.y);
    drawSpring(chassis.x + cosA * 18, chassis.y + sinA * 18, wheelF.x, wheelF.y);

    // Offroad Monster Wheels with Treads & Spokes
    const wR = 10;
    [wheelF, wheelR].forEach(w => {
      ctx.save(); ctx.translate(w.x, w.y); ctx.rotate(w.rot);

      ctx.fillStyle = '#0f172a'; ctx.beginPath(); ctx.arc(0, 0, wR, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#1e293b'; ctx.lineWidth = 1.5; ctx.stroke();

      ctx.fillStyle = '#334155';
      for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
        ctx.fillRect(Math.cos(a) * (wR - 1.5) - 1, Math.sin(a) * (wR - 1.5) - 1, 2, 2);
      }

      ctx.fillStyle = '#cbd5e1'; ctx.beginPath(); ctx.arc(0, 0, wR * 0.55, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#475569'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-wR * 0.5, 0); ctx.lineTo(wR * 0.5, 0); ctx.moveTo(0, -wR * 0.5); ctx.lineTo(0, wR * 0.5); ctx.stroke();
      ctx.fillStyle = '#facc15'; ctx.beginPath(); ctx.arc(0, 0, 2, 0, Math.PI * 2); ctx.fill();

      ctx.restore();
    });

    // Detailed 4x4 Offroad Jeep Body
    ctx.save(); ctx.translate(chassis.x, chassis.y); ctx.rotate(chassis.angle);

    // Mounted Spare Tire on Back
    ctx.fillStyle = '#1e293b'; ctx.beginPath(); ctx.arc(-22, -3, 8, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#475569'; ctx.lineWidth = 1; ctx.stroke();

    // Metallic Red Body Shell
    ctx.fillStyle = '#dc2626'; ctx.beginPath(); ctx.roundRect(-20, -9, 40, 13, 3); ctx.fill();
    ctx.strokeStyle = '#7f1d1d'; ctx.lineWidth = 1.2; ctx.stroke();

    // Yellow Racing Stripe
    ctx.fillStyle = '#facc15'; ctx.fillRect(-16, -3, 32, 2.5);

    // Offroad Roll Cage & Tinted Windshield
    ctx.strokeStyle = '#1e293b'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-14, -9); ctx.lineTo(-8, -19); ctx.lineTo(8, -19); ctx.lineTo(14, -9); ctx.stroke();

    ctx.fillStyle = 'rgba(56, 189, 248, 0.5)';
    ctx.beginPath(); ctx.moveTo(-6, -18); ctx.lineTo(6, -18); ctx.lineTo(12, -9); ctx.lineTo(-6, -9); ctx.closePath(); ctx.fill();

    // Driver Bill Newton (Blue Shirt + Red Racing Helmet)
    ctx.fillStyle = '#2563eb'; ctx.fillRect(-3, -15, 7, 6);
    ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(0, -18, 4.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#facc15'; ctx.fillRect(-4.5, -19, 9, 1.5);
    ctx.fillStyle = '#0f172a'; ctx.fillRect(1, -19.5, 3.5, 2.5);

    // Glowing Offroad LED Headlights
    ctx.fillStyle = '#fef08a'; ctx.beginPath(); ctx.arc(20, -3, 3.5, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(254, 240, 138, 0.25)';
    ctx.beginPath(); ctx.moveTo(20, -3); ctx.lineTo(48, -14); ctx.lineTo(48, 8); ctx.closePath(); ctx.fill();

    ctx.restore();
    ctx.restore(); // Restore Camera

    // HUD Fuel Bar
    ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(WIDTH - 90, 6, 82, 16);
    ctx.fillStyle = '#ef4444'; ctx.font = 'bold 9px Arial'; ctx.fillText('⛽', WIDTH - 85, 18);
    ctx.fillStyle = '#22c55e'; ctx.fillRect(WIDTH - 70, 10, Math.max(0, (fuel / 100) * 58), 8);
  }

  function loop(timestamp) {
    if (!isPlaying) return;
    if (!lastTime) lastTime = timestamp;
    const dt = Math.min((timestamp - lastTime) / 16.67, 2.0);
    lastTime = timestamp;

    update(dt);
    draw();

    if (!isGameOver) {
      animId = requestAnimationFrame(loop);
    }
  }

  function bindTouch(element, onPress, onRelease) {
    const start = (e) => {
      e.preventDefault();
      e.stopPropagation();
      onPress();
    };
    const end = (e) => {
      e.preventDefault();
      e.stopPropagation();
      onRelease();
    };
    element.addEventListener('pointerdown', start);
    element.addEventListener('pointerup', end);
    element.addEventListener('pointercancel', end);
    element.addEventListener('touchstart', start, { passive: false });
    element.addEventListener('touchend', end, { passive: false });
  }

  bindTouch(btnBrake, () => { isBrakePressed = true; }, () => { isBrakePressed = false; });
  bindTouch(btnGas, () => { isGasPressed = true; }, () => { isGasPressed = false; });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') isBrakePressed = true;
    if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') isGasPressed = true;
  });
  document.addEventListener('keyup', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') isBrakePressed = false;
    if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') isGasPressed = false;
  });

  btnStart.addEventListener('click', () => {
    initAudio();
    startOverlay.classList.add('hidden');
    isPlaying = true;
    initGame();
    lastTime = 0;
    animId = requestAnimationFrame(loop);
  });

  btnRetry.addEventListener('click', () => {
    initAudio();
    gameOverOverlay.classList.add('hidden');
    isPlaying = true;
    initGame();
    lastTime = 0;
    animId = requestAnimationFrame(loop);
  });

  initGame();
  draw();
})();
</script></body>`;

export default htmlPayload;
