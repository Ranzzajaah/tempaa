/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createCanvas, GlobalFonts } from "@napi-rs/canvas";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync, mkdirSync, writeFileSync } from "node:fs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, "../plugins/info/fonts_ping");

const FONT_SOURCES = [
	{
		url: "https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf",
		file: "Inter.ttf",
		family: "Inter",
	},
	{
		url: "https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf",
		file: "NotoColorEmoji.ttf",
		family: "NotoEmoji",
	},
];

let fontsReady = false;

async function ensureFonts() {
	if (fontsReady) return;
	if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
	const { default: axios } = await import("axios");
	for (const f of FONT_SOURCES) {
		const p = join(FONT_DIR, f.file);
		if (!existsSync(p)) {
			try {
				const { data } = await axios.get(f.url, { responseType: "arraybuffer", timeout: 30000 });
				writeFileSync(p, Buffer.from(data));
			} catch (e) {
				console.error("[font-fetch-error]", e);
			}
		}
		if (existsSync(p)) {
			try { GlobalFonts.registerFromPath(p, f.family); } catch {}
		}
	}
	fontsReady = true;
}

const FONT_FAMILY = "Inter, NotoEmoji, sans-serif";

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawBar(ctx, x, y, w, h, val, max, color1, color2) {
  rrp(ctx, x, y, w, h, h / 2);
  ctx.fillStyle = "rgba(140, 90, 50, 0.12)";
  ctx.fill();
  const fillW = Math.max(h, w * Math.min(1, Math.max(0, val / max)));
  const g = ctx.createLinearGradient(x, 0, x + fillW, 0);
  g.addColorStop(0, color1);
  g.addColorStop(1, color2);
  rrp(ctx, x, y, fillW, h, h / 2);
  ctx.fillStyle = g;
  ctx.fill();
}

export async function createQuizCanvas({
  title = "KUIS INTERAKTIF",
  level = "EASY",
  questionNum = 1,
  totalQuestion = 10,
  points = 10,
  limit = 1,
  exp = 50
} = {}) {
  await ensureFonts();
  const W = 900, H = 500;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext("2d");

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, "#fdfbf7");
  bgGrad.addColorStop(0.5, "#f7f0e6");
  bgGrad.addColorStop(1, "#f1e6d6");
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 800; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const vign = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.75);
  vign.addColorStop(0, "transparent");
  vign.addColorStop(1, "rgba(140, 90, 50, 0.08)");
  ctx.fillStyle = vign;
  ctx.fillRect(0, 0, W, H);

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 14);
  ctx.strokeStyle = "#c9956e";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  rrp(ctx, p + 5, p + 5, W - p * 2 - 10, H - p * 2 - 10, 10);
  ctx.strokeStyle = "rgba(201, 149, 110, 0.35)";
  ctx.lineWidth = 1;
  ctx.stroke();

  const startX = p + 35;
  const startY = p + 40;

  rrp(ctx, startX, startY, 160, 32, 8);
  ctx.fillStyle = "rgba(201, 149, 110, 0.2)";
  ctx.fill();
  ctx.strokeStyle = "#c9956e";
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = "#7a3e20";
  ctx.fillText("⚡ HIRARA ARCADE", startX + 16, startY + 21);

  const levelBadgeColors = {
    EASY: { bg: "rgba(34, 197, 94, 0.15)", border: "#16a34a", text: "#15803d" },
    NORMAL: { bg: "rgba(217, 119, 6, 0.15)", border: "#d97706", text: "#b45309" },
    HARD: { bg: "rgba(220, 38, 38, 0.15)", border: "#dc2626", text: "#991b1b" }
  };
  const curLvl = levelBadgeColors[level.toUpperCase()] || levelBadgeColors.EASY;

  rrp(ctx, startX + 175, startY, 105, 32, 8);
  ctx.fillStyle = curLvl.bg;
  ctx.fill();
  ctx.strokeStyle = curLvl.border;
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = curLvl.text;
  ctx.fillText(level.toUpperCase(), startX + 195, startY + 21);

  ctx.font = `bold 32px ${FONT_FAMILY}`;
  ctx.fillStyle = "#3b1c0c";
  ctx.fillText(title.toUpperCase(), startX, startY + 80);

  ctx.font = `bold 15px ${FONT_FAMILY}`;
  ctx.fillStyle = "#7a3e20";
  ctx.fillText(`Soal: ${questionNum} dari ${totalQuestion}`, startX, startY + 120);

  ctx.font = `14px ${FONT_FAMILY}`;
  ctx.fillStyle = "#8c502b";
  ctx.fillText(`Progress (${Math.round((questionNum / totalQuestion) * 100)}%)`, W - p - 170, startY + 120);

  drawBar(ctx, startX, startY + 135, W - p * 2 - 70, 12, questionNum, totalQuestion, "#c9956e", "#8c502b");

  ctx.strokeStyle = "#e0b596";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(startX, startY + 175);
  ctx.lineTo(W - p - 35, startY + 175);
  ctx.stroke();

  const rewards = [
    { label: "REWARD LIMIT", val: `+${limit} Limit 🎟️`, color: "#1d4ed8" },
    { label: "REWARD EXP", val: `+${exp} EXP ⭐`, color: "#b45309" },
    { label: "SCORE POIN", val: `+${points} Poin 🎯`, color: "#15803d" }
  ];

  const cardW = 230;
  const cardGap = 35;
  rewards.forEach((r, idx) => {
    const rx = startX + idx * (cardW + cardGap);
    const ry = startY + 195;
    const rw = cardW;
    const rh = 95;

    rrp(ctx, rx, ry, rw, rh, 12);
    ctx.fillStyle = "rgba(250, 243, 232, 0.85)";
    ctx.fill();
    ctx.strokeStyle = "#e0b596";
    ctx.lineWidth = 1.2;
    ctx.stroke();

    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillStyle = "#8c502b";
    ctx.fillText(r.label, rx + 18, ry + 32);

    ctx.font = `bold 22px ${FONT_FAMILY}`;
    ctx.fillStyle = r.color;
    ctx.fillText(r.val, rx + 18, ry + 68);
  });

  const bY = H - p - 55;
  rrp(ctx, startX, bY, W - p * 2 - 70, 42, 8);
  ctx.fillStyle = "rgba(250, 243, 232, 0.7)";
  ctx.fill();
  ctx.strokeStyle = "#e0b596";
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `13px ${FONT_FAMILY}`;
  ctx.fillStyle = "#7a3e20";
  ctx.fillText("💬 Reply pesan soal untuk menjawab  ·  ⏱️ 45 Detik  ·  🛑 Tekan Berhenti untuk selesai", startX + 20, bY + 26);

  return canvas.toBuffer("image/jpeg");
}
