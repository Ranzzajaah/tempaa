/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createCanvas, loadImage } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY } from './canvas-font.js';

function drawNeoBox(ctx, x, y, w, h, bg, stroke = '#000000', borderWidth = 4, shadowOffsetX = 5, shadowOffsetY = 5) {
  if (shadowOffsetX > 0 || shadowOffsetY > 0) {
    ctx.fillStyle = '#000000';
    ctx.fillRect(x + shadowOffsetX, y + shadowOffsetY, w, h);
  }
  ctx.fillStyle = bg;
  ctx.fillRect(x, y, w, h);
  if (borderWidth > 0) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = borderWidth;
    ctx.strokeRect(x, y, w, h);
  }
}

export async function generateBankCanvas({
  userName = 'Adventurer',
  userTag = '',
  avatarUrl = null,
  wallet = 0,
  bank = 0,
  actionType = 'info',
  actionAmount = 0
}) {
  await ensureCanvasFonts();
  const W = 860, H = 460;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = '#e2e8f0';
  for (let x = 20; x < W; x += 25) {
    for (let y = 20; y < H; y += 25) {
      ctx.beginPath();
      ctx.arc(x, y, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const p = 16;
  drawNeoBox(ctx, p, p, W - p * 2, H - p * 2, '#ffffff', '#000000', 5, 8, 8);

  const bannerBg = actionType === 'deposit' ? '#a0fe00' : actionType === 'withdraw' ? '#ff79c6' : '#ffea00';
  drawNeoBox(ctx, p + 20, p + 20, 480, 50, bannerBg, '#000000', 4, 5, 5);

  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  const headerTitle = actionType === 'deposit' 
    ? '📥 BANK DEPOSIT SUCCESS' 
    : actionType === 'withdraw' 
      ? '📤 BANK WITHDRAW SUCCESS' 
      : '🏛️ CENTRAL VAULT & BANK';
  ctx.fillText(headerTitle, p + 38, p + 52);

  drawNeoBox(ctx, W - p - 220, p + 20, 200, 50, '#00f0ff', '#000000', 4, 5, 5);
  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText('🛡️ 100% SECURE VAULT', W - p - 205, p + 50);

  const leftX = p + 20, leftY = p + 90, leftW = 270, leftH = 300;
  drawNeoBox(ctx, leftX, leftY, leftW, leftH, '#ffffff', '#000000', 4, 6, 6);

  const avSize = 90, avX = leftX + (leftW - avSize) / 2, avY = leftY + 25;
  drawNeoBox(ctx, avX, avY, avSize, avSize, '#ffffff', '#000000', 3, 4, 4);

  ctx.save();
  ctx.beginPath();
  ctx.rect(avX, avY, avSize, avSize);
  ctx.clip();
  let imgLoaded = false;
  if (avatarUrl) {
    try {
      const img = await loadImage(avatarUrl);
      ctx.drawImage(img, avX, avY, avSize, avSize);
      imgLoaded = true;
    } catch (_) {}
  }
  if (!imgLoaded) {
    ctx.fillStyle = '#89b4fa';
    ctx.fillRect(avX, avY, avSize, avSize);
    ctx.font = `bold 42px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((userName[0] || 'U').toUpperCase(), avX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.font = `bold 18px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.textAlign = 'center';
  const displayName = userName.length > 15 ? userName.slice(0, 13) + '...' : userName;
  ctx.fillText(displayName, leftX + leftW / 2, avY + avSize + 32);

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#64748b';
  ctx.fillText(userTag ? `@${userTag}` : 'VIP ACCOUNT', leftX + leftW / 2, avY + avSize + 54);

  drawNeoBox(ctx, leftX + 25, leftY + leftH - 55, leftW - 50, 34, '#a0fe00', '#000000', 3, 3, 3);
  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText('ACCOUNT: ACTIVE', leftX + leftW / 2, leftY + leftH - 34);
  ctx.textAlign = 'left';

  const rightX = leftX + leftW + 20, rightY = leftY, rightW = W - p * 2 - leftW - 60;

  const bH = 88;
  drawNeoBox(ctx, rightX, rightY, rightW, bH, '#fff3bf', '#000000', 4, 5, 5);
  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#d97706';
  ctx.fillText('👛 WALLET (DOMPET TUNAI)', rightX + 20, rightY + 30);
  ctx.font = `bold 28px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`$${wallet.toLocaleString('id-ID')}`, rightX + 20, rightY + 66);

  const bankY = rightY + bH + 16;
  drawNeoBox(ctx, rightX, bankY, rightW, bH, '#dcfce7', '#000000', 4, 5, 5);
  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#16a34a';
  ctx.fillText('🏦 CENTRAL BANK (TABUNGAN AMAN)', rightX + 20, bankY + 30);
  ctx.font = `bold 28px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`$${bank.toLocaleString('id-ID')}`, rightX + 20, bankY + 66);

  const noticeY = bankY + bH + 16;
  const noticeH = 76;
  if (actionType !== 'info' && actionAmount > 0) {
    const isDepo = actionType === 'deposit';
    drawNeoBox(ctx, rightX, noticeY, rightW, noticeH, isDepo ? '#dbeafe' : '#fce7f3', '#000000', 4, 5, 5);
    ctx.font = `bold 13px ${FONT_FAMILY}`;
    ctx.fillStyle = isDepo ? '#1d4ed8' : '#be185d';
    ctx.fillText(isDepo ? '⚡ RECENT DEPOSIT AMOUNT' : '⚡ RECENT WITHDRAW AMOUNT', rightX + 20, noticeY + 28);
    ctx.font = `bold 22px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.fillText(`${isDepo ? '+' : '-'}$${actionAmount.toLocaleString('id-ID')}`, rightX + 20, noticeY + 58);
  } else {
    drawNeoBox(ctx, rightX, noticeY, rightW, noticeH, '#ffffff', '#000000', 4, 5, 5);
    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillStyle = '#475569';
    ctx.fillText('💡 TIPS KEAMANAN BANK:', rightX + 20, noticeY + 26);
    ctx.font = `bold 13px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.fillText('Uang di Bank 100% kebal dari perampokan (.steal / .rob)', rightX + 20, noticeY + 52);
  }

  return canvas.toBuffer('image/png');
}

export async function generateTransferCanvas({
  senderName = 'Pengirim',
  senderTag = '',
  senderAvatar = null,
  receiverName = 'Penerima',
  receiverTag = '',
  receiverAvatar = null,
  amount = 0,
  senderRemainingWallet = 0
}) {
  await ensureCanvasFonts();
  const W = 880, H = 470;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = '#f1f5f9';
  for (let x = 20; x < W; x += 22) {
    for (let y = 20; y < H; y += 22) {
      ctx.beginPath();
      ctx.arc(x, y, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const p = 16;
  drawNeoBox(ctx, p, p, W - p * 2, H - p * 2, '#ffffff', '#000000', 5, 8, 8);

  drawNeoBox(ctx, p + 20, p + 20, 480, 48, '#a0fe00', '#000000', 4, 5, 5);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText('💸 MONEY TRANSFER RECEIPT', p + 38, p + 52);

  drawNeoBox(ctx, W - p - 220, p + 20, 200, 48, '#ffea00', '#000000', 4, 5, 5);
  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText('✅ TRANSFER SUCCESS', W - p - 200, p + 50);

  const cardY = p + 86;
  const cardW = 330, cardH = 220;

  const sX = p + 20;
  drawNeoBox(ctx, sX, cardY, cardW, cardH, '#eff6ff', '#000000', 4, 6, 6);

  const avSize = 70, avY = cardY + 20, avSX = sX + 20;
  drawNeoBox(ctx, avSX, avY, avSize, avSize, '#ffffff', '#000000', 3, 4, 4);

  ctx.save();
  ctx.beginPath();
  ctx.rect(avSX, avY, avSize, avSize);
  ctx.clip();
  let sImgLoaded = false;
  if (senderAvatar) {
    try {
      const img = await loadImage(senderAvatar);
      ctx.drawImage(img, avSX, avY, avSize, avSize);
      sImgLoaded = true;
    } catch (_) {}
  }
  if (!sImgLoaded) {
    ctx.fillStyle = '#3b82f6';
    ctx.fillRect(avSX, avY, avSize, avSize);
    ctx.font = `bold 32px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((senderName[0] || 'S').toUpperCase(), avSX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#2563eb';
  ctx.fillText('SENDER (PENGIRIM)', sX + 105, avY + 22);

  ctx.font = `bold 17px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  const sDisplay = senderName.length > 13 ? senderName.slice(0, 11) + '...' : senderName;
  ctx.fillText(sDisplay, sX + 105, avY + 48);

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#64748b';
  ctx.fillText(senderTag ? `@${senderTag}` : '', sX + 105, avY + 68);

  drawNeoBox(ctx, sX + 20, cardY + 115, cardW - 40, 78, '#ffffff', '#000000', 3, 3, 3);
  ctx.font = `bold 11px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ef4444';
  ctx.fillText('DITRANSFER (KELUAR):', sX + 32, cardY + 140);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#dc2626';
  ctx.fillText(`-$${amount.toLocaleString('id-ID')}`, sX + 32, cardY + 172);

  const cX = W / 2, cY = cardY + cardH / 2;
  drawNeoBox(ctx, cX - 45, cY - 28, 90, 56, '#ff5ebb', '#000000', 4, 5, 5);
  ctx.font = `bold 26px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.fillText('➔', cX, cY + 9);
  ctx.textAlign = 'left';

  const rX = W - p - 20 - cardW;
  drawNeoBox(ctx, rX, cardY, cardW, cardH, '#f0fdf4', '#000000', 4, 6, 6);

  const avRX = rX + 20;
  drawNeoBox(ctx, avRX, avY, avSize, avSize, '#ffffff', '#000000', 3, 4, 4);

  ctx.save();
  ctx.beginPath();
  ctx.rect(avRX, avY, avSize, avSize);
  ctx.clip();
  let rImgLoaded = false;
  if (receiverAvatar) {
    try {
      const img = await loadImage(receiverAvatar);
      ctx.drawImage(img, avRX, avY, avSize, avSize);
      rImgLoaded = true;
    } catch (_) {}
  }
  if (!rImgLoaded) {
    ctx.fillStyle = '#22c55e';
    ctx.fillRect(avRX, avY, avSize, avSize);
    ctx.font = `bold 32px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((receiverName[0] || 'R').toUpperCase(), avRX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#16a34a';
  ctx.fillText('RECEIVER (PENERIMA)', rX + 105, avY + 22);

  ctx.font = `bold 17px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  const rDisplay = receiverName.length > 13 ? receiverName.slice(0, 11) + '...' : receiverName;
  ctx.fillText(rDisplay, rX + 105, avY + 48);

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#64748b';
  ctx.fillText(receiverTag ? `@${receiverTag}` : '', rX + 105, avY + 68);

  drawNeoBox(ctx, rX + 20, cardY + 115, cardW - 40, 78, '#ffffff', '#000000', 3, 3, 3);
  ctx.font = `bold 11px ${FONT_FAMILY}`;
  ctx.fillStyle = '#15803d';
  ctx.fillText('DITERIMA (MASUK):', rX + 32, cardY + 140);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#16a34a';
  ctx.fillText(`+$${amount.toLocaleString('id-ID')}`, rX + 32, cardY + 172);

  const bY = cardY + cardH + 20;
  const bW = W - p * 2 - 40;
  drawNeoBox(ctx, p + 20, bY, bW, 70, '#ffea00', '#000000', 4, 5, 5);

  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`💰 TOTAL DITRANSFER: $${amount.toLocaleString('id-ID')}`, p + 40, bY + 30);
  ctx.fillText(`👛 SISA DOMPET PENGIRIM: $${senderRemainingWallet.toLocaleString('id-ID')}`, p + 40, bY + 54);

  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#475569';
  ctx.textAlign = 'right';
  ctx.fillText('STATUS: SUCCESS & VERIFIED IN DATABASE', W - p - 40, bY + 42);
  ctx.textAlign = 'left';

  return canvas.toBuffer('image/png');
}
