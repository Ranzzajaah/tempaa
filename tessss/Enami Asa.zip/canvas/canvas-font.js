/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { GlobalFonts, loadImage } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, '../fonts_cache');
export const DEFAULT_AVATAR_PATH = join(process.cwd(), 'src/avatar_contact.png');

const FONT_SOURCES = [
	{
		url: 'https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf',
		file: 'Inter.ttf',
		family: 'Inter',
	},
	{
		url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
		file: 'NotoColorEmoji.ttf',
		family: 'NotoEmoji',
	},
];

let fontsReady = false;

export async function ensureCanvasFonts() {
	if (fontsReady) return;
	if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
	
	try {
		const { default: axios } = await import('axios');
		for (const f of FONT_SOURCES) {
			const p = join(FONT_DIR, f.file);
			if (!existsSync(p)) {
				try {
					const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
					writeFileSync(p, Buffer.from(data));
				} catch (e) {
					console.error('[canvas-font-fetch-error]', f.file, e.message);
				}
			}
			if (existsSync(p)) {
				try { GlobalFonts.registerFromPath(p, f.family); } catch (_) {}
			}
		}
	} catch (err) {
		console.error('[ensureCanvasFonts-error]', err);
	}
	fontsReady = true;
}

export async function loadAvatarImage(ppUrl) {
	if (ppUrl) {
		try {
			return await loadImage(ppUrl);
		} catch (_) {}
	}
	if (existsSync(DEFAULT_AVATAR_PATH)) {
		try {
			return await loadImage(DEFAULT_AVATAR_PATH);
		} catch (_) {}
	}
	return null;
}

export const FONT_FAMILY = 'Inter, NotoEmoji, sans-serif';
