/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

module.exports = {
	apps: [
		{
			name: 'Hirara',
			script: 'index.js',
			cwd: __dirname,
			interpreter: 'node',
			exec_mode: 'fork',
			instances: 1,
			max_memory_restart: '1G',
			autorestart: true,
			watch: false,
			min_uptime: '10s',
			max_restarts: 15,
			restart_delay: 3000,
			kill_timeout: 5000,
			out_file: './logs/hirara-out.log',
			error_file: './logs/hirara-error.log',
			merge_logs: true,
			time: true,
			env: {
				NODE_ENV: 'production'
			}
		}
	]
};
