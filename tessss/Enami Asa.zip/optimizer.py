#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===================================================================
 Hirara AI - System & Memory Optimizer (Pterodactyl Panel Node.js)
 Auto Memory Trimmer, Cache Cleaner, Log Compactor & Temp Sweeper
===================================================================
"""

import os
import sys
import time
import glob
import shutil
import sqlite3
import datetime
import subprocess

# ANSI Colors for Console Output
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RED = "\033[91m"
MAGENTA = "\033[95m"
BOLD = "\033[1m"
RESET = "\033[0m"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def log(msg, level="INFO"):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    color = GREEN if level == "INFO" else (YELLOW if level == "WARN" else (RED if level == "ERROR" else CYAN))
    print(f"{CYAN}[{now}]{RESET} {color}{BOLD}[{level}]{RESET} {msg}", flush=True)

def get_dir_size(path):
    total = 0
    if not os.path.exists(path):
        return 0
    for dirpath, _, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if not os.path.islink(fp) and os.path.exists(fp):
                total += os.path.getsize(fp)
    return total

def format_size(bytes_size):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024.0:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024.0
    return f"{bytes_size:.2f} TB"

def clean_temp_files():
    log("Scanning temporary files in ./tmp...", "CLEAN")
    tmp_dir = os.path.join(BASE_DIR, "tmp")
    deleted_count = 0
    deleted_bytes = 0

    if os.path.exists(tmp_dir):
        now = time.time()
        for filename in os.listdir(tmp_dir):
            file_path = os.path.join(tmp_dir, filename)
            try:
                # Remove temp files older than 10 minutes (600s)
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    if now - os.path.getmtime(file_path) > 600:
                        size = os.path.getsize(file_path)
                        os.remove(file_path)
                        deleted_count += 1
                        deleted_bytes += size
                elif os.path.isdir(file_path):
                    if now - os.path.getmtime(file_path) > 1800:
                        size = get_dir_size(file_path)
                        shutil.rmtree(file_path, ignore_errors=True)
                        deleted_count += 1
                        deleted_bytes += size
            except Exception as e:
                pass
    else:
        os.makedirs(tmp_dir, exist_ok=True)

    log(f"Cleaned {deleted_count} temp files ({format_size(deleted_bytes)} freed)", "INFO")
    return deleted_bytes

def clean_session_garbage():
    log("Optimizing WhatsApp session pre-keys & app state syncs...", "CLEAN")
    session_dirs = [os.path.join(BASE_DIR, "session"), os.path.join(BASE_DIR, "session_jadibot")]
    deleted_count = 0
    deleted_bytes = 0
    now = time.time()

    for s_dir in session_dirs:
        if not os.path.exists(s_dir):
            continue

        # In root session folder
        for root, dirs, files in os.walk(s_dir):
            for file in files:
                # NEVER touch creds.json or active identity keys
                if file == "creds.json" or file.startswith("app-state-sync-key"):
                    continue

                # Clean old pre-keys, sender-keys, and app-state sync files older than 2 hours
                if (file.startswith("pre-key-") or file.startswith("sender-key-") or file.startswith("session-") or file.startswith("app-state-sync-version-")):
                    fp = os.path.join(root, file)
                    try:
                        if now - os.path.getmtime(fp) > 7200: # 2 hours
                            size = os.path.getsize(fp)
                            os.remove(fp)
                            deleted_count += 1
                            deleted_bytes += size
                    except Exception:
                        pass

    log(f"Cleaned {deleted_count} session sync artifacts ({format_size(deleted_bytes)} freed)", "INFO")
    return deleted_bytes

def optimize_sqlite_databases():
    log("Compacting SQLite databases & flushing WAL...", "SQLITE")
    db_files = glob.glob(os.path.join(BASE_DIR, "**/*.db"), recursive=True) + glob.glob(os.path.join(BASE_DIR, "**/*.sqlite"), recursive=True)
    optimized = 0

    for db_path in db_files:
        if "node_modules" in db_path:
            continue
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("PRAGMA wal_checkpoint(TRUNCATE);")
            cursor.execute("PRAGMA incremental_vacuum;")
            conn.commit()
            conn.close()
            optimized += 1
        except Exception as e:
            pass

    log(f"Optimized {optimized} SQLite database files", "INFO")

def truncate_oversized_logs():
    log("Checking application logs size...", "LOGS")
    log_files = glob.glob(os.path.join(BASE_DIR, "**/*.log"), recursive=True)
    truncated = 0
    now = time.time()

    for log_path in log_files:
        if "node_modules" in log_path:
            continue
        try:
            size = os.path.getsize(log_path)
            # Truncate logs larger than 10MB
            if size > 10 * 1024 * 1024:
                with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                    lines = f.readlines()
                # Keep last 5000 lines
                with open(log_path, "w", encoding="utf-8") as f:
                    f.writelines(lines[-5000:])
                truncated += 1
        except Exception:
            pass

    log(f"Checked and formatted {len(log_files)} log files (Truncated: {truncated})", "INFO")

def run_optimization_cycle():
    start_time = time.time()
    print(f"\n{MAGENTA}{BOLD}{'='*60}{RESET}")
    log(f"{BOLD}Starting System & Memory Optimization Cycle (Pterodactyl Node.js)...{RESET}", "OPTIMIZE")
    print(f"{MAGENTA}{BOLD}{'='*60}{RESET}")

    t1 = clean_temp_files()
    t2 = clean_session_garbage()
    optimize_sqlite_databases()
    truncate_oversized_logs()

    elapsed = time.time() - start_time
    total_freed = t1 + t2
    log(f"Optimization finished in {elapsed:.2f}s! Total space freed: {format_size(total_freed)}", "SUCCESS")
    print(f"{MAGENTA}{BOLD}{'='*60}{RESET}\n")

def main():
    # If called with --once, execute one cycle and exit
    if "--once" in sys.argv:
        run_optimization_cycle()
        return

    # Daemon loop for background optimizer
    log("Optimizer Daemon active. Running periodic sweep every 20 minutes...", "DAEMON")
    while True:
        try:
            run_optimization_cycle()
            time.sleep(20 * 60) # 20 minutes interval
        except KeyboardInterrupt:
            log("Optimizer stopped gracefully.", "EXIT")
            break
        except Exception as e:
            log(f"Optimizer loop error: {e}", "ERROR")
            time.sleep(60)

if __name__ == "__main__":
    main()
