/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import moment from 'moment-timezone';
import chalk from 'chalk';
import { getScheduledGroups, setScheduleLast } from '../lib/database.js';

const CHECK_INTERVAL = 60 * 1000; 

const _tick = async () => {
	const sock = global.mainSock;
	if (!sock) return;

	const now = moment().tz('Asia/Jakarta');
	const hhmm = now.format('HH:mm');
	const today = now.format('YYYY-MM-DD');

	let groups = [];
	try {
		groups = await getScheduledGroups();
	} catch (e) {
		console.error(chalk.red('[Scheduler] Gagal ambil data grup:'), e.message);
		return;
	}

	for (const g of groups) {
		if (!g.open_time && !g.close_time) continue;

		if (g.open_time === hhmm) {
			const marker = `${today} ${hhmm} open`;
			if (g.schedule_last === marker) continue;
			try {
				await sock.groupSettingUpdate(g.id, 'not_announcement');
				await sock.sendMessage(g.id, { text: `🔓 *Grup dibuka otomatis* sesuai jadwal (${hhmm} WIB)\nSemua member sekarang bisa kirim pesan.` });
				await setScheduleLast(g.id, marker);
				console.log(chalk.green(`[Scheduler] Grup ${g.id} dibuka otomatis (${hhmm})`));
			} catch (e) {
				console.error(chalk.red(`[Scheduler] Gagal buka grup ${g.id}:`), e.message);
			}
		}

		if (g.close_time === hhmm) {
			const marker = `${today} ${hhmm} close`;
			if (g.schedule_last === marker) continue;
			try {
				await sock.groupSettingUpdate(g.id, 'announcement');
				await sock.sendMessage(g.id, { text: `🔒 *Grup ditutup otomatis* sesuai jadwal (${hhmm} WIB)\nHanya admin yang bisa kirim pesan.` });
				await setScheduleLast(g.id, marker);
				console.log(chalk.green(`[Scheduler] Grup ${g.id} ditutup otomatis (${hhmm})`));
			} catch (e) {
				console.error(chalk.red(`[Scheduler] Gagal tutup grup ${g.id}:`), e.message);
			}
		}
	}

	try {
		const { checkSewaGroup } = await import('../lib/database.js');
		await checkSewaGroup(sock);
	} catch (e) {
		console.error(chalk.red('[Scheduler] Gagal cek status sewa:'), e.message);
	}
};

let _timer = null;

export const startGroupScheduler = () => {
	if (_timer) return _timer;
	console.log(chalk.cyan('[Scheduler] Group auto open/close aktif — cek tiap 1 menit'));
	_timer = setInterval(() => {
		_tick().catch(e => console.error(chalk.red('[Scheduler] Error:'), e.message));
	}, CHECK_INTERVAL);
	return _timer;
};

export const stopGroupScheduler = () => {
	if (_timer) {
		clearInterval(_timer);
		_timer = null;
	}
};
