## jxz base v5.0.0

# INFO 📢
  * Creator: Kyzz
  * Contact: t.me/kyzz 
  * Follow: https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09
  * Recode: Mommy kyu
  * Follow: https://whatsapp.com/channel/0029Vb7gcbuLdQelWzrTzD3D
  * Follow: https://whatsapp.com/channel/0029VbCsmdMC1Fu6NbIaaY2T
  * Bot name: jxz based 
  * Version: 5.0.0
  * Library: Original baileys 
  * Type: plugins 
  * Modules: ECMAScript Module (ESM)

# ⚠️ NOTICE
  * Dilarang menjual ulang atau menyebarkan script ini secara gratis.
  * Ketahuan? Tidak akan ada update lagu lagi.
  
# FEATURES 🤖
  * Support buttons, Carousel, Produc, Catalog, richAi, dll
  * Auto convert @lid > @whatsapp.net
  * Auto reload plugin & auto add cmd baru ke menu 
  * Terdapat beberapa fitur bawaan 
  * No bad sesions 
  * Free dokumentasi penggunaan helper 
  * Tanpa newsletter follow 
  
# PENGGUNAAN 👤
  * User wajib ubah nomor owner di file settings.js > cari global.owner = ["62xx"]
  * Ubah juga di file ./data/owner.json ["62xxx@s.whatsapp.net","62xxx@s.whatsapp.net"]
  * Note, format wajib sama seperti di atas agar tidak eror
  * Jika nomor bukan dari Indonesia tulis saja full format nya tanpa spasi, strip (-), kurung buka (), & tambah (+)
  * Contoh +1 (548) 457-xxxx, maka cara penulisan nya adalah 1548457xxxx
  
# HANDLER PLUGINS 📂
    handler.owner = true //only owners 
    handler.premium = true //harus premium 
    handler.group = true //harus di dalam grup 
    handler.private = true //harus di private chat
    handler.admin = true //yang pake harus admin 
    handler.botadmin = true //bot harus admin 
    handler.noJadiBot = true //agar fitur tidak bisa dipake saat ada yang jadibot (biasanya di taruh di fitur owner)
    
    true = aktif 
    false = nonaktif 

# CONTOH KODE PLUGINS 📂
const handler = async (m, { sock }) => {
   m.reply("contoh!!")
}
handler.command = ["tes"]
handler.owner = true
handler.noJadiBot = true
handler.group = false 

export default handler;

# RUNNING 🖥️
** PANEL PETERODACTYL **
1. masuk ke panel kalian 
2. masuk ke file
3. upload script 
4. pencet ( ⋮ ) titik tiga di sebelah kanan file yang telah di upload 
5. pilih unzip
6. terus masuk ke console > klik start > tuggu sampai di suruh masuk in nomor > masuk in nomor 62xxx enter > tauin ke wa > done!!

** VPS (VIRTUAL PRIVATE SERVER) **
1. siapin vps nya login vps nya di apk termius
2. masuk terus setting dulu vps nya (kalo belum di setting)
    apt update &&  apt install wget && wget https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh && bash install.sh && source ~/.bashrc && nvm install v22 && npm i pm2 -g && pm2 install ffmpeg && apt install git &&  apt install ffmpeg -y &&   apt install webp -y &&  apt install ffmpeg -y &&  apt install imagemagick -y && apt install unzip && apt install zip && apt install neofetch && apt-get install g++ && npm i gyp -g && apt-get install make && apt install python3-pip && apt install speedtest-cli && neofetch
   salin aja kode di atas tempel di vps kalian terus tuggu sampai selesai, kalo udah 
3. pencet tanda ( + ) tanda tambah di atas > pilih SFTP
4. kalo udah pilih ( ⋮ ) titik tiga, kanan atas samping tulisan upload 
5. pilih New Folder > namain folder nya, bebas untuk namanya 
6. masuk ke folder yang udah di buat tadi > upload file script nya > pastikan nama script nya sama nama folder nya ingat yah
7. masuk ke terminal, ketik 
    › cd nama folder yang udah di buat tadi 
    › unzip nama-sc-yang-udah-di-upload.zip
    › npm install
    › npm node index.js (bagian index.js sesuaikan sama SC kalian)
    › tuggu info suruh masuk in nomor > masuk in nomor 62xxx > takutkan ke WhatsApp > balik ke apk termius lagi 
    › pencet Ctrl + c
    › pm2 start index.js --name (bagian index.js sesuaikan sama SC kalian, bagian name itu buat nama bebas apa aja)
    › pm2 save > done script terpasang 

# WARNING/ PERINGATAN ⚠️
  * Dilarang membagikan script secara gratis 
  * Silahkan kembangkan, kalo bisa creator, credits sama contributor jangan di hapus 🙏

# DOCS PENGGUNAAN HELPER BAILEYS 💻

# All type buttons
await sock.sendMessage(m.chat, {
  text: 'Hallo aku kyzz',
  footer: '© kyzz',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'kyzz' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [
          { header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }
        ]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

# All type buttons + bottom sheet
await sock.sendButtons(m.chat, {
  text: 'Hallo aku kyzz',
  footer: '© kyzz',
  messageParams: {
    bottom_sheet: {
      in_thread_buttons_limit: 1,
      list_title: 'bottom_sheet',
      button_title: '© kyzz'
    }
  },
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'kyzz' }
      }
    },
    {
      title: 'DOC',
      sections: [
        {
          title: 'default',
          rows: [
            { title: 'ping', description: 'cek ping', id: 'ping' },
            { title: 'runtime', description: 'cek runtime', id: 'runtime' }
          ]
        }
      ],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [
        {
          title: 'Promotion',
          highlight_label: 'Promo',
          rows: [
            { header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }
          ]
        }
      ],
      icon: 'PROMOTION'
    },
    {
    title: 'DEFAULT',
    sections: [
        {
          title: 'DEFAULT',
          rows: [
            { title: 'ping', description: 'cek ping', id: 'ping' },
            { title: 'menu', description: 'lihat menu', id: 'menu' }
          ]
        }
      ],
    icon: "NONE"
   }
  ]
}, { quoted: m })

# All type buttons + image
await sock.sendMessage(m.chat, {
  image: { url: 'https://url.jpg' },
  text: 'Hallo aku kyzz',
  footer: '© kyzz',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'kyzz' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [{ header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

# All type buttons + video
await sock.sendMessage(m.chat, {
  video: { url: 'https://url.mp4' },
  text: 'Hallo aku kyzz',
  footer: '© kyzz',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'kyzz' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [{ header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

# All type buttons + document
await sock.sendMessage(m.chat, {
  document: { url: 'https://url.jpg' }, // url bebas, jpg/mp4 juga bisa
  mimetype: 'application/pdf',
  filename: 'kyzz.pdf',
  text: 'Hallo aku kyzz',
  footer: '© kyzz',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'kyzz' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [{ header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

# Carousel + buttons
await sock.sendMessage(m.chat, {
  type: 'carousel',
  text: 'Produk Pilihan',
  cards: [
    {
      image: { url: 'https://example.com/img1.jpg' },
      body: 'image 1',
      footer: '© kyzz',
      buttons: [
        { displayText: 'Beli', id: 'beli_a' },
        { displayText: 'Detail', url: 'https://example.com' }
      ]
    },
    {
      image: { url: 'https://example.com/img2.jpg' },
      body: 'image 2',
      footer: '© kyzz',
      buttons: [
        { displayText: 'Beli', id: 'beli_b' },
        { displayText: 'Detail', url: 'https://example.com' }
      ]
    }
  ]
}, { quoted: m })

# Buttons location + image auto resize (via helper)
await sock.sendMessage(m.chat, {
  type: 'location_buttons',
  thumbnail: 'https://url.jpg', // helper auto resize
  text: 'Kyzz:',
  footer: '© kyzz',
  lat: -0,
  lng: 0,
  buttons: [
    { displayText: 'Klik', id: 'ya' },
    { displayText: 'Klik', id: 'yo' }
  ]
}, { quoted: m })

# Buttons location, image + single select
await sock.sendMessage(m.chat, {
  type: 'location_buttons',
  thumbnail: 'https://url.jpg',
  text: 'Example:',
  footer: '© kyzz',
  lat: -0,
  lng: 0,
  buttons: [
    {
      displayText: 'kyzz',
      id: 'menu',
      sections: [{
        title: 'Kyzz Greyat',
        highlight_label: '',
        rows: [
          { 
            header: 'tes 1', 
            title: 'Example 1', 
            description: 'Contoh kode', 
            id: 'kyzz' 
          },
          { 
            header: 'tes 2', 
            title: 'Example 1', 
            description: 'Contoh kode', 
            id: 'kyzz' 
          }
        ]
      }]
    }
  ]
}, { quoted: m })

# Original Produk/catalog message (tanpa buttons)
await sock.sendProduct(m.chat, {
  image: { url: 'https://url.jpg' },
  productId: '26625178293769528',
  title: '© kyzz',
  description: 'woi',
  price: 10000,
  currency: 'IDR',
  retailerId: 'p-001',
  url: 'https://example.com/kaos',
  businessJid: '62xxx@s.whatsapp.net' // wajib diisi
})

# Produk/catalog message + buttons
await sock.sendProduct(m.chat, {
  image: { url: "https://url.jpg" },
  productId: '9116471035103640',
  title: 'Nama Produk',
  description: 'Deskripsi',
  text: 'Teks body',
  footer: '© kyzz',
  price: 10000,
  currency: 'IDR',
  retailerId: '4144242',
  businessJid: '628xxxx@s.whatsapp.net', // wajib diisi
  buttons: [
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

# Poll original 
await sock.sendPoll(m.chat, {
  title: 'Pilih salah satu:',
  options: ['Opsi A', 'Opsi B', 'Opsi C'],
  selectableCount: 1
}, { quoted: m })

# Poll snapshot (hasil poll)
await sock.sendPollSnapshot(m.chat, {
  name: 'Pilih salah satu:',  
  pollVotes: [
    { 
      optionName: 'Opsi A', 
      optionVoteCount: 5 
    },
    { 
      optionName: 'Opsi B', 
      optionVoteCount: 3 
    }
  ]
}, { quoted: m })

# Event message (simple)
await sock.sendEvent(m.chat, {
  name: 'Nama Event',
  startTime: '2026-06-10T09:00:00'
})

# Event message + booking button 
await sock.sendMessage(m.chat, {
  type: 'booking_confirmation',
  title: 'Kyzz',
  text: 'Hello everyone!!',
  footer: '© kyzz',
  start_datetime: '2026-05-27T13:35:41.081Z',
  end_datetime: '2026-05-27T13:45:41.081Z',
  location: 'Indonesia',
  booking_url: 'https://t.me/xstoretelebot',
  phone_number: '62xxx',
  booking_management_url: 'https://t.me/xstoretelebot',
  description: 'kyzz its here',
  email: 'jarexe8@gmail.com',
  display_text: 'Contoh',
  display_content: {
    display_language: 'id',
    display_meeting_type: 'Example codes!'
  }
}, { quoted: m })

# Custom link preview/extendedTextMessage 
await sock.sendLinkPreview(m.chat, {
  text: 'https://github.com\nContohnya', // wajib ada link biar muncul di WA nya
  url: 'https://github.com',
  title: 'Example code',
  description: '© kyzz',
  thumbnail: "https://foto.jpg", 
  thumbnailWidth: 768, //biar 
  thumbnailHeight: 1280 //biar
}, { quoted: m })

# review_and_pay/pesanan
await sock.sendMessage(m.chat, {
  type: 'review_and_pay',
  image: { url: 'https://url.jpg' },
  title: 'Kyzzxz',
  text: 'Example codes',
  footer: '© kyzz',
  paymentParams: {
    currency: 'IDR',
    total_amount: { value: 20000000, offset: 100 },
    reference_id: 'kyzzxxz',
    order_request_id: crypto.randomUUID(),
    type: 'digital-goods',
    order: {
      status: 'shipped',
      subtotal: { value: 20000000, offset: 100 },
      tax: { value: 8, offset: 100 },
      discount: { value: 6400, offset: 100 },
      shipping: { value: 4, offset: 100 },
      order_type: 'ORDER',
      items: [{
        retailer_id: '778739a4-e7b1-4295-9f29-ed3daec92a95',
        name: 'kyzz',
        amount: { value: 900000, offset: 100 },
        quantity: 1
      }]
    },
    additional_note: 'kyzz'
  }
}, { quoted: m })

# AI Rich Text biasa
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Halo! Ini pesan biasa.'
  }
}, { quoted: m })

# AI Rich Text + hyperlink
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Kunjungi [Link](https://t.me/xstoretelebot) untuk info lebih lanjut'
  }
}, { quoted: m })

# AI Rich Text + citation
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Hallo cari panel? klik: [](https://t.me/xstoretelebot)'
  }
}, { quoted: m })

# AI Rich Code block
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Contoh kode:',
    code: ['javascript', `let text = 'Hello im kyzz'\nm.reply(text)`],
    footer: 'p'
  }
}, { quoted: m })

# AI Rich Tabel
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Daftar harga:',
    table: [
      ['Produk', 'Harga', 'Stok'],
      ['Apel',   '5000',  '100'],
      ['Jeruk',  '3000',  '200'],
      ['Mangga', '8000',  '50']
    ]
  }
}, { quoted: m })

# AI Rich Gambar single
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Ini gambarnya:',
    image: 'https://example.com/foto.jpg'
  }
}, { quoted: m })

# AI Rich Gambar multiple
await sock.sendMessage(m.chat, {
  rich: {
    image: [
      'https://example.com/foto1.jpg',
      'https://example.com/foto2.jpg',
      'https://example.com/foto3.jpg'
    ]
  }
}, { quoted: m })

# AI Rich Video
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Ini videonya:',
    video: 'https://example.com/video.mp4|30'
  }
}, { quoted: m })

# AI Rich Source / referensi
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Berikut sumber informasinya:',
    source: [
      ['https://google.com/favicon.ico', 'https://google.com', 'Google'],
      ['https://wikipedia.org/favicon.ico', 'https://wikipedia.org', 'Wikipedia']
    ]
  }
}, { quoted: m })

# AI Rich Reels
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Reels terpopuler:',
    reels: [{
      username: 'user_keren',
      profile_url: 'https://example.com/avatar.jpg',
      thumbnail: 'https://example.com/thumb.jpg',
      url: 'https://example.com/reel.mp4',
      reels_title: 'Judul Reel',
      like: 1200,
      share: 300,
      view: 50000,
      source: 'IG',
      verified: true
    }]
  }
}, { quoted: m })

# AI Rich Product single
await sock.sendMessage(m.chat, {
  rich: {
    product: {
      title: 'kyzz?',
      brand: '© kyzz',
      price: 'Rp 1.200.000',
      sale_price: 'Rp 950.000',
      url: 'https://tokopedia.com',
      image: global.thumbnail,
      icon: 'https://example.com.jpg'
    },
    text: 'The result:'
  }
}, { quoted: m })

# AI Rich Product multiple
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Select:',
    product: [
      {
        title: 'Example 1',
        brand: '© kyzz',
        price: 'Rp 1.200.000',
        sale_price: 'Rp 950.000',
        url: 'https://tokopedia.com',
        image: 'https://example.com.jpg'
      },
      {
        title: 'Example 2',
        brand: '© kyzz',
        price: 'Rp 1.000.000',
        sale_price: 'Rp 800.000',
        url: 'https://tokopedia.com',
        image: 'https://example.com.jpg'
      }
    ]
  }
}, { quoted: m })

# AI Rich Post sosmed
await sock.sendMessage(m.chat, {
  rich: {
    post: [{
      username: 'usr',
      profile_url: 'https://example.com/avatar.jpg',
      thumbnail: 'https://example.com/thumb.jpg',
      caption: 'caption postingan',
      url: 'https://instagram.com/p/xxx',
      like: 500,
      comment: 20,
      share: 10,
      source: 'INSTAGRAM',
      verified: true,
      post_type: 'VIDEO',
      orientation: 'LANDSCAPE'
    }]
  }
}, { quoted: m })

# AI Rich Tips + suggest
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Jawaban di atas berdasarkan data terbaru.',
    tip: '💡 Tip: Gunakan dengan bijak ya!',
    suggest: ['Cari resep', 'Cek cuaca', 'Buat kode']
  }
}, { quoted: m })

# AI Rich Kombinasi lengkap
await sock.sendMessage(m.chat, {
  rich: {
    title: 'Meta AI',
    footer: 'Powered by kyzz',
    text: 'The result:',
    product: [{
      title: 'Example 1',
      brand: '© kyzz',
      price: 'Rp 2.000.000',
      sale_price: 'Rp 1.500.000',
      url: 'https://tokopedia.com',
      image: 'https://example.com.jpg'
    }],
    source: [
      ['https://tokopedia.com/favicon.ico', 'https://tokopedia.com', 'Tokopedia']
    ],
    tip: 'WhatsApp bot',
    suggest: ['kyzz', 'wabot', 'WhatsApp']
  }
}, { quoted: m })

** _Copyright (©) Kyzz 2026_ **
** _All rights reserved_ **

** 🇮🇩 Jangan hapus creator/credit maupun contributor **
** 🇬🇧 Do not delete creator/credit or contributor **

#whatsApp-bot #baileys #wabot #kyzz #readme.md