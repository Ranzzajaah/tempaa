/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, args, usedPrefix, command }) => {
	if (!global.tokengh) {
		return m.reply(`❌ *Token GitHub Belum Diset!*\n\nGunakan *${usedPrefix}setghtoken ghp_xxxx* untuk mengatur token.`);
	}

	if (!args[0]) {
		return m.reply(`❌ *Format Salah!*\n\nContoh: *${usedPrefix}${command} nama-repo-yang-ingin-dihapus*`);
	}

	await global.react(sock, m, 'loading');

	try {
		const headers = {
			'user-agent': 'Mozilla/5.0',
			'Authorization': `token ${global.tokengh}`,
			'Accept': 'application/vnd.github.v3+json'
		};

		const { data: user } = await axios.get('https://api.github.com/user', { headers, timeout: 10000 });
		const repoName = args[0].trim().replace(/^https?:\/\/github\.com\//i, '').replace(/^[^\/]+\//, '').replace(/\/$/, '');
		await axios.delete(`https://api.github.com/repos/${user.login}/${repoName}`, { headers, timeout: 15000 });

		await global.react(sock, m, 'success');
		return m.reply(`🗑️ *REPOSITORI BERHASIL DIHAPUS*\n\nRepositori *${user.login}/${repoName}* telah berhasil dihapus secara permanen dari akun GitHub.`);
	} catch (err) {
		console.error('[GHDELETE ERROR]', err?.response?.data || err?.message || err);
		await global.react(sock, m, 'error');
		const errMsg = err?.response?.data?.message || err?.message || 'Error occurred';
		return m.reply(`❌ Gagal menghapus repositori GitHub!\nReason: ${errMsg}`);
	}
};

handler.command = ['ghdelete', 'ghdel', 'deleterepo'];
handler.limit = true;
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
