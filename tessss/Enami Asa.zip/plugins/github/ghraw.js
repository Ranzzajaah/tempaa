import axios from 'axios';

const handler = async (m, { sock, text, usedPrefix, command }) => {
	if (!text) {
		return m.reply(`❌ *Format Salah!*\n\nContoh: *${usedPrefix}${command} whiskeysockets/baileys/package.json*\natau raw URL GitHub.`);
	}

	let rawUrl = text.trim();
	if (rawUrl.startsWith('https://raw.githubusercontent.com/')) {
	} else if (rawUrl.startsWith('https://github.com/')) {
		rawUrl = rawUrl.replace('github.com', 'raw.githubusercontent.com').replace('/blob/', '/');
	} else {
		const parts = rawUrl.split('/');
		if (parts.length >= 3) {
			const owner = parts[0];
			const repo = parts[1];
			const filePath = parts.slice(2).join('/');
			rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/main/${filePath}`;
		} else {
			return m.reply(`❌ Format tidak valid! Gunakan format *owner/repo/path/file.ext*`);
		}
	}

	await global.react(sock, m, 'loading');

	try {
		const headers = { 'user-agent': 'Mozilla/5.0' };
		const res = await axios.get(rawUrl, { headers, timeout: 10000 });

		let fileContent = typeof res.data === 'object' ? JSON.stringify(res.data, null, 2) : String(res.data);

		if (fileContent.length > 4000) {
			fileContent = fileContent.slice(0, 4000) + '\n\n... (Terpotong karena isi file terlalu panjang)';
		}

		await m.reply(`📄 *RAW FILE GITHUB*\n🔗 ${rawUrl}\n\n\`\`\`\n${fileContent}\n\`\`\``);
		await global.react(sock, m, 'success');
	} catch (err) {
		console.error('[GHRAW ERROR]', err?.message || err);
		await global.react(sock, m, 'error');
		return m.reply(`❌ Gagal mengambil raw file GitHub! Pastikan path file atau URL benar.\nURL: ${rawUrl}`);
	}
};

handler.command = ['ghraw', 'ghfile', 'rawgithub'];
handler.category = 'github';
handler.description = 'Ambil isi kode/file raw langsung dari GitHub';

handler.register = true;

export default handler;
