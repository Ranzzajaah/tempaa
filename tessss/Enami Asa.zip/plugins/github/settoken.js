/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command }) => {
	if (!text) {
		const maskedToken = global.tokengh ? `${global.tokengh.slice(0, 8)}...${global.tokengh.slice(-4)}` : 'Belum diset';
		return m.reply(`🔑 *GITHUB TOKEN SETTING*\n\n• Token Saat Ini: \`${maskedToken}\`\n\nContoh Penggunaan:\n*${usedPrefix}${command} ghp_xxxx...*`);
	}

	const newToken = text.trim();
	global.tokengh = newToken;

	try {
		const settingsPath = path.join(process.cwd(), 'settings.js');
		let content = fs.readFileSync(settingsPath, 'utf-8');

		if (content.includes('global.tokengh')) {
			content = content.replace(/global\.tokengh\s*=\s*['"][^'"]*['"];?/, `global.tokengh = '${newToken}';`);
		} else {
			content += `\nglobal.tokengh = '${newToken}';\n`;
		}

		fs.writeFileSync(settingsPath, content);
		return m.reply(`✅ *TOKEN GITHUB BERHASIL DISIMPAN*\n\nToken baru telah berhasil disimpan ke \`settings.js\` dan siap digunakan.`);
	} catch (e) {
		console.error('[SETGHTOKEN ERROR]', e);
		return m.reply(`✅ Token aktif di memory tetapi gagal menyimpan ke file settings.js.`);
	}
};

handler.command = ['setghtoken'];
handler.limit = true;
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
