import axios from 'axios';

const handler = async (m, { sock, text, usedPrefix, command }) => {
	if (!text) {
		return m.reply(`❌ *Format Salah!*\n\nContoh: *${usedPrefix}${command} torvalds*`);
	}

	const username = text.trim().replace('@', '');
	await global.react(sock, m, 'loading');

	try {
		const headers = { 'user-agent': 'Mozilla/5.0' };
		if (global.tokengh) headers['Authorization'] = `token ${global.tokengh}`;

		const { data: repos } = await axios.get(`https://api.github.com/users/${username}/repos?sort=updated&per_page=10`, { headers, timeout: 10000 });

		if (!repos || repos.length === 0) {
			await global.react(sock, m, 'error');
			return m.reply(`ℹ️ User *@${username}* tidak memiliki repositori publik.`);
		}

		let textMsg = `📦 *REPOSITORI GITHUB: @${username}*\n\n` +
			`Menampilkan 10 repositori terbaru:\n\n`;

		repos.forEach((repo, i) => {
			textMsg += `${i + 1}. *${repo.name}*\n` +
				`   📝 ${repo.description || 'Tidak ada deskripsi'}\n` +
				`   ⭐ ${repo.stargazers_count} Stars | 🔀 ${repo.forks_count} Forks | 💻 ${repo.language || '-'}\n` +
				`   🔗 ${repo.html_url}\n\n`;
		});

		const firstRepo = repos[0];
		const thumb = global.getThumbBuffer ? global.getThumbBuffer() : '';

		await sock.sendButtons(m.chat, {
			location: {
				degreesLatitude: 0,
				degreesLongitude: 0,
				address: `User Repositories • @${username}`,
				jpegThumbnail: thumb ? (typeof thumb === 'string' ? Buffer.from(thumb, 'base64') : thumb) : Buffer.alloc(0),
			},
			text: textMsg,
			footer: `Ketik .ghclone <owner/repo> untuk mendownload ZIP repo`,
			buttons: [
				{ id: `${usedPrefix}ghclone ${firstRepo.full_name}`, text: `📦 Download ${firstRepo.name}` }
			]
		}, { quoted: m });

		await global.react(sock, m, 'success');
	} catch (err) {
		console.error('[GHREPOS ERROR]', err?.message || err);
		await global.react(sock, m, 'error');
		if (err?.response?.status === 404) {
			return m.reply(`❌ Username GitHub *${username}* tidak ditemukan!`);
		}
		return m.reply(`❌ Gagal mengambil daftar repositori: ${err?.message || 'Error occurred'}`);
	}
};

handler.command = ['ghrepos', 'userrepos', 'githubrepos'];
handler.category = 'github';
handler.description = 'Tampilkan daftar repositori publik milik user GitHub';

handler.register = true;

export default handler;
