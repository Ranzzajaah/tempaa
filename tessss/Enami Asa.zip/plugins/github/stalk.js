/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock
	if (!text) {
		return reply(`*GitHub User Stalker*\n\nContoh:\n${usedPrefix}${command} torvalds\n${usedPrefix}${command} octocat`)
	}

	const username = text.trim().replace('@', '')
	reply(global.mess.wait)

	try {
		const headers = { 'user-agent': 'Mozilla/5.0' }
		if (global.tokengh) headers['Authorization'] = `token ${global.tokengh}`

		const { data: user } = await axios.get(`https://api.github.com/users/${username}`, { headers, timeout: 10000 })

		const caption = `👤 *GITHUB USER PROFILE*\n\n` +
			`• *Nama:* ${user.name || '-'}\n` +
			`• *Username:* @${user.login}\n` +
			`• *Bio:* ${user.bio || '-'}\n` +
			`• *Perusahaan:* ${user.company || '-'}\n` +
			`• *Lokasi:* ${user.location || '-'}\n` +
			`• *Public Repos:* ${user.public_repos}\n` +
			`• *Followers:* ${user.followers.toLocaleString('id-ID')}\n` +
			`• *Following:* ${user.following.toLocaleString('id-ID')}\n` +
			`• *Bergabung:* ${new Date(user.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}\n` +
			`• *URL:* ${user.html_url}`

		if (user.avatar_url) {
			return await client.sendMessage(m.chat, {
				image: { url: user.avatar_url },
				caption: caption
			}, { quoted: m })
		} else {
			return reply(caption)
		}
	} catch (e) {
		console.error('[GHSTALK ERROR]', e)
		return reply(`❌ Username GitHub *${username}* tidak ditemukan.`)
	}
}

handler.help = ['ghstalk <username>', 'githubstalk <username>']
handler.tags = ['search', 'github']
handler.command = ['ghstalk', 'githubstalk', 'ghuser']
handler.limit = true;
handler.register = true

handler.noJadiBot = true;

export default handler
