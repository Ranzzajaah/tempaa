/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, text, usedPrefix, command }) => {
	if (!text) {
		return m.reply(`❌ *Format Salah!*\n\nContoh: *${usedPrefix}${command} baileys bot*`);
	}

	await global.react(sock, m, 'loading');

	try {
		const headers = { 'user-agent': 'Mozilla/5.0' };
		if (global.tokengh) headers['Authorization'] = `token ${global.tokengh}`;

		const { data } = await axios.get(`https://api.github.com/search/repositories?q=${encodeURIComponent(text)}&per_page=5`, { headers, timeout: 10000 });

		if (!data || !data.items || data.items.length === 0) {
			await global.react(sock, m, 'error');
			return m.reply(`❌ Repositori GitHub untuk pencarian "*${text}*" tidak ditemukan!`);
		}

		let resultMsg = `🔍 *PENCARIAN REPOSITORI GITHUB*\n\n` +
			`Kata Kunci: *${text}*\n` +
			`Total Hasil: *${data.total_count.toLocaleString('id-ID')}*\n\n`;

		data.items.forEach((item, index) => {
			resultMsg += `${index + 1}. *${item.full_name}*\n` +
				`   📝 Desc: ${item.description || 'Tidak ada deskripsi'}\n` +
				`   ⭐ Stars: ${item.stargazers_count} | 🔀 Forks: ${item.forks_count}\n` +
				`   💻 Bahasa: ${item.language || '-'}\n` +
				`   🔗 ${item.html_url}\n\n`;
		});

		const firstRepo = data.items[0];
		const thumb = global.getThumbBuffer ? global.getThumbBuffer() : '';

		await sock.sendButtons(m.chat, {
			location: {
				degreesLatitude: 0,
				degreesLongitude: 0,
				address: `GitHub Search • ${data.total_count} Repos`,
				jpegThumbnail: thumb ? (typeof thumb === 'string' ? Buffer.from(thumb, 'base64') : thumb) : Buffer.alloc(0),
			},
			text: resultMsg,
			footer: `Ketik .ghclone <owner/repo> untuk mendownload ZIP repo`,
			buttons: [
				{ id: `${usedPrefix}ghclone ${firstRepo.full_name}`, text: `📦 Download ${firstRepo.name}` }
			]
		}, { quoted: m });

		await global.react(sock, m, 'success');
	} catch (err) {
		console.error('[GHSEARCH ERROR]', err?.message || err);
		await global.react(sock, m, 'error');
		return m.reply(`❌ Gagal mencari repositori GitHub: ${err?.message || 'Error occurred'}`);
	}
};

handler.command = ['ghsearch', 'githubsearch', 'searchrepo'];
handler.limit = true;
handler.category = 'github';
handler.description = 'Cari repositori di GitHub berdasarkan kata kunci';

handler.register = true;

handler.noJadiBot = true;

export default handler;
