/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import crypto from 'node:crypto';

const BASE = 'https://notegpt.io';
const UA =
	'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

const sendReact = async (sock, m, emoji) => {
	try {
		await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
	} catch (e) {
		console.error('[DS REACT ERROR]', e.message);
	}
};

function randomNumber(length = 10) {
	let result = '';
	for (let i = 0; i < length; i++) result += Math.floor(Math.random() * 10);
	return result;
}

function makeSboxGuid() {
	const now = Math.floor(Date.now() / 1000);
	const raw = `${now}|762|${randomNumber(9)}`;
	return Buffer.from(raw).toString('base64');
}

function makeCookieHeader() {
	const now = Math.floor(Date.now() / 1000);
	const anonymousUserId = crypto.randomUUID();

	return [
		`_ga_PFX3BRW5RQ=GS2.1.s${now}$o1$g0$t${now}$j60$l0$h${randomNumber(9)}`,
		`_ga=GA1.2.${randomNumber(9)}.${now}`,
		`_gid=GA1.2.${randomNumber(9)}.${now}`,
		`_gat_gtag_UA_252982427_14=1`,
		`sbox-guid=${encodeURIComponent(makeSboxGuid())}`,
		`anonymous_user_id=${anonymousUserId}`,
	].join('; ');
}

function parseSSE(rawBody) {
	let answer = '';
	let reasoning = '';

	for (const line of rawBody.split(/\r?\n/)) {
		const clean = line.trim();
		if (!clean.startsWith('data:')) continue;

		const raw = clean.replace(/^data:\s*/, '').trim();
		if (!raw || raw === '[DONE]') continue;

		try {
			const json = JSON.parse(raw);
			if (json.reasoning) reasoning += json.reasoning;
			if (json.text) answer += json.text;
			if (json.done) break;
		} catch {}
	}

	return { answer, reasoning };
}

async function deepSeekChat(prompt) {
	const conversationId = crypto.randomUUID();
	const cookieHeader = makeCookieHeader();

	const payload = {
		message: prompt,
		language: 'auto',
		model: 'deepseek-v4-flash',
		tone: 'default',
		length: 'moderate',
		conversation_id: conversationId,
		image_urls: [],
		history_messages: [],
		chat_mode: 'deep_think',
	};

	const res = await axios.post(`${BASE}/api/v2/chat/stream`, JSON.stringify(payload), {
		timeout: 60000,
		responseType: 'stream',
		validateStatus: () => true,
		headers: {
			'sec-ch-ua-platform': '"Android"',
			'User-Agent': UA,
			'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
			'Content-Type': 'application/json',
			'sec-ch-ua-mobile': '?1',
			Accept: '*/*',
			Origin: BASE,
			'sec-fetch-site': 'same-origin',
			'sec-fetch-mode': 'cors',
			'sec-fetch-dest': 'empty',
			Referer: `${BASE}/chat-deepseek`,
			'Accept-Encoding': 'gzip, deflate, br, zstd',
			'Accept-Language': 'id-ID,id;q=0.9',
			Cookie: cookieHeader,
			priority: 'u=1, i',
		},
	});

	let rawBody = '';
	res.data.setEncoding('utf8');
	res.data.on('data', (chunk) => { rawBody += chunk; });

	return await new Promise((resolve, reject) => {
		res.data.on('end', () => {
			const parsed = parseSSE(rawBody);
			if (!parsed.answer && !parsed.reasoning) return reject(new Error('Empty response'));
			resolve(parsed);
		});
		res.data.on('error', (e) => reject(e));
	});
}

const handler = async (m, { sock, text, reply }) => {
	if (!text) return reply('Masukkan pertanyaan!\nContoh: .deepseek jelaskan teori relativitas');

	await sendReact(sock, m, '🤔');

	try {
		const result = await deepSeekChat(text);

		await reply(result.answer || result.reasoning);
		await sendReact(sock, m, '✅');
	} catch (e) {
		console.error('[DS ERROR]', e.message);
		await sendReact(sock, m, '❌');

		const isTimeout = e.code === 'ECONNABORTED' || /timeout/i.test(e.message || '');
		await reply(isTimeout ? '⏱️ Server kelamaan respon, coba lagi sebentar ya.' : e.message || 'Terjadi kesalahan');
	}
};

handler.help = ['deepseek <teks>'];
handler.tags = ['ai'];
handler.command = ['deepseek', 'ds'];
handler.limit = true;

handler.premium = true;

handler.register = true;

export default handler;
