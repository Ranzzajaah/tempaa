/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from "axios";
import FormData from "form-data";

let handler = async (m, { conn, sock, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || q.mediaType || "";
	const isImage = /image/.test(mime);

	if (!isImage) {
		return reply(`⚠️ Kirim atau reply gambar dengan command *${usedPrefix + command}* untuk mengonversi gambar.`);
	}

	if (global.mess?.wait) reply(global.mess.wait);

	try {
		let mediaBuffer = null;
		if (typeof q.download === "function") {
			mediaBuffer = await Promise.race([
				q.download(),
				new Promise((_, reject) => setTimeout(() => reject(new Error("Download media timeout (15s)")), 15000))
			]).catch(() => null);
		}

		if (!mediaBuffer && client?.downloadAndSaveMediaMessage) {
			const tmpPath = await client.downloadAndSaveMediaMessage(q).catch(() => null);
			if (tmpPath) {
				const fs = await import("fs");
				mediaBuffer = fs.readFileSync(tmpPath);
				try { fs.unlinkSync(tmpPath); } catch (_) {}
			}
		}

		if (!mediaBuffer) throw new Error("Gagal mengunduh gambar dari WhatsApp.");

		const form = new FormData();
		form.append("media", mediaBuffer, "image.jpg");

		const apiUrl = global.API("kyzz", "/api/ai-image/topixar", {}, "apikey");

		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: "arraybuffer",
			timeout: 90000
		});

		const contentType = res.headers["content-type"] || "";
		let resultBuffer = null;

		if (contentType.includes("application/json")) {
			const jsonStr = Buffer.from(res.data).toString("utf-8");
			const json = JSON.parse(jsonStr);
			if (json.status === false || json.error) {
				throw new Error(json.message || json.error || "Gagal memproses gambar.");
			}
			if (json.url || json.result || json.image) {
				const imgRes = await axios.get(json.url || json.result || json.image, { responseType: "arraybuffer" });
				resultBuffer = Buffer.from(imgRes.data);
			} else {
				throw new Error("Respon API tidak memuat gambar.");
			}
		} else {
			resultBuffer = Buffer.from(res.data);
		}

		const caption = `🎨 *${"TO PIXAR"}*

` +
			`✨ *API:* api.kyzzz.xyz/api/ai-image/topixar`;

		if (typeof client?.sendButtons === "function") {
			await client.sendButtons(m.chat, {
				image: resultBuffer,
				text: caption,
				footer: global.namaBot || "Hirara AI",
				buttons: [
					{
						displayText: "🌐 Kyzz APIs",
						url: global.APIs?.kyzz || "https://api.kyzzz.xyz"
					}
				]
			}, { quoted: m });
		} else {
			await client.sendMessage(m.chat, {
				image: resultBuffer,
				caption: caption
			}, { quoted: m });
		}

		} catch (e) {
		console.error("[TOPIXAR ERROR]", e.message || e);
		let errorMsg = e.message;
		if (e.response?.data) {
			try {
				const parsed = JSON.parse(Buffer.from(e.response.data).toString("utf-8"));
				errorMsg = parsed.message || parsed.error || errorMsg;
			} catch (_) {}
		}
		await reply(`❌ *Gagal mengonversi gambar:*
${errorMsg || "Terjadi kesalahan pada server."}`);
	}
};

handler.help = ["topixar (reply gambar)"];
handler.tags = ["ai"];
handler.command = ["topixar"];
handler.limit = true;
handler.register = true;

export default handler;
