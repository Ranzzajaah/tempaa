/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const AVAILABLE_MODELS = ['namazu', 'sakana', 'namazu-v2', 'namazu-pro', 'llama'];

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(
			`🐟 *SAKANA AI*\n\n` +
			`Kirim pertanyaan kepada Sakana AI!\n\n` +
			`📌 *Format:*\n` +
			`*${usedPrefix + command} <pertanyaan>*\n` +
			`*${usedPrefix + command} --model=sakana --thinking=true <pertanyaan>*\n\n` +
			`⚙️ *Daftar Model:*\n` +
			AVAILABLE_MODELS.map(m => ` • ${m}`).join('\n') +
			`\n\n💡 *Opsi Thinking:* \`--thinking=true\` atau \`--thinking=false\` (default: false)`
		);
	}

	let question = text;
	let model = 'namazu';
	let thinking = 0;

	const modelMatch = question.match(/--model=([a-zA-Z0-9_-]+)/i);
	if (modelMatch) {
		const reqModel = modelMatch[1].toLowerCase();
		if (AVAILABLE_MODELS.includes(reqModel)) {
			model = reqModel;
		}
		question = question.replace(modelMatch[0], '').trim();
	}

	const thinkMatch = question.match(/--thinking=(true|false|1|0)/i);
	if (thinkMatch) {
		thinking = (thinkMatch[1] === 'true' || thinkMatch[1] === '1') ? 1 : 0;
		question = question.replace(thinkMatch[0], '').trim();
	} else if (/\s*-t\b/i.test(question)) {
		thinking = 1;
		question = question.replace(/\s*-t\b/i, '').trim();
	}

	if (!question) {
		return reply(`⚠️ Masukkan pertanyaan yang ingin diajukan ke Sakana AI!`);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/ai/sakana-ai', {
			question: question.trim(),
			model: model,
			thinking: thinking
		}, 'apikey');

		const { data: res } = await axios.get(apiUrl, { timeout: 60000 });

		if (!res || !res.status) {
			await global.react(client, m, 'error');
			return reply(`❌ Gagal mendapatkan respon dari Sakana AI: ${res?.message || 'Tidak ada respon.'}`);
		}

		const answer = typeof res.result === 'string' ? res.result : (res.result?.text || res.result?.answer || JSON.stringify(res.result));

		let replyText = `🐟 *SAKANA AI (${model.toUpperCase()})*\n\n`;
		replyText += `${answer}\n\n`;
		replyText += `⚙️ _Model: ${model} | Thinking: ${thinking === 1 ? 'Aktif' : 'Nonaktif'}_\n`;
		replyText += `© ${global.namaBot || 'Hirara AI'}`;

		await reply(replyText.trim());
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[SAKANA AI ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan saat memproses Sakana AI: ${e.response?.data?.message || e.message}`);
	}
};

handler.help = ['sakana <pertanyaan>', 'sakanaai <pertanyaan>'];
handler.tags = ['ai'];
handler.command = ['sakana', 'sakanaai'];
handler.limit = true;
handler.register = true;

export default handler;
