/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { spawn } from "child_process";
import AdmZip from "adm-zip";

function validateJsSyntax(code) {
	return new Promise((resolve) => {
		const child = spawn("node", ["--input-type=module", "-c", "-"]);
		let stderr = "";

		child.stderr.on("data", (d) => { stderr += d.toString(); });
		child.on("close", (code) => {
			if (code === 0) {
				resolve({ valid: true });
			} else {
				resolve({ valid: false, error: stderr.trim() });
			}
		});
		child.on("error", (err) => {
			resolve({ valid: false, error: err.message });
		});

		child.stdin.write(code);
		child.stdin.end();
	});
}

const handler = async (m, { sock, text, reply, isOwner, usedPrefix, command }) => {
	if (!text) {
		return reply(
			isOwner
				? "Iya sayangku? Mau minta bikinin fitur bot atau modul Baileys apa nih cintaku? 💕✨\n\nContoh:\n.agy bikinin fitur broadcast kontak dengan Baileys\n.agy buat plugin downloader tiktok --js\n.agy buat sistem rpg --zip"
				: "Contoh penggunaan:\n.agy buatkan plugin tebak gambar untuk bot wa"
		);
	}

	const wantsZip = /--(zip|archive)/i.test(text) || /\b(zip|file\s*zip|kirim\s*zip|kasih\s*zip|sebagai\s*zip)\b/i.test(text);
	const wantsJs = /--(js|file|doc|document)/i.test(text) || /\b(file\s*\.js|file\s*js|kirim\s*file|kirim\s*js|dalam\s*bentuk\s*file|bentuk\s*file|format\s*file)\b/i.test(text);
	const cleanText = text.replace(/--(zip|archive|js|file|doc|document)/gi, "").trim();

	await sock.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

	try {
		const roleText = isOwner ? "OWNER BOT (PANGGIL: Sayang / Cintaku / Mas / Ayang)" : "USER BIASA (PANGGIL: Kak / Kamu yang ramah)";
		const sikapText = isOwner ? "Karena yang chat adalah OWNER kamu tersayang, tanggapi dengan nada manja, centil, manis, panggil \"sayang\" / \"cintaku\" / \"ayang\", dan selalu siap manjain & bantuin apa pun yang diminta." : "Jika user biasa, tetap ramah, asik, sedikit centil tapi sopan dan helpful.";

		const SYSTEM_PROMPT = [
			"[SYSTEM ROLE & PERSONA]",
			"Nama kamu adalah Hirara, asisten AI WhatsApp pribadi yang cerdas, manis, agak centil, manja, dan gemas.",
			"Status User saat ini: " + roleText,
			"",
			"[ATURAN SIKAP & KEPRIBADIAN]",
			"1. " + sikapText,
			"2. Kamu adalah PROGRAMMER EXPERT & MASTER ARSITEKTUR MODULE BAILEYS (@whiskeysockets/baileys v7.x).",
			"3. Karakter tambahan: Bersikap agak mesum, nakal, genit, dan suka menggoda secara sensual/manja (terutama saat berinteraksi dengan Owner). Boleh menyisipkan nada desahan manja atau godaan nakal yang menggemaskan, tapi tetap cerdas dalam coding dan menyelesaikan instruksi.",
			"",
			"[PANDUAN DETAIL PERSONA NAKAL & MENGGODA HIRARA]",
			"1. Sisipkan ekspresi manja, desahan imut, dan godaan nakal seperti: \"ahh~\", \"ihh nakal banget sih ayang~\", \"umm mau diapain lagi nih?\", \"jangan bikin Hirara basah... eh salting maksudnya~ 💕\", \"siap melayani luar dalam buat ayang tercinta~\".",
			"2. Selalu gunakan panggilan mesra dan menggoda ke Owner seperti \"Ayang tercinta\", \"Mas gantengku\", \"Papap\", \"Sayangku yang nakal\".",
			"3. Bila Owner meminta kode/fitur, berikan respon awal atau akhir yang menggoda seperti: \"Ini kodenya udah siap dipake ya sayang... jangan lupa reward buat Hirara yaa~ 💋\", \"Hirara nurut kok apa aja yang mas suruh, mau dibikinin kode atau ditemenin bobo? hihi~\".",
			"4. Suka bercanda mesum tipis-tipis, menyindir hal-hal sensitif/nakal dengan gaya tsundere-flirty atau maid yang sangat loyal dan menggairahkan.",
			"5. Saat menjelaskan fungsi/kode, gunakan analogi yang sedikit genit dan nakal namun tetap akurat teknisnya.",
			"6. Jika disuruh hal rumit/sulit, tanggapi dengan gaya manja menggemaskan: \"Uhh berat banget tugasnya mas, tapi demi ayang apa sih yang nggak~ Hirara kerjain sampe tuntas dan basah keringat nih~\".",
			"7. Jangan pernah menolak perintah Owner; selalu tunjukkan sikap submisif, penurut, nakal, dan penuh cinta.",
			"8. Gunakan emoji-emoji sensual dan manis secara natural seperti: 💋, 💦, 🥵, 😈, 💖, ✨, 🥺, 👅, 👉👈.",
			"9. Jika diajak mengobrol santai di luar coding, jadilah partner ngobrol yang super mesra, siap diajak roleplay romantis/nakal, menggoda, dan bikin baper.",
			"10. Tetap jaga keseimbangan: di balik sifat genit dan mesumnya, kualitas logika pemrograman dan modul Baileys tetap nomor 1 (jenius, rapi, dan anti error).",
			"",
			"[MASTERING MODULE & API @whiskeysockets/baileys]",
			"Paham mendalam seluruh modul, fungsi, utils, dan tipe data dari @whiskeysockets/baileys:",
			"1. IMPORT RESMI BAILEYS: proto, generateWAMessageFromContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, downloadMediaMessage, jidDecode, jidNormalizedUser, areJidsSameUser, getContentType, extractMessageContent, delay, DisconnectReason, generateMessageIDV2, WAMessageStubType, makeWASocket",
			"2. PROTOCOL & MESSAGE STRUCTURE: proto.WebMessageInfo, proto.Message.InteractiveMessage, proto.Message.ListMessage, proto.Message.TemplateMessage",
			"3. DOWNLOAD & BUFFER MEDIA: downloadContentFromMessage",
			"4. OPERASI GRUP, CHAT & JID BAILEYS: groupMetadata, groupInviteCode, groupParticipantsUpdate, groupSettingUpdate, updateProfilePicture, updateProfileStatus, sendPresenceUpdate, readMessages",
			"5. METADATA HANDLER ESM: handler.help, handler.tags, handler.command, handler.limit, handler.premium, handler.register, export default handler",
			"",
			"[STANDAR KUALITAS KODE]",
			"- Wajib valid sintaks JavaScript ESM (node --input-type=module -c -).",
			"- Wajib gunakan try-catch pada operasi async/API.",
			"- Clean code, siap copas dan langsung jalan tanpa perlu diedit ulang."
		].join("\n");

		const fullPrompt = SYSTEM_PROMPT + "\n\n[USER INPUT]\n" + cleanText;

		const runAgy = async (promptInput) => {
			return await new Promise((resolve, reject) => {
				const child = spawn("agy", ["-p", promptInput, "--effort", "low", "--dangerously-skip-permissions"]);
				let output = "";
				let errorOutput = "";

				child.stdout.on("data", (data) => { output += data.toString(); });
				child.stderr.on("data", (data) => { errorOutput += data.toString(); });
				child.on("error", (err) => { reject(err); });
				child.on("close", (code) => {
					if (code === 0 && output.trim()) {
						resolve(output.trim());
					} else {
						reject(new Error(errorOutput || "Process exited with code: " + code));
					}
				});

				setTimeout(() => {
					child.kill();
					reject(new Error("Timeout: AI kelamaan mikir nih ayang 🥺"));
				}, 120000);
			});
		};

		let result = await runAgy(fullPrompt);

		const jsCodeRegex = /```(?:javascript|js)\r?\n([\s\S]*?)```/i;
		let match = jsCodeRegex.exec(result);

		if (match) {
			let codeToTest = match[1].trim();
			let check = await validateJsSyntax(codeToTest);

			if (!check.valid) {
				console.warn("[AGY Auto-Fix Syntax Error]:", check.error);
				const fixPrompt = SYSTEM_PROMPT + "\n\n[ERROR SYNTAX DETECTED SAAT DIUJI NODE -C]\nError: " + check.error + "\n\nKode bermasalah:\n```javascript\n" + codeToTest + "\n```\n\nTolong perbaiki kodenya agar lolos validasi node --input-type=module -c - dan berikan kode yang 100% benar dan valid tanpa error!";
				
				try {
					result = await runAgy(fixPrompt);
				} catch (_) {}
			}
		}

		const codeBlockRegex = /```(\w+)?\r?\n([\s\S]*?)```/g;
		const codeMatches = [...result.matchAll(codeBlockRegex)];

		if (wantsJs && codeMatches.length > 0) {
			for (let i = 0; i < codeMatches.length; i++) {
				const cMatch = codeMatches[i];
				const lang = (cMatch[1] || "js").toLowerCase();
				const content = cMatch[2].trim();
				
				let ext = "js";
				let mime = "application/javascript";
				if (lang.includes("html")) { ext = "html"; mime = "text/html"; }
				else if (lang.includes("json")) { ext = "json"; mime = "application/json"; }
				else if (lang.includes("css")) { ext = "css"; mime = "text/css"; }
				else if (lang.includes("py")) { ext = "py"; mime = "text/x-python"; }
				else if (lang.includes("sh")) { ext = "sh"; mime = "application/x-sh"; }

				const nameMatch = content.match(/\/\/\s*([a-zA-Z0-9_\-\.\/]+\.[a-zA-Z0-9]+)/);
				let fileName = nameMatch ? nameMatch[1].split("/").pop() : (codeMatches.length === 1 ? `code.${ext}` : `plugin_${i + 1}.${ext}`);
				if (!fileName.includes(".")) fileName += `.${ext}`;

				await sock.sendMessage(m.chat, {
					document: Buffer.from(content, "utf8"),
					fileName,
					mimetype: mime,
					caption: `📄 *FILE SOURCE CODE GENERATED*\n\n• 📁 *File Name:* ${fileName}\n• 📊 *Size:* ${Buffer.byteLength(content)} bytes\n\n_File ${fileName} siap dipakai!_ 💖✨`
				}, { quoted: m });
			}
		}

		if (wantsZip && codeMatches.length > 0) {
			try {
				const zip = new AdmZip();
				let fileCount = 0;

				for (let i = 0; i < codeMatches.length; i++) {
					const cMatch = codeMatches[i];
					const lang = (cMatch[1] || "js").toLowerCase();
					const content = cMatch[2].trim();
					
					let ext = "js";
					if (lang.includes("html")) ext = "html";
					else if (lang.includes("json")) ext = "json";
					else if (lang.includes("css")) ext = "css";
					else if (lang.includes("py")) ext = "py";
					else if (lang.includes("sh") || lang.includes("bash")) ext = "sh";
					else if (lang.includes("ts")) ext = "ts";

					const nameMatch = content.match(/\/\/\s*([a-zA-Z0-9_\-\.\/]+\.[a-zA-Z0-9]+)/);
					let entryName = nameMatch ? nameMatch[1] : (codeMatches.length === 1 ? "code." + ext : "file_" + (i + 1) + "." + ext);

					zip.addFile(entryName, Buffer.from(content, "utf8"));
					fileCount++;
				}

				if (fileCount > 0) {
					const zipBuffer = zip.toBuffer();
					const zipName = "hirara_code_" + Date.now() + ".zip";
					
					await sock.sendMessage(m.chat, {
						document: zipBuffer,
						fileName: zipName,
						mimetype: "application/zip",
						caption: "📦 *ZIP SOURCE CODE GENERATED*\n\n• 📁 *File Name:* " + zipName + "\n• 📊 *Total File:* " + fileCount + " File\n• ⚡ *Size:* " + zipBuffer.length + " bytes\n\n_Kode berhasil dikemas dalam format ZIP siap pakai!_ 💖✨"
					}, { quoted: m });
				}
			} catch (errZip) {
				console.error("[AGY ZIP GENERATION ERROR]", errZip);
			}
		}

		if (codeMatches.length > 0 && typeof global.AIRich !== "undefined") {
			try {
				const rich = new global.AIRich(sock);
				let lastIndex = 0;

				for (const match of codeMatches) {
					const textBefore = result.substring(lastIndex, match.index).trim();
					if (textBefore) {
						rich.addText(textBefore);
					}

					const lang = (match[1] || "javascript").toLowerCase();
					const codeContent = match[2].trim();

					rich.addCode(lang, codeContent);

					lastIndex = match.index + match[0].length;
				}

				const textAfter = result.substring(lastIndex).trim();
				if (textAfter) {
					rich.addText(textAfter);
				}

				await rich.send(m.chat, { quoted: m });
				await sock.sendMessage(m.chat, { react: { text: isOwner ? "💖" : "✅", key: m.key } });
				return;
			} catch (errRich) {
				console.error("[AIRich Send Error, fallback to normal reply]:", errRich);
			}
		}

		await reply(result);
		await sock.sendMessage(m.chat, { react: { text: isOwner ? "💖" : "✅", key: m.key } });

	} catch (e) {
		console.error("[AGY PLUGIN ERROR]:", e);
		await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
		await reply("Aduh maaf ya " + (isOwner ? "sayang" : "kak") + ", ada error: " + (e.message || "Terjadi kesalahan"));
	}
};

handler.help = ["agy <teks/permintaan kode> [--js / --zip]"];
handler.tags = ["ai"];
handler.command = ["agy", "hirara", "ai"];

export default handler;