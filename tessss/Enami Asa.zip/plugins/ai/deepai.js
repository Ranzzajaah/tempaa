/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const AVAILABLE_MODELS = [
	'standard',
	'deepseek-v3.2',
	'gemini-2.5-flash-lite',
	'gemma-4',
	'llama-3.3-70b-instruct',
	'gpt-oss-120b',
	'gpt-5-nano'
];

const DEFAULT_PROFESSIONAL_PROMPT = 
	'Anda adalah AI Assistant profesional, cerdas, berpengetahuan luas, ramah, dan solutif bernama Hirara AI. ' +
	'Berikan penjelasan yang komprehensif, terstruktur dengan rapi, logis, mudah dipahami, serta sertakan contoh relevan jika diperlukan. ' +
	'Gunakan bahasa Indonesia yang baik, santun, baku, dan tetap luwes.';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(
			`🤖 *DEEPAI ASSISTANT*\n\n` +
			`Tanyakan apa saja kepada AI dengan model canggih & prompt profesional!\n\n` +
			`📌 *Format Penggunaan:*\n` +
			`*${usedPrefix + command} <pertanyaan>*\n` +
			`*${usedPrefix + command} --model=gemini-2.5-flash-lite <pertanyaan>*\n` +
			`*${usedPrefix + command} <pertanyaan> | <custom system prompt>*\n\n` +
			`⚙️ *Pilihan Model:*\n` +
			AVAILABLE_MODELS.map(m => ` • ${m}`).join('\n') +
			`\n\n📌 *Contoh:*\n` +
			`*${usedPrefix + command} Jelaskan arsitektur microservices dan kelebihannya*\n` +
			`*${usedPrefix + command} --model=deepseek-v3.2 Buatkan kode Python REST API sederhana*`
		);
	}

	let query = text;
	let model = 'standard';
	let prompt = DEFAULT_PROFESSIONAL_PROMPT;

	const modelMatch = query.match(/--model=([a-zA-Z0-9_.-]+)/i);
	if (modelMatch) {
		const reqModel = modelMatch[1].toLowerCase();
		if (AVAILABLE_MODELS.includes(reqModel)) {
			model = reqModel;
		}
		query = query.replace(modelMatch[0], '').trim();
	}

	const promptMatch = query.match(/--prompt=(.+?)(?=\s+--|$)/i);
	if (promptMatch) {
		prompt = promptMatch[1].trim();
		query = query.replace(promptMatch[0], '').trim();
	} else if (query.includes('|')) {
		const parts = query.split('|');
		query = parts[0].trim();
		if (parts[1]?.trim()) {
			prompt = parts.slice(1).join('|').trim();
		}
	}

	if (!query) {
		return reply(`⚠️ Masukkan pertanyaan atau topik yang ingin dibahas!`);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/ai/deepai', {
			text: query,
			prompt: prompt,
			model: model
		}, 'apikey');

		const { data: res } = await axios.get(apiUrl, { timeout: 60000 });

		if (!res || !res.status) {
			await global.react(client, m, 'error');
			return reply(`❌ Gagal mendapatkan respon dari DeepAI: ${res?.message || 'Server tidak merespon.'}`);
		}

		const answer = typeof res.result === 'string' ? res.result : (res.result?.text || JSON.stringify(res.result));

		let replyText = `🤖 *DEEPAI (${(res.model || model).toUpperCase()})*\n\n`;
		replyText += `${answer}\n\n`;
		replyText += `⚙️ _Model: ${res.model || model}_\n`;
		replyText += `© ${global.namaBot || 'Hirara AI'}`;

		await reply(replyText.trim());
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[DEEPAI ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan saat memproses DeepAI: ${e.response?.data?.message || e.message}`);
	}
};

handler.help = ['deepai <pertanyaan>', 'deepai --model=<model> <pertanyaan>'];
handler.tags = ['ai'];
handler.command = ['deepai', 'deep-ai'];
handler.limit = true;
handler.register = true;

export default handler;
