/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';

const sendReact = async (conn, sock, m, emoji) => {
	try {
		const client = conn || sock || global.mainSock;
		if (client?.sendMessage) {
			await client.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
		}
	} catch (e) {
		console.error('[EDITIMG REACT ERROR]', e.message);
	}
};

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || q.mediaType || '';
	const isImage = /image/.test(mime);

	if (!isImage) {
		return reply(`⚠️ Kirim atau reply gambar dengan caption:\n\n*${usedPrefix + command} <prompt edit>*\n\nContoh:\n*${usedPrefix + command} hitamkan kulit wajah*`);
	}

	let prompt = text || '';
	if (!prompt && m.quoted?.text) prompt = m.quoted.text;
	if (!prompt && m.msg?.caption) prompt = m.msg.caption;

	if (!prompt) {
		return reply(`Contoh:\n*${usedPrefix + command} hitamkan kulit wajah*`);
	}

	await sendReact(conn, sock, m, '🕒');
	if (global.mess?.wait) reply(global.mess.wait);

	try {
		let mediaBuffer = null;
		if (typeof q.download === 'function') {
			mediaBuffer = await Promise.race([
				q.download(),
				new Promise((_, reject) => setTimeout(() => reject(new Error('Download media timeout (15s)')), 15000))
			]).catch(() => null);
		}

		if (!mediaBuffer && client?.downloadAndSaveMediaMessage) {
			const tmpPath = await client.downloadAndSaveMediaMessage(q).catch(() => null);
			if (tmpPath) {
				const fs = await import('fs');
				mediaBuffer = fs.readFileSync(tmpPath);
				try { fs.unlinkSync(tmpPath); } catch (_) {}
			}
		}

		if (!mediaBuffer) throw new Error('Gagal mengunduh gambar dari WhatsApp. Pastikan media dapat diakses.');

		const form = new FormData();
		form.append('media', mediaBuffer, 'image.jpg');
		form.append('prompt', prompt);
		form.append('filename', 'image.jpg');

		const apiKey = global.APIKeys?.['https://api.kyzzz.xyz'] || 'kyuuimp';
		const apiUrl = `https://api.kyzzz.xyz/api/ai-image/edit-image?apikey=${apiKey}`;

		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer',
			timeout: 90000
		});

		const contentType = res.headers['content-type'] || '';
		let resultBuffer = null;

		if (contentType.includes('application/json')) {
			const jsonStr = Buffer.from(res.data).toString('utf-8');
			const json = JSON.parse(jsonStr);
			if (json.status === false || json.error) {
				throw new Error(json.message || json.error || 'Gagal mengedit gambar.');
			}
			if (json.url || json.result || json.image) {
				const imgRes = await axios.get(json.url || json.result || json.image, { responseType: 'arraybuffer' });
				resultBuffer = Buffer.from(imgRes.data);
			} else {
				throw new Error('Respon JSON API tidak memuat gambar.');
			}
		} else {
			resultBuffer = Buffer.from(res.data);
		}

		const caption = `🎨 *AI EDIT IMAGE*\n\n` +
			`📝 *Prompt:* ${prompt}\n` +
			`✨ *API:* api.kyzzz.xyz`;

		if (typeof client?.sendButtons === 'function') {
			await client.sendButtons(m.chat, {
				image: resultBuffer,
				text: caption,
				footer: global.namaBot || 'Hirara AI',
				buttons: [
					{
						displayText: '🌐 Kunjungi REST API',
						url: 'https://api.kyzzz.xyz'
					}
				]
			}, { quoted: m });
		} else {
			await client.sendMessage(m.chat, {
				image: resultBuffer,
				caption: caption
			}, { quoted: m });
		}

		await sendReact(conn, sock, m, '✅');

	} catch (e) {
		console.error('[EDITIMG ERROR]', e.message || e);
		await sendReact(conn, sock, m, '❌');
		let errorMsg = e.message;
		if (e.response?.data) {
			try {
				const parsed = JSON.parse(Buffer.from(e.response.data).toString('utf-8'));
				errorMsg = parsed.message || parsed.error || errorMsg;
			} catch (_) {}
		}
		await reply(`❌ *Gagal mengedit gambar:*\n${errorMsg || 'Terjadi kesalahan pada server.'}`);
	}
};

handler.help = ['editimg <prompt> (reply gambar)'];
handler.tags = ['ai'];
handler.command = ['editimg', 'img2img', 'editimage'];
handler.limit = true;
handler.register = true;

export default handler;
