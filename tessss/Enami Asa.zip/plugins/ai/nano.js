/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';

const bananaSession = {};

const sendReact = async (sock, m, emoji) => {
	try {
		await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
	} catch (e) {
		console.error('[NANO REACT ERROR]', e.message);
	}
};

async function uploadMedia(m) {
	try {
		const q = m.quoted ? m.quoted : m;
		if (!/image/.test(q.mimetype || q.msg?.mimetype)) return null;
		const media = await q.download();
		const form = new FormData();
		form.append('file', media, { filename: 'image.jpg' });
		form.append('type', 'permanent');
		const res = await axios.post('https://tmp.malvryx.dev/upload', form, {
			headers: form.getHeaders(),
		});
		return res.data?.cdnUrl || res.data?.directUrl || null;
	} catch {
		return null;
	}
}

async function pollResult(taskId, maxAttempts = 25) {
	for (let i = 0; i < maxAttempts; i++) {
		await new Promise((r) => setTimeout(r, 5000));
		const { data } = await axios.get(
			`https://omegatech-api.dixonomega.tech/api/ai/nano-banana2-result?task_id=${taskId}`
		);
		if (data.status === 'completed' && data.image_url) return data.image_url;
		if (data.status === 'failed') throw new Error('Server reported generation failure.');
	}
	throw new Error('Generation timed out.');
}

const handler = async (m, { sock, text, usedPrefix, command, reply }) => {
	const userId = m.sender;
	const isNanoPro = /nanopro/i.test(command);
	const prompt = text || m.quoted?.text || m.msg?.caption || '';

	if (isNanoPro) {
		if (!bananaSession[userId]) bananaSession[userId] = { images: [] };

		if (text?.toLowerCase().startsWith('done')) {
			const session = bananaSession[userId];
			const finalPrompt = text.replace(/done/i, '').trim();

			if (session.images.length < 2)
				return reply('⚠️ *Nano-Banana Pro*\n\nPlease add at least 2 images before finishing.');
			if (!finalPrompt)
				return reply(`⚠️ *Prompt Required*\n\nUsage: ${usedPrefix}${command} done <your prompt>`);

			await sendReact(sock, m, '🕒');
			try {
				let apiUrl = `https://omegatech-api.dixonomega.tech/api/ai/nanobana-pro-v3?prompt=${encodeURIComponent(finalPrompt)}`;
				session.images.forEach((url, i) => {
					apiUrl += `&image${i + 1}=${encodeURIComponent(url)}`;
				});

				const { data: initRes } = await axios.get(apiUrl);
				if (!initRes.success) throw new Error('API failed to initiate blend.');

				const resultUrl = await pollResult(initRes.task_id);

				await sock.sendMessage(
					m.chat,
					{
						image: { url: resultUrl },
						caption: `🍌 *NANO-BANANA PRO SUCCESS*\n\n🖼️ *Images Blended:* ${session.images.length}\n📝 *Prompt:* ${finalPrompt}\n🚀 *Source:* Omegatech API`,
					},
					{ quoted: m }
				);

				await sendReact(sock, m, '✅');
				delete bananaSession[userId];
			} catch (e) {
				await sendReact(sock, m, '❌');
				await reply(`❌ *Error:* ${e.message}`);
				delete bananaSession[userId];
			}
			return;
		}

		const link = await uploadMedia(m);
		if (!link)
			return reply(
				`📸 *Collector Mode*\n\nQuote atau kirim gambar dengan *${usedPrefix}${command}* untuk menambahkan.\n\nKetik *${usedPrefix}${command} done <prompt>* jika sudah selesai.`
			);

		if (bananaSession[userId].images.length >= 4)
			return reply('❌ *Limit Reached*\n\nMaksimal 4 gambar.');

		bananaSession[userId].images.push(link);
		await sendReact(sock, m, '📥');
		return reply(
			`✅ *Image ${bananaSession[userId].images.length}/4 Added*\n\nKirim gambar lain atau ketik:\n*${usedPrefix}${command} done <prompt>*`
		);
	}

	const imageUrl = await uploadMedia(m);

	if (imageUrl) {
		if (!prompt)
			return reply(
				`⚠️ *Instruction Required*\n\nContoh: Reply gambar dengan \`${usedPrefix}nano make it a zombie\``
			);

		await sendReact(sock, m, '🎨');
		try {
			const { data: init } = await axios.get(
				`https://omegatech-api.dixonomega.tech/api/ai/nano-banana2?prompt=${encodeURIComponent(prompt)}&image=${encodeURIComponent(imageUrl)}`
			);

			const resultUrl = await pollResult(init.task_id, 20);

			await sock.sendMessage(
				m.chat,
				{
					image: { url: resultUrl },
					caption: `✨ *NANO EDIT SUCCESS*\n\n📝 *Prompt:* ${prompt}`,
				},
				{ quoted: m }
			);
			await sendReact(sock, m, '✅');
		} catch (e) {
			await sendReact(sock, m, '❌');
			await reply(`❌ Image edit failed: ${e.message}`);
		}
		return;
	}

	if (!prompt) return reply(`⚠️ *Input Required*\n\nUsage: ${usedPrefix}nano <prompt>`);

	await sendReact(sock, m, '⏳');
	try {
		const { data } = await axios.get(
			`https://omegatech-api.dixonomega.tech/api/ai/nano-banana-pro?prompt=${encodeURIComponent(prompt)}`
		);
		if (data.image) {
			await sock.sendMessage(
				m.chat,
				{
					image: { url: data.image },
					caption: `🍌 *NANO PRO GENERATION*\n\n📝 *Prompt:* ${prompt}`,
				},
				{ quoted: m }
			);
			await sendReact(sock, m, '✅');
		}
	} catch (e) {
		await sendReact(sock, m, '❌');
		await reply(`❌ Generation failed: ${e.message}`);
	}
};

handler.help = ['nano <prompt>', 'nanopro'];
handler.tags = ['ai'];
handler.command = ['nanopro', 'nano'];
handler.limit = true;

handler.premium = true;

handler.register = true;

export default handler;
