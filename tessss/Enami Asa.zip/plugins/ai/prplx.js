/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import crypto from 'node:crypto';

const UA =
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0';

const sendReact = async (sock, m, emoji) => {
	try {
		await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
	} catch (e) {
		console.error('[PPLX REACT ERROR]', e.message);
	}
};

async function bootstrap() {
	const visitorId = crypto.randomUUID();
	const sessionId = crypto.randomUUID();
	const edgeVid = crypto.randomUUID();
	const edgeSid = crypto.randomUUID();
	const captured = [];

	try {
		const res = await axios.get('https://www.perplexity.ai/', {
			headers: {
				'user-agent': UA,
				accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
				'accept-language': 'en-US,en;q=0.9',
				'sec-ch-ua': '"Chromium";v="148", "Microsoft Edge";v="148", "Not/A)Brand";v="99"',
				'sec-ch-ua-mobile': '?0',
				'sec-ch-ua-platform': '"Windows"',
				'sec-fetch-dest': 'document',
				'sec-fetch-mode': 'navigate',
				'sec-fetch-site': 'none',
				'upgrade-insecure-requests': '1',
			},
			maxRedirects: 5,
			validateStatus: () => true,
		});

		const raw = res.headers['set-cookie'] || [];
		for (const c of raw) captured.push(c.split(';')[0]);
	} catch {}

	const cookieParts = [
		`pplx.visitor-id=${visitorId}`,
		`pplx.session-id=${sessionId}`,
		`pplx.edge-vid=${edgeVid}`,
		`pplx.edge-sid=${edgeSid}`,
		'pplx.trackingAllowed=true',
		...captured,
	];
	return { visitorId, sessionId, cookie: cookieParts.join('; ') };
}

function parseSSE(raw) {
	let lastChunk = null;
	const events = raw.split(/\r?\n\r?\n/);
	for (const ev of events) {
		if (!ev.trim()) continue;
		let dataStr = '';
		for (const ln of ev.split(/\r?\n/)) {
			if (ln.startsWith('data: ')) dataStr += ln.slice(6);
			else if (ln.startsWith('data:')) dataStr += ln.slice(5).trim();
		}
		if (!dataStr || dataStr === '{}') continue;
		try {
			const obj = JSON.parse(dataStr);
			if (obj && typeof obj === 'object' && Object.keys(obj).length > 0) lastChunk = obj;
		} catch {}
	}
	return lastChunk;
}

function extractAnswer(chunk) {
	if (!chunk?.text) return '';
	let steps;
	try {
		steps = JSON.parse(chunk.text);
	} catch {
		return '';
	}
	if (!Array.isArray(steps)) return '';
	const finalStep = steps.find((s) => s.step_type === 'FINAL');
	if (!finalStep?.content?.answer) return '';
	try {
		const inner = JSON.parse(finalStep.content.answer);
		return (inner.answer || '').replace(/【\d+†[^】]*】/g, '').trim();
	} catch {
		return '';
	}
}

function cleanSources(arr) {
	if (!Array.isArray(arr)) return [];
	return arr
		.map((s) => ({ title: s.name || s.title || '', url: s.url || s.link || '' }))
		.filter((s) => s.url);
}

async function perplexitySearch(query) {
	const session = await bootstrap();

	const payload = {
		params: {
			attachments: [],
			language: 'id-ID',
			timezone: 'Asia/Jakarta',
			search_focus: 'internet',
			sources: ['web'],
			frontend_uuid: crypto.randomUUID(),
			mode: 'concise',
			model_preference: 'turbo',
			is_related_query: false,
			is_sponsored: false,
			frontend_context_uuid: crypto.randomUUID(),
			prompt_source: 'user',
			query_source: 'home',
			is_incognito: false,
			time_from_first_type: 3000 + Math.floor(Math.random() * 4000),
			local_search_enabled: false,
			use_schematized_api: true,
			send_back_text_in_streaming_api: false,
			supported_block_use_cases: [
				'answer_modes', 'media_items', 'knowledge_cards', 'inline_entity_cards',
				'place_widgets', 'finance_widgets', 'news_widgets', 'shopping_widgets',
				'search_result_widgets', 'inline_images', 'inline_assets', 'placeholder_cards',
				'diff_blocks', 'inline_knowledge_cards', 'entity_group_v2', 'refinement_filters',
				'answer_tabs', 'preserve_latex', 'in_context_suggestions',
				'pending_followups', 'inline_claims', 'unified_assets',
			],
			client_coordinates: null,
			mentions: [],
			dsl_query: query,
			skip_search_enabled: true,
			is_nav_suggestions_disabled: false,
			source: 'default',
			always_search_override: false,
			override_no_search: false,
			client_search_results_cache_key: crypto.randomUUID(),
			should_ask_for_mcp_tool_confirmation: true,
			browser_agent_allow_once_from_toggle: false,
			force_enable_browser_agent: false,
			supported_features: ['browser_agent_permission_banner_v1.1'],
			extended_context: false,
			version: '2.18',
			rum_session_id: crypto.randomUUID(),
		},
		query_str: query,
	};

	const res = await axios.post('https://www.perplexity.ai/rest/sse/perplexity_ask', JSON.stringify(payload), {
		timeout: 60000,
		responseType: 'text',
		validateStatus: () => true,
		headers: {
			accept: 'text/event-stream',
			'accept-language': 'en-US,en;q=0.9',
			'cache-control': 'no-cache',
			'content-type': 'application/json',
			cookie: session.cookie,
			origin: 'https://www.perplexity.ai',
			pragma: 'no-cache',
			referer: 'https://www.perplexity.ai/',
			'sec-ch-ua': '"Chromium";v="148", "Microsoft Edge";v="148", "Not/A)Brand";v="99"',
			'sec-ch-ua-mobile': '?0',
			'sec-ch-ua-platform': '"Windows"',
			'sec-fetch-dest': 'empty',
			'sec-fetch-mode': 'cors',
			'sec-fetch-site': 'same-origin',
			'user-agent': UA,
			'x-perplexity-request-endpoint': 'https://www.perplexity.ai/rest/sse/perplexity_ask',
			'x-perplexity-request-reason': 'ask-query-state-provider',
			'x-perplexity-request-try-number': '1',
			'x-request-id': crypto.randomUUID(),
		},
	});

	if (res.status !== 200) throw new Error(`HTTP ${res.status}`);

	const lastChunk = parseSSE(res.data);
	if (!lastChunk) throw new Error('Empty SSE stream');

	return {
		answer: extractAnswer(lastChunk),
		sources: cleanSources(lastChunk.sources),
		related: lastChunk.related_queries || [],
	};
}

const handler = async (m, { sock, text, reply }) => {
	if (!text) return reply(`Masukkan pertanyaan!\nContoh: .perplexity siapa presiden indonesia?`);

	await sendReact(sock, m, '🔍');

	try {
		const result = await perplexitySearch(text);

		if (!result.answer) {
			await sendReact(sock, m, '❌');
			return reply('❌ Tidak ada jawaban dari Perplexity.');
		}

		let out = `🔎 *Perplexity Search*\n\n`;
		out += `*Q:* ${text}\n\n`;
		out += `*A:* ${result.answer}`;

		if (result.sources?.length) {
			out += `\n\n📚 *Sumber:*`;
			for (const s of result.sources.slice(0, 3)) {
				out += `\n• ${s.title || s.url}`;
			}
		}

		if (result.related?.length) {
			out += `\n\n💡 *Related:*`;
			for (const r of result.related.slice(0, 3)) {
				out += `\n• ${r}`;
			}
		}

		await reply(out);
		await sendReact(sock, m, '✅');
	} catch (e) {
		console.error('[PPLX ERROR]', e.message);
		await sendReact(sock, m, '❌');

		const isTimeout = e.code === 'ECONNABORTED' || /timeout/i.test(e.message || '');
		await reply(isTimeout ? '⏱️ Server kelamaan respon, coba lagi sebentar ya.' : e.message || 'Terjadi kesalahan');
	}
};

handler.help = ['perplexity <pertanyaan>'];
handler.tags = ['ai'];
handler.command = ['perplexity', 'pplx'];
handler.limit = true;

handler.premium = true;

handler.register = true;

export default handler;
