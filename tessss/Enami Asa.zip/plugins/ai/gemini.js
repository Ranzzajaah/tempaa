/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { geminiChat } from '../../scrape/gemini.js';
import { getAiSession, saveAiSession, deleteAiSession } from '../../lib/database.js';

const handler = async (m, { sock, conn, text, reply, isOwner, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock || global.conn;

	if (!text) {
		return reply(
			`Contoh penggunaan:\n• \`${usedPrefix + command} jelaskan tentang black hole\`\n• \`${usedPrefix + command} buatkan kode html kalkulator\`\n• \`${usedPrefix + command} reset\` (untuk mereset percakapan)`
		);
	}

	if (text.trim().toLowerCase() === 'reset' || text.trim().toLowerCase() === 'clear') {
		const fnDelete = global.deleteAiSession || deleteAiSession;
		fnDelete(m.sender, 'gemini');
		return reply('✨ Sesi percakapan Gemini Anda telah direset.');
	}

	await client.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

	try {
		const fnGet = global.getAiSession || getAiSession;
		const fnSave = global.saveAiSession || saveAiSession;

		const prevSession = fnGet(m.sender, 'gemini') || null;
		const res = await geminiChat(text, { sessionId: prevSession });

		if (!res || !res.response) {
			await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
			return reply('❌ Gagal mendapatkan respon dari Gemini. Coba beberapa saat lagi.');
		}

		if (res.sessionId) {
			fnSave(m.sender, res.sessionId, 'gemini');
		}

		const result = res.response;

		const codeBlockRegex = /```(\w+)?\r?\n([\s\S]*?)```/g;
		const codeMatches = [...result.matchAll(codeBlockRegex)];

		if (codeMatches.length > 0 && typeof global.AIRich !== 'undefined') {
			try {
				const rich = new global.AIRich(client);
				let lastIndex = 0;

				for (const match of codeMatches) {
					const textBefore = result.substring(lastIndex, match.index).trim();
					if (textBefore) {
						rich.addText(textBefore);
					}

					const lang = (match[1] || 'javascript').toLowerCase();
					const codeContent = match[2].trim();

					rich.addCode(lang, codeContent);

					lastIndex = match.index + match[0].length;
				}

				const textAfter = result.substring(lastIndex).trim();
				if (textAfter) {
					rich.addText(textAfter);
				}

				await rich.send(m.chat, { quoted: m });
				await client.sendMessage(m.chat, { react: { text: isOwner ? '💖' : '✅', key: m.key } });
				return;
			} catch (errRich) {
				console.error('[AIRich Send Error, fallback to normal reply]:', errRich);
			}
		}

		await reply(result);
		await client.sendMessage(m.chat, { react: { text: isOwner ? '💖' : '✅', key: m.key } });
	} catch (e) {
		console.error('[GEMINI PLUGIN ERROR]:', e);
		await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
		await reply(`Aduh maaf, ada error: ${e.message || 'Terjadi kesalahan'}`);
	}
};

handler.help = ['gemini <pertanyaan/kode>'];
handler.tags = ['ai'];
handler.command = ['gemini', 'bard'];
handler.limit = true;

export default handler;
