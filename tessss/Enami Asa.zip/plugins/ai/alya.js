/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { text, reply, usedPrefix, command }) => {
	if (!text) {
		return reply(`*Alya AI*\n\nContoh:\n${usedPrefix}${command} hai`);
	}

	try {
		const { data } = await axios.get(global.API(
			'kyzz',
			'/api/ai/alya',
			{
				message: text,
				session: m.sender
			},
			'apikey'
		));

		if (!data.status) {
			return reply(data.message || 'Terjadi kesalahan.');
		}

		return reply(data.reply);
	} catch (e) {
		console.error('[ALYA ERROR]', e.response?.data || e);
		return reply('❌ Gagal menghubungi Alya.');
	}
};

handler.help = ['alya <pesan>'];
handler.tags = ['ai'];
handler.command = ['alya'];
handler.limit = true;
handler.register = true;

export default handler;
