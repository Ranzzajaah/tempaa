/**
 * Hirara AI — WhatsApp Bot
 * Feature : ChatEverywhere AI Assistant (api.kyzzz.xyz)
 * Creator : Mommy Kyu
 */

import axios from 'axios';

const handler = async (m, { sock, conn, text, reply, isOwner, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock || global.conn;

	if (!text) {
		return reply(
			`🤖 *ᴄʜᴀᴛ ᴇᴠᴇʀʏᴡʜᴇʀᴇ ᴀɪ* ✨\n\n` +
			`• 📌 *Contoh:* \`${usedPrefix + command} apa itu Jokowi dodo\`\n` +
			`• 💡 *Contoh:* \`${usedPrefix + command} buatkan puisi tentang senja\``
		);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API(
			'kyzz',
			'/api/ai/chateverywhere',
			{
				prompt: text
			},
			'apikey'
		);

		const { data } = await axios.get(apiUrl, {
			timeout: 30000,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
			}
		});

		if (!data || !data.status || !data.result) {
			await global.react(client, m, 'error');
			return reply(data?.message || '❌ Gagal mendapatkan respon dari AI.');
		}

		const result = data.result.trim();

		// Check if AIRich is available for formatted code output
		const codeBlockRegex = /```(\w+)?\r?\n([\s\S]*?)```/g;
		const codeMatches = [...result.matchAll(codeBlockRegex)];

		if (codeMatches.length > 0 && typeof global.AIRich !== 'undefined') {
			try {
				const rich = new global.AIRich(client);
				let lastIndex = 0;

				for (const match of codeMatches) {
					const textBefore = result.substring(lastIndex, match.index).trim();
					if (textBefore) rich.addText(textBefore);

					const lang = (match[1] || 'javascript').toLowerCase();
					const codeContent = match[2].trim();
					rich.addCode(lang, codeContent);

					lastIndex = match.index + match[0].length;
				}

				const textAfter = result.substring(lastIndex).trim();
				if (textAfter) rich.addText(textAfter);

				await rich.send(m.chat, { quoted: m });
				await global.react(client, m, 'success');
				return;
			} catch (_) {}
		}

		await reply(result);
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[CHATEVERYWHERE ERROR]:', e.response?.data || e);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan: ${e.response?.data?.message || e.message || 'Gagal menghubungi server AI.'}`);
	}
};

handler.help = ['chateverywhere <pertanyaan>', 'ce <pertanyaan>'];
handler.tags = ['ai'];
handler.command = ['chateverywhere', 'ce'];
handler.limit = true;
handler.register = true;

export default handler;
