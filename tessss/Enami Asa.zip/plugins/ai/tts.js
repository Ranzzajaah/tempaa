import axios from 'axios';
import crypto from 'crypto';

// Mapping suara berdasarkan bahasa
const listvoice_indo = { 'Gadis': '173', 'Ardi': '174', 'Siti': '404', 'Dimas': '405', 'Tuti': '488', 'Jajang': '489' };
const listvoice_english = { 'Abbi': '540', 'Bella': '541', 'Hollie': '542', 'Maisie': '543', 'Mia': '544', 'Olivia': '545', 'Alfie': '546', 'Elliot': '547', 'Ethan': '548', 'Noah': '549' };
const listvoice_turkish = { 'Meryem': '218', 'Ibrahim': '219' };
const listvoice_japanese = { 'Aoi': '779', 'Daichi': '780', 'Mayu': '781', 'Naoki': '782', 'Shiori': '783', 'Nanami': '178', 'Keita': '179' };
const listvoice_korean = { 'BongJin': '785', 'GookMin': '786', 'Hyunsu': '787', 'JiMin': '788', 'SeoHyeon': '789', 'SoonBok': '790', 'YuJin': '791', 'SunHi': '180', 'InJoon': '181' };
const listvoice_multilingual = { 'Algenib': '817', 'Despina': '824', 'Enceladus': '825', 'Ava': '663', 'Marcello': '695', 'William': '713', 'Ash': '706', 'Sage': '709' };

const voiceMap = {
    ...listvoice_indo,
    ...listvoice_english,
    ...listvoice_turkish,
    ...listvoice_japanese,
    ...listvoice_korean,
    ...listvoice_multilingual
};

const list_model = Object.keys(voiceMap);

function randomRevenuecatId() {
    return 'rc_anon_' + crypto.randomBytes(8).toString('hex');
}

// Fungsi Scraper Voiser TTS
async function voiserTTS(text, model) {
    const base_url = 'https://app-tts.voiser.ai';
    if (!list_model.includes(model)) return { success: false };
    const voiceId = voiceMap[model];
    const revenuecatId = randomRevenuecatId();

    try {
        const registerRes = await axios.post(`${base_url}/members`, {
            mac: null, platform: "android", revenuecatId: revenuecatId, fcmToken: ""
        }, { headers: { 'User-Agent': 'Neo/1.0', 'Content-Type': 'application/json' } });

        const memberCode = registerRes.data?.memberCode;
        if (!memberCode) return { success: false };

        const generateRes = await axios.post(`${base_url}/tts`, {
            memberCode: memberCode, text: text, voiceId: voiceId, pitch: "0", speed: "1.0", mood: "neutral", instruction: "", hasEmotionTag: false, lang: "tr"
        }, { headers: { 'User-Agent': 'Dart/3.0 (dart:io)', 'Content-Type': 'application/json' } });

        if (generateRes.data?.status !== "1" || !generateRes.data?.file) {
            return { success: false };
        }

        return { success: true, audio_url: generateRes.data.file, id: generateRes.data.id };
    } catch {
        return { success: false };
    }
}

// Handler Bot
const handler = async (m, { sock, text, command }) => {
    if (!text) {
        return m.reply(`❓ *Cara Penggunaan:*\nKetik *${command} <teks>* untuk memilih suara dari list.\n\nContoh: *${command} Halo saya bot WA*`);
    }

    if (!text.includes('|')) {
        const sections = [
            {
                title: '🇮🇩 Indonesian Voices',
                rows: Object.keys(listvoice_indo).map(model => ({ title: model, description: `Model suara ${model}`, id: `${command} ${model}|${text}` }))
            },
            {
                title: '🇬🇧 English Voices',
                rows: Object.keys(listvoice_english).map(model => ({ title: model, description: `Model suara ${model}`, id: `${command} ${model}|${text}` }))
            },
            {
                title: '🇯🇵 Japanese Voices',
                rows: Object.keys(listvoice_japanese).map(model => ({ title: model, description: `Model suara ${model}`, id: `${command} ${model}|${text}` }))
            }
        ];

        return await sock.sendMessage(m.chat, { 
            text: `Halo! Silakan pilih model suara untuk teks:\n\n_"${text}"_`, 
            footer: '© ranzz',
            buttons: [
                { 
                    title: 'Pilih Suara 🗣️', 
                    sections: sections, 
                    icon: 'DEFAULT' 
                }
            ],
            headerType: 1
        }, { quoted: m });
    }

    let [model, ...isiTeksArr] = text.split('|');
    let isiTeks = isiTeksArr.join('|').trim();
    model = model.trim();

    if (!list_model.includes(model)) {
        return m.reply('❌ Model suara tidak valid! Silakan ulangi perintah.');
    }

    await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    const res = await voiserTTS(isiTeks, model);

    if (!res.success || !res.audio_url) {
        await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        return m.reply('❌ Gagal menghasilkan suara. Server TTS mungkin sedang sibuk atau down.');
    }

    await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    
    try {
        // Download audio ke buffer terlebih dahulu
        const response = await axios.get(res.audio_url, { responseType: 'arraybuffer' });
        const audioBuffer = Buffer.from(response.data);
        
        // MENGIRIM SEBAGAI FILE AUDIO (Bukan Voice Note)
        await sock.sendMessage(m.chat, { 
            audio: audioBuffer, 
            mimetype: 'audio/mpeg', // Standar MP3
            ptt: false // Ubah ptt menjadi false agar WA langsung memutarnya tanpa memedulikan format OGG/OPUS
        }, { quoted: m });
        
    } catch (error) {
        console.error(error);
        return m.reply('❌ Gagal memproses file audio untuk dikirimkan ke WhatsApp.');
    }
}

handler.command = ["tts", "voiser"];
handler.owner = false;
handler.group = false;

export default handler;