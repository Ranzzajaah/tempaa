import axios from 'axios';
import { db, getUser, updateUser } from '../../lib/database.js';

// Auto-migration guard untuk memastikan kolom session tersedia di SQLite
try { db.exec(`ALTER TABLE users ADD COLUMN prabowo_session TEXT NOT NULL DEFAULT ''`); } catch (_) {}

const handler = async (m, { sock, text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(
            `🇮🇩 *PAK PRABOWO - AI CHAT* 🇮🇩\n\n` +
            `*Cara Penggunaan:*\n` +
            `• \`${usedPrefix + command} Halo Pak, bagaimana kabarnya?\`\n` +
            `• \`${usedPrefix + command} reset\` (Untuk mereset sesi/ingatan obrolan)\n\n` +
            `> 💡 _Fitur ini memiliki memori sesi, sehingga percakapan akan terus menyambung._`
        );
    }

    const query = text.trim();

    // Fitur Reset Sesi Percakapan
    if (query.toLowerCase() === 'reset') {
        await updateUser(m.sender, { prabowo_session: '' });
        return m.reply(`🔄 *Sesi Pak Prabowo berhasil direset.* Ingatan obrolan telah dikembalikan ke awal.`);
    }

    try {
        await sock.sendMessage(m.chat, { react: { text: '🇮🇩', key: m.key } });

        // Ambil data user untuk mengecek apakah sudah ada sessionId aktif sebelumnya
        const user = await getUser(m.sender);
        const activeSessionId = user.prabowo_session || '';

        // Membangun URL menggunakan global.API dari settings.js
        const params = {
            message: query,
            ...(activeSessionId ? { sessionId: activeSessionId } : {})
        };

        const apiUrl = global.API('kyzz', '/api/ai/prabowo', params, true);

        const res = await axios.get(apiUrl, { timeout: 30000 });
        const data = res.data;

        if (!data || !data.status || !data.result) {
            throw new Error(data?.message || 'Gagal merespons dari server Pak Prabowo.');
        }

        const result = data.result;
        const replyText = result.reply || '...';
        const newSessionId = result.sessionId;

        // Simpan sessionId terbaru ke database SQLite user
        if (newSessionId) {
            await updateUser(m.sender, { prabowo_session: newSessionId });
        }

        const formattedMessage = `🎤 *Pak Prabowo* \n\n${replyText}`;

        await sock.sendMessage(m.chat, { text: formattedMessage }, { quoted: m });
        await sock.sendMessage(m.chat, { react: { text: '✨', key: m.key } });

    } catch (error) {
        console.error('[PRABOWO AI ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply(`❌ Terjadi kesalahan: ${error.message || error}`);
    }
};

handler.help = ['prabowo <pesan>', 'bowo <pesan>'];
handler.tags = ['ai', 'tools'];
handler.command = ['prabowo', 'prabowoai'];

export default handler;