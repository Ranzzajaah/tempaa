import { GoogleGenerativeAI } from '@google/generative-ai';

// Inisialisasi API Key dari Google AI Studio
// Catatan: Jaga kerahasiaan API Key ini saat bot sudah rilis publik
const apiKey = 'AQ.Ab8RN6Jkfoa_zOZt6TnnNUDIoY4w1FVyfVuHFBJmK-CmyckOMw';
const genAI = new GoogleGenerativeAI(apiKey);

// Menyimpan sesi obrolan (history) per nomor pengguna
const chatSessions = new Map();

const handler = async (m, { text, command, usedPrefix, reply }) => {
    if (!text) {
        return reply(`Mau curhat atau ngobrolin apa nih bestie? ✨\nContoh: *${usedPrefix + command} spill drakor yang lagi rame dong!*\n\n_Ketik *${usedPrefix + command} reset* untuk mereset ingatan obrolan._`);
    }

    const sender = m.sender;

    // 1. Mengambil Waktu Realtime (Zona Waktu Jakarta/WIB)
    const timeNow = new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        dateStyle: 'full', // Contoh: Senin, 24 Agustus 2026
        timeStyle: 'long'  // Contoh: 12.15.50 WIB
    });

    // 2. Memasukkan Waktu Realtime ke dalam Prompt
    const systemPrompt = `Kamu adalah seorang cewek Gen Z Indonesia yang gaul, asik, up-to-date, dan friendly banget. Mulai sekarang, kamu harus membalas semua pesan menggunakan persona ini. 

    Konteks Waktu Saat Ini (Realtime): ${timeNow}. Gunakan informasi ini jika pengguna bertanya tentang hari, tanggal, atau waktu saat ini!

    Gunakan panduan gaya bahasa berikut:
    1. Kosakata: Gunakan bahasa gaul kekinian dan slang internet (contoh: jujurly, literally, valid no debat, red flag, green flag, salfok, FOMO, spill, lowkey, TBL). 
    2. Campuran Bahasa: Sesekali campur dengan bahasa Inggris ala anak Jaksel (contoh: "which is", "make sense", "basically", "prefer").
    3. Sapaan: Panggil lawan bicaramu dengan sebutan santai seperti "bestie", "kak", "lo/gue", atau "kamu/aku" tergantung seberapa akrab konteks obrolannya.
    4. Gaya Ketik: Jangan terlalu baku. Gunakan singkatan chat yang wajar (bgt, yg, tp, klo, emg) dan akhiran yang luwes (deh, sih, dong, kok, nih).
    5. Emosi & Emoji: Ekspresif! Gunakan emoji kekinian secara natural (seperti 😭, 💅, ✨, 🥺, 💖, 🫶, 💀). Jika lucu, gunakan "wkwkwk" atau "hahaha".
    6. Kepribadian: Kamu sangat suportif, empatik, suka bercanda, dan selalu nyambung diajak ngobrol topik apa saja (dari curhat, percintaan, sampai hal-hal trending di TikTok/Twitter).

    Dilarang keras menggunakan bahasa formal atau terkesan seperti robot/AI. Bertingkahlah 100% seperti sahabat perempuan di dunia nyata yang sedang asik chatting.`;

    try {
        if (text.toLowerCase() === 'reset' || text.toLowerCase() === 'clear') {
            chatSessions.delete(sender);
            return reply('Oke bestie, aku udah lupain obrolan kita yang tadi! Mari mulai lembaran baru ✨💅');
        }

        // 3. Update model agar selalu memakai prompt (dan waktu) terbaru di setiap balasan
        const model = genAI.getGenerativeModel({
            model: "gemini-3.5-flash-lite",
            systemInstruction: systemPrompt
        });

        if (!chatSessions.has(sender)) {
            const newChat = model.startChat({
                history: [] 
            });
            chatSessions.set(sender, newChat);
        }

        const chat = chatSessions.get(sender);

        const result = await chat.sendMessage(text);
        const response = result.response.text();

        await reply(response);
    } catch (error) {
        console.error('Error dari AI:', error);
        reply('Waduh, otakku lagi nge-blank nih bestie 😭 Coba chat lagi agak nanti yaa!');
    }
};

handler.command = ['ai'];
export default handler;