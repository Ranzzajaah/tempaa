/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'

const sendReact = async (sock, m, emoji) => {
	try {
		if (sock?.sendMessage) {
			await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } })
		}
	} catch {}
}

const sessionCounters = new Map()

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
	const connSock = sock || conn
	if (!text) {
		return reply(`*Shizuku AI*\n\nContoh:\n${usedPrefix}${command} hai shizuku`)
	}

	await sendReact(connSock, m, '⏳')

	try {
		const currentCount = (sessionCounters.get(m.sender) || 0) + 1
		sessionCounters.set(m.sender, currentCount)

		const sessionCycle = Math.floor((currentCount - 1) / 20)
		const sessionId = `${m.sender}_${sessionCycle}`

		const { data } = await axios.get(global.API(
			'kyzz',
			'/api/ai/shizuku',
			{
				message: text,
				session: sessionId
			},
			'apikey'
		))

		if (!data.status) {
			await sendReact(connSock, m, '❌')
			return reply(data.message || 'Terjadi kesalahan.')
		}

		await sendReact(connSock, m, '✨')
		return reply(data.reply)
	} catch (e) {
		console.error('[SHIZUKU ERROR]', e.response?.data || e)
		await sendReact(connSock, m, '❌')
		return reply('❌ Gagal menghubungi Shizuku.')
	}
}

handler.help = ['shizuku <pesan>']
handler.tags = ['ai']
handler.command = ['shizuku']
handler.limit = true;

handler.register = true;

export default handler;

