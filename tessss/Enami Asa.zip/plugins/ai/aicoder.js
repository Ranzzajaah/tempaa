import { exec } from 'child_process';
import { promisify } from 'util';
import { writeFile, mkdir, readFile, unlink, rm } from 'fs/promises';
import path from 'path';

const execAsync = promisify(exec);

const sendReact = async (sock, m, emoji) => {
	try {
		await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
	} catch (e) {
		console.error('[AICODER REACT ERROR]', e.message);
	}
};

async function createChat(prompt, proxyIp = null) {
	return null;
}

async function streamCompletion(lastMessageId) {
	return '';
}

function extractFiles(output) {
	const files = [];
	const regexWithPath = /```(?:[a-zA-Z0-9_\-+]+)?\{path=([^}]+)\}\n([\s\S]*?)```/g;
	let match;
	while ((match = regexWithPath.exec(output)) !== null) {
		const cleanPath = match[1].trim().replace(/^["']|["']$/g, '');
		files.push({ path: cleanPath, content: match[2] });
	}

	if (files.length === 0) {
		const regexFallback = /```([a-zA-Z0-9_\-+]+)?\n(?:\/\/|#|\/\*|\<!--)?\s*(?:File:|filepath:)?\s*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)?\s*(?:\*\/|\-->)?\n([\s\S]*?)```/g;
		let fbMatch;
		let count = 1;
		while ((fbMatch = regexFallback.exec(output)) !== null) {
			const ext = fbMatch[1] || 'txt';
			const filePath = fbMatch[2] ? fbMatch[2].trim() : `file_${count}.${ext}`;
			files.push({ path: filePath, content: fbMatch[3] });
			count++;
		}
	}

	return files;
}

const handler = async (m, { sock, text, reply }) => {
	if (!text) {
		return reply(`*🤖 AICODER PRO - AI FULLSTACK DEVELOPER*

*Cara Penggunaan:*
.aicoder <deskripsi project/aplikasi yang ingin dibuat>

*Contoh:*
.aicoder buat website romantik interaktif untuk pacar dengan lagu, galeri foto, timeline kenangan & ucapan cinta
.aicoder buat REST API Express.js lengkap dengan fitur auth JWT, swagger doc & CRUD user
.aicoder buat aplikasi kasir POS kaya fitur dengan React & Tailwind

*Fitur AICODER PRO:*
• Otomatis pecah project ke komponen modular (10+ file)
• Bebas error & kaya fitur interaktif
• Dikirim langsung berbentuk file *.ZIP*`);
	}

	await sendReact(sock, m, '⏳');

	const randomId = Math.floor(Math.random() * 10000);
	const tempDir = path.join(process.cwd(), `temp_aicoder_${Date.now()}_${randomId}`);
	const cleanSlug = text.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase().slice(0, 25) || 'project';

	try {
		let chatId = null;
		let lastMessageId = null;

		let lastErr = null;
		for (let attempt = 1; attempt <= 3; attempt++) {
			try {
				const data = await createChat(text);
				if (data && data.chatId) {
					chatId = data.chatId;
					lastMessageId = data.lastMessageId;
					break;
				}
			} catch (err) {
				lastErr = err;
				console.error(`[AICODER] Attempt ${attempt} failed:`, err.message);
				if (attempt < 3) await new Promise(r => setTimeout(r, 2000));
			}
		}

		if (!chatId) throw new Error(lastErr?.message || 'Gagal terhubung ke AI Coder server.');

		const output = await streamCompletion(lastMessageId);
		const files = extractFiles(output);

		if (files.length === 0) {
			files.push({
				path: 'main_output.txt',
				content: output || 'No output generated'
			});
		}

		await mkdir(tempDir, { recursive: true });

		for (const file of files) {
			const filePath = path.join(tempDir, file.path);
			await mkdir(path.dirname(filePath), { recursive: true });
			await writeFile(filePath, file.content, 'utf-8');
		}

		const zipName = `aicoder-${cleanSlug}.zip`;
		const zipPath = path.join(process.cwd(), zipName);

		await execAsync(`cd "${tempDir}" && zip -r "${zipPath}" .`);

		const zipBuffer = await readFile(zipPath);
		await unlink(zipPath).catch(() => {});

		let fileListPreview = files.slice(0, 15).map((f) => `• ${f.path}`).join('\n');
		if (files.length > 15) fileListPreview += `\n...dan ${files.length - 15} file lainnya`;

		let caption = `⚡ *AICODER PRO - MODULAR PROJECT READY*\n\n` +
			`📁 *Total File:* ${files.length} file\n` +
			`📝 *Prompt:* ${text.slice(0, 80)}${text.length > 80 ? '...' : ''}\n\n` +
			`📌 *Struktur File:* \n${fileListPreview}\n\n` +
			`💡 _Extract file ZIP di atas untuk menjalankan project._`;

		await sock.sendMessage(m.chat, {
			document: zipBuffer,
			mimetype: 'application/zip',
			fileName: zipName,
			caption,
		}, { quoted: m });

		await sendReact(sock, m, '✅');
	} catch (e) {
		console.error('[AICODER ERROR]', e);
		await sendReact(sock, m, '❌');
		await reply(`❌ *Gagal membuat project!*\nAlasan: ${e.message || 'Terjadi kesalahan sistem'}`);
	} finally {
		try {
			await rm(tempDir, { recursive: true, force: true });
		} catch {}
	}
};

handler.help = ['aicoder <prompt>'];
handler.tags = ['ai', 'tools'];
handler.command = ['aicoder', 'aicode', 'gencode'];
handler.premium = true;
handler.register = true;

export default handler;
