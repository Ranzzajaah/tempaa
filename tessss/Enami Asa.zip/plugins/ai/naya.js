/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const sendReact = async (sock, m, emoji) => {
	try {
		await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
	} catch (e) {
		console.error('[NAYA REACT ERROR]', e.message);
	}
};

const handler = async (m, { sock, text, reply }) => {
	if (!text) return reply('Masukkan pertanyaan untuk Naya');

	await sendReact(sock, m, '💬');

	try {
		const { data } = await axios.get(`https://api.cuki.biz.id/api/ai/naya?apikey=cuki-x&question=${encodeURIComponent(text)}`);

		await reply(data.data.response);
		await sendReact(sock, m, '✅');
	} catch (e) {
		console.error('[NAYA ERROR]', e.message);
		await sendReact(sock, m, '❌');
		await reply(`❌ Error: ${e.message}`);
	}
};

handler.help = ['naya <pertanyaan>'];
handler.tags = ['ai'];
handler.command = ['naya'];
handler.limit = true;

handler.register = true;

export default handler;
