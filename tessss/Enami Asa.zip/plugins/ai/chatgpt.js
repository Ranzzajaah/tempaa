/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { chatgpt } from '../../scrape/chatgpt.js';

const handler = async (m, { sock, conn, text, reply, isOwner, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock || global.conn;

	if (!text) {
		return reply(
			`🍓 *ᴄʜᴀᴛɢᴘᴛ ᴀɪ ᴀssɪsᴛᴀɴᴛ* 🎀✨\n\n` +
			`• 📌 *ᴄᴏɴᴛᴏʜ:* \`${usedPrefix + command} jelaskan teori relativitas einstein\`\n` +
			`• 💻 *ᴋᴏᴅᴇ:* \`${usedPrefix + command} buatkan kode python game ular\``
		);
	}

	await client.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

	try {
		const res = await chatgpt(text);

		if (!res || !res.ok || !res.answer) {
			await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
			const stageMsg = res.stage ? ` (Tahap ${res.stage})` : '';
			return reply(`❌ ᴍᴏʜᴏɴ ᴍᴀᴀғ: ɢᴀɢᴀʟ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʀᴇsᴘᴏɴ ᴅᴀʀɪ ᴄʜᴀᴛɢᴘᴛ (ʜᴛᴛᴘ ${res.status || '500'}${stageMsg}). 🎀✨`);
		}

		const result = res.answer.trim();

		const codeBlockRegex = /```(\w+)?\r?\n([\s\S]*?)```/g;
		const codeMatches = [...result.matchAll(codeBlockRegex)];

		if (codeMatches.length > 0 && typeof global.AIRich !== 'undefined') {
			try {
				const rich = new global.AIRich(client);
				let lastIndex = 0;

				for (const match of codeMatches) {
					const textBefore = result.substring(lastIndex, match.index).trim();
					if (textBefore) {
						rich.addText(textBefore);
					}

					const lang = (match[1] || 'javascript').toLowerCase();
					const codeContent = match[2].trim();

					rich.addCode(lang, codeContent);

					lastIndex = match.index + match[0].length;
				}

				const textAfter = result.substring(lastIndex).trim();
				if (textAfter) {
					rich.addText(textAfter);
				}

				await rich.send(m.chat, { quoted: m });
				await client.sendMessage(m.chat, { react: { text: isOwner ? '💖' : '✅', key: m.key } });
				return;
			} catch (errRich) {
				console.error('[AIRich ChatGPT Error, fallback to normal reply]:', errRich);
			}
		}

		await reply(result);
		await client.sendMessage(m.chat, { react: { text: isOwner ? '💖' : '✅', key: m.key } });
	} catch (e) {
		console.error('[CHATGPT PLUGIN ERROR]:', e);
		await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
		await reply(`❌ ᴛᴇʀᴊᴀᴅɪ ᴋᴇsᴀʟᴀʜᴀɴ: ${e.message || 'ɢᴀɢᴀʟ ᴍᴇɴɢʜᴜʙᴜɴɢɪ ᴄʜᴀᴛɢᴘᴛ 🎀✨'}`);
	}
};

handler.help = ['chatgpt <pertanyaan/kode>'];
handler.tags = ['ai'];
handler.command = ['chatgpt', 'cai'];
handler.limit = true;

export default handler;
