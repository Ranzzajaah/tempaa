/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(`🎭 *VENICE AI*\n\nMasukkan pesan atau pertanyaan yang ingin ditanyakan ke Venice AI!\n\nContoh:\n*${usedPrefix + command} Halo, apa kabar?*\n*${usedPrefix + command} Ceritakan lelucon lucu hari ini*`);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/ai/venice', { message: text.trim() }, 'apikey');
		const { data: res } = await axios.get(apiUrl, { timeout: 45000 });

		if (!res || !res.status || !res.result) {
			await global.react(client, m, 'error');
			return reply(`❌ Gagal mendapatkan respon dari Venice AI.`);
		}

		let answer = typeof res.result === 'string' ? res.result : (res.result?.text || JSON.stringify(res.result));

		let replyText = `🎭 *VENICE AI*\n\n`;
		replyText += `${answer}\n\n`;
		replyText += `© ${global.namaBot || 'Hirara AI'}`;

		await reply(replyText.trim());
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[VENICE AI ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan pada Venice AI: ${e.response?.data?.message || e.message}`);
	}
};

handler.help = ['venice <pesan>', 'veniceai <pesan>'];
handler.tags = ['ai'];
handler.command = ['venice', 'veniceai'];
handler.limit = true;
handler.register = true;

export default handler;
