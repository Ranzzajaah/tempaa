/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(`✨ *AI PROMPT GENERATOR*\n\nMasukkan konsep/ide deskripsi singkat untuk dibuatkan prompt AI yang detail!\n\nContoh:\n*${usedPrefix + command} Foto astronot di pantai Bali waktu senja*\n*${usedPrefix + command} Robot kucing futuristik cyberpunk*`);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/ai/prompt-generator', { text: text.trim() }, 'apikey');
		const { data: res } = await axios.get(apiUrl, { timeout: 30000 });

		if (!res || !res.status || !res.result) {
			await global.react(client, m, 'error');
			return reply(`❌ Gagal membuat prompt untuk *"${text}"*.`);
		}

		const { english, indonesian } = res.result;

		let caption = `✨ *AI PROMPT GENERATOR RESULT*\n\n`;
		caption += `📥 *Input:* ${text}\n\n`;

		if (english) {
			caption += `🇬🇧 *Prompt (English):*\n\`\`\`\n${english}\n\`\`\`\n\n`;
		}

		if (indonesian) {
			caption += `🇮🇩 *Prompt (Indonesian):*\n\`\`\`\n${indonesian}\n\`\`\`\n\n`;
		}

		caption += `💡 *Tips:* Copy teks di dalam box di atas untuk digunakan pada generator AI (Midjourney, DALL-E, SD, FLUX, Bing, dll).\n\n`;
		caption += `© ${global.namaBot || 'Hirara AI'}`;

		await reply(caption.trim());
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[PROMPT GENERATOR ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan saat membuat prompt: ${e.response?.data?.message || e.message}`);
	}
};

handler.help = ['promptgen <ide/teks>', 'genprompt <ide/teks>', 'promptgenerator <ide/teks>'];
handler.tags = ['ai'];
handler.command = ['promptgen', 'genprompt', 'promptgenerator'];
handler.limit = true;
handler.register = true;

export default handler;
