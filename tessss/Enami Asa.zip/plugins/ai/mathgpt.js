import axios from "axios";
import crypto from "crypto";
import { fileTypeFromBuffer } from "file-type";

// --- KUMPULAN FUNGSI SCRAPER ---
function clear(rawText) {
    if (!rawText) return "";
    return rawText
        .replace(/\$(.*?)\$/g, '$1')
        .replace(/\\\[|\\\]/g, '')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

async function mathgpt({ query, enableReasoning = false, attachedImage = null } = {}) {
    try {
        if (!query) throw new Error('Query pertanyaan wajib diisi');

        const ip = [10, crypto.randomInt(256), crypto.randomInt(256), crypto.randomInt(256)].join('.');

        const client = axios.create({
            baseURL: 'https://math-gpt.ai/api',
            headers: {
                'accept': 'application/json',
                'accept-language': 'id-ID,id;q=0.9',
                'content-type': 'application/json',
                'origin': 'https://math-gpt.ai',
                'referer': 'https://math-gpt.ai/',
                'sec-ch-ua': '"Chromium";v="127", "Not)A;Brand";v="99"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
                'x-forwarded-for': ip,
                'x-originating-ip': ip,
                'x-remote-ip': ip,
                'x-remote-addr': ip,
                'client-ip': ip,
                'x-real-ip': ip
            }
        });

        let mediaPayload = null;
        if (attachedImage) {
            try {
                const type = await fileTypeFromBuffer(attachedImage);

                if (type && type.mime.startsWith('image/')) {
                    const uniqueFileName = 'chat/' + crypto.randomBytes(32).toString('hex') + '.' + type.ext;

                    const { data: s3Ticket } = await client.post('/trpc/uploads.signedUploadUrl?batch=1', {
                        0: { json: { path: uniqueFileName, bucket: 'mathgpt' } }
                    });

                    const uploadUrl = s3Ticket[0].result.data.json;
                    await axios.put(uploadUrl, attachedImage, {
                        headers: { 'content-type': type.mime }
                    });

                    mediaPayload = {
                        fileUrl: 'https://files.math-gpt.ai/' + uniqueFileName,
                        mimeType: type.mime,
                        fileName: 'math-img-' + Date.now() + '.' + type.ext
                    };
                }
            } catch (err) {
                console.error('Gagal mengunggah gambar ke MathGPT:', err.message);
                // Tetap lanjut tanpa gambar jika gagal upload
            }
        }

        const { data: streamResponse } = await client.post('/ai/generateAnswerStream', {
            messages: [{
                id: Date.now(),
                text: query,
                sender: 'user',
                ...(mediaPayload || {})
            }],
            type: 'MathAI',
            isJustAnswerEnabled: false,
            isThinkingEnabled: enableReasoning,
            visitorId: crypto.randomUUID().replace(/-/g, '')
        });

        const parsedNode = streamResponse
            .split('\n\n')
            .filter(row => row.startsWith('data: {'))
            .map(row => JSON.parse(row.substring(6)))
            .find(node => node.type === 'end');

        if (!parsedNode) throw new Error('Server tidak merespon node akhir');
        
        const structuredAnswer = clear(parsedNode.content);

        return {
            success: true,
            result: {
                answer: structuredAnswer
            }
        };
    } catch (err) {
        return {
            success: false,
            message: err.message
        };
    }
}

// --- HANDLER FITUR BOT ---
const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
    // Mengecek apakah ada pesan teks atau caption
    const query = text || (m.quoted && m.quoted.text ? m.quoted.text : '');
    
    // Mengecek apakah pesan saat ini atau yang di-reply adalah gambar
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';
    const isImage = mime.startsWith('image/');

    if (!query && !isImage) {
        return reply(`*Math GPT AI*\n\nKirimkan soal matematika (teks atau gambar beserta caption).\n\nContoh:\n${usedPrefix}${command} 2^5 * 2^9`);
    }

    if (!query && isImage) {
        return reply('Tolong sertakan instruksi atau pertanyaan bersamaan dengan gambarnya.');
    }

    try {
        // Reaction Loading
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let imageBuffer = null;
        
        // Mengunduh buffer gambar jika pengguna mengirimkan foto
        if (isImage) {
            imageBuffer = await q.download();
        }

        const response = await mathgpt({ 
            query: query, 
            enableReasoning: false, 
            attachedImage: imageBuffer 
        });

        if (!response.success || !response.result) {
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return reply(`❌ Gagal menyelesaikan soal. Error: ${response.message || 'Unknown Error'}`);
        }

        // Mengirimkan hasil jawaban AI
        await reply(`*MATH GPT*\n\n${response.result.answer}`);

        // Reaction Sukses
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[MATHGPT ERROR]', e);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return reply('❌ Terjadi kesalahan pada sistem saat memproses soal matematika.');
    }
};

handler.help = ['mathgpt <soal>'];
handler.tags = ['ai'];
handler.command = ['mathgpt', 'mathai', 'mtk'];

export default handler;