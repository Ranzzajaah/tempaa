const validRatios = ['1:1', '4:3', '3:4', '3:2', '2:3', '16:9', '9:16', '21:9', '5:4', '4:5']

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	if (!text) {
		return reply(`*Text to Image*\n\nContoh:\n${usedPrefix}${command} Foto cewe cantik di padang rumput style anime|1:1\n\nRatio: ${validRatios.join(', ')}`)
	}

	const [prompt, ratio] = text.split('|').map(v => v?.trim())
	const finalRatio = ratio || '1:1'

	if (!validRatios.includes(finalRatio)) {
		return reply(`Ratio tidak valid.\n\nPilihan: ${validRatios.join(', ')}`)
	}

	try {
		const url = global.API(
			'kyzz',
			'/api/ai-image/text2img2',
			{
				prompt,
				ratio: finalRatio
			},
			'apikey'
		)

		await sock.sendMessage(m.chat, {
			image: { url },
			caption: prompt
		}, { quoted: m })
	} catch (e) {
		console.error('[TEXT2IMG2 ERROR]', e.response?.data || e)
		return reply('❌ Gagal membuat gambar.')
	}
}

handler.help = ['text2img2 <prompt>|<ratio>']
handler.tags = ['ai']
handler.command = ['text2img2']

handler.register = true;

export default handler;
