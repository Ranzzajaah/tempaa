import { sendReaction } from "../../scrape/rch.js";

const toSmallCaps = (str) => {
  const smallCapsMap = {
    a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ғ", g: "ɢ", h: "ʜ", i: "ɪ",
    j: "ᴊ", k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ",
    s: "s", t: "ᴛ", u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ"
  };
  return str.toLowerCase().split("").map(c => smallCapsMap[c] || c).join("");
};

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
  const botName = global.namaBot || "Hirara AI";
  const ownerName = global.namaOwner || "Mommy kyu";

  if (!text) {
    const helpText =
      `*${toSmallCaps("reach wa")}*\n\n` +
      `📌 *Penggunaan:* ${usedPrefix}${command} <link_channel>\n` +
      `📌 *Custom Reaksi:* ${usedPrefix}${command} <link_channel> | 😈,🥵,🔥\n\n` +
      `© ${botName} • Created by ${ownerName}`;

    return reply(helpText);
  }

  let reactions = ["😂"];
  const urlMatch = text.match(/https?:\/\/(?:www\.)?whatsapp\.com\/channel\/[^\s|]+/i);

  if (!urlMatch) {
    const errUrlText = `❌ *URL TIDAK VALID*\n\nURL harus berupa link WhatsApp Channel!\n*Contoh:* https://whatsapp.com/channel/xxx/123\n\n© ${botName} • Created by ${ownerName}`;
    return reply(errUrlText);
  }

  const targetUrl = urlMatch[0];
  const remainingText = text.replace(targetUrl, "").replace(/^[\s|]+/, "").trim();

  if (remainingText) {
    const customReactions = remainingText.split(/[,|\s]+/).map(r => r.trim()).filter(Boolean);
    if (customReactions.length > 0) {
      reactions = customReactions;
    }
  }

  await reply(global.mess?.wait || "⏳ *Sedang memproses pengiriman reaksi ke WhatsApp Channel...*");

  try {
    const res = await sendReaction(targetUrl, {
      reactions,
      maxRetries: 5
    });

    if (res && res.status && res.result) {
      const reactionsText = Array.isArray(res.result.reactions) ? res.result.reactions.join(", ") : (res.result.reactions || "😂");
      const resultMsg =
        `*${toSmallCaps("reach wa")}*\n\n` +
        `🎯 *ᴛᴀʀɢᴇᴛ* : ${res.result.targetUrl || targetUrl}\n` +
        `🎭 *ʀᴇᴀᴋsɪ* : ${reactionsText}\n` +
        `👤 *ᴜsᴇʀɴᴀᴍᴇ* : ${res.result.usernameUsed || res.result.fingerprint || "Bot"}\n` +
        `💬 *sᴛᴀᴛᴜs* : ${res.result.message || "Reaction berhasil dikirim"}\n` +
        `⚡ *ᴀᴜᴛʜᴏʀ* : ${res.author || "AwasPhpJir"}\n\n` +
        `© ${botName} • Created by ${ownerName}`;

      return reply(resultMsg);
    } else {
      const errorMsg =
        `*${toSmallCaps("gagal kirim reaksi")}*\n\n` +
        `❌ *ᴀʟᴀsᴀɴ* : ${res?.error || "Terjadi kesalahan"}\n\n` +
        `© ${botName} • Created by ${ownerName}`;

      return reply(errorMsg);
    }
  } catch (err) {
    console.error("[RCH PLUGIN ERROR]", err);
    const errSysText = `❌ *Terjadi kesalahan:* ${err.message}\n\n© ${botName} • Created by ${ownerName}`;
    return reply(errSysText);
  }
};

handler.help = ["rch <link_channel>"];
handler.tags = ["premium"];
handler.command = ["rch", "reach"];
handler.premium = true;
handler.register = true;

export default handler;