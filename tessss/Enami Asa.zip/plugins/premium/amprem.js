/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { sendVerificationLink } from '../../scrape/am.js';

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
  const client = conn || sock;

  if (!text) {
    return reply(
      `✨ *ALIGHT MOTION PREMIUM VERIFICATION*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} <email>\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} user@gmail.com\`\n\n` +
      `_Bot akan mengirimkan link verifikasi Alight Motion ke email tersebut._`
    );
  }

  const email = text.trim();
  if (!email.includes('@') || !email.includes('.')) {
    return reply(`❌ Format email tidak valid! Harap masukkan email yang benar.\nContoh: \`${usedPrefix + command} user@gmail.com\``);
  }

  await reply(global.mess?.wait || '⏳ Mohon tunggu, sedang diproses...');
  if (typeof global.react === 'function') {
    await global.react(client, m, 'loading');
  }

  try {
    const res = await sendVerificationLink(email);

    if (res.status === 200) {
      if (typeof global.react === 'function') {
        await global.react(client, m, 'success');
      }
      const caption = 
        `✅ *LINK VERIFIKASI BERHASIL DIKIRIM*\n\n` +
        `📧 *Email Target:* \`${email}\`\n` +
        `💬 *Pesan:* ${res.message}\n\n` +
        `💡 *Langkah Selanjutnya:*\n` +
        `1. Cek kotak masuk / spam pada email *${email}*.\n` +
        `2. Salin *Magic Link* verifikasi yang diterima.\n` +
        `3. Kirim link verifikasi ke bot dengan perintah:\n` +
        `   \`${usedPrefix}verifam ${email} <magic_link>\`\n` +
        `   atau\n` +
        `   \`${usedPrefix}verifam <magic_link>\``;
      
      return reply(caption);
    } else {
      if (typeof global.react === 'function') {
        await global.react(client, m, 'error');
      }
      return reply(`❌ *Gagal Mengirim Link Verifikasi*\n\n💬 *Alasan:* ${res.message || global.mess?.error || 'Terjadi kesalahan'}`);
    }
  } catch (e) {
    console.error('[AMPREM ERROR]', e);
    if (typeof global.react === 'function') {
      await global.react(client, m, 'error');
    }
    return reply(`❌ *Error:* ${e.message || global.mess?.error || 'Terjadi kesalahan sistem.'}`);
  }
};

handler.help = ['amprem <email>'];
handler.tags = ['premium'];
handler.command = ['amprem', 'amrem'];
handler.limit = true;
handler.premium = true;
handler.register = true;

export default handler;
