/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { verifyMagicLink } from '../../scrape/am.js';

const extractEmailFromUrl = (urlStr) => {
  try {
    const parsed = new URL(urlStr);
    return parsed.searchParams.get('email') || parsed.searchParams.get('to') || null;
  } catch (e) {
    return null;
  }
};

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
  const client = conn || sock;

  if (!text) {
    return reply(
      `✨ *ALIGHT MOTION MAGIC LINK VERIFIER*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} <email> <magic_link>\`\n` +
      `Atau: \`${usedPrefix + command} <magic_link>\`\n\n` +
      `💡 *Contoh:* \`${usedPrefix + command} user@gmail.com https://.../verify?token=xyz\`\n\n` +
      `_Verifikasi magic link yang dikirim ke email kamu untuk menyelesaikan akun Premium Alight Motion._`
    );
  }

  const args = text.trim().split(/\s+/);
  let email = '';
  let link = '';

  if (args.length >= 2 && args[0].includes('@')) {
    email = args[0];
    link = args.slice(1).join(' ');
  } else if (args.length === 1 && (args[0].startsWith('http://') || args[0].startsWith('https://'))) {
    link = args[0];
    email = extractEmailFromUrl(link);
  } else if (args.length >= 2 && (args[args.length - 1].startsWith('http://') || args[args.length - 1].startsWith('https://'))) {
    link = args[args.length - 1];
    email = args.slice(0, args.length - 1).join(' ');
  }

  if (!link) {
    link = text.trim();
  }

  if (!email) {
    return reply(
      `❌ Email tidak terdeteksi!\n\n` +
      `Harap masukkan email dan magic link dengan format:\n` +
      `\`${usedPrefix + command} <email> <magic_link>\`\n\n` +
      `Contoh:\n\`${usedPrefix + command} test@gmail.com https://am.yappi.my.id/verify?token=...\``
    );
  }

  await reply(global.mess?.wait || '⏳ Mohon tunggu, sedang diproses...');
  if (typeof global.react === 'function') {
    await global.react(client, m, 'loading');
  }

  try {
    const res = await verifyMagicLink(email, link);

    if (res.status === 200) {
      if (typeof global.react === 'function') {
        await global.react(client, m, 'success');
      }
      const user = res.result?.user;
      
      let caption = `🎉 *VERIFIKASI ALIGHT MOTION BERHASIL!*\n\n`;
      caption += `📧 *Email:* \`${res.result?.email || email}\`\n`;
      caption += `👤 *Creator:* ${res.creator || 'Kyu:英俊的'}\n`;

      if (user && typeof user === 'object') {
        if (user.id || user.uid) caption += `🆔 *User ID:* \`${user.id || user.uid}\`\n`;
        if (user.name || user.displayName) caption += `📛 *Nama:* ${user.name || user.displayName}\n`;
        if (user.membership || user.status) caption += `⭐ *Status:* ${user.membership || user.status}\n`;
      }

      caption += `\n✨ Selamat! Akun Alight Motion kamu sekarang sudah terverifikasi.`;

      return reply(caption);
    } else {
      if (typeof global.react === 'function') {
        await global.react(client, m, 'error');
      }
      return reply(`❌ *Verifikasi Gagal*\n\n💬 *Pesan:* ${res.message || global.mess?.error || 'Link tidak valid atau telah kadaluarsa.'}`);
    }
  } catch (e) {
    console.error('[VERIFAM ERROR]', e);
    if (typeof global.react === 'function') {
      await global.react(client, m, 'error');
    }
    return reply(`❌ *Error:* ${e.message || global.mess?.error || 'Terjadi kesalahan saat memverifikasi magic link.'}`);
  }
};

handler.help = ['verifam <email> <link>', 'verifam <link>'];
handler.tags = ['premium'];
handler.command = ['verifam', 'verifalight'];
handler.limit = true;
handler.premium = true;
handler.register = true;

export default handler;
