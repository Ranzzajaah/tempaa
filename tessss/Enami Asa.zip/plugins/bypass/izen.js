/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command, reply }) => {
	const url = args[0] || (m.quoted ? (m.quoted.text || '') : '');
	if (!url) return reply(`Masukkan link yang ingin di-bypass!\n\nContoh:\n${usedPrefix + command} https://linkvertise.com/xxx`);

	const matchUrl = url.match(/https?:\/\/[^\s]+/i);
	const targetUrl = matchUrl ? matchUrl[0] : url;

	reply(global.mess?.wait || '⏳ Mohon tunggu, sedang memproses bypass link...');

	try {
		let destinationUrl = null;

		try {
			const res = await axios.get(`https://api.izen.lol/bypass`, {
				params: { url: targetUrl },
				timeout: 15000,
				headers: {
					'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
					'Accept': 'application/json'
				}
			});
			if (res.data && (res.data.result || res.data.destination || res.data.url || res.data.bypassed)) {
				destinationUrl = res.data.result || res.data.destination || res.data.url || res.data.bypassed;
			}
		} catch (e1) {
			console.log('[IZEN BYPASS API 1 FAILED]', e1.message);
		}

		if (!destinationUrl) {
			try {
				const res2 = await axios.get(`https://izen.lol/api/bypass`, {
					params: { url: targetUrl },
					timeout: 15000,
					headers: {
						'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
						'Accept': 'application/json'
					}
				});
				if (res2.data && (res2.data.result || res2.data.destination || res2.data.url || res2.data.bypassed)) {
					destinationUrl = res2.data.result || res2.data.destination || res2.data.url || res2.data.bypassed;
				}
			} catch (e2) {
				console.log('[IZEN BYPASS API 2 FAILED]', e2.message);
			}
		}

		if (!destinationUrl) {
			return reply('❌ Gagal melakukan bypass link. Pastikan link valid dan didukung oleh izen.lol.');
		}

		let caption = `🔓 *IZEN.LOL LINK BYPASS*\n\n`;
		caption += `🔗 *Original:* ${targetUrl}\n`;
		caption += `🎯 *Result:* ${destinationUrl}\n`;

		return reply(caption);
	} catch (e) {
		console.error('[IZEN BYPASS ERROR]', e.message);
		return reply('❌ Terjadi kesalahan saat melakukan bypass.');
	}
};

handler.help = ['izen <link>', 'bypassizen <link>'];
handler.tags = ['bypass'];
handler.category = 'bypass';
handler.command = ['izen'];
handler.limit = true;
handler.register = true;

export default handler;
