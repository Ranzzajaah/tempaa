/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, sock, args, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const rawUrl = args[0] || (m.quoted ? (m.quoted.text || '') : text);

	if (!rawUrl) {
		return reply(`🔓 *BYPASS SHORTLINK*\n\nMasukkan link yang ingin di-bypass!\n\nContoh:\n*${usedPrefix + command} https://example.link/xxxx*`);
	}

	const match = rawUrl.match(/https?:\/\/[^\s]+/i);
	const targetUrl = match ? match[0] : (rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/bypass/bypass', { url: targetUrl }, 'apikey');
		const { data: res } = await axios.get(apiUrl, { timeout: 30000 });

		if (!res || !res.status) {
			await global.react(client, m, 'error');
			return reply(`❌ Gagal bypass link: ${res?.message || 'Link tidak dapat diproses.'}`);
		}

		const result = res.result || res.data || res;
		const resultUrl = typeof result === 'string' ? result : (result.url || result.destinationUrl || result.destination || result.link || result.result || '-');

		let caption = `🔓 *BYPASS RESULT*\n\n`;
		caption += `🔗 *Original:* ${targetUrl}\n`;
		caption += `🎯 *Result:* ${resultUrl}\n\n`;
		caption += `© ${global.namaBot || 'Hirara AI'}`;

		await reply(caption.trim());
		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[BYPASS ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan: ${e.response?.data?.message || e.message}`);
	}
};

handler.help = ['bypass <link>'];
handler.tags = ['bypass'];
handler.command = ['bypass'];
handler.limit = true;
handler.register = true;

export default handler;
