/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command, reply }) => {
	const url = args[0] || (m.quoted ? (m.quoted.text || '') : '');
	if (!url) return reply(`Masukkan link SFL yang ingin di-bypass!\n\nContoh:\n${usedPrefix + command} <link>`);

	const matchUrl = url.match(/https?:\/\/[^\s]+/i);
	const targetUrl = matchUrl ? matchUrl[0] : url;

	reply(global.mess?.wait || '⏳ Mohon tunggu, sedang memproses bypass SFL...');

	try {
		const apiUrl = global.API('kyzz', '/api/bypass/sfl', { url: targetUrl }, 'apikey');
		const res = await axios.get(apiUrl, { timeout: 15000 });
		const data = res.data;

		if (!data?.status || !data?.result) {
			return reply('❌ Gagal melakukan bypass link SFL. Pastikan link valid.');
		}

		const { originalUrl, destinationUrl } = data.result;

		let caption = `🔓 *SFL LINK BYPASS*\n\n`;
		caption += `🔗 *Original:* ${originalUrl || targetUrl}\n`;
		caption += `🎯 *Destination:* ${destinationUrl || '-'}\n`;

		return reply(caption);
	} catch (e) {
		console.error('[SFL BYPASS ERROR]', e.message);
		return reply('❌ Terjadi kesalahan saat menghubungi server bypass.');
	}
};

handler.help = ['sfl <link>', 'bypasssfl <link>'];
handler.tags = ['bypass'];
handler.category = 'bypass';
handler.command = ['sfl', 'bypasssfl', 'sflbypass'];
handler.limit = true;
handler.register = true;

export default handler;
