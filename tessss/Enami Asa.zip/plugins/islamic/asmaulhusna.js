/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn;

	let num = parseInt(text?.trim());
	if (isNaN(num) || num < 1 || num > 99) {
		num = Math.floor(Math.random() * 99) + 1;
	}

	try {
		await global.react?.(client, m, '🕒').catch(() => {});

		const apiUrl = `https://api.kyzzz.xyz/api/islamic/asmaul-husna?nomor=${num}&apikey=kyuuimp`;
		const { data } = await axios.get(apiUrl, { timeout: 15000 });

		if (!data?.status || !data?.result) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply('❌ Gagal mengambil data Asmaul Husna.');
		}

		const res = data.result;
		const caption = `✨ *ASMAUL HUSNA* (${res.index}/99)\n\n` +
			`📖 *Arab:* ${res.arabic}\n` +
			`🔤 *Latin:* ${res.latin}\n` +
			`🇮🇩 *Arti (ID):* ${res.translation_id}\n` +
			`🇬🇧 *Arti (EN):* ${res.translation_en}\n\n` +
			`💡 *Tips:* Ketik \`${usedPrefix}${command} 1\` - \`${usedPrefix}${command} 99\` untuk nomor tertentu.`;

		await reply(caption);
		await global.react?.(client, m, '✅').catch(() => {});

	} catch (err) {
		console.error('[ASMAUL HUSNA ERROR]', err);
		await global.react?.(client, m, '❌').catch(() => {});
		return reply('❌ Terjadi kesalahan saat mengambil Asmaul Husna!');
	}
};

handler.help = ['asmaulhusna <nomor 1-99>'];
handler.tags = ['islamic'];
handler.command = ['asmaulhusna', 'asma'];
handler.limit = true;

handler.register = true;

export default handler;
