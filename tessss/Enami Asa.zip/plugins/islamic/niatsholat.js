/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn;
	let waktu = text?.trim().toLowerCase() || 'subuh';

	if (waktu === 'isya' || waktu === "isya'") waktu = 'isha';

	try {
		await global.react?.(client, m, '🕒').catch(() => {});

		const apiUrl = `https://api.kyzzz.xyz/api/islamic/niat-sholat?waktu=${encodeURIComponent(waktu)}&apikey=kyuuimp`;
		const { data } = await axios.get(apiUrl, { timeout: 15000 });

		if (!data?.status || !data?.result) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply(`❌ Niat sholat untuk waktu *${waktu}* tidak ditemukan.\nPilihan waktu: subuh, dzuhur, ashar, maghrib, isha.`);
		}

		const res = data.result;
		const caption = `🕌 *NIAT SHOLAT ${res.waktu.toUpperCase()}*\n\n` +
			`📖 *Arab:*\n${res.arabic}\n\n` +
			`🔤 *Latin:*\n${res.latin}\n\n` +
			`🇮🇩 *Terjemahan:*\n${res.translation_id}\n\n` +
			`💡 *Pilihan Waktu:* subuh, dzuhur, ashar, maghrib, isha`;

		await reply(caption);
		await global.react?.(client, m, '✅').catch(() => {});

	} catch (err) {
		console.error('[NIAT SHOLAT ERROR]', err);
		await global.react?.(client, m, '❌').catch(() => {});
		return reply('❌ Terjadi kesalahan saat mengambil Niat Sholat!');
	}
};

handler.help = ['niatsholat <waktu>'];
handler.tags = ['islamic'];
handler.command = ['niatsholat', 'niatsolat'];
handler.limit = true;

handler.register = true;

export default handler;
