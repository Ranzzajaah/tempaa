/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn;
	const kota = text?.trim() || 'Jakarta';

	try {
		await global.react?.(client, m, '🕒').catch(() => {});

		const apiUrl = `https://api.kyzzz.xyz/api/islamic/jadwal-sholat?wilayah=${encodeURIComponent(kota)}&apikey=kyuuimp`;
		const { data } = await axios.get(apiUrl, { timeout: 15000 });

		if (!data?.status || !data?.result?.today) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply(`❌ Jadwal sholat untuk wilayah *${kota}* tidak ditemukan.`);
		}

		const res = data.result;
		const today = res.today;

		const caption = `🕋 *JADWAL SHOLAT*\n\n` +
			`📍 *Wilayah:* ${res.cityName}\n` +
			`📅 *Tanggal:* Tanggal ${today.tanggal} (${today.hijriyah})\n\n` +
			`🌆 *Imsyak:* ${today.imsyak}\n` +
			`🌅 *Subuh:* ${today.subuh}\n` +
			`☀️ *Terbit:* ${today.terbit}\n` +
			`🌤️ *Dhuha:* ${today.dhuha}\n` +
			`🌞 *Dzuhur:* ${today.dzuhur}\n` +
			`🌇 *Ashar:* ${today.ashar}\n` +
			`🌆 *Maghrib:* ${today.maghrib}\n` +
			`🌌 *Isya:* ${today.isya}\n\n` +
			`💡 *Tips:* Ketik \`${usedPrefix}${command} Banjarnegara\` untuk kota lain.`;

		await reply(caption);
		await global.react?.(client, m, '✅').catch(() => {});

	} catch (err) {
		console.error('[JADWAL SHOLAT ERROR]', err);
		await global.react?.(client, m, '❌').catch(() => {});
		return reply('❌ Terjadi kesalahan saat mengambil Jadwal Sholat!');
	}
};

handler.help = ['jadwalsholat <wilayah/kota>'];
handler.tags = ['islamic'];
handler.command = ['jadwalsholat'];
handler.limit = true;

handler.register = true;

export default handler;
