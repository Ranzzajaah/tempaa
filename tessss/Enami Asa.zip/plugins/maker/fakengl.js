/**
 * Hirara AI — WhatsApp Bot
 * Feature : Fake NGL Canvas Maker (api.kyzzz.xyz)
 * Creator : Mommy Kyu
 */

import axios from 'axios';

const handler = async (m, { sock, conn, text, reply, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock || global.conn;

	if (!text) {
		return reply(
			`💌 *ꜰᴀᴋᴇ ɴɢʟ ɢᴇɴᴇʀᴀᴛᴏʀ*\n\n` +
			`• 📌 *Contoh:* \`${usedPrefix + command} Halo owner kamu siapaa\``
		);
	}

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API(
			'kyzz',
			'/api/canvas/fake-ngl',
			{
				text: text
			},
			'apikey'
		);

		const response = await axios.get(apiUrl, {
			responseType: 'arraybuffer',
			timeout: 30000,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
			}
		});

		const buffer = Buffer.from(response.data);

		await client.sendMessage(
			m.chat,
			{
				image: buffer,
				caption: `💌 *Fake NGL Message*\n💬 "${text}"`
			},
			{ quoted: m }
		);

		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[FAKENGL ERROR]:', e);
		await global.react(client, m, 'error');
		return reply('❌ Gagal membuat gambar Fake NGL.');
	}
};

handler.help = ['fakengl <teks>', 'ngl <teks>'];
handler.tags = ['maker'];
handler.command = ['fakengl', 'ngl'];
handler.limit = true;
handler.register = true;

export default handler;
