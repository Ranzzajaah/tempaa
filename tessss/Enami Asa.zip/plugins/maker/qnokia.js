/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'

const handler = async (m, { text, usedPrefix, command, sock }) => {
    if (!text) {
        return m.reply(
            `Contoh:\n${usedPrefix + command} Halo dunia|Kyzz`
        )
    }

    const [message, sender = global.wm || m.pushName] = text.split('|')

    try {
        const { data } = await axios.get(
            global.API(
                'kyzz',
                '/api/canvas/quote-nokia',
                {
                    message: message.trim(),
                    sender: sender.trim()
                },
                'apikey'
            ),
            {
                responseType: 'arraybuffer'
            }
        )

        await sock.sendMessage(
            m.chat,
            {
                image: Buffer.from(data),
                mimetype: 'image/png'
            },
            { quoted: m }
        )
    } catch (e) {
        console.error('[QUOTE NOKIA]', e)
        m.reply('❌ Gagal membuat Quote Nokia.')
    }
}

handler.help = ['quotenokia <pesan>|<nama>']
handler.tags = ['maker']
handler.command = ['quotenokia', 'qnokia']
handler.limit = true;

handler.register = true;

export default handler;
