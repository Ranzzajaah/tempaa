/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, 'fonts_memearab');
const TEMPLATE_URL = 'https://athars.space/uploads/dc077181.jpeg';

const FONT_SOURCES = [
  {
    url: 'https://github.com/google/fonts/raw/main/ofl/bebasneue/BebasNeue-Regular.ttf',
    file: 'BebasNeue-Regular.ttf',
    family: 'BebasNeue',
  },
  {
    url: 'https://github.com/google/fonts/raw/main/ofl/oswald/Oswald%5Bwght%5D.ttf',
    file: 'Oswald.ttf',
    family: 'Oswald',
  }
];

let fontsReady = false;

async function ensureFonts() {
  if (fontsReady) return;
  if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
  const { default: axios } = await import('axios');
  for (const f of FONT_SOURCES) {
    const p = join(FONT_DIR, f.file);
    if (!existsSync(p)) {
      try {
        const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
        writeFileSync(p, Buffer.from(data));
      } catch (err) {
        console.error(`[memearab-font] Failed to download ${f.file}:`, err.message);
      }
    }
    try {
      if (existsSync(p)) {
        GlobalFonts.registerFromPath(p, f.family);
      }
    } catch (err) {
      console.error(`[memearab-font] Failed to register ${f.family}:`, err.message);
    }
  }
  fontsReady = true;
}

function wrapText(ctx, text, maxWidth) {
  const words = text.split(' ');
  const lines = [];
  let currentLine = '';

  for (const word of words) {
    const testLine = currentLine ? `${currentLine} ${word}` : word;
    const width = ctx.measureText(testLine).width;
    if (width > maxWidth && currentLine) {
      lines.push(currentLine);
      currentLine = word;
    } else {
      currentLine = testLine;
    }
  }
  if (currentLine) {
    lines.push(currentLine);
  }
  return lines;
}

function getFittedLines(ctx, text, maxWidth, maxHeight, initialFontSize = 46, minFontSize = 18) {
  let fontSize = initialFontSize;
  while (fontSize >= minFontSize) {
    ctx.font = `bold ${fontSize}px BebasNeue, Oswald, sans-serif`;
    const lines = wrapText(ctx, text, maxWidth);
    const lineHeight = fontSize * 1.15;
    const totalHeight = lines.length * lineHeight;

    if (totalHeight <= maxHeight) {
      return { lines, fontSize, lineHeight };
    }
    fontSize -= 2;
  }

  ctx.font = `bold ${minFontSize}px BebasNeue, Oswald, sans-serif`;
  const lines = wrapText(ctx, text, maxWidth);
  return { lines, fontSize: minFontSize, lineHeight: minFontSize * 1.15 };
}

function drawMemeText(ctx, text, cx, startY, maxWidth, maxHeight, isTop = true) {
  if (!text) return;

  const uppercaseText = text.toUpperCase();
  const { lines, fontSize, lineHeight } = getFittedLines(ctx, uppercaseText, maxWidth, maxHeight, 46, 18);

  ctx.font = `bold ${fontSize}px BebasNeue, Oswald, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';

  const totalHeight = lines.length * lineHeight;
  let currentY = isTop ? startY + lineHeight / 2 : startY - totalHeight + lineHeight / 2;

  for (const line of lines) {
    ctx.fillText(line, cx, currentY);
    currentY += lineHeight;
  }
}

async function generateMemeArab(topText, bottomText) {
  await ensureFonts();

  const img = await loadImage(TEMPLATE_URL);
  const W = img.width; 
  const H = img.height; 

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  ctx.drawImage(img, 0, 0, W, H);

  const marginX = 24;

  const topStartY = Math.floor(H * 0.595);
  const maxTextWidth = W - marginX * 2;
  const maxTextHeightTop = H * 0.18;
  const maxTextHeightBottom = H * 0.18;

  const marginYBottom = 26;

  if (topText) {
    drawMemeText(ctx, topText, W / 2, topStartY, maxTextWidth, maxTextHeightTop, true);
  }

  if (bottomText) {
    drawMemeText(ctx, bottomText, W / 2, H - marginYBottom, maxTextWidth, maxTextHeightBottom, false);
  }

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`⚙️ *Format Salah!*\n\nGunakan:\n\`${usedPrefix}${command} teks atas | teks bawah\`\n\nContoh:\n\`${usedPrefix}${command} KETIKA KAMU | LUPA MATIKAN KOMPOR\``);
  }

  const parts = text.split('|');
  const topText = (parts[0] || '').trim();
  const bottomText = (parts[1] || '').trim();

  if (!topText && !bottomText) {
    return m.reply(`⚙️ Teks tidak boleh kosong!`);
  }

  try {
    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const imgBuffer = await generateMemeArab(topText, bottomText);

    await sock.sendMessage(m.chat, {
      image: imgBuffer,
      caption: `✨ *Meme Arab Canvas*`,
      mimetype: 'image/jpeg'
    }, { quoted: m });

    await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    console.error('[memearab-canvas]', e);
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.command = ['memearab', 'arabmeme', 'mmarab'];
handler.limit = true;
export default handler;
