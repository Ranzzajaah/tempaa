/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { downloadContentFromMessage } from '@whiskeysockets/baileys'

const formatTime = (timestamp) => {
    const d = new Date(timestamp)
    return `${String(d.getHours()).padStart(2, '0')}.${String(d.getMinutes()).padStart(2, '0')}`
}

const formatPhone = (jid) => {
    if (!jid) return ''
    const num = jid.split('@')[0].split(':')[0]

    if (!num.startsWith('62')) return `+${num}`

    const rest = num.slice(2)

    return rest.length >= 9
        ? `+62 ${rest.slice(0, 3)}-${rest.slice(3, 7)}-${rest.slice(7)}`
        : `+62 ${rest}`
}

async function downloadImage(msg) {
    if (!msg?.message?.imageMessage) return null
    const stream = await downloadContentFromMessage(
        msg.message.imageMessage,
        'image'
    )

    let buffer = Buffer.alloc(0)

    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk])
    }

    return {
        buffer,
        mime: msg.message.imageMessage.mimetype || 'image/jpeg'
    }
}

const handler = async (m, {sock, usedPrefix, command, reply}) => {
    const q = m.quoted

    if (!q) {
        return m.reply(`Reply pesan yang ingin dijadikan QWA.\n\nContoh:\n${usedPrefix + command}`)
    }

    try {
        reply(global.mess.wait)

        let senderAvatar = ''
        try {
            senderAvatar = await sock.profilePictureUrl(q.sender, 'image').catch(() => '')
        } catch {}

        let rawSender = q.sender ? q.sender.split('@')[0].split(':')[0] : ''
        let displayName = ''
        try {
            displayName = await sock.getName(q.sender).catch(() => '')
        } catch {}

        if (!displayName || /^\d+$/.test(displayName) || displayName.includes('@')) {
            displayName =
                (q.pushName && !q.pushName.includes('@') ? q.pushName : null) ||
                (q.name && !q.name.includes('@') ? q.name : null) ||
                rawSender
        }

        if (!displayName.startsWith('~')) {
            displayName = `~ ${displayName}`
        }

        let senderImage = ''
        let messageText = q.text || q.caption || ''

        if (q.message?.imageMessage) {
            const imgData = await downloadImage(q)
            if (imgData) {
                senderImage = `data:${imgData.mime};base64,${imgData.buffer.toString('base64')}`
            }
            messageText = q.caption || ''
        }

        let replyData = null
        if (q.quoted) {
            const qq = q.quoted
            let rawQqSender = qq.sender ? qq.sender.split('@')[0].split(':')[0] : ''
            let replyName = ''
            try {
                replyName = await sock.getName(qq.sender).catch(() => '')
            } catch {}
            if (!replyName || /^\d+$/.test(replyName) || replyName.includes('@')) {
                replyName =
                    (qq.pushName && !qq.pushName.includes('@') ? qq.pushName : null) ||
                    (qq.name && !qq.name.includes('@') ? qq.name : null) ||
                    rawQqSender
            }

            let replyText = qq.text || qq.caption || ''
            let replyImage = ''

            if (qq.message?.imageMessage) {
                const imgData = await downloadImage(qq)
                if (imgData) {
                    replyImage = `data:${imgData.mime};base64,${imgData.buffer.toString('base64')}`
                }
                if (!replyText) replyText = '📷 Foto'
            }

            replyData = {
                name: replyName,
                number: formatPhone(qq.sender),
                text: replyText,
                image: replyImage
            }
        }

        const payload = {
            sender_name: displayName,
            sender_number: formatPhone(q.sender),
            sender_avatar: senderAvatar,
            sender_image: senderImage,
            message: messageText,
            time: formatTime(q.messageTimestamp ? q.messageTimestamp * 1000 : Date.now()),
            background: true
        }

        if (replyData) {
            payload.reply = replyData
            payload.quoted = replyData
            payload.reply_name = replyData.name
            payload.reply_text = replyData.text
            payload.reply_number = replyData.number
        }

        const res = await fetch('https://qwa.eeq.my.id/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        })

        if (!res.ok) throw new Error(await res.text())

        const buffer = Buffer.from(await res.arrayBuffer())

        await sock.sendMessage(
            m.chat,
            {
                image: buffer
            },
            {
                quoted: m
            }
        )
    } catch (e) {
        console.error('[QWA]', e)
        m.reply(`❌ ${e.message}`)
    }
}

handler.help = ['qwa']
handler.tags = ['maker']
handler.command = ['qwa']
handler.limit = true;
handler.register = true;

export default handler;
