/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || '';
	let txt = text || (m.quoted ? (m.quoted.text || m.quoted.caption) : '');

	if (!txt) return reply(`Ketik teksnya!\nContoh: ${usedPrefix + command} lawak`);

	try {
		let imgBuffer = null;
		if (/image/.test(mime) && typeof q.download === 'function') {
			imgBuffer = await q.download().catch(() => null);
		}
		if (!imgBuffer) {
			const fs = await import('fs');
			const path = await import('path');
			const localAv = path.join(process.cwd(), 'src/avatar_contact.png');
			const pfp = await client.profilePictureUrl(m.sender, 'image').catch(() => null);
			if (pfp) {
				const res = await axios.get(pfp, { responseType: 'arraybuffer' });
				imgBuffer = Buffer.from(res.data);
			} else if (fs.existsSync(localAv)) {
				try { imgBuffer = fs.readFileSync(localAv); } catch (_) {}
			} else {
				const res = await axios.get('https://files.catbox.moe/sd61v3.jpg', { responseType: 'arraybuffer' });
				imgBuffer = Buffer.from(res.data);
			}
		}

		const form = new FormData();
		form.append('image', imgBuffer, 'image.png');
		form.append('txt', txt);
		form.append('menuTimeStr', '');

		const apiUrl = global.API('kyzz', '/api/canvas/igqc', {}, 'apikey');
		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer'
		});

		await client.sendMessage(m.chat, { image: Buffer.from(res.data) }, { quoted: m });
	} catch (e) {
		reply(`Error: ${e.message}`);
	}
};

handler.help = ['igc <teks>'];
handler.tags = ['maker'];
handler.command = ['igc', 'igqc'];
handler.limit = true;
handler.register = true;

export default handler;
