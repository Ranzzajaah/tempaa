/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(`Masukkan nama!\n\nContoh:\n${usedPrefix + command} Ujang`);
	}

	try {
		const apiUrl = global.API('kyzz', '/api/canvas/sertifikat-tolol', { name: text }, 'apikey');
		const res = await axios.get(apiUrl, { responseType: 'arraybuffer' });

		await client.sendMessage(m.chat, {
			image: Buffer.from(res.data),
			caption: `Sertifikat Tolol: *${text}*`
		}, { quoted: m });
	} catch (e) {
		reply(`Error: ${e.message}`);
	}
};

handler.help = ['sertifikattolol <nama>'];
handler.tags = ['maker'];
handler.command = ['sertifikattolol', 'sertitolol'];
handler.limit = true;
handler.register = true;

export default handler;
