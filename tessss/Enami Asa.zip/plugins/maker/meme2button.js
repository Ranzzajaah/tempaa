import axios from 'axios';

const handler = async (m, { sock, text, usedPrefix, command }) => {
    // Contoh penggunaan: .twobuttons Scroll Fesnuk | Ngoding | Gue pas deadline
    if (!text) {
        return m.reply(
            `📌 *Cara Penggunaan:*` +
            `\n• \`${usedPrefix + command} Teks1 | Teks2 | Teks3\`` +
            `\n\n*Contoh:*\n• \`${usedPrefix + command} Scroll Fesnuk | Ngoding | Gue pas deadline\``
        );
    }

    const parts = text.split('|').map(v => v.trim());
    const teks1 = parts[0] || '';
    const teks2 = parts[1] || '';
    const teks3 = parts[2] || 'Meme Generator';

    if (!teks1 || !teks2) {
        return m.reply(`❌ Harap masukkan minimal dua teks!\nContoh: \`${usedPrefix + command} Teks Atas | Teks Bawah\``);
    }

    try {
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        // Memanggil global.API yang sudah didefinisikan di settings.js
        // Parameter ke-4 (true / 'apikey') berfungsi untuk memicu penambahan apikey dari global.APIKeys
        const apiUrl = global.API('kyzz', '/api/meme/meme-twobuttons', {
            teks1,
            teks2,
            teks3
        }, true);

        // Ambil buffer gambar dari URL API
        const res = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 25000 });
        const buffer = Buffer.from(res.data);

        if (!buffer || buffer.length < 100) {
            throw new Error('Gagal memuat gambar meme dari server API.');
        }

        const caption = `🖼️ *MEME TWO BUTTONS*` +
                        `\n├ 🔤 Teks 1: ${teks1}` +
                        `\n├ 🔤 Teks 2: ${teks2}` +
                        `\n└ 🔤 Teks 3: ${teks3}`;

        await sock.sendMessage(m.chat, {
            image: buffer,
            caption: caption
        }, { quoted: m });

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[MEME TWOBUTTONS ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply(`❌ Terjadi kesalahan saat membuat meme: ${error.message || error}`);
    }
};

handler.help = ['twobuttons <teks1> | <teks2> | <teks3>'];
handler.tags = ['maker', 'tools'];
handler.command = ['twobuttons', 'meme2button', 'twobutton'];

export default handler;