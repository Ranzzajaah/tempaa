/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';
import { downloadMediaMessage } from '@whiskeysockets/baileys';

const getMediaBuffer = async (sock, msgObj) => {
	try {
		const realMsg = msgObj.fakeObj ? msgObj.fakeObj : (msgObj.message ? msgObj : { message: msgObj.msg || msgObj, key: msgObj.key || {} });
		return await downloadMediaMessage(realMsg, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage });
	} catch (e) {
		try {
			if (typeof sock.downloadMediaMessage === 'function') {
				return await sock.downloadMediaMessage(msgObj);
			}
		} catch (err) {
			console.error('[GET MEDIA BUFFER ERROR]', err.message);
		}
	}
	return null;
};

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn;

	const q = m.quoted ? m.quoted : m;
	const inner = q.message || q.msg || q;
	const mime = q.mimetype || q.mediaType || inner.mimetype || inner.imageMessage?.mimetype || '';
	const mtype = q.mtype || inner.mtype || '';

	const isImage = /image/.test(mime) || mtype === 'imageMessage' || !!inner.imageMessage;

	if (!isImage) {
		return reply(`Kirim atau balas gambar dengan caption:\n*${usedPrefix}${command} nama | durasi*\n\nContoh:\n*${usedPrefix}${command} Bini | 01:08:00*\n*${usedPrefix}${command} Ayang*`);
	}

	let nama = 'Bini';
	let durasi = '00:15:30';

	const input = (text || '').trim();
	if (input) {
		if (input.includes('|')) {
			const split = input.split('|');
			nama = split[0].trim() || nama;
			durasi = split[1].trim() || durasi;
		} else {
			nama = input;
		}
	} else if (m.pushName) {
		nama = m.pushName;
	}

	try {
		await global.react?.(client, m, '🕒').catch(() => {});

		const mediaBuffer = await getMediaBuffer(client, q);
		if (!mediaBuffer || mediaBuffer.length === 0) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply('❌ Gagal mengunduh foto profil!');
		}

		const form = new FormData();
		form.append('profile', mediaBuffer, { filename: 'profile.jpg', contentType: 'image/jpeg' });
		form.append('nama', nama);
		form.append('durasi', durasi);

		const apiUrl = 'https://api.kyzzz.xyz/api/canvas/fake-call?apikey=kyuuimp';

		const response = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer',
			timeout: 60000
		});

		const resultBuffer = Buffer.from(response.data);

		if (!resultBuffer || resultBuffer.length === 0) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply('❌ Gagal membuat gambar fake call.');
		}

		await client.sendMessage(m.chat, {
			image: resultBuffer,
			caption: `📞 *FAKE CALL*\n\n👤 *Nama:* ${nama}\n⏱️ *Durasi:* ${durasi}`
		}, { quoted: m });

		await global.react?.(client, m, '✅').catch(() => {});

	} catch (err) {
		console.error('[FAKE CALL ERROR]', err);
		await global.react?.(client, m, '❌').catch(() => {});
		return reply('❌ Terjadi kesalahan saat membuat fake call!');
	}
};

handler.help = ['fakecall <nama | durasi>', 'fc <nama | durasi>'];
handler.tags = ['maker'];
handler.command = ['fakecall', 'fc', 'fakevc'];
handler.limit = true;

handler.register = true;

export default handler;
