/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import sharp from "sharp"
import { addExif, videoToWebp } from "../../lib/webp.js"
import { getActiveThumbBuffer } from "../../lib/thumb.js"

const activeSessions = new Set()

const themes = {
  white: { label: 'White' },
  black: { label: 'Black' },
  green: { label: 'Green' },
  pink: { label: 'Pink' }
}

const isFromButton = (text) => /\|(white|black|green|pink)(\s+--gif)?$/i.test(text)

const toSmallCaps = (text) => {
  const map = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
    j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
    s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ',
    A: 'ᴀ', B: 'ʙ', C: 'ᴄ', D: 'ᴅ', E: 'ᴇ', F: 'ғ', G: 'ɢ', H: 'ʜ', I: 'ɪ',
    J: 'ᴊ', K: 'ᴋ', L: 'ʟ', M: 'ᴍ', N: 'ɴ', O: 'ᴏ', P: 'ᴘ', Q: 'ǫ', R: 'ʀ',
    S: 's', T: 'ᴛ', U: 'ᴜ', V: 'ᴠ', W: 'ᴡ', X: 'x', Y: 'ʏ', Z: 'ᴢ'
  }
  return String(text).split('').map(c => map[c] || c).join('')
}

const handler = async (m, { sock, conn, text, reply, usedPrefix, command }) => {
  const client = sock || conn || global.mainSock

  if (!text) {
    return reply(
      `*${toSmallCaps('brat generator')}*\n\n` +
      `*${toSmallCaps('brat standard')}*\n` +
      `• \`${usedPrefix}brat <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratpink <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratgreen <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratblack <${toSmallCaps('teks')}>\`\n\n` +
      `*${toSmallCaps('brat multi baris')}*\n` +
      `• \`${usedPrefix}bratv2 <${toSmallCaps('teks1 | teks2 | teks3')}>\`\n\n` +
      `*${toSmallCaps('brat video')}*\n` +
      `• \`${usedPrefix}bratvid <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvidv2 <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvidpink <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvidgreen <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvidblack <${toSmallCaps('teks')}>\`\n\n` +
      `*${toSmallCaps('special character')}*\n` +
      `• \`${usedPrefix}bratgojo <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratgojov <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvermeil <${toSmallCaps('teks')}>\`\n` +
      `• \`${usedPrefix}bratvidvermeil <${toSmallCaps('teks')}>\``
    )
  }

  const userJid = m.sender || m.key?.participant || m.chat
  const cmdLower = command.toLowerCase()

  let mode = 'brat' 
  let directTheme = 'white'
  let isDirectCmd = false

  if (cmdLower === 'bratv2_guide') {
    return reply(
      `*${toSmallCaps('panduan format brat v2')}*\n\n` +
      `${toSmallCaps('fitur brat v2 membutuhkan format pemisah tanda garis')} (\`|\`)\n\n` +
      `${toSmallCaps('contoh penggunaan')}:\n` +
      `• \`${usedPrefix}bratv2 ${text.trim()} | ${toSmallCaps('baris dua')} | ${toSmallCaps('baris tiga')}\`\n\n` +
      `${toSmallCaps('catatan')}:\n` +
      `• ${toSmallCaps('minimal 1 baris, maksimal 3 baris teks')}\n` +
      `• ${toSmallCaps('bisa juga langsung ketik')} \`${usedPrefix}brat teks1 | teks2 | teks3\``
    )
  }

  if (cmdLower === 'bratgojo') {
    mode = 'gojo'
    isDirectCmd = true
  } else if (cmdLower === 'bratgojov' || cmdLower === 'bratvidgojo') {
    mode = 'gojov'
    isDirectCmd = true
  } else if (cmdLower === 'bratvermeil' || cmdLower === 'bratvermail') {
    mode = 'vermeil'
    isDirectCmd = true
  } else if (cmdLower === 'bratvidvermeil' || cmdLower === 'bratvidvermail' || cmdLower === 'bratvermeilv' || cmdLower === 'bratvermailv') {
    mode = 'vermeilv'
    isDirectCmd = true
  } else if (cmdLower === 'bratvidv2') {
    mode = 'bratvidv2'
    isDirectCmd = true
  } else if (cmdLower === 'bratvid' || cmdLower === 'bratv') {
    mode = 'bratvid'
    isDirectCmd = true
  } else if (cmdLower === 'bratv2') {
    mode = 'bratv2'
    isDirectCmd = true
  } else if (cmdLower === 'bratpink') {
    mode = 'brat'
    directTheme = 'pink'
    isDirectCmd = true
  } else if (cmdLower === 'bratgreen') {
    mode = 'brat'
    directTheme = 'green'
    isDirectCmd = true
  } else if (cmdLower === 'bratblack') {
    mode = 'brat'
    directTheme = 'black'
    isDirectCmd = true
  } else if (cmdLower === 'bratvidpink') {
    mode = 'bratvid'
    directTheme = 'pink'
    isDirectCmd = true
  } else if (cmdLower === 'bratvidgreen') {
    mode = 'bratvid'
    directTheme = 'green'
    isDirectCmd = true
  } else if (cmdLower === 'bratvidblack') {
    mode = 'bratvid'
    directTheme = 'black'
    isDirectCmd = true
  }

  const fromButton = isFromButton(text)

  if (!fromButton && !isDirectCmd && !/--gif/i.test(text) && !text.includes('|')) {
    const teksInput = text.trim()
    if (!teksInput) return reply(toSmallCaps('teks tidak boleh kosong'))

    const thumb = await getActiveThumbBuffer().catch(() => null)
    const themeKeys = Object.keys(themes)

    const imageRows = themeKeys.map(key => ({
      title: toSmallCaps(`${themes[key].label} theme`),
      description: toSmallCaps(`brat image tema ${themes[key].label}`),
      id: `${usedPrefix}brat ${teksInput}|${key}`
    }))

    const gifRows = themeKeys.map(key => ({
      title: toSmallCaps(`${themes[key].label} theme (gif)`),
      description: toSmallCaps(`brat video tema ${themes[key].label}`),
      id: `${usedPrefix}bratvid ${teksInput}|${key} --gif`
    }))

    const v2Rows = [
      {
        title: toSmallCaps('brat video v2 (60fps)'),
        description: toSmallCaps('brat video v2 per kata'),
        id: `${usedPrefix}bratvidv2 ${teksInput}`
      },
      {
        title: toSmallCaps('brat multi baris (v2)'),
        description: toSmallCaps('panduan format multi baris v2'),
        id: `${usedPrefix}bratv2_guide ${teksInput}`
      }
    ]

    const specialRows = [
      {
        title: toSmallCaps('gojo satoru image'),
        description: toSmallCaps('brat template gojo satoru'),
        id: `${usedPrefix}bratgojo ${teksInput}`
      },
      {
        title: toSmallCaps('gojo satoru video'),
        description: toSmallCaps('brat video gojo satoru'),
        id: `${usedPrefix}bratgojov ${teksInput}`
      },
      {
        title: toSmallCaps('vermeil image'),
        description: toSmallCaps('brat template vermeil'),
        id: `${usedPrefix}bratvermeil ${teksInput}`
      },
      {
        title: toSmallCaps('vermeil video'),
        description: toSmallCaps('brat video vermeil'),
        id: `${usedPrefix}bratvidvermeil ${teksInput}`
      }
    ]

    return await client.sendButtons(m.chat, {
      location: {
        degreesLatitude: 0,
        degreesLongitude: 0,
        name: toSmallCaps('brat generator'),
        address: `${toSmallCaps('teks')}: "${teksInput.slice(0, 30)}"`,
        jpegThumbnail: thumb
      },
      text: `${toSmallCaps('pilih format dan tema brat')}\n\n${toSmallCaps('teks')}: *${teksInput}*`,
      footer: `${global.packname} • ${toSmallCaps('brat generator')}`,
      buttons: [
        {
          title: toSmallCaps('pilih format brat'),
          sections: [
            {
              title: toSmallCaps('brat standard (v1)'),
              highlight_label: global.packname,
              rows: imageRows
            },
            {
              title: toSmallCaps('brat video (v1)'),
              highlight_label: global.packname,
              rows: gifRows
            },
            {
              title: toSmallCaps('brat v2'),
              highlight_label: global.packname,
              rows: v2Rows
            },
            {
              title: toSmallCaps('special character'),
              highlight_label: global.packname,
              rows: specialRows
            }
          ],
          icon: 'DEFAULT'
        }
      ]
    }, { quoted: m })
  }

  if (activeSessions.has(userJid)) {
    return reply(toSmallCaps('masih ada proses pembuatan brat yang sedang berlangsung'))
  }

  let isGif = /--gif/i.test(text) || mode === 'bratvid' || mode === 'bratvidv2' || mode === 'gojov' || mode === 'vermeilv'
  let cleanText = text.replace(/--gif/gi, '').trim()
  let teksInput = ''
  let themeInput = isDirectCmd ? directTheme : 'white'

  if (fromButton) {
    const lastPipeIndex = cleanText.lastIndexOf('|')
    const rawTeks = cleanText.slice(0, lastPipeIndex).trim()
    const rawTheme = cleanText.slice(lastPipeIndex + 1).trim().toLowerCase()
    teksInput = rawTeks
    themeInput = themes[rawTheme] ? rawTheme : 'white'
  } else {
    teksInput = cleanText
  }

  if (!teksInput) return reply(toSmallCaps('teks tidak boleh kosong'))

  if (teksInput.includes('|') && mode === 'brat') {
    mode = 'bratv2'
  }

  activeSessions.add(userJid)
  const sessionTimeout = setTimeout(() => {
    activeSessions.delete(userJid)
  }, 60000)

  reply(toSmallCaps('sedang membuat brat sticker...'))

  try {
    let buff
    let apiUrl = ''

    if (mode === 'gojo') {
      apiUrl = global.API('kyzz', '/api/maker/brat-gojo', { text: teksInput }, 'apikey')
    } else if (mode === 'gojov') {
      apiUrl = global.API('kyzz', '/api/maker/brat-gojov', { text: teksInput }, 'apikey')
    } else if (mode === 'vermeil') {
      apiUrl = global.API('kyzz', '/api/maker/brat-vermail', { text: teksInput }, 'apikey')
    } else if (mode === 'vermeilv') {
      apiUrl = global.API('kyzz', '/api/maker/bratvid-vermeil', { text: teksInput }, 'apikey')
    } else if (mode === 'bratvidv2') {
      apiUrl = global.API('kyzz', '/api/maker/bratvid-v2', {
        text: teksInput.replace(/\|/g, ' '),
        theme: themeInput,
        format: 'gif'
      }, 'apikey')
    } else if (mode === 'bratvid') {
      apiUrl = global.API('kyzz', '/api/maker/bratvid', {
        text: teksInput.replace(/\|/g, ' '),
        theme: themeInput,
        format: 'gif'
      }, 'apikey')
    } else if (mode === 'bratv2') {

      const parts = teksInput.split('|').map(s => s.trim()).filter(Boolean)
      const query = {
        text1: parts[0] || teksInput,
        theme: themeInput
      }
      if (parts[1]) query.text2 = parts[1]
      if (parts[2]) query.text3 = parts[2]
      if (parts[3] && !parts[2]) query.text3 = parts[3]

      apiUrl = global.API('kyzz', '/api/maker/brat-v2', query, 'apikey')
    } else {
      apiUrl = global.API('kyzz', '/api/maker/brat', {
        text: teksInput,
        theme: themeInput
      }, 'apikey')
    }

    const res = await fetch(apiUrl)
    if (!res.ok) throw new Error(`API error ${res.status}: ${res.statusText}`)
    buff = Buffer.from(await res.arrayBuffer())

    let stickerBuff
    if (isGif) {
      const webpBuff = await videoToWebp(buff)
      stickerBuff = await addExif(webpBuff, global.packname, global.author)
    } else {
      const webpBuff = await sharp(buff)
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 100 })
        .toBuffer()
      stickerBuff = await addExif(webpBuff, global.packname, global.author)
    }

    await client.sendMessage(m.chat, {
      sticker: stickerBuff
    }, { quoted: m })

  } catch (e) {
    console.error('[BRAT ERROR]', e)
    reply(`❌ Gagal membuat brat!\n${e.message}`)
  } finally {
    clearTimeout(sessionTimeout)
    activeSessions.delete(userJid)
  }
}

handler.help = [
  'brat <teks>',
  'bratpink <teks>',
  'bratgreen <teks>',
  'bratblack <teks>',
  'bratv2 <teks1 | teks2 | teks3>',
  'bratvid <teks>',
  'bratvidv2 <teks>',
  'bratvidpink <teks>',
  'bratvidgreen <teks>',
  'bratvidblack <teks>',
  'bratgojo <teks>',
  'bratgojov <teks>',
  'bratvermeil <teks>',
  'bratvidvermeil <teks>'
]
handler.tags = ['maker']
handler.command = [
  'brat', 'bratpink', 'bratgreen', 'bratblack',
  'bratv2', 'bratv2_guide',
  'bratvid', 'bratv', 'bratvidv2', 'bratvidpink', 'bratvidgreen', 'bratvidblack',
  'bratgojo', 'bratgojov', 'bratvidgojo',
  'bratvermeil', 'bratvermail', 'bratvidvermeil', 'bratvidvermail', 'bratvermeilv', 'bratvermailv'
]
handler.limit = true
handler.register = true

export default handler
