/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || q.mediaType || '';
	const isImage = /image/.test(mime);

	if (!text && !isImage) {
		return reply(
			`📸 *FAKE INSTAGRAM PROFILE MAKER*\n\n` +
			`Buat mockup profil Instagram custom dengan foto Anda!\n\n` +
			`📌 *Format:*\n` +
			`Kirim/reply foto dengan caption:\n` +
			`*${usedPrefix + command} username|bio|pengikut|mengikuti|postingan*\n\n` +
			`📌 *Contoh:*\n` +
			`*${usedPrefix + command} KyuuXd|hy? Just living my life ✨|100k|1|727*`
		);
	}

	const parts = text.split('|').map(v => v?.trim());
	const username = parts[0] || m.pushName || 'user_instagram';
	const bio = parts[1] || 'Welcome to my profile!';
	const pengikut = parts[2] || '10.5k';
	const mengikuti = parts[3] || '250';
	const postingan = parts[4] || '12';

	await global.react(client, m, 'loading');

	try {
		let profileBuffer = null;

		if (isImage) {
			if (typeof q.download === 'function') {
				profileBuffer = await q.download().catch(() => null);
			}
			if (!profileBuffer && client?.downloadAndSaveMediaMessage) {
				const tmpPath = await client.downloadAndSaveMediaMessage(q).catch(() => null);
				if (tmpPath) {
					const fs = await import('fs');
					profileBuffer = fs.readFileSync(tmpPath);
					try { fs.unlinkSync(tmpPath); } catch (_) {}
				}
			}
		}

		if (!profileBuffer) {
			try {
				const pfpUrl = await client.profilePictureUrl(m.sender, 'image').catch(() => null);
				if (pfpUrl) {
					const imgRes = await axios.get(pfpUrl, { responseType: 'arraybuffer', timeout: 10000 });
					profileBuffer = Buffer.from(imgRes.data);
				}
			} catch (_) {}
		}

		if (!profileBuffer) {
			const fs = await import('fs');
			const path = await import('path');
			const localAv = path.join(process.cwd(), 'src/avatar_contact.png');
			if (fs.existsSync(localAv)) {
				try { profileBuffer = fs.readFileSync(localAv); } catch (_) {}
			}
		}

		if (!profileBuffer) {
			const fallbackPfp = 'https://files.catbox.moe/sd61v3.jpg';
			const imgRes = await axios.get(fallbackPfp, { responseType: 'arraybuffer' });
			profileBuffer = Buffer.from(imgRes.data);
		}

		const form = new FormData();
		form.append('profile', profileBuffer, 'profile.jpg');
		form.append('username', username);
		form.append('bio', bio);
		form.append('pengikut', pengikut);
		form.append('mengikuti', mengikuti);
		form.append('postingan', postingan);

		const apiKey = global.APIKeys?.['https://api.kyzzz.xyz'] || 'kyuuimp';
		const apiUrl = `https://api.kyzzz.xyz/api/canvas/fakeigprofile?apikey=${apiKey}`;

		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer',
			timeout: 60000
		});

		const contentType = res.headers['content-type'] || '';
		let resultBuffer = null;

		if (contentType.includes('application/json')) {
			const jsonStr = Buffer.from(res.data).toString('utf-8');
			const json = JSON.parse(jsonStr);
			if (json.status === false || json.error) {
				throw new Error(json.message || json.error || 'Gagal membuat Fake IG Profile.');
			}
			if (json.url || json.result || json.image) {
				const imgRes = await axios.get(json.url || json.result || json.image, { responseType: 'arraybuffer' });
				resultBuffer = Buffer.from(imgRes.data);
			} else {
				throw new Error('Respon API tidak memuat gambar.');
			}
		} else {
			resultBuffer = Buffer.from(res.data);
		}

		await client.sendMessage(m.chat, {
			image: resultBuffer,
			caption: `📸 *Fake Instagram Profile: @${username}*\n\n© ${global.namaBot || 'Hirara AI'}`
		}, { quoted: m });

		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[FAKE IG ERROR]', e.message);
		await global.react(client, m, 'error');
		return reply(`❌ Terjadi kesalahan: ${e.message}`);
	}
};

handler.help = ['fakeig <user|bio|pengikut|mengikuti|postingan>', 'fakeigprofile'];
handler.tags = ['maker'];
handler.command = ['fakeig', 'fakeigprofile', 'fakeinstagram'];
handler.limit = true;
handler.register = true;

export default handler;
