/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import * as JimpModule from 'jimp';

const Jimp = JimpModule.Jimp ?? JimpModule.default ?? JimpModule;
const FRAME_URL = 'https://files.clugx.my.id/ehmVW.png';

const handler = async (m, { sock }) => {
    const react = (emoji) => sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } });

    const quoted = m.quoted ? m.quoted : m;
    const mime = (quoted.msg || quoted).mimetype || '';

    if (!mime.startsWith('image')) throw `Reply atau kirim foto dengan caption ${m.usedPrefix || '.'}mpls`;

    await react('🕒');

    try {
        const userBuf = await quoted.download?.();
        if (!userBuf) throw new Error('Gagal mengunduh gambar');

        const user = await Jimp.read(userBuf);
        const frame = await Jimp.read(FRAME_URL);

        if (typeof user.resize === 'function' && user.resize.length <= 1) {
            user.resize({ w: 1080, h: 1080 });
            frame.resize({ w: 1080, h: 1080 });
        } else {
            user.resize(1080, 1080);
            frame.resize(1080, 1080);
        }

        user.composite(frame, 0, 0);

        const buffer = typeof user.getBuffer === 'function' && user.getBuffer.length <= 1
            ? await user.getBuffer('image/png')
            : await user.getBufferAsync('image/png');

        await sock.sendMessage(m.chat, {
            image: buffer,
            caption: '🎒 MPLS'
        }, { quoted: m });

        await react('✅');
    } catch (e) {
        await react('✖️');
        throw `Gagal bikin mpls: ${e.message || e}`;
    }
};

handler.help = ['mpls'];
handler.tags = ['maker'];
handler.command = ['mpls'];
handler.limit = true;
handler.register = true;

export default handler;
