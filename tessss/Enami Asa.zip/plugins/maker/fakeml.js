/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import { uploadMedia } from '../../lib/Uploader.js';
import { getActiveThumbBuffer } from '../../lib/thumb.js';

const VALID_RANKS = ['epic', 'glory', 'gm', 'honor', 'imo'];
const DEFAULT_AVATAR = 'https://athars.space/uploads/621f5539.jpg';

const handler = async (m, { sock, text, usedPrefix, command, reply }) => {
	const botName = global.namaBot || 'Hirara AI';
	const web = global.website || 'https://api.kyzzz.xyz';

	const sendHelpMessage = async (bodyText) => {
		const footerText = `${bodyText}\n\n© ${botName}`;
		const thumb = await getActiveThumbBuffer().catch(() => null);

		if (sock?.sendButtons) {
			try {
				await sock.sendButtons(m.chat, {
					location: {
						degreesLatitude: 0,
						degreesLongitude: 0,
						name: botName,
						address: web,
						jpegThumbnail: thumb
					},
					text: '',
					footer: footerText,
					messageParams: {
						bottom_sheet: {
							in_thread_buttons_limit: 1,
							list_title: 'fake_ml',
							button_title: 'Hirara AI'
						}
					},
					contextInfo: {
						mentionedJid: [m.sender]
					}
				}, { quoted: m });
				return;
			} catch (e) {
				console.error('[SEND HELP ERROR]', e);
			}
		}
		return reply(footerText);
	};

	const quoted = m.quoted ? m.quoted : m;
	const mime = (quoted.msg || quoted).mimetype || quoted.mimetype || '';

	if (!text && !/image/.test(mime)) {
		return sendHelpMessage(
			`⚔️ *FAKE MOBILE LEGENDS CANVAS*\n\n` +
			`⚙️ *Format Penggunaan:*\n` +
			`*${usedPrefix}${command} <username>|<rank>|<border (1-16)>|<avatar_url (opsional)>*\n\n` +
			`🖼️ *Atau Reply Gambar dengan Caption:*\n` +
			`*${usedPrefix}${command} <username>|<rank>|<border (1-16)>*\n\n` +
			`📌 *Pilihan Rank:* epic, glory, gm, honor, imo\n` +
			`📌 *Pilihan Border:* 1 - 16\n\n` +
			`📌 *Contoh:*\n` +
			`*${usedPrefix}${command} KyuuXd|glory|0*`
		);
	}

	const parts = text ? text.split('|').map(v => v?.trim()) : [];
	let avatar = DEFAULT_AVATAR;
	let username = '';
	let rank = '';
	let border = '0';

	if (/image/.test(mime)) {
		try {
			await global.react(sock, m, 'loading');
			const imgBuff = quoted.download ? await quoted.download() : await sock.downloadM(quoted, 'image');
			if (imgBuff && imgBuff.length) {
				avatar = await uploadMedia(imgBuff, 'avatar.jpg');
			}
		} catch (err) {
			console.warn('[FAKE ML UPLOAD WARN]', err.message);
		}
		[username, rank, border] = parts;
	} else {
		if (parts.length >= 4 && /^https?:\/\//i.test(parts[3])) {
			[avatar, username, rank, border] = parts;
		} else {
			[username, rank, border, avatar] = parts;
			if (!avatar || !/^https?:\/\//i.test(avatar)) avatar = DEFAULT_AVATAR;
		}
	}

	if (!username || !rank) {
		return sendHelpMessage(
			`⚠️ Username dan Rank wajib diisi!\n\n` +
			`Contoh: *${usedPrefix}${command} KyuuXd|glory|1*\n` +
			`Rank tersedia: ${VALID_RANKS.join(', ')}`
		);
	}

	const rankLower = rank.toLowerCase();
	if (!VALID_RANKS.includes(rankLower)) {
		return sendHelpMessage(`⚠️ Rank tidak valid! Silakan pilih salah satu rank: *${VALID_RANKS.join(', ')}*`);
	}

	const borderNum = parseInt(border) || 0;

	await global.react(sock, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/canvas/fake-ml', {
			avatar,
			username,
			rank: rankLower,
			border: borderNum
		}, 'apikey');

		const res = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 30000 });

		await sock.sendMessage(m.chat, {
			image: Buffer.from(res.data)
		}, { quoted: m });

		await global.react(sock, m, 'success');
	} catch (e) {
		console.error('[FAKE ML ERROR]', e);
		await global.react(sock, m, 'error');
		sendHelpMessage(`❌ Gagal membuat Fake ML: ${e.message}`);
	}
};

handler.help = ['fakeml', 'fake-ml'];
handler.tags = ['maker'];
handler.command = ['fakeml', 'fake-ml'];
handler.limit = true;
handler.register = true;

export default handler;
