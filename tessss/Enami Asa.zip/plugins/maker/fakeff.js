/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import { getActiveThumbBuffer } from '../../lib/thumb.js';

const handler = async (m, { sock, text, usedPrefix, command, reply }) => {
	const botName = global.namaBot || 'Hirara AI';
	const web = global.website || 'https://api.kyzzz.xyz';

	const sendHelpMessage = async (bodyText) => {
		const footerText = `${bodyText}\n\n© ${botName}`;
		const thumb = await getActiveThumbBuffer().catch(() => null);

		if (sock?.sendButtons) {
			try {
				await sock.sendButtons(m.chat, {
					location: {
						degreesLatitude: 0,
						degreesLongitude: 0,
						name: botName,
						address: web,
						jpegThumbnail: thumb
					},
					text: '',
					footer: footerText,
					messageParams: {
						bottom_sheet: {
							in_thread_buttons_limit: 1,
							list_title: 'fake_ff',
							button_title: 'Hirara AI'
						}
					},
					contextInfo: {
						mentionedJid: [m.sender]
					}
				}, { quoted: m });
				return;
			} catch (e) {
				console.error('[SEND HELP ERROR]', e);
			}
		}
		return reply(footerText);
	};

	if (!text) {
		return sendHelpMessage(
			`🎮 *FAKE FF LOBBY CANVAS*\n\n` +
			`⚙️ *Format Penggunaan:*\n` +
			`*${usedPrefix}${command} <username>|<lobby (1-30)>*\n\n` +
			`📌 *Contoh:*\n` +
			`*${usedPrefix}${command} KyuuXd|11*`
		);
	}

	const [username, lobby] = text.split('|').map(v => v?.trim());
	if (!username || !lobby) {
		return sendHelpMessage(`⚠️ Format salah! Gunakan:\n*${usedPrefix}${command} username|lobby*\n\nContoh: *${usedPrefix}${command} KyuuXd|11*`);
	}

	const lobbyNum = parseInt(lobby);
	if (isNaN(lobbyNum) || lobbyNum < 1 || lobbyNum > 30) {
		return sendHelpMessage(`⚠️ Lobby harus berupa angka antara 1 sampai 30!`);
	}

	await global.react(sock, m, 'loading');

	try {
		const apiUrl = global.API('kyzz', '/api/canvas/fake-ff', { username, lobby: lobbyNum }, 'apikey');
		const res = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 30000 });

		await sock.sendMessage(m.chat, {
			image: Buffer.from(res.data)
		}, { quoted: m });

		await global.react(sock, m, 'success');
	} catch (e) {
		console.error('[FAKE FF ERROR]', e);
		await global.react(sock, m, 'error');
		sendHelpMessage(`❌ Gagal membuat Fake FF: ${e.message}`);
	}
};

handler.help = ['fakeff', 'fake-ff'];
handler.tags = ['maker'];
handler.command = ['fakeff', 'fake-ff'];
handler.limit = true;
handler.register = true;

export default handler;
