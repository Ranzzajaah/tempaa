/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn;
	const query = text || m.quoted?.text || '';

	if (!query) {
		return reply(`Gunakan format:\n*${usedPrefix}${command} <pertanyaan/teks>*\n\nContoh:\n*${usedPrefix}${command} Apa hukumnya Menikahi cwe Bondol?*`);
	}

	try {
		await global.react?.(client, m, '🕒').catch(() => {});

		const apiUrl = `https://api.kyzzz.xyz/api/canvas/pak-ustadz?text=${encodeURIComponent(query)}&apikey=kyuuimp`;

		const response = await axios.get(apiUrl, {
			responseType: 'arraybuffer',
			timeout: 30000
		});

		const buffer = Buffer.from(response.data);

		if (!buffer || buffer.length === 0) {
			await global.react?.(client, m, '❌').catch(() => {});
			return reply('❌ Gagal membuat gambar Pak Ustadz.');
		}

		await client.sendMessage(m.chat, {
			image: buffer,
			caption: `👳‍♂️ *PAK USTADZ MENJAWAB*\n\n❓ *Tanya:* ${query}`
		}, { quoted: m });

		await global.react?.(client, m, '✅').catch(() => {});

	} catch (err) {
		console.error('[PAK USTADZ ERROR]', err);
		await global.react?.(client, m, '❌').catch(() => {});
		return reply('❌ Terjadi kesalahan saat memproses Pak Ustadz!');
	}
};

handler.help = ['pakustadz <teks>', 'ustadz <teks>'];
handler.tags = ['maker'];
handler.command = ['pakustadz', 'ustadz', 'ustad'];
handler.limit = true;

handler.register = true;

export default handler;
