/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import FormData from 'form-data';
import axios from 'axios';

const generateNIK = () => {
	const rand = Math.floor(100000000000 + Math.random() * 900000000000);
	return `3273${rand}`;
};

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const quoted = m.quoted ? m.quoted : m;
	const mime = (quoted.msg || quoted).mimetype || quoted.mimetype || '';

	if (!/image/.test(mime)) {
		return reply(
			`🪪 *Fake KTP Maker (Full Version)*\n\n` +
			`Silakan reply/kirim foto (pas photo) dengan caption:\n\n` +
			`*Format 1 (Key=Value):*\n` +
			`› *${usedPrefix}${command} nama=HIRARA|nik=32730101001|provinsi=JAWA BARAT|kota=BANDUNG|ttl=BANDUNG, 01-01-2000|jenis_kelamin=LAKI-LAKI|golongan_darah=O|alamat=JL. MERDEKA NO. 1|rt_rw=001/002|kel_desa=CIBADUYUT|kecamatan=BOJONGLOA|agama=ISLAM|status=BELUM KAWIN|pekerjaan=SWASTA|kewarganegaraan=WNI|masa_berlaku=SEUMUR HIDUP|terbuat=BANDUNG, 01-01-2020*\n\n` +
			`*Format 2 (Posisi Pipe |):*\n` +
			`› *${usedPrefix}${command} NAMA|NIK|TTL|JENIS_KELAMIN|GOLDAR|ALAMAT|RT_RW|KEL_DESA|KECAMATAN|AGAMA|STATUS|PEKERJAAN|KEWARGANEGARAAN|MASA_BERLAKU|TERBUAT|KOTA|PROVINSI*`
		);
	}

	await sock.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

	try {
		const imgBuffer = quoted.download ? await quoted.download() : await sock.downloadM(quoted, 'image');
		if (!imgBuffer || !imgBuffer.length) throw new Error('Gagal mengunduh gambar pas photo.');

		const pushName = (m.pushName || 'USER').toUpperCase();
		const defaultKota = 'BANDUNG';

		const fields = {
			provinsi: 'JAWA BARAT',
			kota: defaultKota,
			nik: generateNIK(),
			nama: pushName,
			ttl: 'BANDUNG, 01-01-2000',
			jenis_kelamin: 'LAKI-LAKI',
			golongan_darah: 'O',
			alamat: 'JL. MERDEKA NO. 1',
			rt_rw: '001/002',
			kel_desa: 'CIBADUYUT',
			kecamatan: 'BOJONGLOA KIDUL',
			agama: 'ISLAM',
			status: 'BELUM KAWIN',
			pekerjaan: 'SWASTA',
			kewarganegaraan: 'WNI',
			masa_berlaku: 'SEUMUR HIDUP',
			terbuat: `${defaultKota}, 01-01-2020`
		};

		if (text) {
			if (text.includes('=')) {
				const pairs = text.split('|');
				for (const pair of pairs) {
					const [key, ...valArr] = pair.split('=');
					const k = key.trim().toLowerCase().replace('/', '_');
					const v = valArr.join('=').trim();
					if (k && v) {
						if (k === 'rt_rw' || k === 'rtrw' || k === 'rt') fields.rt_rw = v;
						else if (k === 'kel_desa' || k === 'kelurahan' || k === 'desa' || k === 'kel') fields.kel_desa = v;
						else if (k === 'jk' || k === 'gender' || k === 'jenis_kelamin') fields.jenis_kelamin = v;
						else if (k === 'goldar' || k === 'golongan_darah') fields.golongan_darah = v;
						else fields[k] = v;
					}
				}
			} else {
				const parts = text.split('|').map(v => v.trim());
				if (parts[0]) fields.nama = parts[0];
				if (parts[1]) fields.nik = parts[1];
				if (parts[2]) fields.ttl = parts[2];
				if (parts[3]) fields.jenis_kelamin = parts[3];
				if (parts[4]) fields.golongan_darah = parts[4];
				if (parts[5]) fields.alamat = parts[5];
				if (parts[6]) fields.rt_rw = parts[6];
				if (parts[7]) fields.kel_desa = parts[7];
				if (parts[8]) fields.kecamatan = parts[8];
				if (parts[9]) fields.agama = parts[9];
				if (parts[10]) fields.status = parts[10];
				if (parts[11]) fields.pekerjaan = parts[11];
				if (parts[12]) fields.kewarganegaraan = parts[12];
				if (parts[13]) fields.masa_berlaku = parts[13];
				if (parts[14]) fields.terbuat = parts[14];
				if (parts[15]) fields.kota = parts[15];
				if (parts[16]) fields.provinsi = parts[16];
			}
		}

		const form = new FormData();
		form.append('provinsi', fields.provinsi);
		form.append('kota', fields.kota);
		form.append('nik', fields.nik);
		form.append('nama', fields.nama);
		form.append('ttl', fields.ttl);
		form.append('jenis_kelamin', fields.jenis_kelamin);
		form.append('golongan_darah', fields.golongan_darah);
		form.append('alamat', fields.alamat);
		form.append('rt_rw', fields.rt_rw);
		form.append('rt/rw', fields.rt_rw);
		form.append('kel_desa', fields.kel_desa);
		form.append('kel/desa', fields.kel_desa);
		form.append('kecamatan', fields.kecamatan);
		form.append('agama', fields.agama);
		form.append('status', fields.status);
		form.append('pekerjaan', fields.pekerjaan);
		form.append('kewarganegaraan', fields.kewarganegaraan);
		form.append('masa_berlaku', fields.masa_berlaku);
		form.append('terbuat', fields.terbuat);

		form.append('pas_photo', imgBuffer, {
			filename: 'pas_photo.jpg',
			contentType: 'image/jpeg'
		});

		const apiUrl = global.API('kyzz', '/api/canvas/fake-ktp', {}, 'apikey');

		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer'
		});

		const resultBuffer = Buffer.from(res.data);

		await sock.sendMessage(m.chat, {
			image: resultBuffer,
			caption: `🪪 *E-KTP GENERATOR*\n\n` +
			         `◦ NIK: *${fields.nik}*\n` +
			         `◦ Nama: *${fields.nama}*\n` +
			         `◦ TTL: *${fields.ttl}*\n` +
			         `◦ Kota: *${fields.kota}*\n` +
			         `◦ Provinsi: *${fields.provinsi}*`
		}, { quoted: m });

		await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

	} catch (err) {
		console.error('[FAKE KTP ERROR]', err);
		await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
		reply(`❌ Gagal membuat Fake KTP: ${err.response?.data ? Buffer.from(err.response.data).toString() : err.message || err}`);
	}
};

handler.help = ['fakektp', 'ktpmaker'];
handler.tags = ['maker'];
handler.command = ['fakektp'];
handler.limit = true;
handler.register = true;

export default handler;
