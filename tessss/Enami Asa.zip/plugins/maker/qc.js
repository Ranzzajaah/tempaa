/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import FormData from 'form-data';
import { imageToWebp, addExif } from '../../lib/webp.js';

const DEFAULT_AVATAR = 'https://files.catbox.moe/sd61v3.jpg';

const sendReact = async (conn, sock, m, emoji) => {
	try {
		const client = conn || sock || global.mainSock;
		if (client?.sendMessage) {
			await client.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
		}
	} catch (e) {
		console.error('[QC REACT ERROR]', e.message);
	}
};

let handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	let txt = text || (m.quoted ? m.quoted.text || m.quoted.caption : '');

	if (!txt) {
		return reply(`⚠️ Masukkan teks untuk membuat Quote Sticker!\n\nContoh:\n*${usedPrefix + command} Halo Semuanya!*`);
	}

	await sendReact(conn, sock, m, '🕒');

	try {
		const sender = m.quoted ? m.quoted.sender : m.sender;

		let name = '';
		if (m.quoted && m.quoted.sender === sender) {
			name = m.quoted.pushName || m.quoted.name || m.quoted.vname || m.quoted.verifiedName || '';
		} else {
			name = m.pushName || m.pushname || m.name || m.vname || m.verifiedName || '';
		}

		if (!name || name.includes('@') || /^\d+$/.test(name.trim())) {
			try {
								const u = await getUser(sender);
				if (u) {
					const dbName = u.nama || u.name;
					if (dbName && !dbName.includes('@') && !/^\d+$/.test(dbName.trim())) {
						name = dbName;
					}
				}
			} catch (_) {}
		}

		if ((!name || name.includes('@') || /^\d+$/.test(name.trim())) && typeof client?.getName === 'function') {
			try {
				const cName = await client.getName(sender);
				if (cName && !cName.includes('@') && !/^\d+$/.test(cName.trim())) {
					name = cName;
				}
			} catch (_) {}
		}

		if (!name || name.includes('@')) {
			name = sender.split('@')[0].split(':')[0];
		}

		let pfpBuffer = null;
		try {
			const pfpUrl = await client.profilePictureUrl(sender, 'image').catch(() => null);
			if (pfpUrl) {
				const imgRes = await axios.get(pfpUrl, { responseType: 'arraybuffer', timeout: 10000 });
				if (imgRes.data && imgRes.data.length > 100) {
					pfpBuffer = Buffer.from(imgRes.data);
				}
			}
		} catch (_) {}

		if (!pfpBuffer) {
			const fs = await import('fs');
			const path = await import('path');
			const localAv = path.join(process.cwd(), 'src/avatar_contact.png');
			if (fs.existsSync(localAv)) {
				try { pfpBuffer = fs.readFileSync(localAv); } catch (_) {}
			}
		}

		if (!pfpBuffer) {
			const defaultAvatars = [
				DEFAULT_AVATAR,
				'https://i.ibb.co/3Fh9V6p/avatar-contact.png',
				'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png'
			];
			for (const avatarUrl of defaultAvatars) {
				try {
					const fallbackRes = await axios.get(avatarUrl, { responseType: 'arraybuffer', timeout: 7000 });
					if (fallbackRes.data && fallbackRes.data.length > 100) {
						pfpBuffer = Buffer.from(fallbackRes.data);
						break;
					}
				} catch (_) {}
			}
		}

		if (!pfpBuffer) {
			const svgAvatar = `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
				<rect width="512" height="512" fill="#cfd8dc"/>
				<circle cx="256" cy="190" r="90" fill="#ffffff"/>
				<path d="M256 310 c-110 0 -170 60 -170 140 L426 450 c0 -80 -60 -140 -170 -140 Z" fill="#ffffff"/>
			</svg>`;
			pfpBuffer = Buffer.from(svgAvatar);
		}

		const form = new FormData();
		form.append('media', pfpBuffer, 'avatar.jpg');
		form.append('text', txt);
		form.append('name', name);

		const apiUrl = global.API('kyzz', '/api/maker/qc', {}, 'apikey');

		const res = await axios.post(apiUrl, form, {
			headers: form.getHeaders(),
			responseType: 'arraybuffer',
			timeout: 30000
		});

		const contentType = res.headers['content-type'] || '';
		let rawBuffer = null;

		if (contentType.includes('application/json')) {
			const jsonStr = Buffer.from(res.data).toString('utf-8');
			const json = JSON.parse(jsonStr);
			if (json.status === false || json.error) {
				throw new Error(json.message || json.error || 'Gagal membuat Quote Sticker.');
			}
			if (json.url || json.result || json.image) {
				const imgRes = await axios.get(json.url || json.result || json.image, { responseType: 'arraybuffer' });
				rawBuffer = Buffer.from(imgRes.data);
			} else {
				throw new Error('Respon API tidak memuat gambar sticker.');
			}
		} else {
			rawBuffer = Buffer.from(res.data);
		}

		let stickerBuffer = null;
		const packname = global.packname || 'Hirara AI';
		const author = global.author || 'kyzz';

		try {
			const sharp = (await import('sharp')).default;
			const webpFull = await sharp(rawBuffer)
				.trim()
				.resize(512, 512, {
					fit: 'contain',
					background: { r: 0, g: 0, b: 0, alpha: 0 }
				})
				.webp()
				.toBuffer();

			stickerBuffer = await addExif(webpFull, packname, author);
		} catch (sharpErr) {
			try {
				const webpBuf = await imageToWebp(rawBuffer);
				stickerBuffer = await addExif(webpBuf, packname, author);
			} catch (convErr) {
				console.error('[QC WEBP CONVERT ERROR]', convErr);
				stickerBuffer = rawBuffer;
			}
		}

		await client.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
		await sendReact(conn, sock, m, '✅');

	} catch (e) {
		console.error('[QC ERROR]', e.message || e);
		await sendReact(conn, sock, m, '❌');
		let errorMsg = e.message;
		if (e.response?.data) {
			try {
				const parsed = JSON.parse(Buffer.from(e.response.data).toString('utf-8'));
				errorMsg = parsed.message || parsed.error || errorMsg;
			} catch (_) {}
		}
		await reply(`❌ *Gagal membuat QC:* ${errorMsg || 'Terjadi kesalahan pada server.'}`);
	}
};

handler.help = ['qc <teks>'];
handler.tags = ['maker'];
handler.command = ['qc', 'quotechat'];
handler.limit = true;
handler.register = true;

export default handler;
