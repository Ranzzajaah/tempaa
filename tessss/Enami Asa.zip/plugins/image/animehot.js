/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'

const handler = async (m, { sock, conn, reply }) => {
	const client = sock || conn
	if (global.mess?.wait) reply(global.mess.wait)

	try {
		const apiUrl = global.API('kyzz', '/api/image/anime-hot', {}, 'apikey')
		const { data } = await axios.get(apiUrl, { timeout: 20000 }).catch(() => ({ data: null }))

		let imgUrl = null
		if (typeof data === 'string' && data.startsWith('http')) {
			imgUrl = data
		} else if (data && typeof data === 'object') {
			imgUrl = data.url || data.result || data.image || data.link || (data.data && data.data.url)
		}

		if (!imgUrl) {
			imgUrl = apiUrl
		}

		const caption = `🔥 *ANIME HOT*\n\n© ${global.namaBot || 'Hirara AI'}`

		return await client.sendMessage(m.chat, {
			image: { url: imgUrl },
			caption: caption
		}, { quoted: m })

	} catch (e) {
		console.error('[ANIME HOT ERROR]', e.message)
		return reply('❌ Gagal mengambil gambar Anime Hot.')
	}
}

handler.help = ['animehot']
handler.tags = ['image', 'anime']
handler.command = ['animehot']
handler.premium = true
handler.limit = true
handler.register = true

export default handler
