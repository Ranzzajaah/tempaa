const handler = async (m, { sock, reply, text, usedPrefix, command }) => {
    // Tentukan target: m.quoted jika me-reply pesan, atau m jika pesan langsung
    const q = m.quoted ? m.quoted : m;
    
    // Deteksi mimetype media jika ada
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    
    // Prioritas teks: Input langsung > Teks dari pesan yang di-reply
    const teks = text || q.text || q.caption || q.description || '';

    // Jika tidak ada teks dan tidak ada media, tampilkan panduan
    if (!teks && !mime) {
        return reply(
            `📌 *Format Penggunaan:*\n\n` +
            `› Kirim pesan/media dengan caption: \`${usedPrefix + command} teks\`\n` +
            `› Atau balas (reply) pesan/media orang lain lalu ketik: \`${usedPrefix + command} [teks tambahan opsional]\``
        );
    }

    try {
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        // Ambil daftar member grup
        const metadata = await sock.groupMetadata(m.chat);
        const members = metadata.participants.map((u) => u.id);

        // Jika terdapat Media (Gambar, Video, Stiker, Dokumen, Audio)
        if (mime) {
            // Unduh buffer media dengan aman
            const mediaBuffer = await (q.download?.() || sock.downloadMediaMessage(q));
            if (!mediaBuffer) throw new Error('Gagal mengunduh berkas media');

            let type = 'document';
            if (/image/.test(mime)) type = 'image';
            else if (/video/.test(mime)) type = 'video';
            else if (/audio/.test(mime)) type = 'audio';
            else if (/webp/.test(mime)) type = 'sticker';

            const sendObj = {
                [type]: mediaBuffer,
                mentions: members
            };

            // Tambahkan caption & spesifikasi khusus per tipe media
            if (type === 'audio') {
                sendObj.mimetype = mime;
                sendObj.ptt = q.msg?.ptt || false; // Pertahankan format VN/Audio reguler
            } else if (type === 'document') {
                sendObj.mimetype = mime;
                sendObj.fileName = q.msg?.fileName || q.fileName || 'file';
                sendObj.caption = teks;
            } else if (type !== 'sticker') {
                sendObj.caption = teks;
            }

            // Kirim media beserta tag
            await sock.sendMessage(m.chat, sendObj, { quoted: m });

        } else {
            // Jika HANYA berupa teks
            await sock.sendMessage(m.chat, { text: teks, mentions: members }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[HIDETAG ERROR]', e);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        reply(`❌ Gagal mengirim pesan hidetag:\n${e.message || String(e)}`);
    }
};

handler.command = ['hidetag', 'ht', 'h'];
handler.admin = true;
handler.group = true;
handler.register = true;
handler.noJadiBot = true;

export default handler;