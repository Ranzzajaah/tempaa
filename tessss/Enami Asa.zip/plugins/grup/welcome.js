import moment from 'moment-timezone'

const handler = async (m, { text, reply, updateData, usedPrefix }) => {
	if (!text) return reply(`Contoh penggunaan:\n\n${usedPrefix}welcome on\n${usedPrefix}welcome off`)

	const sub = text.toLowerCase()

	if (sub === 'on') {
		await updateData('groups', m.chat, 'welcome', 1)
		return reply('Welcome aktif ✅')
	}

	if (sub === 'off') {
		await updateData('groups', m.chat, 'welcome', 0)
		return reply('Welcome dimatikan ❌')
	}

	reply('Gunakan on / off')
}

handler.onGroupUpdate = async (update, { sock, getGroup }) => {
	const { id, author, participants, action } = update
	if (!id || !participants) return

	const groupData = await getGroup(id)
	if (!groupData) return

	const now = moment().tz('Asia/Jakarta')
	const date = `${now.format('DD MMMM YYYY')} | ${now.format('HH:mm:ss')} WIB`
	const image = 'https://athars.space/uploads/c528fdc2.jpeg'
	const url = global.linkGC || 'https://chat.whatsapp.com/LlePewannNRKTuduT4u57M?s=cl&p=a&ilr=1'

	let groupName = 'Group WhatsApp', groupDesc = '', totalMembers = 0, totalAdmins = 0

	try {
		const metadata = await sock.groupMetadata(id)
		groupName = metadata.subject || 'Group WhatsApp'
		groupDesc = metadata.desc || ''
		totalMembers = metadata.participants.length
		totalAdmins = metadata.participants.filter(v => v.admin !== null).length
	} catch {
		console.log('Gagal ambil metadata grup')
	}

	const formatMessage = (template, userJid, actorJid) => {
		const userTag = `@${userJid.split('@')[0]}`
		const actorTag = actorJid ? `@${actorJid.split('@')[0]}` : 'Admin'
		return template
			.replace(/@user/gi, userTag)
			.replace(/@tag/gi, userTag)
			.replace(/@grup/gi, groupName)
			.replace(/@group/gi, groupName)
			.replace(/@desk/gi, groupDesc)
			.replace(/@desc/gi, groupDesc)
			.replace(/@member/gi, totalMembers)
			.replace(/@admin/gi, totalAdmins)
			.replace(/@date/gi, now.format('DD MMMM YYYY'))
			.replace(/@time/gi, `${now.format('HH:mm:ss')} WIB`)
			.replace(/@actor/gi, actorTag)
	}

	const sendPreview = (text, mentions) => sock.sendLinkPreview(id, {
		text: `${url}\n\n${text}`,
		url,
		title: date,
		description: "",
		thumbnail: image,
		thumbnailWidth: 768,
		thumbnailHeight: 1280,
		contextInfo: { mentionedJid: mentions }
	})

	for (const n of participants) {
		const user = typeof n === 'string' ? n : n?.id || n?.jid || ''
		if (!user) continue

		const tag = user.split('@')[0]
		const actor = author ? author.split('@')[0] : 'Admin'

		if (action === 'add' && groupData.welcome === 1) {
			const text = groupData.sWelcome
				? formatMessage(groupData.sWelcome, user, author)
				: `*Welcome!*\n\nHallo @${tag}, selamat datang di grup *${groupName}* 👋\n\n> Total member: ${totalMembers}`
			await sendPreview(text, [user])
		} else if (action === 'remove' && groupData.goodbye === 1) {
			const text = groupData.sGoodbye
				? formatMessage(groupData.sGoodbye, user, author)
				: `*Goodbye!*\n\nSelamat tinggal @${tag} 👋\n\n> Sisa member: ${totalMembers}`
			await sendPreview(text, [user])
		} else if (action === 'promote' && groupData.welcome === 1) {
			await sendPreview(
				`*Promoted!*\n\nKini @${tag} sekarang menjadi admin grup\nPromoted by @${actor}\n\n> Total admin: ${totalAdmins}`,
				[user, author]
			)
		} else if (action === 'demote' && groupData.welcome === 1) {
			await sendPreview(
				`*Demoted!*\n\nKini @${tag} bukan admin lagi\nDemoted by @${actor}\n\n> Sisa admin: ${totalAdmins}`,
				[user, author]
			)
		}
	}
}

handler.command = ['welcome']
handler.admin = true
handler.group = true

handler.register = true;

export default handler;
