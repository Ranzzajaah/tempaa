/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from "fs";
import path from "path";

const filePath = path.join(process.cwd(), "database", "absen.json");

function getAbsenData() {
	if (!fs.existsSync(filePath)) {
		const dir = path.dirname(filePath);
		if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
		fs.writeFileSync(filePath, JSON.stringify({ absensi: [] }, null, 2));
		return { absensi: [] };
	}
	try {
		return JSON.parse(fs.readFileSync(filePath, "utf-8"));
	} catch {
		return { absensi: [] };
	}
}

function saveAbsenData(data) {
	fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

const handler = async (m, { sock, command, reply, usedPrefix }) => {
	if (!m.isGroup) {
		return reply(global.mess.group);
	}

	const senderId = m.sender;
	const groupId = m.chat;
	const absenData = getAbsenData();
	const today = new Date().toISOString().split("T")[0];

	switch (command) {
		case "absen": {
			const userAbsen = absenData.absensi.find(entry => entry.id === senderId && entry.tanggal === today && entry.groupId === groupId);
			if (userAbsen) {
				return reply(`⚠️ Kamu sudah melakukan absen hari ini!
Ketik *${usedPrefix}riwayatabsen* untuk melihat riwayat absen.`);
			}

			absenData.absensi.push({
				id: senderId,
				nama: m.pushName || "Member",
				tanggal: today,
				groupId: groupId,
				timestamp: Date.now()
			});
			saveAbsenData(absenData);

			return reply(`✅ *Absen Berhasil!*
Nama: *${m.pushName || "Member"}*
Tanggal: *${today}*

Ketik *${usedPrefix}listabsen* untuk melihat daftar absen grup.`);
		}

		case "listabsen": {
			const absenListToday = absenData.absensi.filter(entry => entry.groupId === groupId && entry.tanggal === today);
			if (absenListToday.length === 0) {
				return reply(`ℹ️ Belum ada yang absen di grup ini hari ini (*${today}*).
Ketik *${usedPrefix}absen* untuk mulai absen.`);
			}

			let listText = `📋 *DAFTAR ABSEN HARI INI (${today})*

`;
			absenListToday.forEach((entry, idx) => {
				listText += `${idx + 1}. @${entry.id.split("@")[0]} - ${entry.nama || "Member"}
`;
			});

			return reply(listText.trim(), null, { mentions: absenListToday.map(e => e.id) });
		}

		case "riwayatabsen": {
			const riwayatUser = absenData.absensi.filter(entry => entry.id === senderId && entry.groupId === groupId);
			if (riwayatUser.length === 0) {
				return reply(`ℹ️ Kamu belum pernah absen di grup ini.
Ketik *${usedPrefix}absen* untuk mulai absen.`);
			}

			let riwayatText = `📜 *RIWAYAT ABSEN KAMU (${m.pushName || "Member"})*
Total: *${riwayatUser.length} kali*

`;
			riwayatUser.slice(-15).forEach((entry, idx) => {
				riwayatText += `• ${entry.tanggal}
`;
			});

			return reply(riwayatText.trim());
		}

		case "totalabsen": {
			const totalAbsenUser = absenData.absensi.filter(entry => entry.id === senderId && entry.groupId === groupId).length;
			return reply(`📊 Total kehadiran absen kamu di grup ini: *${totalAbsenUser} kali*
Ketik *${usedPrefix}riwayatabsen* untuk melihat daftar tanggal.`);
		}

		case "berhentiabsen": {
			const filtered = absenData.absensi.filter(entry => !(entry.id === senderId && entry.groupId === groupId));
			saveAbsenData({ absensi: filtered });
			return reply("🗑️ Seluruh data riwayat absen kamu di grup ini telah dihapus.");
		}

		case "rekapabsen": {
			const groupAbsen = absenData.absensi.filter(entry => entry.groupId === groupId);
			if (groupAbsen.length === 0) {
				return reply(`ℹ️ Belum ada catatan absensi di grup ini.
Ketik *${usedPrefix}absen* untuk mulai absen.`);
			}

			const userCount = {};
			groupAbsen.forEach(entry => {
				userCount[entry.id] = (userCount[entry.id] || 0) + 1;
			});

			const sorted = Object.entries(userCount).sort((a, b) => b[1] - a[1]);
			let rekapText = `📊 *REKAP KESELURUHAN ABSENSI GRUP*

`;
			sorted.forEach(([jid, count], idx) => {
				rekapText += `${idx + 1}. @${jid.split("@")[0]}: *${count} kali*
`;
			});

			return reply(rekapText.trim(), null, { mentions: sorted.map(([jid]) => jid) });
		}
	}
};

handler.help = ["absen", "listabsen", "riwayatabsen", "totalabsen", "berhentiabsen", "rekapabsen"];
handler.tags = ["grup"];
handler.command = ["absen", "listabsen", "riwayatabsen", "totalabsen", "berhentiabsen", "rekapabsen"];
handler.group = true;
handler.register = true;

export default handler;