/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	let target;

	if (m.mentionedJid?.[0]) target = m.mentionedJid[0];
	else if (m.quoted?.sender) target = m.quoted.sender;
	else if (text) {
		let clean = text.replace(/[^0-9]/g, '');
		if (clean.length < 5) return reply('Nomor tidak valid!');
		target = clean + '@s.whatsapp.net';
	}

	if (!target) return reply(`Contoh: ${usedPrefix + command} tag/reply/nomor`);

	try {
		await sock.groupParticipantsUpdate(m.chat, [target], 'remove');
		const msg = (global.defaultGroupMessages?.kick || 'ʏᴀʜʜ @user ᴛᴇʟᴀʜ ᴅɪᴋᴇʟᴜᴀʀᴋᴀɴ ᴅᴀʀɪ ɢʀᴜᴘ *@grup* 🚪🏃💨\nᴅɪᴋɪᴄᴋ ᴏʟᴇʜ: @actor')
			.replace(/@user|@tag/gi, `@${target.split('@')[0]}`)
			.replace(/@grup|@group/gi, m.metadata?.subject || 'Group WhatsApp')
			.replace(/@actor/gi, `@${m.sender.split('@')[0]}`);

		await sock.sendMessage(m.chat, {
			text: msg,
			mentions: [target, m.sender]
		}, { quoted: m });
	} catch (err) {
		console.error(err);
		reply('Gagal mengeluarkan anggota!');
	}
};

handler.command = ['kick'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;
handler.register = true;
handler.noJadiBot = true;

export default handler;
