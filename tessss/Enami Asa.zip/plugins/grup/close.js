/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { setCloseTime, clearCloseSchedule } from "../../lib/database.js";
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

const handler = async (m, { sock, reply, args, usedPrefix, command, getGroup }) => {
	const arg = (args[0] || '').toLowerCase();

	if (!arg) {
		await sock.groupSettingUpdate(m.chat, 'announcement');
		return reply('🔒 *Group Close* hanya admin yang dapat mengirim pesan!');
	}

	if (arg === 'off') {
		await clearCloseSchedule(m.chat);
		return reply('🔕 Jadwal tutup otomatis untuk grup ini dimatikan.');
	}

	if (arg === 'status') {
		const g = await getGroup(m.chat);
		return reply(g?.close_time
			? `🕒 Jadwal tutup otomatis: *${g.close_time} WIB* setiap hari.`
			: '🕒 Belum ada jadwal tutup otomatis diatur.');
	}

	if (!TIME_RE.test(arg)) {
		return reply(`Format salah!\n\nCara pakai:\n› ${usedPrefix + command}\n   _(tutup grup sekarang)_\n› ${usedPrefix + command} 22:00\n   _(jadwal tutup otomatis tiap hari jam 22:00 WIB)_\n› ${usedPrefix + command} off\n   _(matikan jadwal)_`);
	}

	await setCloseTime(m.chat, arg);
	return reply(`✅ *Jadwal tutup grup otomatis* diatur jam *${arg} WIB* setiap hari.\n\nUntuk matikan: ${usedPrefix + command} off`);
};

handler.command = ['close', 'tutup'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;

handler.register = true;

handler.noJadiBot = true;

export default handler;
