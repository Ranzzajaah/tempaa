/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import moment from 'moment-timezone';
import { isSistemSewaEnabled, setSistemSewa } from '../../lib/database.js';

const wish = () => {
	const h = moment().tz('Asia/Jakarta').hour();
	if (h >= 18) return 'Selamat Malam';
	if (h >= 15) return 'Selamat Sore';
	if (h >= 11) return 'Selamat Siang';
	if (h >= 4) return 'Selamat Pagi';
	return 'Selamat Malam';
};

const OPTIONS = {
	antilink: 'antilink',
	antidelete: 'antidelete',
	antitagsw: 'antitagsw',
	antirvo: 'antiviewonce',
	antiviewonce: 'antiviewonce',
	rvo: 'antiviewonce',
	viewonce: 'antiviewonce',
	readviewonce: 'antiviewonce',
	antitoxic: 'antitoxic',
	antibot: 'antibot',
	antisticker: 'antisticker',
	antivirtex: 'antivirtex',
	virtex: 'antivirtex',
	antispam: 'antispam',
	antiaudio: 'antiaudio',
	antifoto: 'antifoto',
	antivideo: 'antivideo',
	antidokumen: 'antidokumen',
	welcome: 'welcome',
	goodbye: 'goodbye',
	autoacc: 'autoacc',
	sistemsewa: 'sistemsewa',
	sewa: 'sistemsewa'
};

const GROUP_KEYS = [
	'antilink',
	'antidelete',
	'antitagsw',
	'antirvo',
	'antitoxic',
	'antibot',
	'antisticker',
	'antivirtex',
	'antispam',
	'antiaudio',
	'antifoto',
	'antivideo',
	'antidokumen',
	'welcome',
	'goodbye',
	'sistemsewa'
];

const ANTI_FEATURES = [
	'antilink',
	'antitoxic',
	'antibot',
	'antisticker',
	'antitagsw',
	'antivirtex',
	'antispam',
	'antiaudio',
	'antifoto',
	'antivideo',
	'antidokumen'
];

const ACTION_MODES = {
	del: 'Hapus Pesan Saja (DEL)',
	delete: 'Hapus Pesan Saja (DEL)',
	kick: 'Langsung Kick (KICK)',
	warn: 'Peringatan 3x Sebelum Kick (WARN)'
};

const handler = async (m, { args, reply, usedPrefix, command, isOwner, getGroup, updateData }) => {
	const groupDb = await getGroup(m.chat);
	const cmd = (command || '').toLowerCase();

	if (['setanti', 'setaction', 'antiaction'].includes(cmd)) {
		const targetFeature = (args[0] || '').toLowerCase().trim();
		const targetAction = (args[1] || '').toLowerCase().trim();

		if (!ANTI_FEATURES.includes(targetFeature) || !['del', 'delete', 'kick', 'warn'].includes(targetAction)) {
			let teks = `🛡️ *PENGATURAN AKSI ANTI-GRUP*\n\n`;
			teks += `*Status Aksi Saat Ini:*\n`;
			ANTI_FEATURES.forEach((f, i) => {
				const curr = groupDb[`${f}_action`] || (['antibot', 'antiaudio', 'antifoto', 'antivideo', 'antidokumen'].includes(f) ? 'del' : 'warn');
				teks += `${i + 1}. *${f}*: \`${curr.toUpperCase()}\`\n`;
			});
			teks += `\n*Format Penggunaan:*\n`;
			teks += `• \`${usedPrefix + cmd} <fitur> <kick/del/warn>\`\n\n`;
			teks += `*Pilihan Aksi:*\n`;
			teks += `• \`del\` : Hanya menghapus pesan pelanggar.\n`;
			teks += `• \`kick\` : Langsung mengeluarkan pelanggar dari grup.\n`;
			teks += `• \`warn\` : Memberikan peringatan 3x sebelum dikeluarkan.\n\n`;
			teks += `*Contoh:* \`${usedPrefix + cmd} antilink kick\``;
			return reply(teks);
		}

		const actionKey = targetAction === 'delete' ? 'del' : targetAction;
		const colName = `${targetFeature}_action`;
		await updateData('groups', m.chat, colName, actionKey);

		return reply(`✅ Berhasil mengatur aksi untuk *${targetFeature}* menjadi:\n👉 *${ACTION_MODES[actionKey]}*`);
	}

	let isEnable = false;
	let isDisable = false;
	let tokens = [];

	if (['on', 'enable', 'aktif'].includes(cmd)) {
		isEnable = true;
		tokens = args.map(a => a.toLowerCase().trim()).filter(Boolean);
	} else if (['off', 'disable', 'nonaktif'].includes(cmd)) {
		isDisable = true;
		tokens = args.map(a => a.toLowerCase().trim()).filter(Boolean);
	} else {
		const rawInput = args.join(' ').toLowerCase().trim();
		isEnable = /^(on|enable|true|1|aktif)\b/.test(rawInput);
		isDisable = /^(off|disable|false|0|nonaktif)\b/.test(rawInput);

		if (isEnable || isDisable) {
			tokens = args.slice(1).map(a => a.toLowerCase().trim()).filter(Boolean);
		}
	}

	if (!tokens.length) {
		let teks = `◦❒ *FITUR GRUP (${GROUP_KEYS.length} FITUR)*\n◦❒ ${wish()}\n\n`;

		GROUP_KEYS.forEach((key, i) => {
			const isAnti = ANTI_FEATURES.includes(key);
			const act = isAnti ? ` [${(groupDb[`${key}_action`] || (['antibot', 'antiaudio', 'antifoto', 'antivideo', 'antidokumen'].includes(key) ? 'del' : 'warn')).toUpperCase()}]` : '';
			const num = String(i + 1).padStart(2, '0');

			if (key === 'sistemsewa') {
				const isSewaOn = isSistemSewaEnabled();
				teks += `${num}. ${key} : ${isSewaOn ? '🟢 ON' : '🔴 OFF'} 👑\n`;
			} else {
				const isFeatureOn = groupDb[OPTIONS[key]] === 1;
				teks += `${num}. ${key} : ${isFeatureOn ? '🟢 ON' : '🔴 OFF'}${act}\n`;
			}
		});

		teks += `\n*Contoh Penggunaan:*\n`;
		teks += `• \`${usedPrefix}on antilink\`\n`;
		teks += `• \`${usedPrefix}on 1 3 5 10 16\`\n`;
		teks += `• \`${usedPrefix}off antisticker\`\n`;
		teks += `• \`${usedPrefix}on all\` *(Aktifkan semua)*\n`;
		teks += `• \`${usedPrefix}off all\` *(Matikan semua)*\n`;
		teks += `• \`${usedPrefix}setanti antilink kick\``;
		return reply(teks);
	}

	if (tokens.includes('all') || tokens.includes('semua')) {
		for (const key of GROUP_KEYS) {
			if (key === 'sistemsewa') {
				if (isOwner) setSistemSewa(isEnable);
			} else {
				await updateData('groups', m.chat, OPTIONS[key], isEnable ? 1 : 0);
			}
		}
		return reply(`✅ *Seluruh Fitur Grup* berhasil diubah ke *${isEnable ? 'ON 🟢' : 'OFF 🔴'}*!`);
	}

	const resolved = [];
	let hasSewa = false;

	for (const token of tokens) {
		if (/^\d+$/.test(token)) {
			const idx = parseInt(token, 10) - 1;
			if (idx >= 0 && idx < GROUP_KEYS.length) {
				const feat = GROUP_KEYS[idx];
				if (feat === 'sistemsewa') hasSewa = true;
				else if (!resolved.includes(feat)) resolved.push(feat);
			}
		} else if (token === 'sistemsewa' || token === 'sewa') {
			hasSewa = true;
		} else if (OPTIONS[token] && GROUP_KEYS.includes(OPTIONS[token])) {
			const feat = OPTIONS[token];
			if (feat === 'sistemsewa') hasSewa = true;
			else if (!resolved.includes(feat)) resolved.push(feat);
		}
	}

	if (!resolved.length && !hasSewa) {
		return reply(`❌ Tidak ada fitur valid yang ditemukan.\nKetik *${usedPrefix}on* untuk melihat daftar nomor & nama fitur grup.`);
	}

	if (hasSewa) {
		if (!isOwner) {
			reply('⚠️ Fitur *sistemsewa* hanya dapat diubah oleh Owner.');
		} else {
			setSistemSewa(isEnable);
			resolved.push('sistemsewa (Global)');
		}
	}

	for (const key of resolved) {
		if (key !== 'sistemsewa (Global)') {
			await updateData('groups', m.chat, OPTIONS[key], isEnable ? 1 : 0);
		}
	}

	const list = resolved.map(k => `• ${k}`).join('\n');
	return reply(`◦❒ Berhasil diubah ke ${isEnable ? 'ON 🟢' : 'OFF 🔴'}\n\n${list}`);
};

handler.command = ['on', 'off', 'enable', 'disable', 'settinggc', 'setanti', 'setaction', 'antiaction'];
handler.limit = true;
handler.group = true;
handler.admin = true;
handler.register = true;

export default handler;
