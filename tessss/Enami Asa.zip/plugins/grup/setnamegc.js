/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, args, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!args || args.length === 0) {
		return reply('❌ Silakan tulis nama baru untuk grup. Contoh: `.setnamegc Nama Baru`');
	}

	try {
		await client.groupUpdateSubject(m.chat, args.join(' '));
		reply('✅ Sukses mengganti nama grup');
	} catch (err) {
		console.error('[SETNAME GC ERROR]', err);
		reply(global.mess?.error || '❌ Gagal mengganti nama grup. Pastikan bot memiliki hak admin.');
	}
};

handler.help = ['setnamegc <nama baru>'];
handler.tags = ['group'];
handler.command = ['setnamegc', 'setnamagc', 'setnamegrup', 'setsubject'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;
handler.register = true;

export default handler;
