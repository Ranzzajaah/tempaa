global.db_giveaway = global.db_giveaway || new Map();

const handler = async (m, { sock, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const chatId = m.chat;
    if (!global.db_giveaway.has(chatId)) {
        return m.reply('❌ Tidak ada Giveaway yang sedang berlangsung untuk dihapus.');
    }

    global.db_giveaway.delete(chatId);
    await m.reply('🗑️ *Sesi Giveaway berhasil dibatalkan dan dihapus!*');
};

handler.help = ['deletegiveaway'];
handler.tags = ['group'];
handler.command = ['deletegiveaway', 'delgw', 'stopgw', 'batalgw'];
handler.group = true;
handler.admin = true;

export default handler;