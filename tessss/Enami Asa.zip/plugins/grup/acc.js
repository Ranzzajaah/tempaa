/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, text, args, usedPrefix, command, reply }) => {
	const cmd = command.toLowerCase();

	try {
		const pendingList = await sock.groupRequestParticipantsList(m.chat);

		if (!pendingList || pendingList.length === 0) {
			return reply('👥 *ACC Member*\n\nTidak ada permintaan bergabung (pending member) di grup ini.');
		}

		if (['listacc', 'acclist', 'accpending', 'reqlist'].includes(cmd)) {
			let caption = `┌─❒ *PENDING MEMBER REQUESTS*\n`;
			caption += `│ 💬 Total: *${pendingList.length}* orang\n│\n`;

			pendingList.forEach((req, idx) => {
				const num = req.jid.split('@')[0];
				caption += `│ ${idx + 1}. @${num}\n`;
			});

			caption += `└─\n\n📌 *Cara ACC / Menolak:*\n`;
			caption += `• \`${usedPrefix}acc all\` _(Terima semua)_\n`;
			caption += `• \`${usedPrefix}acc 1\` atau \`${usedPrefix}acc 1 2 3\` _(Terima nomor tertentu)_\n`;
			caption += `• \`${usedPrefix}rejectacc all\` _(Tolak semua)_\n`;
			caption += `• \`${usedPrefix}rejectacc 1\` _(Tolak nomor tertentu)_`;

			return sock.sendMessage(m.chat, {
				text: caption,
				mentions: pendingList.map(v => v.jid)
			}, { quoted: m });
		}

		if (['rejectacc', 'rejectall', 'reject', 'tolakacc', 'tolak'].includes(cmd)) {
			let targets = [];

			if (cmd === 'rejectall' || (args[0] && ['all', 'semua'].includes(args[0].toLowerCase()))) {
				targets = pendingList.map(v => v.jid);
			} else if (m.mentionedJid?.length) {
				targets = m.mentionedJid.filter(j => pendingList.some(p => p.jid === j));
			} else if (m.quoted?.sender) {
				if (pendingList.some(p => p.jid === m.quoted.sender)) {
					targets = [m.quoted.sender];
				}
			} else if (args.length > 0) {
				for (const arg of args) {
					const clean = arg.replace(/[^0-9]/g, '');
					if (!clean) continue;
					const idx = parseInt(clean) - 1;
					if (idx >= 0 && idx < pendingList.length) {
						targets.push(pendingList[idx].jid);
					} else {
						const targetJid = clean + '@s.whatsapp.net';
						if (pendingList.some(p => p.jid === targetJid)) {
							targets.push(targetJid);
						}
					}
				}
			}

			if (!targets.length) {
				return reply(`Gunakan:\n• \`${usedPrefix + command} all\` _(Tolak semua)_\n• \`${usedPrefix + command} 1\` _(Tolak urutan ke-1)_\n• \`${usedPrefix}listacc\` _(Lihat daftar)_`);
			}

			targets = [...new Set(targets)];
			await sock.groupRequestParticipantsUpdate(m.chat, targets, 'reject');

			const mentions = targets;
			const listText = targets.map(j => `@${j.split('@')[0]}`).join(', ');
			return sock.sendMessage(m.chat, {
				text: `❌ Berhasil menolak *${targets.length}* calon member:\n${listText}`,
				mentions
			}, { quoted: m });
		}

		let targets = [];

		if (cmd === 'accall' || (args[0] && ['all', 'semua'].includes(args[0].toLowerCase()))) {
			targets = pendingList.map(v => v.jid);
		} else if (m.mentionedJid?.length) {
			targets = m.mentionedJid.filter(j => pendingList.some(p => p.jid === j));
		} else if (m.quoted?.sender) {
			if (pendingList.some(p => p.jid === m.quoted.sender)) {
				targets = [m.quoted.sender];
			}
		} else if (args.length > 0) {
			for (const arg of args) {
				const clean = arg.replace(/[^0-9]/g, '');
				if (!clean) continue;
				const idx = parseInt(clean) - 1;
				if (idx >= 0 && idx < pendingList.length) {
					targets.push(pendingList[idx].jid);
				} else {
					const targetJid = clean + '@s.whatsapp.net';
					if (pendingList.some(p => p.jid === targetJid)) {
						targets.push(targetJid);
					}
				}
			}
		} else if (pendingList.length === 1) {
			targets = [pendingList[0].jid];
		}

		if (!targets.length) {
			let caption = `┌─❒ *PERMINTAAN BERGABUNG* (${pendingList.length})\n`;
			pendingList.forEach((req, idx) => {
				caption += `│ ${idx + 1}. @${req.jid.split('@')[0]}\n`;
			});
			caption += `└─\n\n📌 *Cara Penggunaan:*\n`;
			caption += `• \`${usedPrefix + command} all\` _(ACC semua member)_\n`;
			caption += `• \`${usedPrefix + command} 1\` _(ACC urutan ke-1)_\n`;
			caption += `• \`${usedPrefix + command} 1 2 3\` _(ACC urutan 1, 2, dan 3)_`;

			return sock.sendMessage(m.chat, {
				text: caption,
				mentions: pendingList.map(v => v.jid)
			}, { quoted: m });
		}

		targets = [...new Set(targets)];
		await sock.groupRequestParticipantsUpdate(m.chat, targets, 'approve');

		const mentions = targets;
		const listText = targets.map(j => `@${j.split('@')[0]}`).join(', ');
		return sock.sendMessage(m.chat, {
			text: `✅ Berhasil menyetujui (ACC) *${targets.length}* member baru:\n${listText}`,
			mentions
		}, { quoted: m });

	} catch (err) {
		console.error('[ACC MEMBER ERROR]', err);
		return reply('⚠️ Terjadi kesalahan saat memproses ACC member. Pastikan bot adalah Admin dan fitur persetujuan grup (Approve new members) diaktifkan.');
	}
};

handler.command = ['acc','accall','rejectacc'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;
handler.register = true;

export default handler;
