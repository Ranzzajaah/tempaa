global.db_giveaway = global.db_giveaway || new Map();

const handler = async (m, { sock, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const chatId = m.chat;
    const session = global.db_giveaway.get(chatId);

    if (!session) {
        return m.reply('❌ Tidak ada Giveaway yang sedang berlangsung di grup ini.');
    }

    let caption = `📊 *INFORMASI GIVEAWAY* 📊\n\n` +
        `🎁 *Hadiah:* ${session.prize}\n` +
        `👑 *Host:* @${session.host.split('@')[0]}\n` +
        `👥 *Total Peserta:* ${session.participants.length} Orang\n\n`;

    if (session.participants.length > 0) {
        caption += `📋 *Daftar Peserta:*\n`;
        session.participants.forEach((jid, index) => {
            caption += `${index + 1}. @${jid.split('@')[0]}\n`;
        });
    } else {
        caption += `_Belum ada peserta yang bergabung._`;
    }

    const mentions = [session.host, ...session.participants];
    await sock.sendMessage(m.chat, { text: caption.trim(), mentions }, { quoted: m });
};

handler.help = ['cekgiveaway'];
handler.tags = ['group'];
handler.command = ['cekgiveaway', 'cekgw', 'statusgw'];
handler.group = true;

export default handler;