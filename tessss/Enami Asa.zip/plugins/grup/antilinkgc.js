const handler = async (m, { args, command, usedPrefix, updateData }) => {
	const text = args[0] ? args[0].toLowerCase() : '';

	if (text === 'on') {
		await updateData('groups', m.chat, 'antilink', 1);
		return m.reply(`Fitur *Antilink* berhasil diaktifkan!`);
	}

	if (text === 'off') {
		await updateData('groups', m.chat, 'antilink', 0);
		return m.reply(`Fitur *Antilink* dimatikan.`);
	}

	return m.reply(`*Mode Switch Antilink*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);
};



handler.command = ['antilink', 'antilinkgc'];
handler.group = true;
handler.admin = true;
handler.botadmin = true;

handler.register = true;

export default handler;
