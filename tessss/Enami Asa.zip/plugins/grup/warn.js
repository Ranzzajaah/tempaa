/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getGroup, updateData } from "../../lib/database.js";
const handler = async (m, { conn, sock, text, usedPrefix, command, args, reply, isBotAdmin }) => {
	const client = conn || sock || global.mainSock;
	const chatId = m.chat;
	const group = await getGroup(chatId);

	let warnings = {};
	try {
		warnings = typeof group.warnings === 'object' ? (group.warnings || {}) : JSON.parse(group.warnings || '{}');
	} catch {
		warnings = {};
	}

	const maxWarnings = group.maxWarnings || 3;

	if (command === 'warn') {
		if (args[0] === 'max') {
			const newMax = parseInt(args[1]);
			if (isNaN(newMax) || newMax < 1) {
				return reply(`❌ *Format Salah!*\nContoh: \`${usedPrefix + command} max 5\``);
			}
			await updateData('groups', chatId, 'maxWarnings', newMax);
			return reply(`> ✅ *Batas warning grup berhasil diupdate ke: ${newMax}*`);
		}

		let target = m.mentionedJid?.[0] || (m.quoted ? (m.quoted.sender || m.quoted.participant) : null);
		if (!target) return reply('> ❌ *Reply atau tag orangnya!*');

		let reason = (text || '')
			.replace(new RegExp(`^${command}`, 'gi'), '')
			.replace(/@\d+/g, '')
			.trim() || 'Tanpa alasan';

		if (!warnings[target]) warnings[target] = [];
		warnings[target].push({ reason, time: Date.now() });

		const warnCount = warnings[target].length;

		if (warnCount >= maxWarnings) {
			if (isBotAdmin) {
				try {
					await client.groupParticipantsUpdate(chatId, [target], 'remove');
					await client.sendMessage(chatId, {
						text: `> 🚨 *MAX WARNING REACHED (${warnCount}/${maxWarnings})*\n> @${target.split('@')[0]} telah dikeluarkan dari grup.`,
						mentions: [target]
					}, { quoted: m });
				} catch {
					await reply('> ❌ *Gagal kick member, tetapi warning sudah tercatat.*');
				}
			} else {
				await client.sendMessage(chatId, {
					text: `> 🚨 *MAX WARNING REACHED (${warnCount}/${maxWarnings})*\n> @${target.split('@')[0]} mencapai batas maksimal warning.\n> _Bot bukan admin, tidak dapat melakukan kick otomatis._`,
					mentions: [target]
				}, { quoted: m });
			}
			delete warnings[target];
		} else {
			await client.sendMessage(chatId, {
				text: `> ⚠️ *PERINGATAN DIBERIKAN*\n> Target: @${target.split('@')[0]}\n> Peringatan: ${warnCount}/${maxWarnings}\n> Alasan: ${reason}`,
				mentions: [target]
			}, { quoted: m });
		}

		await updateData('groups', chatId, 'warnings', JSON.stringify(warnings));

	} else if (command === 'resetwarn') {
		let target = m.mentionedJid?.[0] || (m.quoted ? (m.quoted.sender || m.quoted.participant) : null);
		if (!target) return reply('> ❌ *Tag atau reply orangnya!*');

		if (!warnings[target] || warnings[target].length === 0) {
			return reply(`> ℹ️ @${target.split('@')[0]} tidak memiliki catatan warning.`);
		}

		delete warnings[target];
		await updateData('groups', chatId, 'warnings', JSON.stringify(warnings));

		await client.sendMessage(chatId, {
			text: `> ✅ *Warning @${target.split('@')[0]} telah direset.*`,
			mentions: [target]
		}, { quoted: m });

	} else if (command === 'listwarn') {
		let users = Object.keys(warnings).filter(u => warnings[u]?.length > 0);
		if (!users.length) return reply('> ✅ *Tidak ada member yang terkena warning di grup ini.*');

		let txt = `> ⚠️ *DAFTAR MEMBER WARNING*\n\n` +
			users.map((u, i) => `> ${i + 1}. @${u.split('@')[0]} (${warnings[u].length}/${maxWarnings})`).join('\n');

		await client.sendMessage(chatId, { text: txt, mentions: users }, { quoted: m });
	}
};

handler.help = ['warn @tag <alasan>', 'warn max <jumlah>', 'resetwarn @tag', 'listwarn'];
handler.tags = ['group'];
handler.command = /^(warn|resetwarn|listwarn)$/i;
handler.group = true;
handler.admin = true;
handler.register = true;

export default handler;
