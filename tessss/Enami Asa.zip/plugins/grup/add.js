/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	let nomor = text?.replace(/[^0-9]/g, '');

	if (m.mentionedJid?.[0]) nomor = m.mentionedJid[0].split('@')[0];
	else if (m.quoted?.sender) nomor = m.quoted.sender.split('@')[0];

	if (!nomor) return reply(`Contoh: ${usedPrefix}${command} 628xxxx`);
	if (nomor.length < 8) return reply('Nomor tidak valid!');

	const target = nomor + '@s.whatsapp.net';

	try {
		await sock.groupParticipantsUpdate(m.chat, [target], 'add');
		await sock.sendMessage(
			m.chat,
			{
				text: `Berhasil menambahkan @${nomor}`,
				mentions: [target],
			},
			{ quoted: m }
		);
	} catch (err) {
		console.error(err);
		reply('Gagal menambahkan. Nomor mungkin privat / tidak aktif / sudah di grup.');
	}
};

handler.command = ['add'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;

handler.register = true;

handler.noJadiBot = true;

export default handler;
