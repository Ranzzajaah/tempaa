const handler = async (m, { text, reply, updateData, usedPrefix }) => {
	if (!text) return reply(`Contoh penggunaan:\n\n${usedPrefix}goodbye on\n${usedPrefix}goodbye off`)

	const sub = text.toLowerCase()

	if (sub === 'on') {
		await updateData('groups', m.chat, 'goodbye', 1)
		return reply('Goodbye aktif ✅')
	}

	if (sub === 'off') {
		await updateData('groups', m.chat, 'goodbye', 0)
		return reply('Goodbye dimatikan ❌')
	}

	reply('Gunakan on / off')
}

handler.command = ['goodbye', 'bye']
handler.admin = true
handler.group = true
handler.register = true

export default handler
