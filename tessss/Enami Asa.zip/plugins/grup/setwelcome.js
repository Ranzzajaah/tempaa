/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getGroup, setGroupWelcome, setGroupGoodbye, resetGroupWelcome, resetGroupGoodbye, updateData } from "../../lib/database.js";

const handler = async (m, { text, reply, usedPrefix, command }) => {
	const groupData = await getGroup(m.chat);
	const cmd = (command || '').toLowerCase();
	const isSetWelcome = ['setwelcome', 'setwel', 'setwlc'].includes(cmd);
	const featureName = isSetWelcome ? 'Welcome' : 'Goodbye';

	if (!text) {
		const currentMsg = isSetWelcome ? groupData?.sWelcome : groupData?.sGoodbye;
		const isActive = isSetWelcome ? (groupData?.welcome === 1) : (groupData?.goodbye === 1);
		return reply(
			`*⚙️ PENGATURAN CUSTOM TEKS ${featureName.toUpperCase()}*\n\n` +
			`*Status Fitur:* ${isActive ? '✅ AKTIF' : '❌ NONAKTIF'}\n` +
			`*Penggunaan:* \`${usedPrefix}${command} <teks pesan>\`\n` +
			`*Reset ke default:* \`${usedPrefix}${command} reset\`\n\n` +
			`*Variabel yang dapat digunakan:*\n` +
			`• *@user* / *@tag* : Tag member baru/keluar\n` +
			`• *@grup* / *@group* : Nama grup\n` +
			`• *@desk* / *@desc* : Deskripsi grup\n` +
			`• *@member* : Jumlah total member\n` +
			`• *@admin* : Jumlah total admin\n` +
			`• *@date* : Tanggal saat ini\n` +
			`• *@time* : Waktu (WIB)\n` +
			`• *@actor* : Admin yang melakukan aksi (khusus promote/demote)\n\n` +
			`*Teks ${featureName} saat ini:*\n` +
			`${currentMsg ? currentMsg : '_Belum diatur (menggunakan template default)_'}`
		);
	}

	const isReset = text.toLowerCase() === 'reset' || text.toLowerCase() === 'default';

	if (isReset) {
		if (isSetWelcome) {
			await resetGroupWelcome(m.chat);
			await updateData('groups', m.chat, 'sWelcome', '').catch(() => {});
			return reply(`✅ Teks *Welcome* berhasil di-reset ke default template bot.`);
		} else {
			await resetGroupGoodbye(m.chat);
			await updateData('groups', m.chat, 'sGoodbye', '').catch(() => {});
			return reply(`✅ Teks *Goodbye* berhasil di-reset ke default template bot.`);
		}
	}

	if (isSetWelcome) {
		await setGroupWelcome(m.chat, text);
		await updateData('groups', m.chat, 'sWelcome', text).catch(() => {});
		await updateData('groups', m.chat, 'welcome', 1).catch(() => {});
		return reply(
			`✅ *Berhasil Menyimpan Custom Teks Welcome!*\n\n` +
			`📝 *Pesan Baru:*\n${text}\n\n` +
			`📌 *Fitur Welcome otomatis DIAKTIFKAN* untuk grup ini.`
		);
	} else {
		await setGroupGoodbye(m.chat, text);
		await updateData('groups', m.chat, 'sGoodbye', text).catch(() => {});
		await updateData('groups', m.chat, 'goodbye', 1).catch(() => {});
		return reply(
			`✅ *Berhasil Menyimpan Custom Teks Goodbye!*\n\n` +
			`📝 *Pesan Baru:*\n${text}\n\n` +
			`📌 *Fitur Goodbye otomatis DIAKTIFKAN* untuk grup ini.`
		);
	}
};

handler.help = ['setwelcome <teks>', 'setgoodbye <teks>'];
handler.tags = ['group'];
handler.command = ['setwelcome', 'setgoodbye', 'setwel', 'setbye', 'setwlc', 'setleft'];
handler.limit = false;
handler.admin = true;
handler.group = true;
handler.register = false;

export default handler;
