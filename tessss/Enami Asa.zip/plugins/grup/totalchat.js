import { db } from '../../lib/database.js';

// Auto-Migration Guard: Membuat tabel otomatis jika belum ada di SQLite
try {
    db.exec(`
        CREATE TABLE IF NOT EXISTS group_messages (
            group_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            count INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (group_id, user_id)
        );
    `);
} catch (_) {}

const handler = async (m, { sock, args, usedPrefix, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const subCmd = args[0]?.toLowerCase();

    // ─── 1. FITUR RESET TOTAL CHAT (KHUSUS ADMIN / OWNER) ───────────────────
    if (subCmd === 'reset' || command === 'resetpesan' || command === 'resettotalchat') {
        if (!isAdmin && !isOwner) {
            return m.reply('❌ Fitur reset total chat hanya dapat digunakan oleh *Admin Grup* atau *Owner*!');
        }

        try {
            db.prepare('DELETE FROM group_messages WHERE group_id = ?').run(m.chat);
            
            await sock.sendMessage(m.chat, { react: { text: '🗑️', key: m.key } });
            return sock.sendMessage(m.chat, {
                text: '✨ *RESET TOTAL CHAT BERHASIL!*\n\nSemua statistik jumlah pesan anggota di grup ini telah direset ke 0.'
            }, { quoted: m });
        } catch (err) {
            console.error('[RESET TOTALCHAT ERROR]', err);
            return m.reply('❌ Gagal mereset statistik chat grup.');
        }
    }

    // ─── 2. TAMPILKAN STATISTIK TOTAL CHAT SELURUH ANGGOTA GRUP ───────────────
    try {
        await sock.sendMessage(m.chat, { react: { text: '📊', key: m.key } });

        // Hitung total seluruh pesan di grup
        const totalRow = db.prepare('SELECT SUM(count) as total FROM group_messages WHERE group_id = ?').get(m.chat);
        const totalGroupChats = totalRow?.total || 0;

        // Ambil SELURUH anggota terdata di database (tanpa batasan LIMIT)
        const allSenders = db.prepare('SELECT user_id, count FROM group_messages WHERE group_id = ? ORDER BY count DESC').all(m.chat);

        // Ambil statistik pengirim pesan saat ini
        const userStat = db.prepare('SELECT count FROM group_messages WHERE group_id = ? AND user_id = ?').get(m.chat, m.sender);
        const userChats = userStat?.count || 0;

        if (!allSenders || allSenders.length === 0 || totalGroupChats === 0) {
            return sock.sendMessage(m.chat, {
                text: '📊 *STATISTIK CHAT GRUP*\n\nBelum ada riwayat obrolan yang tercatat di grup ini.'
            }, { quoted: m });
        }

        let caption = `📊 *STATISTIK TOTAL CHAT GRUP (SEMUA ANGGOTA)*\n`;
        caption += `────────────────────────────\n`;
        caption += `💬 *Total Pesan Grup:* ${totalGroupChats.toLocaleString('id-ID')}\n`;
        caption += `👥 *Total Anggota Terdata:* ${allSenders.length} Anggota\n`;
        caption += `👤 *Pesan Kamu:* ${userChats.toLocaleString('id-ID')} pesan\n`;
        caption += `────────────────────────────\n\n`;
        caption += `🏆 *DAFTAR STATISTIK CHAT ANGGOTA:*\n`;

        const mentions = [];
        allSenders.forEach((user, index) => {
            const jid = user.user_id;
            mentions.push(jid);
            const num = jid.split('@')[0];
            const rankEmoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
            const percentage = totalGroupChats > 0 ? ((user.count / totalGroupChats) * 100).toFixed(1) : 0;

            caption += `${rankEmoji} @${num} — *${user.count.toLocaleString('id-ID')}* pesan (${percentage}%)\n`;
        });

        caption += `\n💡 *Khusus Admin:*
• Ketik \`${usedPrefix}${command} reset\` untuk mereset riwayat chat grup ini.`;

        await sock.sendMessage(m.chat, {
            text: caption,
            mentions: mentions
        }, { quoted: m });

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[TOTALCHAT ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply('❌ Terjadi kesalahan saat mengambil statistik chat.');
    }
};

// ─── HOOK BEFORE: MENGHITUNG PESAN MASUK DI GRUP SECARA REAL-TIME ────────────
handler.before = async (m) => {
    if (!m.isGroup || m.isNewsletter || m.fromMe) return;

    try {
        db.prepare(`
            INSERT INTO group_messages (group_id, user_id, count)
            VALUES (?, ?, 1)
            ON CONFLICT(group_id, user_id)
            DO UPDATE SET count = count + 1
        `).run(m.chat, m.sender);
    } catch (err) {
        console.error('[TOTALCHAT BEFORE ERROR]', err);
    }
};

handler.help = ['totalchat', 'topchat', 'resettotalchat'];
handler.tags = ['group'];
handler.command = ['totalchat', 'topchat', 'cekchat', 'resettotalchat'];

export default handler;