/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { setOpenTime, clearOpenSchedule } from "../../lib/database.js";
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;

const handler = async (m, { sock, reply, args, usedPrefix, command, getGroup }) => {
	const arg = (args[0] || '').toLowerCase();

	if (!arg) {
		await sock.groupSettingUpdate(m.chat, 'not_announcement');
		return reply('🔓 *Grup Open* semua member sekarang bisa kirim pesan!');
	}

	if (arg === 'off') {
		await clearOpenSchedule(m.chat);
		return reply('🔕 Jadwal buka otomatis untuk grup ini dimatikan.');
	}

	if (arg === 'status') {
		const g = await getGroup(m.chat);
		return reply(g?.open_time
			? `🕒 Jadwal buka otomatis: *${g.open_time} WIB* setiap hari.`
			: '🕒 Belum ada jadwal buka otomatis diatur.');
	}

	if (!TIME_RE.test(arg)) {
		return reply(`Format salah!\n\nCara pakai:\n› ${usedPrefix + command}\n   _(buka grup sekarang)_\n› ${usedPrefix + command} 10:10\n   _(jadwal buka otomatis tiap hari jam 10:10 WIB)_\n› ${usedPrefix + command} off\n   _(matikan jadwal)_`);
	}

	await setOpenTime(m.chat, arg);
	return reply(`✅ *Jadwal buka grup otomatis* diatur jam *${arg} WIB* setiap hari.\n\nUntuk matikan: ${usedPrefix + command} off`);
};

handler.command = ['open', 'buka'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.botadmin = true;

handler.register = true;

handler.noJadiBot = true;

export default handler;
