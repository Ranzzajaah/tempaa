/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import welcomeHandler from '../-/welcome_event.js';

const handler = async (m, { text, args, usedPrefix, command, conn, sock, getGroup }) => {
	const client = conn || sock;

	if (!text) {
		return m.reply(
			`*Simulasi Event Grup (Welcome/Goodbye/Promote/Demote)*\n\n` +
			`Contoh Penggunaan:\n` +
			`• \`${usedPrefix}${command} welcome\` (@mention / optional)\n` +
			`• \`${usedPrefix}${command} goodbye\` (@mention / optional)\n` +
			`• \`${usedPrefix}${command} promote\` (@mention / optional)\n` +
			`• \`${usedPrefix}${command} demote\` (@mention / optional)\n\n` +
			`*Contoh:* \`${usedPrefix}${command} welcome @user\``
		);
	}

	const eventType = args[0]?.toLowerCase();
	const validEvents = {
		welcome: 'add',
		add: 'add',
		goodbye: 'remove',
		remove: 'remove',
		leave: 'remove',
		promote: 'promote',
		demote: 'demote'
	};

	const action = validEvents[eventType];
	if (!action) {
		return m.reply(
			`Event \`${eventType}\` tidak dikenal!\n\n` +
			`Pilihan event yang tersedia:\n` +
			`• \`welcome\` / \`add\`\n` +
			`• \`goodbye\` / \`remove\`\n` +
			`• \`promote\`\n` +
			`• \`demote\``
		);
	}

	const targetUser = m.mentionedJid?.[0] || m.quoted?.sender || m.sender;

	const mockGetGroup = async (jid) => {
		let realData = {};
		if (typeof getGroup === 'function') {
			try {
				realData = (await getGroup(jid)) || {};
			} catch (_) {}
		}
		return {
			...realData,
			welcome: 1,
			goodbye: 1
		};
	};

	const updatePayload = {
		id: m.chat,
		author: m.sender,
		participants: [targetUser],
		action: action
	};

	try {
		await welcomeHandler.onGroupUpdate(updatePayload, { sock: client, getGroup: mockGetGroup });
	} catch (err) {
		console.error('[SIMULATE ERROR]', err);
		m.reply(`Gagal me-simulasikan event ${eventType}: ${err.message}`);
	}
};

handler.help = ['simulate <welcome/goodbye/promote/demote> [@user]'];
handler.tags = ['grup'];
handler.category = 'grup';
handler.description = 'Me-simulasikan tampilan notifikasi welcome, goodbye, promote, dan demote grup.';
handler.command = ['simulate', 'simulasi'];
handler.limit = true;
handler.admin = true;
handler.group = true;
handler.register = true;

export default handler;
