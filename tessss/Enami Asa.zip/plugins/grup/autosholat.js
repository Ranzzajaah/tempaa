import axios from 'axios';
import { db, getGroup } from '../../lib/database.js';

// Auto-Migration Guard untuk memastikan kolom autosholat tersedia di SQLite
try { db.exec(`ALTER TABLE groups ADD COLUMN autosholat INTEGER NOT NULL DEFAULT 0`); } catch (_) {}

// Penyimpanan cache jadwal harian & tracker notifikasi yang sudah terkirim
let prayerCache = { date: '', data: null };
const sentAlerts = new Set(); // Format: chatId_sholatName_date

// Helper untuk mengambil jadwal sholat harian (Default: Jakarta / Indonesia)
async function getPrayerTimes() {
    const today = new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Jakarta' }); // Format YYYY-MM-DD
    
    if (prayerCache.date === today && prayerCache.data) {
        return prayerCache.data;
    }

    try {
        const res = await axios.get('https://api.aladhan.com/v1/timingsByCity?city=Jakarta&country=Indonesia&method=11', { timeout: 10000 });
        if (res.data?.data?.timings) {
            const t = res.data.data.timings;
            prayerCache = {
                date: today,
                data: {
                    'Imsak': t.Imsak,
                    'Subuh': t.Fajr,
                    'Dzuhur': t.Dhuhr,
                    'Ashar': t.Asr,
                    'Maghrib': t.Maghrib,
                    'Isya': t.Isha
                }
            };
            return prayerCache.data;
        }
    } catch (e) {
        console.error('[AUTOSHOLAT API ERROR]', e.message);
    }

    // Fallback static jika API gagal
    return {
        'Imsak': '04:30',
        'Subuh': '04:40',
        'Dzuhur': '12:05',
        'Ashar': '15:20',
        'Maghrib': '18:10',
        'Isya': '19:20'
    };
}

const handler = async (m, { sock, text, args, usedPrefix, command, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const subCmd = args[0]?.toLowerCase();

    // ─── 1. TOGGLE ON / OFF (KHUSUS ADMIN / OWNER) ─────────────────────────
    if (subCmd === 'on' || subCmd === '1' || subCmd === 'enable') {
        if (!isAdmin && !isOwner) return m.reply('❌ Perintah ini hanya untuk Admin Grup!');

        db.prepare(`UPDATE groups SET autosholat = 1 WHERE id = ?`).run(m.chat);
        return m.reply(`✅ *Auto Notifikasi Sholat BERHASIL DIAKTIFKAN* di grup ini.\n\nBot akan otomatis mengingatkan waktu sholat wilayah Jakarta & sekitarnya.`);
    }

    if (subCmd === 'off' || subCmd === '0' || subCmd === 'disable') {
        if (!isAdmin && !isOwner) return m.reply('❌ Perintah ini hanya untuk Admin Grup!');

        db.prepare(`UPDATE groups SET autosholat = 0 WHERE id = ?`).run(m.chat);
        return m.reply(`🛑 *Auto Notifikasi Sholat BERHASIL DIMATIKAN* di grup ini.`);
    }

    // ─── 2. TAMPILKAN JADWAL SHOLAT HARI INI ────────────────────────────────
    const timings = await getPrayerTimes();
    const groupData = await getGroup(m.chat);
    const status = groupData?.autosholat === 1 ? 'AKTIF 🟢' : 'NONAKTIF 🔴';

    let caption = `🕌 *JADWAL SHOLAT HARI INI* 🕌\n`;
    caption += `📍 *Wilayah:* Jakarta & Sekitarnya\n`;
    caption += `🔔 *Status Auto Notifikasi:* ${status}\n\n`;

    for (const [sholat, waktu] of Object.entries(timings)) {
        caption += `├ 📌 *${sholat.padEnd(8, ' ')}:* ${waktu.slice(0, 5)} WIB\n`;
    }
    caption += `└ ──────────────\n\n`;
    caption += `💡 *Cara Mengaktifkan / Mematikan:*
• \`${usedPrefix}${command} on\` (Mengaktifkan notifikasi)
• \`${usedPrefix}${command} off\` (Mematikan notifikasi)`;

    return sock.sendMessage(m.chat, { text: caption.trim() }, { quoted: m });
};

// ─── HOOK BEFORE: PENGECEKAN WAKTU SHOLAT SECARA REAL-TIME ────────────────
handler.before = async (m, { sock }) => {
    if (!m.isGroup || m.isNewsletter) return;

    try {
        const groupData = await getGroup(m.chat);
        if (!groupData || groupData.autosholat !== 1) return;

        const now = new Date();
        const timeZone = 'Asia/Jakarta';

        // Format Jam & Menit (HH:mm)
        const timeNow = now.toLocaleTimeString('id-ID', { timeZone, hour: '2-digit', minute: '2-digit', hour12: false }).replace('.', ':');
        const dateToday = now.toLocaleDateString('id-ID', { timeZone });

        const timings = await getPrayerTimes();

        for (const [sholatName, timeStr] of Object.entries(timings)) {
            const formattedTime = timeStr.slice(0, 5); // Ambil format HH:mm
            const alertKey = `${m.chat}_${sholatName}_${dateToday}`;

            // Cek jika waktu cocok & notifikasi belum pernah terkirim hari ini
            if (timeNow === formattedTime && !sentAlerts.has(alertKey)) {
                sentAlerts.add(alertKey);

                const alertText = `🕌 *WAKTU SHOLAT ${sholatName.toUpperCase()} HASIL TIBA!* 🕌\n\n` +
                    `⏱️ *Pukul:* ${formattedTime} WIB\n` +
                    `📍 *Wilayah:* Jakarta & Sekitarnya\n\n` +
                    `_“Sesungguhnya shalat itu adalah fardhu yang ditentukan waktunya atas orang-orang yang beriman.”_ (QS. An-Nisa: 103)\n\n` +
                    `Ambillah air wudhu dan segeralah menunaikan ibadah sholat! ✨`;

                await sock.sendMessage(m.chat, {
                    text: alertText,
                    contextInfo: {
                        externalAdReply: {
                            title: `Waktu Sholat ${sholatName} (${formattedTime} WIB)`,
                            body: `Panggilan Sholat Wilayah Jakarta`,
                            previewType: 0,
                            sourceUrl: global.website || 'https://whatsapp.com'
                        }
                    }
                }).catch(() => {});
            }
        }
    } catch (err) {
        console.error('[AUTOSHOLAT BEFORE ERROR]', err);
    }
};

handler.help = ['autosholat <on/off>', 'jadwalsholat'];
handler.tags = ['group', 'islamic'];
handler.command = ['autosholat', 'autojadwalsholat', 'jadwalsholat', 'sholat'];

export default handler;