const handler = async (m, { sock, conn, reply, isBotAdmin, isAdmin }) => {
    // Kompatibilitas untuk berbagai base bot (sock/conn)
    const client = sock || conn;

    // 1. Validasi Eksekusi di dalam Grup
    if (!m.isGroup) {
        return reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');
    }

    // 2. Validasi Hak Akses Bot
    // Bot WAJIB jadi admin untuk bisa men-generate atau melihat link grup
    if (!isBotAdmin) {
        return reply('❌ Bot harus menjadi *Admin* terlebih dahulu untuk bisa mengambil tautan grup!');
    }

    // 3. Validasi Hak Akses User (Opsional: Hapus blok ini jika member biasa boleh minta link)
    if (!isAdmin) {
        return reply('❌ Hanya *Admin Grup* yang diizinkan untuk meminta tautan grup!');
    }

    try {
        // Beri reaksi proses
        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        // 4. Mengambil Kode Undangan (Invite Code) dari API Baileys
        const inviteCode = await client.groupInviteCode(m.chat);
        
        // 5. Menggabungkan kode dengan URL standar WhatsApp
        const groupLink = `https://chat.whatsapp.com/${inviteCode}`;

        // 6. Menyusun pesan balasan
        let metadata = await client.groupMetadata(m.chat);
        let text = `🔗 *TAUTAN GRUP*\n\n`;
        text += `📝 *Grup:* ${metadata.subject}\n`;
        text += `🌐 *Tautan:* ${groupLink}\n\n`;
        text += `_Tautan ini dapat direset sewaktu-waktu oleh Admin._`;

        // Kirim link ke obrolan
        await reply(text);

        // Beri reaksi sukses
        await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (e) {
        console.error('[LINKGC ERROR]', e);
        await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        reply('❌ Gagal mengambil tautan grup. Pastikan bot adalah admin dan fitur tautan grup tidak dinonaktifkan oleh WhatsApp.');
    }
};

handler.help = ['linkgc', 'linkgrup'];
handler.tags = ['group'];
handler.command = /^(linkgc|linkgrup|linkgroup|grouplink)$/i;

// Mengamankan command hanya untuk grup (fallback middleware)
handler.group = true; 
handler.admin = true; 
handler.botAdmin = true; 

export default handler;