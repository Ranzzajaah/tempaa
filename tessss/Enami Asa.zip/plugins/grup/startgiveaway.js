global.db_giveaway = global.db_giveaway || new Map();

const handler = async (m, { sock, text, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');
    if (!text) {
        return m.reply(`📌 *Contoh Penggunaan:*\n• \`${usedPrefix + command} Premium 1 Bulan\`\n• \`${usedPrefix + command} 50.000 Money\``);
    }

    const chatId = m.chat;
    if (global.db_giveaway.has(chatId)) {
        return m.reply(`⚠️ Masih ada Giveaway yang berlangsung di grup ini!\n\nKetik \`${usedPrefix}cekgiveaway\` untuk melihat detailnya.`);
    }

    global.db_giveaway.set(chatId, {
        prize: text.trim(),
        host: m.sender,
        participants: [],
        startedAt: Date.now()
    });

    const caption = `🎉 *GIVEAWAY DIMULAI!* 🎉\n\n` +
        `🎁 *Hadiah:* ${text.trim()}\n` +
        `👑 *Host:* @${m.sender.split('@')[0]}\n\n` +
        `👉 *Cara Ikut:* Ketik \`${usedPrefix}ikutgiveaway\`\n` +
        `📌 *Cek Status:* Ketik \`${usedPrefix}cekgiveaway\``;

    await sock.sendMessage(m.chat, { text: caption, mentions: [m.sender] }, { quoted: m });
};

handler.help = ['startgiveaway <hadiah>'];
handler.tags = ['group'];
handler.command = ['startgiveaway', 'creategiveaway', 'startgw', 'buatgw'];
handler.group = true;
handler.admin = true;

export default handler;