global.db_giveaway = global.db_giveaway || new Map();

const handler = async (m, { sock, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const chatId = m.chat;
    const session = global.db_giveaway.get(chatId);

    if (!session) {
        return m.reply('❌ Tidak ada Giveaway yang aktif di grup ini.');
    }

    if (session.participants.length === 0) {
        return m.reply('❌ Belum ada peserta yang mendaftar pada Giveaway ini!');
    }

    // Acak pemenang secara sah
    const winnerIndex = Math.floor(Math.random() * session.participants.length);
    const winner = session.participants[winnerIndex];

    const caption = `🎊 *PEMENANG GIVEAWAY!* 🎊\n\n` +
        `🎁 *Hadiah:* ${session.prize}\n` +
        `🏆 *Pemenang:* @${winner.split('@')[0]}\n` +
        `👥 *Total Peserta:* ${session.participants.length} Orang\n\n` +
        `Selamat kepada pemenang! Silakan hubungi host @${session.host.split('@')[0]} untuk mengambil hadiah. ✨`;

    await sock.sendMessage(m.chat, { text: caption, mentions: [winner, session.host] }, { quoted: m });

    // Hapus sesi setelah pemenang ditentukan
    global.db_giveaway.delete(chatId);
};

handler.help = ['rollgiveaway'];
handler.tags = ['group'];
handler.command = ['rollgiveaway', 'rollgw', 'kocokgw', 'winnergw'];
handler.group = true;
handler.admin = true;

export default handler;