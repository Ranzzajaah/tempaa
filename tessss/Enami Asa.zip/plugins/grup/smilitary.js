
const handler = async (m, { text, reply, updateData, usedPrefix, isOwner, isAdmin, isBotAdmin }) => {
	if (!isBotAdmin) return reply('Bot harus jadi admin dulu buat aktifin mode ini!');

	const sub = text?.toLowerCase();
	if (!sub) return reply(`*sMilitary Mode* 🪖\n\nHanya admin & owner yang bisa chat.\n\nCara pakai:\n› ${usedPrefix}smilitary on\n› ${usedPrefix}smilitary off`);

	if (sub === 'on') {
		await updateData('groups', m.chat, 'smilitary', 1);
		return reply('🪖 *sMilitary Mode* diaktifkan!\nHanya admin & owner yang bisa kirim pesan.');
	}

	if (sub === 'off') {
		await updateData('groups', m.chat, 'smilitary', 0);
		return reply('✅ *sMilitary Mode* dimatikan. Semua member bisa chat lagi.');
	}

	reply('Gunakan on / off');
};

handler.before = async (m, { sock, isOwner, isAdmin, isBotAdmin, getGroup }) => {
	if (!m.isGroup || !m.text) return;
	const chatDb = await getGroup(m.chat);
	if (chatDb?.smilitary !== 1) return;
	if (isOwner || isAdmin) return;
	if (!isBotAdmin) return;

	try {
		await sock.sendMessage(m.chat, {
			delete: {
				remoteJid: m.chat,
				id: m.key.id,
				participant: m.key.participant || m.sender,
				fromMe: false
			}
		});
	} catch {}
};

handler.command = ['smilitary', 'military'];
handler.group = true;
handler.admin = true;
handler.botadmin = true;

handler.register = true;

export default handler;
