global.db_giveaway = global.db_giveaway || new Map();

const handler = async (m, { sock, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');

    const chatId = m.chat;
    const session = global.db_giveaway.get(chatId);

    if (!session) {
        return m.reply(`❌ Belum ada Giveaway yang aktif di grup ini.\n\nKetik \`${usedPrefix}startgiveaway <hadiah>\` untuk membuat Giveaway baru!`);
    }

    const sender = m.sender;
    if (session.participants.includes(sender)) {
        return m.reply('⚠️ Kamu sudah terdaftar dalam Giveaway ini!');
    }

    session.participants.push(sender);

    const caption = `✅ @${sender.split('@')[0]} berhasil mendaftar ke Giveaway!\n\n` +
        `🎁 *Hadiah:* ${session.prize}\n` +
        `👥 *Total Peserta:* ${session.participants.length} Orang`;

    await sock.sendMessage(m.chat, { text: caption, mentions: [sender] }, { quoted: m });
};

handler.help = ['ikutgiveaway'];
handler.tags = ['group'];
handler.command = ['ikutgiveaway', 'ikutgw', 'joingw'];
handler.group = true;

export default handler;