/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, command, usedPrefix, reply }) => {
	const client = conn || sock || global.mainSock;
	const chatId = m.chat;

	let q = m.quoted ? m.quoted : m;
	let mime = (q.msg || q).mimetype || q.mediaType || '';

	if (!/image/i.test(mime) || /webp/i.test(mime)) {
		return reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau reply/tag gambar yang sudah dikirim`);
	}

	try {
		await reply(global.mess?.wait || '⏳ Mohon tunggu...');
		let media = await q.download();
		if (!media) return reply(global.mess?.error || 'Gagal mengunduh gambar.');

		await client.updateProfilePicture(chatId, media);

		const senderNum = (m.sender || '').replace(/[^0-9]/g, '');
		await client.sendMessage(chatId, {
			text: `Admin @${senderNum} telah mengganti Icon Group!`,
			mentions: [m.sender]
		}, { quoted: m });
	} catch (e) {
		console.error('[SETPP GC ERROR]', e);
		reply(global.mess?.error || '❌ Gagal memperbarui foto profil grup.');
	}
};

handler.help = ['setppgc'];
handler.tags = ['group'];
handler.command = /^(setppgc|setppgcpanjang|setppgrup|setppgroup)$/i;
handler.admin = true;
handler.botAdmin = true;
handler.group = true;
handler.register = true;

export default handler;
