/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import * as baileys from '@whiskeysockets/baileys';
const { areJidsSameUser } = baileys;

const handler = async (m, { sock, reply, isAdmin, isOwner, isBotAdmin, usedPrefix, command }) => {
	if (!m.quoted) return reply(`Reply/tag pesan yang ingin dihapus dengan *${usedPrefix + command}*`);

	const quoted = m.quoted;
	const botJid = sock.user?.id || sock.user?.jid || '';
	const isOwnMessage = !!(
		quoted.key?.fromMe ||
		quoted.fromMe ||
		(quoted.sender && botJid && areJidsSameUser(quoted.sender, botJid))
	);

	if (!isOwnMessage) {
		if (!m.isGroup) return reply('❌ Menghapus pesan pengguna lain hanya dapat dilakukan di dalam grup!');
		if (!isAdmin && !isOwner) return reply('❌ Hanya admin atau owner yang bisa menghapus pesan orang lain!');
		if (!isBotAdmin) return reply('❌ Bot harus menjadi admin terlebih dahulu untuk menghapus pesan orang lain!');
	}

	try {
		const deleteKey = {
			remoteJid: quoted.key?.remoteJid || quoted.chat || m.chat,
			fromMe: isOwnMessage,
			id: quoted.key?.id || quoted.id,
			participant: isOwnMessage ? undefined : (quoted.key?.participant || quoted.sender || quoted.participant)
		};

		await sock.sendMessage(m.chat, { delete: deleteKey });
	} catch (e) {
		console.error('[DEL] Gagal hapus pesan:', e.message);
		try {
			if (quoted.key) {
				await sock.sendMessage(m.chat, { delete: quoted.key });
			} else {
				reply('❌ Gagal menghapus pesan.');
			}
		} catch (err2) {
			reply('❌ Gagal menghapus pesan.');
		}
	}
};

handler.command = ['del','delete'];
handler.limit = true;
handler.register = true;

export default handler;
