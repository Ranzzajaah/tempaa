/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const urls = [
  "https://telegra.ph/file/c1599cc2424ec477dba9c.jpg",
  "https://telegra.ph/file/b855baefdec15510c8fdc.jpg",
  "https://telegra.ph/file/49f7b55ddfe2eba3a4e70.jpg",
  "https://telegra.ph/file/9b3e6f0c7e4f4b9dc3832.jpg",
  "https://telegra.ph/file/bf3444292b5c5e43cae2f.jpg",
  "https://telegra.ph/file/067e8dc26b6a7860d23e8.jpg",
  "https://telegra.ph/file/f0dfebc4a7cabdb2f18d4.jpg",
  "https://telegra.ph/file/5e5888813807387170227.jpg",
  "https://telegra.ph/file/85d92052a774e5fff90d3.jpg",
  "https://telegra.ph/file/7359e5d3c60962d3d5638.jpg",
  "https://telegra.ph/file/81466171835a42ceb8ef5.jpg",
  "https://telegra.ph/file/708bd8a7b0faa7f70078b.jpg",
  "https://telegra.ph/file/03d2778acd65eec07774f.jpg",
  "https://telegra.ph/file/ac3e6a46d5097365bee7d.jpg",
  "https://telegra.ph/file/810cb10e72ab1de7567b8.jpg",
  "https://files.catbox.moe/ew8d2s.jpg",
  "https://files.catbox.moe/834b0e.jpg",
  "https://files.catbox.moe/fd6q61.jpg",
  "https://files.catbox.moe/36evlv.jpg",
  "https://files.catbox.moe/k6t278.jpg",
  "https://files.catbox.moe/dl7104.jpg"
];

const handler = async (m, { sock, reply }) => {
	try {
		const randomUrl = urls[Math.floor(Math.random() * urls.length)];
		await sock.sendMessage(m.chat, {
			image: { url: randomUrl },
			caption: '📸 *PAP TT Random*'
		}, { quoted: m });
	} catch (err) {
		console.error('[paptt error]', err);
		reply('❌ Gagal mengirim gambar PAP TT.');
	}
};

handler.help = ['paptt'];
handler.tags = ['cewerandom', 'premium'];
handler.command = ['paptt', 'paptoek', 'pap-tt'];
handler.limit = true;
handler.premium = true;
handler.register = true;

export default handler;
