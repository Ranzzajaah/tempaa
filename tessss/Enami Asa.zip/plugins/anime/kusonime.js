/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'
import sharp from 'sharp'
import { getActiveThumbBuffer } from '../../lib/thumb.js'
import { kusonime } from '../../scrape/kusonime.js'

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
	const client = conn || sock
	const cmd = command.toLowerCase()

	if (cmd === 'kusonimedl') {
		if (!text) {
			return reply(`Format salah!\nPenggunaan: \`${usedPrefix}kusonimedl <url_download>\``)
		}
		return await handleDirectDownload(client, m, reply, text.trim())
	}

	if (cmd === 'kusonime') {
		const args = (text || '').trim().split(/\s+/)
		const subCmd = args[0]?.toLowerCase()

		if (!text || subCmd === 'help') {
			const helpText = `*Kusonime Anime Downloader*\n\n` +
				`• Search: \`${usedPrefix}kusonime search <judul>\`\n` +
				`• Latest: \`${usedPrefix}kusonime latest [halaman]\`\n` +
				`• Genre: \`${usedPrefix}kusonime genre <nama_genre> [halaman]\`\n` +
				`• Genres List: \`${usedPrefix}kusonime genres\`\n` +
				`• Detail / Download: \`${usedPrefix}kusonime detail <url>\`\n` +
				`• Download Link: \`${usedPrefix}kusonimedl <url>\`\n\n` +
				`*Contoh:* \`${usedPrefix}kusonime frieren\`\n` +
				`*Contoh Genre:* \`${usedPrefix}kusonime genre action 1\``

			if (client && typeof client.sendButtons === 'function') {
				try {
					const thumb = await getThumbImage().catch(() => null)
					return await client.sendButtons(m.chat, {
						location: {
							degreesLatitude: 0,
							degreesLongitude: 0,
							name: 'Kusonime Anime',
							address: global.website || 'https://kusonime.com',
							jpegThumbnail: thumb
						},
						text: '',
						footer: helpText,
						buttons: [
							{
								title: 'Daftar Menu Kusonime',
								sections: [
									{
										title: 'Fitur Kusonime',
										rows: [
											{
												title: '🆕 Anime Terbaru',
												description: 'Lihat rilis anime batch terbaru',
												id: `${usedPrefix}kusonime latest 1`
											},
											{
												title: '🏷️ Genre Action',
												description: 'Filter anime genre Action',
												id: `${usedPrefix}kusonime genre action 1`
											},
											{
												title: '📚 Daftar Semua Genre',
												description: 'Lihat seluruh genre kusonime',
												id: `${usedPrefix}kusonime genres`
											},
											{
												title: '🔍 Cari Anime Frieren',
												description: 'Contoh pencarian anime',
												id: `${usedPrefix}kusonime search frieren`
											}
										]
									}
								]
							}
						]
					}, { quoted: m })
				} catch (e) {
					console.warn('[KUSONIME MENU BUTTON FAIL]', e.message)
				}
			}
			return reply(helpText)
		}

		if (subCmd === 'latest' || subCmd === 'terbaru') {
			const page = parseInt(args[1]) || 1
			reply(global.mess?.wait || 'Memuat anime terbaru...')
			try {
				const results = await kusonime.latest(page)
				if (!results || results.length === 0) {
					return reply('Gagal mengambil daftar anime terbaru atau halaman kosong.')
				}
				return await renderAnimeList(client, m, reply, usedPrefix, results, `Anime Terbaru (Page ${page})`, `Total ${results.length} anime ditemukan`)
			} catch (e) {
				console.error('[KUSONIME LATEST ERROR]', e)
				return reply('Terjadi kesalahan saat mengambil anime terbaru.')
			}
		}

		if (subCmd === 'genres' || subCmd === 'genrelist') {
			reply(global.mess?.wait || 'Memuat daftar genre...')
			try {
				const list = await kusonime.genresList()
				if (!list || list.length === 0) {
					return reply('Gagal mengambil daftar genre.')
				}

				const rows = list.slice(0, 50).map(g => ({
					title: g.name,
					description: `Lihat anime genre ${g.name}`,
					id: `${usedPrefix}kusonime genre ${g.name.toLowerCase()} 1`
				}))

				let textList = `*Daftar Genre Kusonime:*\n\n`
				list.forEach((g, idx) => {
					textList += `${idx + 1}. *${g.name}* => \`${usedPrefix}kusonime genre ${g.name.toLowerCase()}\`\n`
				})

				if (client && typeof client.sendButtons === 'function') {
					try {
						const thumb = await getThumbImage().catch(() => null)
						return await client.sendButtons(m.chat, {
							location: {
								degreesLatitude: 0,
								degreesLongitude: 0,
								name: 'Daftar Genre Kusonime',
								address: `Total ${list.length} Genre`,
								jpegThumbnail: thumb
							},
							text: '',
							footer: `Pilih genre yang diinginkan dari tombol di bawah:`,
							buttons: [
								{
									title: 'Pilih Genre',
									sections: [
										{
											title: 'Genre Tersedia',
											rows
										}
									]
								}
							]
						}, { quoted: m })
					} catch (e) {
						console.warn('[KUSONIME GENRES BUTTON FAIL]', e.message)
					}
				}

				return reply(textList)
			} catch (e) {
				console.error('[KUSONIME GENRES ERROR]', e)
				return reply('Terjadi kesalahan saat mengambil daftar genre.')
			}
		}

		if (subCmd === 'genre') {
			const genreName = args[1]?.toLowerCase()
			if (!genreName) {
				return reply(`Masukkan nama genre!\nContoh: ${usedPrefix}kusonime genre action 1`)
			}
			const page = parseInt(args[2]) || 1
			reply(global.mess?.wait || `Memuat anime genre ${genreName}...`)
			try {
				const results = await kusonime.genre(genreName, page)
				if (!results || results.length === 0) {
					return reply(`Anime untuk genre ${genreName} tidak ditemukan / halaman kosong.`)
				}
				return await renderAnimeList(client, m, reply, usedPrefix, results, `Genre: ${genreName.toUpperCase()} (Page ${page})`, `Total ${results.length} anime`)
			} catch (e) {
				console.error('[KUSONIME GENRE ERROR]', e)
				return reply('Terjadi kesalahan saat mengambil data genre.')
			}
		}

		if (subCmd === 'detail' || text.startsWith('http://') || text.startsWith('https://')) {
			let url = text.startsWith('http://') || text.startsWith('https://') ? text : text.replace(/^detail\s+/i, '').trim()
			if (url.includes('pixeldrain.com') || url.includes('krakenfiles.com') || url.includes('mp4upload.com') || url.includes('mediafire.com')) {
				return await handleDirectDownload(client, m, reply, url)
			}
			return await getAnimeDetail(client, m, reply, usedPrefix, url)
		}

		let searchQuery = text
		if (subCmd === 'search' || subCmd === 'cari') {
			searchQuery = text.replace(/^(search|cari)\s+/i, '').trim()
			if (!searchQuery) {
				return reply(`Masukkan kata kunci pencarian!\nContoh: ${usedPrefix}kusonime search frieren`)
			}
		}

		reply(global.mess?.wait || `Mencari anime ${searchQuery}...`)
		try {
			const results = await kusonime.search(searchQuery, 1)
			if (!results || results.length === 0) {
				return reply(`Anime "${searchQuery}" tidak ditemukan di Kusonime.`)
			}
			return await renderAnimeList(client, m, reply, usedPrefix, results, `Hasil Pencarian: ${searchQuery}`, `Ditemukan ${results.length} anime`)
		} catch (e) {
			console.error('[KUSONIME SEARCH ERROR]', e)
			return reply('Terjadi kesalahan saat mencari anime.')
		}
	}
}

async function handleDirectDownload(client, m, reply, url) {
	if (url.includes('pixeldrain.com')) {
		reply(global.mess?.wait || '⏳ Mengunduh file dari Pixeldrain...')
		try {
			const apiUrl = typeof global.API === 'function'
				? global.API('kyzz', '/api/download/pixeldrain', { url }, 'apikey')
				: `https://api.kyzzz.xyz/api/download/pixeldrain?url=${encodeURIComponent(url)}&apikey=${global.APIKeys?.['https://api.kyzzz.xyz'] || 'kyuuimp'}`

			const { data } = await axios.get(apiUrl, { timeout: 25000 })
			if (!data.status) {
				return reply(`❌ Gagal mengunduh: ${data.error || 'Terjadi kesalahan dari API Pixeldrain.'}`)
			}

			const directUrl = data.directUrl || data.url || data.result?.directUrl || data.result?.url
			const fileName = data.fileName || data.result?.fileName || 'kusonime_file.rar'
			const fileSize = data.fileSize || data.result?.fileSize || '-'
			const mimeType = data.mimeType || data.result?.mimeType || 'application/octet-stream'

			if (!directUrl) {
				return reply('❌ Gagal mendapatkan direct link file.')
			}

			const caption = `📁 *KUSONIME DOWNLOADER (PIXELDRAIN)*\n\n` +
				`📄 *Nama:* ${fileName}\n` +
				`📦 *Ukuran:* ${fileSize}\n` +
				`🔗 *Direct Link:* ${directUrl}\n\n` +
				`⏳ Mengirim berkas...`

			await client.sendMessage(m.chat, { text: caption }, { quoted: m })

			return await client.sendMessage(m.chat, {
				document: { url: directUrl },
				fileName: fileName,
				mimetype: mimeType
			}, { quoted: m })

		} catch (e) {
			console.error('[KUSONIME PIXELDRAIN DL ERROR]', e)
			return reply('❌ Terjadi kesalahan saat mengunduh berkas Pixeldrain.')
		}
	} else if (url.includes('krakenfiles.com')) {
		reply(global.mess?.wait || '⏳ Mengunduh file dari Krakenfiles...')
		try {
			const apiUrl = typeof global.API === 'function'
				? global.API('kyzz', '/api/download/krakenfiles', { url }, 'apikey')
				: `https://api.kyzzz.xyz/api/download/krakenfiles?url=${encodeURIComponent(url)}&apikey=${global.APIKeys?.['https://api.kyzzz.xyz'] || 'kyuuimp'}`

			const { data } = await axios.get(apiUrl, { timeout: 25000 })
			if (!data.status) {
				return reply(`❌ Gagal mengunduh: ${data.error || 'Terjadi kesalahan dari API Krakenfiles.'}`)
			}

			const directUrl = data.directUrl || data.url || data.downloadUrl || data.result?.directUrl || data.result?.url || data.result?.downloadUrl
			const fileName = data.fileName || data.title || data.result?.fileName || data.result?.title || 'kraken_file.rar'
			const fileSize = data.fileSize || data.size || data.result?.fileSize || data.result?.size || '-'
			const mimeType = data.mimeType || data.result?.mimeType || 'application/octet-stream'

			if (!directUrl) {
				return reply('❌ Gagal mendapatkan link download dari Krakenfiles.')
			}

			const caption = `📁 *KUSONIME DOWNLOADER (KRAKENFILES)*\n\n` +
				`📄 *Nama:* ${fileName}\n` +
				`📦 *Ukuran:* ${fileSize}\n` +
				`🔗 *Direct Link:* ${directUrl}\n\n` +
				`⏳ Mengirim berkas...`

			await client.sendMessage(m.chat, { text: caption }, { quoted: m })

			return await client.sendMessage(m.chat, {
				document: { url: directUrl },
				fileName: fileName,
				mimetype: mimeType
			}, { quoted: m })

		} catch (e) {
			console.error('[KUSONIME KRAKEN DL ERROR]', e)
			return reply('❌ Terjadi kesalahan saat mengunduh berkas Krakenfiles.')
		}
	} else if (url.includes('mp4upload.com')) {
		reply(global.mess?.wait || '⏳ Mengunduh video dari Mp4Upload...')
		try {
			const apiUrl = typeof global.API === 'function'
				? global.API('kyzz', '/api/download/mp4upload', { url }, 'apikey')
				: `https://api.kyzzz.xyz/api/download/mp4upload?url=${encodeURIComponent(url)}&apikey=${global.APIKeys?.['https://api.kyzzz.xyz'] || 'kyuuimp'}`

			const { data } = await axios.get(apiUrl, { timeout: 25000 })
			if (!data.status) {
				return reply(`❌ Gagal mengunduh: ${data.error || 'Terjadi kesalahan dari API Mp4Upload.'}`)
			}

			const directUrl = data.directUrl || data.url || data.downloadUrl || data.result?.directUrl || data.result?.url || data.result?.downloadUrl
			const fileName = data.fileName || data.title || data.result?.fileName || data.result?.title || 'anime_episode.mp4'
			const fileSize = data.fileSize || data.size || data.result?.fileSize || data.result?.size || '-'

			if (!directUrl) {
				return reply('❌ Gagal mendapatkan direct link Mp4Upload.')
			}

			const caption = `🎬 *KUSONIME DOWNLOADER (MP4UPLOAD)*\n\n` +
				`📄 *Nama:* ${fileName}\n` +
				`📦 *Ukuran:* ${fileSize}\n` +
				`🔗 *Direct Link:* ${directUrl}\n\n` +
				`⏳ Mengirim video...`

			await client.sendMessage(m.chat, { text: caption }, { quoted: m })

			return await client.sendMessage(m.chat, {
				video: { url: directUrl },
				caption: `🎬 ${fileName}`,
				mimetype: 'video/mp4'
			}, { quoted: m }).catch(async () => {
				await client.sendMessage(m.chat, {
					document: { url: directUrl },
					fileName: fileName,
					mimetype: 'video/mp4'
				}, { quoted: m })
			})

		} catch (e) {
			console.error('[KUSONIME MP4UPLOAD DL ERROR]', e)
			return reply('❌ Terjadi kesalahan saat mengunduh video Mp4Upload.')
		}
	} else {
		return reply(`Link download: ${url}`)
	}
}

async function getThumbImage(url) {
	if (url) {
		try {
			const res = await axios.get(url, {
				responseType: 'arraybuffer',
				headers: {
					'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
					'Referer': 'https://kusonime.com/'
				},
				timeout: 10000
			})
			if (res.data && res.data.length > 0) {
				const jpegBuf = await sharp(Buffer.from(res.data))
					.resize(300, 300, { fit: 'cover' })
					.jpeg({ quality: 80 })
					.toBuffer()
				return jpegBuf
			}
		} catch (e) {
			console.warn('[FETCH KUSONIME THUMB ERROR]', e.message)
		}
	}
	try {
		return await getActiveThumbBuffer(300)
	} catch (e) {
		return null
	}
}

async function renderAnimeList(client, m, reply, usedPrefix, results, headerTitle, subtitle) {
	const firstItem = results[0]
	const thumb = await getThumbImage(firstItem?.thumb)

	const rows = results.slice(0, 20).map((item, idx) => ({
		title: `${idx + 1}. ${(item.title || 'Anime').slice(0, 20)}`,
		description: `Rilis: ${item.released || '-'} | Genre: ${item.genres?.slice(0, 2).join(', ') || '-'}`,
		id: `${usedPrefix}kusonime detail ${item.url}`
	}))

	let textList = `*${headerTitle}*\n${subtitle}\n\n`
	results.slice(0, 20).forEach((item, idx) => {
		textList += `${idx + 1}. *${item.title}*\n`
		textList += `   • Rilis: ${item.released || '-'}\n`
		textList += `   • Genres: ${item.genres?.join(', ') || '-'}\n`
		textList += `   • Detail: \`${usedPrefix}kusonime detail ${item.url}\`\n\n`
	})

	const captionText = `${headerTitle}\n${subtitle}\n\nPilih anime dari tombol di bawah:`

	if (client && typeof client.sendButtons === 'function') {
		try {
			return await client.sendButtons(m.chat, {
				location: {
					degreesLatitude: 0,
					degreesLongitude: 0,
					name: headerTitle,
					address: subtitle,
					jpegThumbnail: thumb
				},
				text: '',
				footer: captionText,
				buttons: [
					{
						title: 'Hasil Anime',
						sections: [
							{
								title: subtitle.slice(0, 24),
								rows
							}
						]
					}
				]
			}, { quoted: m })
		} catch (e) {
			console.warn('[KUSONIME LIST SEND_BUTTONS FAIL]', e.message)
		}
	}

	if (firstItem && firstItem.thumb) {
		return await client.sendMessage(m.chat, { image: { url: firstItem.thumb }, caption: textList }, { quoted: m })
	} else {
		return reply(textList)
	}
}

async function getAnimeDetail(client, m, reply, usedPrefix, url) {
	reply(global.mess?.wait || 'Memuat detail & link download anime...')
	try {
		const data = await kusonime.detail(url)
		if (!data || !data.metadata) {
			return reply('Gagal mengambil detail anime.')
		}

		const { metadata, download } = data
		const info = metadata.info || {}
		const thumb = await getThumbImage(metadata.poster_url)

		let caption = `*${metadata.title}*\n\n` +
			(info.japanese ? `🇯🇵 *Japanese:* ${info.japanese}\n` : '') +
			(info.score ? `⭐ *Score:* ${info.score}\n` : '') +
			(info.type ? `📺 *Type:* ${info.type}\n` : '') +
			(info.status ? `📌 *Status:* ${info.status}\n` : '') +
			(info.episodes ? `🎬 *Total Episode:* ${info.episodes}\n` : '') +
			(info.duration ? `⏱️ *Durasi:* ${info.duration}\n` : '') +
			(info.season ? `🍂 *Season:* ${info.season}\n` : '') +
			(info.released ? `📅 *Rilis:* ${info.released}\n` : '') +
			(info.genres ? `🏷️ *Genres:* ${Array.isArray(info.genres) ? info.genres.join(', ') : info.genres}\n` : '') +
			(info.producers ? `🏢 *Producers:* ${Array.isArray(info.producers) ? info.producers.join(', ') : info.producers}\n` : '') +
			(metadata.synopsis ? `\n📖 *Sinopsis:*\n${metadata.synopsis}\n\n` : '\n')

		if (download && download.length > 0) {
			caption += `📥 *DAFTAR DOWNLOAD (BATCH / EPISODE):*\n`
			download.forEach(batch => {
				caption += `\n📦 *${batch.title}*\n`
				Object.keys(batch.resolutions).forEach(resOrEp => {
					caption += `  ├ *${resOrEp}*\n`
					batch.resolutions[resOrEp].forEach(l => {
						const isDirect = l.url.includes('pixeldrain.com') ? ' ⚡ (Direct DL)' :
							l.url.includes('krakenfiles.com') ? ' ⚡ (Kraken DL)' :
							l.url.includes('mp4upload.com') ? ' ⚡ (Mp4Upload DL)' : ''
						caption += `  │ • ${l.provider}: ${l.url}${isDirect}\n`
					})
				})
			})
		} else {
			caption += `_(Tidak ada link download langsung yang terdeteksi)_\n`
		}

		if (client && typeof client.sendButtons === 'function') {
			try {
				const buttons = []
				const sections = []

				if (download && download.length > 0) {
					download.forEach((batch) => {
						const rows = []
						Object.keys(batch.resolutions).forEach(resOrEp => {
							const links = batch.resolutions[resOrEp]
							const directLink = links.find(l => l.url.includes('pixeldrain.com') || l.url.includes('krakenfiles.com') || l.url.includes('mp4upload.com'))
							
							if (directLink) {
								const provName = directLink.url.includes('pixeldrain.com') ? 'Pixeldrain' :
									directLink.url.includes('krakenfiles.com') ? 'Krakenfiles' : 'Mp4Upload'
								rows.push({
									title: `⚡ [${provName}] ${resOrEp}`.slice(0, 24),
									description: `Unduh langsung berkas ${resOrEp}`,
									id: `${usedPrefix}kusonimedl ${directLink.url}`
								})
							} else {
								const providers = links.map(p => p.provider).join(', ')
								rows.push({
									title: `${resOrEp} (${links.length} Link)`.slice(0, 24),
									description: `${providers}`.slice(0, 50),
									id: `${usedPrefix}kusonime detail ${url}`
								})
							}
						})

						const chunkSize = 20
						for (let i = 0; i < rows.length; i += chunkSize) {
							const chunk = rows.slice(i, i + chunkSize)
							const range = rows.length > chunkSize ? ` (Part ${Math.floor(i / chunkSize) + 1})` : ''
							sections.push({
								title: `${batch.title.replace(/Download/i, '').trim()}${range}`.slice(0, 24),
								rows: chunk
							})
						}
					})

					if (sections.length > 0) {
						buttons.push({
							title: 'Pilih Episode / Resolusi',
							sections: sections.slice(0, 10)
						})
					}
				}

				return await client.sendButtons(m.chat, {
					location: {
						degreesLatitude: 0,
						degreesLongitude: 0,
						name: metadata.title,
						address: `Score: ${info.score || '-'} • Status: ${info.status || '-'}`,
						jpegThumbnail: thumb
					},
					text: '',
					footer: caption,
					buttons
				}, { quoted: m })
			} catch (e) {
				console.warn('[KUSONIME DETAIL SEND_BUTTONS FAIL]', e.message)
			}
		}

		if (metadata.poster_url) {
			return await client.sendMessage(m.chat, { image: { url: metadata.poster_url }, caption }, { quoted: m })
		} else {
			return reply(caption)
		}

	} catch (e) {
		console.error('[KUSONIME DETAIL ERROR]', e)
		return reply('Terjadi kesalahan saat mengambil detail anime.')
	}
}

handler.help = [
	'kusonime <judul>',
	'kusonime search <judul>',
	'kusonime latest [page]',
	'kusonime genre <nama_genre> [page]',
	'kusonime genres',
	'kusonime detail <url>',
	'kusonimedl <url_download>'
]
handler.tags = ['anime']
handler.command = ['kusonime', 'kusonimedl']
handler.limit = true;
handler.register = true

export default handler
