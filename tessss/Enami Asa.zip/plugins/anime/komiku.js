/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'
import pdfkit from 'pdfkit'
import { prepareWAMessageMedia } from '@whiskeysockets/baileys'
import { getChapter, getDetail, search } from '../../scrape/komiku.js'

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
	const client = conn || sock
	const cmd = command.toLowerCase()

	if (cmd === 'komiku' || cmd === 'komik') {
		if (!text) {
			return reply(`*Komiku Search & PDF Downloader*\n\n` +
				`📌 *Cari Komik:* ${usedPrefix}${command} Solo Leveling\n` +
				`📌 *Download PDF Chapter:* ${usedPrefix}komikpdf <url_chapter>`)
		}

		if (text.startsWith('http://') || text.startsWith('https://')) {
			if (text.includes('-chapter-') || text.includes('/ch/')) {
				return await downloadChapterPdf(client, m, text, reply)
			} else {
				if (global.mess?.wait) reply(global.mess.wait)
				try {
					const detail = await getDetail(text)
					if (!detail || !detail.title) return reply('❌ Gagal mengambil detail komik.')

					const rows = (detail.chapters || []).slice(0, 20).map((ch, idx) => ({
						title: ch.title,
						description: ch.date ? `Tanggal: ${ch.date}` : 'Download PDF',
						id: `${usedPrefix}komikpdf ${ch.url}`
					}))

					const listMessage = {
						title: '📜 DAFTAR CHAPTER',
						sections: [{ title: `Chapter (${detail.chapters?.length || 0})`, rows }]
					}

					const caption = `📖 *${detail.title}*\n\n` +
						(detail.author ? `👤 *Author:* ${detail.author}\n` : '') +
						(detail.status ? `📌 *Status:* ${detail.status}\n` : '') +
						`📝 *Sinopsis:* ${detail.synopsis?.slice(0, 250) || '-'}\n\n` +
						`Silakan pilih chapter di bawah untuk mendownload PDF nya:`

					let sent = false
					if (client.relayMessage) {
						try {
							let mediaAttachment = {}
							if (detail.image) {
								try {
									const media = await Promise.race([
										prepareWAMessageMedia({ image: { url: detail.image } }, { upload: client.waUploadToServer }),
										new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), 5000))
									]).catch(() => null)
									if (media?.imageMessage) {
										mediaAttachment = {
											header: {
												title: detail.title.slice(0, 25),
												hasMediaAttachment: true,
												imageMessage: media.imageMessage
											}
										}
									}
								} catch (_) {}
							}

							await client.relayMessage(
								m.chat,
								{
									viewOnceMessage: {
										message: {
											interactiveMessage: {
												...mediaAttachment,
												body: { text: caption },
												footer: { text: `© ${global.namaBot || 'Hirara AI'} • Komiku Downloader` },
												nativeFlowMessage: {
													buttons: [{
														name: "single_select",
														buttonParamsJson: JSON.stringify(listMessage)
													}]
												}
											}
										}
									}
								},
								{ quoted: m }
							)
							sent = true
						} catch (e) {
							console.warn('[KOMIKU RELAY WARN]', e.message)
						}
					}

					if (!sent) {
						if (detail.image) {
							return await client.sendMessage(m.chat, { image: { url: detail.image }, caption }, { quoted: m })
						} else {
							return reply(caption)
						}
					}
				} catch (e) {
					console.error('[KOMIKU DETAIL ERROR]', e)
					return reply('❌ Gagal mengambil detail komik.')
				}
			}
		}

		reply(`⏳ Mencari komik *"${text}"*...`)
		try {
			const res = await search(text)
			if (!res || !res.data || res.data.length === 0) {
				return reply(`❌ Komik *"${text}"* tidak ditemukan.`)
			}

			const firstItem = res.data[0]
			const rows = res.data.slice(0, 10).map((item, idx) => ({
				title: `${idx + 1}. ${item.title.slice(0, 20)}`,
				description: item.description || item.title,
				id: `${usedPrefix}komiku ${item.url}`
			}))

			const listMessage = {
				title: '📖 HASIL PENCARIAN KOMIK',
				sections: [{ title: `Kata Kunci: ${text}`, rows }]
			}

			let sent = false
			if (client.relayMessage) {
				try {
					let mediaAttachment = {}
					if (firstItem && firstItem.image) {
						try {
							const media = await Promise.race([
								prepareWAMessageMedia({ image: { url: firstItem.image } }, { upload: client.waUploadToServer }),
								new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), 5000))
							]).catch(() => null)
							if (media?.imageMessage) {
								mediaAttachment = {
									header: {
										title: `Komiku Search: ${text}`,
										hasMediaAttachment: true,
										imageMessage: media.imageMessage
									}
								}
							}
						} catch (_) {}
					}

					await client.relayMessage(
						m.chat,
						{
							viewOnceMessage: {
								message: {
									interactiveMessage: {
										...mediaAttachment,
										body: { text: `📖 *KOMIKU SEARCH RESULTS*\n\nDitemukan *${res.data.length}* komik untuk *"${text}"*.\nSilakan pilih komik dari tombol di bawah:` },
										footer: { text: `© ${global.namaBot || 'Hirara AI'} • Komiku` },
										nativeFlowMessage: {
											buttons: [{
												name: "single_select",
												buttonParamsJson: JSON.stringify(listMessage)
											}]
										}
									}
								}
							}
						},
						{ quoted: m }
					)
					sent = true
				} catch (e) {
					console.warn('[KOMIKU SEARCH RELAY WARN]', e.message)
				}
			}

			if (!sent) {
				let listText = `📖 *KOMIKU SEARCH RESULTS*\n\nDitemukan *${res.data.length}* komik untuk *"${text}"*:\n\n`
				res.data.slice(0, 10).forEach((item, idx) => {
					listText += `*${idx + 1}. ${item.title}*\n🔗 ${usedPrefix}komiku ${item.url}\n\n`
				})
				return reply(listText)
			}
		} catch (e) {
			console.error('[KOMIKU SEARCH ERROR]', e)
			return reply('❌ Terjadi kesalahan saat mencari komik.')
		}
	}

	if (cmd === 'komikpdf' || cmd === 'pdfkomik' || cmd === 'chpdf') {
		if (!text) {
			return reply(`❌ Masukkan URL Chapter Komiku!\nContoh: ${usedPrefix}${command} https://komiku.org/solo-leveling-chapter-01/`)
		}
		return await downloadChapterPdf(client, m, text.trim(), reply)
	}
}

async function downloadChapterPdf(client, m, chapterUrl, reply) {
	if (global.mess?.wait) reply(global.mess.wait)

	try {
		const chData = await getChapter(chapterUrl)
		if (!chData || !chData.images || chData.images.length === 0) {
			return reply('❌ Gagal mengambil gambar dari chapter tersebut.')
		}

		const images = chData.images.filter(src => 
			src && !src.includes('promosi') && !src.includes('logo') && !src.includes('banner') && !src.includes('svg') && !src.includes('wmkomiku')
		)

		if (images.length === 0) {
			return reply('❌ Tidak ada gambar komik valid yang ditemukan.')
		}

		const title = chData.title || 'Komik Chapter'
		const imgBuffers = new Array(images.length).fill(null)

		const chunkSize = 5
		for (let i = 0; i < images.length; i += chunkSize) {
			const batch = images.slice(i, i + chunkSize)
			await Promise.all(batch.map(async (imgUrl, batchIdx) => {
				const actualIdx = i + batchIdx
				try {
					const res = await axios.get(imgUrl, {
						responseType: 'arraybuffer',
						headers: {
							'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
							'Referer': 'https://komiku.org/'
						},
						timeout: 8000
					})
					imgBuffers[actualIdx] = Buffer.from(res.data)
				} catch (e) {
					console.warn(`[IMAGE FETCH WARN ${actualIdx}]`, e.message)
				}
			}))
		}

		const validBuffers = imgBuffers.filter(Boolean)

		if (validBuffers.length === 0) {
			return reply('❌ Gagal mengunduh gambar komik.')
		}

		const doc = new pdfkit({ autoFirstPage: false })
		const pdfChunks = []

		doc.on('data', chunk => pdfChunks.push(chunk))
		for (let buf of validBuffers) {
			try {
				const img = doc.openImage(buf)
				doc.addPage({ size: [img.width, img.height] })
				doc.image(img, 0, 0)
			} catch (e) {
				console.warn('[PDF PAGE ERROR]', e.message)
			}
		}
		doc.end()

		await new Promise(resolve => doc.on('end', resolve))
		const pdfBuffer = Buffer.concat(pdfChunks)

		const fileName = `${title.replace(/[^a-zA-Z0-9\-_]/g, '_')}.pdf`

		await client.sendMessage(m.chat, {
			document: pdfBuffer,
			mimetype: 'application/pdf',
			fileName: fileName,
			caption: `📚 *${title}*\n\n✅ Berhasil mengunduh 1 Chapter penuh (${validBuffers.length} Halaman PDF)!`
		}, { quoted: m })

	} catch (e) {
		console.error('[PDF GENERATE ERROR]', e)
		return reply('❌ Terjadi kesalahan saat mengunduh & membuat PDF Chapter.')
	}
}

handler.help = ['komiku <judul>', 'komikpdf <url_chapter>']
handler.tags = ['anime']
handler.command = ['komiku', 'komikpdf']
handler.limit = true;
handler.register = true

export default handler
