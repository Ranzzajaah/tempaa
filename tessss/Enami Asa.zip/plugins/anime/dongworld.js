/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { searchDongworld, getTopDongworld, getDetailDongworld, getStreamDongworld } from '../../scrape/dongworld.js'

let handler = async (m, { conn, sock, args, text, usedPrefix, command, reply }) => {
	const client = conn || sock
	const lowerText = (text || '').trim().toLowerCase()

	if (command === 'dongworldstream' || command === 'dwstream' || command === 'dongworlddl' || (command === 'dongworld' && (lowerText.startsWith('stream') || lowerText.startsWith('dl')))) {
		let inputStr = text
		if (command === 'dongworld') {
			inputStr = text.replace(/^(stream|dl)\s*/i, '').trim()
		}

		let slug = inputStr
		let epIdx = null
		let providerIdx = null

		let delimiter = inputStr.includes('--') ? '--' : (inputStr.includes('|') ? '|' : null)
		if (delimiter) {
			const parts = inputStr.split(delimiter)
			slug = parts[0].trim()
			if (parts.length >= 2 && parts[1].trim() !== '') {
				epIdx = parseInt(parts[1].trim())
			}
			if (parts.length >= 3 && parts[2].trim() !== '') {
				providerIdx = parseInt(parts[2].trim())
			}
		}

		if (!slug) return reply(`❌ Masukkan slug anime/episode.\nContoh: ${usedPrefix}dongworld stream soul-land-sword-dao-chen-xin`)

		try {
			reply(global.mess.wait)
			const data = await getStreamDongworld(slug)

			if (data.status !== 'success' || !data.episodes || !data.episodes.length) {
				return reply('❌ Episode/stream anime tidak ditemukan.')
			}

			const episodes = data.episodes

			if (episodes.length > 1 && (epIdx === null || isNaN(epIdx) || epIdx < 0 || epIdx >= episodes.length)) {
				const rows = episodes.map((epItem, idx) => ({
					title: `Episode ${epItem.episode_number || (idx + 1)}`,
					description: `Tersedia ${(epItem.streams || []).length} provider server`,
					id: `${usedPrefix}dongworld stream ${slug}--${idx}`
				}))

				const listMessage = {
					title: '📌 PILIH EPISODE',
					sections: [{ title: 'Pilih Episode Donghua', rows }]
				}

				if (client.relayMessage) {
					return await client.relayMessage(
						m.chat,
						{
							viewOnceMessage: {
								message: {
									interactiveMessage: {
										body: { text: `🎬 *${data.series_title || slug}*\n\nDitemukan ${episodes.length} episode.\nSilakan pilih episode di bawah terlebih dahulu:` },
										footer: { text: `© ${global.namaBot || 'Hirara AI'}` },
										nativeFlowMessage: {
											buttons: [{
												name: "single_select",
												buttonParamsJson: JSON.stringify(listMessage)
											}]
										}
									}
								}
							}
						},
						{ quoted: m }
					)
				}
			}

			const selectedEpIdx = (epIdx !== null && !isNaN(epIdx) && epIdx >= 0 && epIdx < episodes.length) ? epIdx : 0
			const ep = episodes[selectedEpIdx]
			const streams = ep.streams || []

			if (!streams.length) {
				return reply('❌ Opsi streaming tidak tersedia untuk episode ini.')
			}

			if (providerIdx === null || isNaN(providerIdx) || providerIdx < 0 || providerIdx >= streams.length) {
				const rows = streams.map((st, idx) => ({
					title: `${idx + 1}. ${st.provider || 'Provider'}`,
					description: `Tipe: ${st.type || 'stream'}`,
					id: `${usedPrefix}dongworld stream ${slug}--${selectedEpIdx}--${idx}`
				}))

				const listMessage = {
					title: '🎬 PILIH PROVIDER STREAM',
					sections: [{ title: 'Pilih Server / Provider Streaming', rows }]
				}

				if (client.relayMessage) {
					return await client.relayMessage(
						m.chat,
						{
							viewOnceMessage: {
								message: {
									interactiveMessage: {
										body: { text: `🎬 *${data.series_title || slug}*\n📌 Episode: ${ep.episode_number || (selectedEpIdx + 1)}\n\nTersedia ${streams.length} server provider streaming.\nSilakan pilih provider di bawah untuk mengunduh/mengirim MP4:` },
										footer: { text: `© ${global.namaBot || 'Hirara AI'}` },
										nativeFlowMessage: {
											buttons: [{
												name: "single_select",
												buttonParamsJson: JSON.stringify(listMessage)
											}]
										}
									}
								}
							}
						},
						{ quoted: m }
					)
				}
			}

			const selectedStream = streams[providerIdx]
			let streamUrl = selectedStream.url || ep.direct_bot_link

			reply(global.mess.wait)

			const caption = `🎬 *${data.series_title || slug}*\n` +
				`📌 Episode: ${ep.episode_number || (selectedEpIdx + 1)}\n` +
				`📡 Provider: ${selectedStream.provider}\n` +
				`🔗 Direct URL: ${streamUrl}\n\n` +
				`© ${global.namaBot || 'Hirara AI'}`

			return await client.sendMessage(m.chat, {
				video: { url: streamUrl },
				mimetype: 'video/mp4',
				caption: caption
			}, { quoted: m })

		} catch (e) {
			console.error('[DONGWORLD STREAM ERROR]', e)
			return reply('❌ Gagal mengambil atau mengunduh video anime.')
		}
	}

	if (command === 'dongworldtop' || command === 'dwtop' || (command === 'dongworld' && lowerText === 'top')) {
		try {
			reply(global.mess.wait)
			const data = await getTopDongworld()

			if (data.status !== 'success' || !data.items || !data.items.length) {
				return reply('❌ Gagal mengambil daftar Top Donghua.')
			}

			const rows = data.items.map((item, idx) => ({
				title: `${idx + 1}. ${item.title.slice(0, 20)}`,
				description: item.title,
				id: `${usedPrefix}dongworld stream ${item.slug}`
			}))

			const listMessage = {
				title: '🔥 Popular Donghua',
				sections: [{ title: '🔥 Top / Popular Donghua', rows }]
			}

			if (client.relayMessage) {
				return await client.relayMessage(
					m.chat,
					{
						viewOnceMessage: {
							message: {
								interactiveMessage: {
									body: { text: `🔥 *TOP DONGHUA (DONGWORLD)*\nTotal: ${data.items.length} anime popular.\n\nPilih anime dari list button di bawah untuk memilih episode & streaming.` },
									footer: { text: `© ${global.namaBot || 'Hirara AI'}` },
									nativeFlowMessage: {
										buttons: [{
											name: "single_select",
											buttonParamsJson: JSON.stringify(listMessage)
										}]
									}
								}
							}
						}
					},
					{ quoted: m }
				)
			}
		} catch (e) {
			console.error('[DONGWORLD TOP ERROR]', e)
			return reply('❌ Gagal mengambil data Top Donghua.')
		}
	}

	let searchQuery = text
	if (command === 'dongworld' && lowerText.startsWith('search')) {
		searchQuery = text.replace(/^search\s*/i, '').trim()
	}

	if (!searchQuery) {
		return reply(
			`🔍 *DONGWORLD ANIME SEARCH & STREAM*\n\n` +
			`Cara Penggunaan:\n` +
			`• *${usedPrefix}dongworld search <judul>* : Cari anime Donghua\n` +
			`• *${usedPrefix}dongworld top* : Lihat daftar Anime Popular/Top\n` +
			`• *${usedPrefix}dongworld stream <slug>* : Langsung stream & pilih provider\n\n` +
			`Contoh: *${usedPrefix}dongworld search Soul Land*`
		)
	}

	try {
		reply(global.mess.wait)
		const data = await searchDongworld(searchQuery)

		if (data.status !== 'success' || !data.items || !data.items.length) {
			return reply(`❌ Tidak ada hasil anime ditemukan untuk *${searchQuery}*.`)
		}

		const rows = data.items.map((item, idx) => ({
			title: `${idx + 1}. ${item.title.slice(0, 20)}`,
			description: item.title,
			id: `${usedPrefix}dongworld stream ${item.slug}`
		}))

		const listMessage = {
			title: '📺 Hasil Pencarian',
			sections: [{ title: `Hasil Pencarian: ${searchQuery}`, rows }]
		}

		if (client.relayMessage) {
			return await client.relayMessage(
				m.chat,
				{
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								body: { text: `📺 *DONGWORLD SEARCH RESULTS*\n\nKata Kunci: *${searchQuery}*\nDitemukan: ${data.items.length} Anime.\n\nKlik tombol di bawah untuk memilih anime:` },
								footer: { text: `© ${global.namaBot || 'Hirara AI'}` },
								nativeFlowMessage: {
									buttons: [{
										name: "single_select",
										buttonParamsJson: JSON.stringify(listMessage)
									}]
								}
							}
						}
					}
				},
				{ quoted: m }
			)
		}
	} catch (e) {
		console.error('[DONGWORLD SEARCH ERROR]', e)
		return reply('❌ Gagal melakukan pencarian di Dongworld.')
	}
}

handler.help = ['dongworld search <query>', 'dongworld top', 'dongworld stream <slug>']
handler.tags = ['anime']
handler.command = ['dongworld','dwsearch']
handler.limit = true;

export default handler
