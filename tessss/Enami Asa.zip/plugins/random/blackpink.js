/**
 * Hirara AI — WhatsApp Bot
 * Feature : Random Blackpink Image (api.kyzzz.xyz)
 * Creator : Mommy Kyu
 */

import axios from 'axios';

const handler = async (m, { sock, conn, reply, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock || global.conn;

	await global.react(client, m, 'loading');

	try {
		const apiUrl = global.API(
			'kyzz',
			'/api/random/blackpink',
			{},
			'apikey'
		);

		const response = await axios.get(apiUrl, {
			responseType: 'arraybuffer',
			timeout: 30000,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
			}
		});

		const buffer = Buffer.from(response.data);

		await client.sendMessage(
			m.chat,
			{
				image: buffer,
				caption: `🖤💖 *Random BLACKPINK Image*`
			},
			{ quoted: m }
		);

		await global.react(client, m, 'success');
	} catch (e) {
		console.error('[BLACKPINK ERROR]:', e);
		await global.react(client, m, 'error');
		return reply('❌ Gagal mengambil gambar Blackpink.');
	}
};

handler.help = ['blackpink'];
handler.tags = ['random'];
handler.command = ['blackpink', 'bp'];
handler.limit = true;
handler.register = true;

export default handler;
