/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import fs from 'fs';
import sharp from 'sharp';
import { writeExifImg, writeExifVid, imageToWebp, videoToWebp, addExif } from '../../lib/webp.js';
import { sendCustomStickerPack } from '../../lib/stickerpack.js';

const OTAKU_GIFS = [
	'cry', 'bite', 'wink', 'nom', 'smile', 'wave',
	'blush', 'happy', 'dance', 'handhold', 'lick'
];

const NEKOS_LIFE = [
	'hug', 'kiss', 'pat', 'slap', 'smug', 'cuddle',
	'feed', 'neko', 'tickle', 'fox_girl', 'avatar',
	'lizard', 'meow', 'woof', '8ball', 'goose', 'gecg',
	'wallpaper', 'waifu'
];

const PREM_CMDS = ['lick', 'kiss'];

const ALL_REACTIONS = [...new Set([...OTAKU_GIFS, ...NEKOS_LIFE])];

const handler = async (m, { sock, command, isPremium, isOwner, reply, text }) => {
	const cmd = command.toLowerCase();

	if (PREM_CMDS.includes(cmd) && !isPremium && !isOwner) {
		return reply(global.mess?.vip || '🍓 ᴀᴋsᴇs ᴋʜᴜsᴜs: ғɪᴛᴜʀ ɪɴɪ ᴋʜᴜsᴜs ᴜsᴇʀ ᴘʀᴇᴍɪᴜᴍ sᴀᴊᴀ ʏᴀᴀ 🎀✨');
	}

	if (global.mess?.wait) reply(global.mess.wait);
	if (typeof global.react === 'function') global.react(sock, m, 'loading');

	let packname = global.packname || 'Hirara AI';
	let author = global.author || 'Mommy kyu';

	if (text && text.trim()) {
		const parts = text.trim().split('|');
		packname = parts[0]?.trim() || packname;
		author = parts[1]?.trim() || author;
	}

	try {
		const TOTAL_STICKERS = 30;
		const processedPack = [];

		if (NEKOS_LIFE.includes(cmd)) {
			const fetchTasks = Array.from({ length: TOTAL_STICKERS }, async () => {
				try {
					const res = await axios.get(`https://nekos.life/api/v2/img/${cmd}`, { timeout: 10000 });
					const url = res.data?.url;
					if (!url) return null;

					const mediaRes = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
					const mediaBuffer = Buffer.from(mediaRes.data);
					const isGif = url.toLowerCase().endsWith('.gif') || mediaRes.headers['content-type']?.includes('gif');

					let finalWebp = null;
					if (isGif) {
						const webpBuf = await videoToWebp(mediaBuffer).catch(() => null);
						if (!webpBuf) return null;
						finalWebp = await addExif(webpBuf, packname, author).catch(() => webpBuf);
						return {
							buffer: finalWebp,
							ext: 'webp',
							isAnimated: true,
							isLottie: false,
							mimetype: 'image/webp'
						};
					} else {
						const compressedWebp = await sharp(mediaBuffer, { animated: false })
							.resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
							.webp({ quality: 40, effort: 4 })
							.toBuffer()
							.catch(() => imageToWebp(mediaBuffer));

						finalWebp = await addExif(compressedWebp, packname, author).catch(() => compressedWebp);

						return {
							buffer: finalWebp,
							ext: 'webp',
							isAnimated: false,
							isLottie: false,
							mimetype: 'image/webp'
						};
					}
				} catch (_) {
					return null;
				}
			});

			const results = await Promise.all(fetchTasks);
			for (const r of results) {
				if (r && r.buffer) processedPack.push(r);
			}
		} else if (OTAKU_GIFS.includes(cmd)) {
			const fetchTasks = Array.from({ length: Math.min(TOTAL_STICKERS, 15) }, async () => {
				try {
					const res = await axios.get(`https://api.otakugifs.xyz/gif?reaction=${cmd}`, { timeout: 10000 });
					const url = res.data?.url;
					if (!url) return null;

					const mediaRes = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
					const mediaBuffer = Buffer.from(mediaRes.data);

					const webpBuf = await videoToWebp(mediaBuffer).catch(() => null);
					if (!webpBuf) return null;

					const finalWebp = await addExif(webpBuf, packname, author).catch(() => webpBuf);

					return {
						buffer: finalWebp,
						ext: 'webp',
						isAnimated: true,
						isLottie: false,
						mimetype: 'image/webp'
					};
				} catch (_) {
					return null;
				}
			});

			const results = await Promise.all(fetchTasks);
			for (const r of results) {
				if (r && r.buffer) processedPack.push(r);
			}
		}

		if (processedPack.length >= 3) {
			const finalPack = processedPack.slice(0, 30);
			const totalResultCount = finalPack.length;
			await sendCustomStickerPack(sock, m.chat, finalPack, {
				name: `${packname} - ${cmd.toUpperCase()}`,
				publisher: author,
				description: `Sticker Pack ${totalResultCount}x ${cmd.toUpperCase()}`,
				quoted: m
			});
			if (typeof global.react === 'function') global.react(sock, m, 'success');
			return;
		}

		let imgUrl = '';
		if (OTAKU_GIFS.includes(cmd)) {
			const res = await axios.get(`https://api.otakugifs.xyz/gif?reaction=${cmd}`, { timeout: 15000 }).catch(() => null);
			imgUrl = res?.data?.url;
		}
		if (!imgUrl && NEKOS_LIFE.includes(cmd)) {
			const res = await axios.get(`https://nekos.life/api/v2/img/${cmd}`, { timeout: 15000 }).catch(() => null);
			imgUrl = res?.data?.url;
		}

		if (!imgUrl) return reply('❌ Gagal mengambil gambar reaksi.');

		const mediaRes = await axios.get(imgUrl, { responseType: 'arraybuffer', timeout: 15000 });
		const mediaBuffer = Buffer.from(mediaRes.data);
		const isGif = imgUrl.toLowerCase().endsWith('.gif') || mediaRes.headers['content-type']?.includes('gif');

		let stickerBuffer;
		if (isGif) {
			const exifFile = await writeExifVid(mediaBuffer, { packname, author }).catch(() => null);
			if (exifFile && fs.existsSync(exifFile)) {
				stickerBuffer = fs.readFileSync(exifFile);
				try { fs.unlinkSync(exifFile); } catch (_) {}
			} else {
				stickerBuffer = await videoToWebp(mediaBuffer).catch(() => null);
			}
		} else {
			const exifFile = await writeExifImg(mediaBuffer, { packname, author }).catch(() => null);
			if (exifFile && fs.existsSync(exifFile)) {
				stickerBuffer = fs.readFileSync(exifFile);
				try { fs.unlinkSync(exifFile); } catch (_) {}
			} else {
				stickerBuffer = await imageToWebp(mediaBuffer).catch(() => null);
			}
		}

		if (!stickerBuffer) throw new Error('Sticker buffer kosong');

		await sock.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
		if (typeof global.react === 'function') global.react(sock, m, 'success');
	} catch (e) {
		console.error(`[REACTION STICKER ${cmd} ERROR]:`, e.message);
		if (typeof global.react === 'function') global.react(sock, m, 'error');
		return reply('❌ Gagal membuat stiker pack reaksi.');
	}
};

handler.help = ALL_REACTIONS;
handler.tags = ['random'];
handler.command = ALL_REACTIONS;
handler.limit = true;
handler.register = true;

export default handler;
