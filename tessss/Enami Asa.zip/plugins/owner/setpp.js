/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import sharp from 'sharp';

async function setProfilePictureBot(client, jid, buffer) {
	try {
		await client.updateProfilePicture(jid, buffer);
	} catch (err) {
		const img = await sharp(buffer)
			.resize(720, 720, { fit: 'inside', withoutEnlargement: true })
			.jpeg({ quality: 90 })
			.toBuffer();

		const preview = await sharp(buffer)
			.resize(96, 96, { fit: 'cover' })
			.jpeg({ quality: 50 })
			.toBuffer();

		await client.query({
			tag: 'iq',
			attrs: {
				to: 's.whatsapp.net',
				type: 'set',
				xmlns: 'w:profile:picture'
			},
			content: [
				{
					tag: 'picture',
					attrs: { type: 'image' },
					content: img
				},
				{
					tag: 'picture',
					attrs: { type: 'preview' },
					content: preview
				}
			]
		});
	}
}

const handler = async (m, { sock, conn, command, reply, usedPrefix }) => {
	const client = sock || conn || global.mainSock || global.conn;
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || q.mediaType || q.mtype || '';

	if (!/image/i.test(mime) && !/image/i.test(q.mtype || '')) {
		return reply(`Kirim atau reply foto dengan caption *${usedPrefix + command}*.`);
	}

	try {
		await reply('⏳ Sedang memproses foto profil bot...');

		let imgBuffer = null;
		if (typeof q.download === 'function') {
			imgBuffer = await q.download();
		} else if (client && typeof client.downloadM === 'function') {
			imgBuffer = await client.downloadM(q.msg || q, 'image');
		} else if (client && typeof client.downloadAndSaveMediaMessage === 'function') {
			const savedPath = await client.downloadAndSaveMediaMessage(q);
			if (savedPath && (await import('fs')).existsSync(savedPath)) {
				imgBuffer = (await import('fs')).readFileSync(savedPath);
				try { (await import('fs')).unlinkSync(savedPath); } catch (_) {}
			}
		}

		if (!imgBuffer || !Buffer.isBuffer(imgBuffer) || imgBuffer.length === 0) {
			return reply('❌ Gagal mengunduh foto. Pastikan kamu reply gambar yang valid.');
		}

		const botJid = client.user?.id 
			? (typeof client.decodeJid === 'function' ? client.decodeJid(client.user.id) : client.user.id) 
			: ((global.nomerBot || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net');

		await setProfilePictureBot(client, botJid, imgBuffer);

		return reply('✅ Foto profil bot berhasil diubah!');
	} catch (err) {
		console.error('[SETPP BOT ERROR]', err);
		return reply(`❌ Gagal mengubah foto profil bot: ${err.message || err}`);
	}
};

handler.help = ['setpp', 'setppbot'];
handler.tags = ['owner'];
handler.command = ['setpp', 'setppbot'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
