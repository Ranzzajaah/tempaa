/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const getAllPluginFiles = (baseDir) => {
	const files = []
	if (!fs.existsSync(baseDir)) return files
	const categories = fs.readdirSync(baseDir).filter(f =>
		fs.statSync(path.join(baseDir, f)).isDirectory()
	)
	for (const cat of categories) {
		const catPath = path.join(baseDir, cat)
		const jsFiles = fs.readdirSync(catPath).filter(f => f.endsWith('.js'))
		for (const file of jsFiles) {
			files.push(`${cat}/${file}`)
		}
	}
	return files
}

const normalizeInput = (s) => (s || '')
	.replace(/[\u200B-\u200D\uFEFF]/g, '')
	.replace(/[０-９]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 0xFEE0))
	.trim()

const handler = async (m, { text, command, reply, usedPrefix }) => {
	try {
		const baseDir = path.join(__dirname, '../../plugins');
		let fileName, fileContent;

		if (m.quoted && m.quoted.text) {
			fileName = normalizeInput(text);
			fileContent = m.quoted.text;
		} else {
			if (!text) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*\n\nBisa juga pakai nomor plugin yang sudah ada (cek *${usedPrefix}listplugin*) buat menimpa plugin itu.`);

			const splitIndex = text.indexOf(' ');
			if (splitIndex === -1) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

			fileName = normalizeInput(text.substring(0, splitIndex));
			fileContent = text.substring(splitIndex + 1).trim();
		}

		if (!fileName) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

		if (/^\d+$/.test(fileName)) {
			const allFiles = getAllPluginFiles(baseDir);
			const idx = parseInt(fileName) - 1;
			if (idx < 0 || idx >= allFiles.length) {
				return reply(`Nomor *${fileName}* tidak valid. Total plugin: ${allFiles.length}\n\nKetik *${usedPrefix}listplugin* untuk lihat nomor file.`);
			}
			fileName = allFiles[idx];
		}

		if (!fileName.endsWith('.js')) {
			return reply(`Gagal! Nama file harus berakhiran *.js*\nContoh: *command/menu.js*`);
		}

		if (!fileContent) {
			return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);
		}

		const hasExport = /export\s+default\s+handler/.test(fileContent);

		const hasCommand = /handler\.command\s*=\s*(\[|\/)/.test(fileContent);

		const hasAsync = /(?:const|let|var)\s+handler\s*=\s*async/.test(fileContent) || /async\s+function\s+handler\s*\(/.test(fileContent);

		if (!hasExport || !hasCommand || !hasAsync) {
			return reply(`*Format plugin tidak valid!*

*Contoh kode plugin benar:*
const handler = async (m, {sock, reply}) => {
   m.reply("contoh!!")
}
handler.command = ["tes"]
export default handler;`);
		}

		const filePath = path.join(baseDir, fileName);
		const dirPath = path.dirname(filePath);

		if (!fs.existsSync(dirPath)) {
			fs.mkdirSync(dirPath, { recursive: true });
		}

		fs.writeFileSync(filePath, fileContent);

		return reply(`Berhasil menyimpan plugins *./plugins/${fileName}*`);
	} catch (err) {
		console.error(err);
		reply('Terjadi kesalahan: ' + err.message);
	}
};

handler.command = ['addp', 'addplugin', 'sp', 'svp'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
