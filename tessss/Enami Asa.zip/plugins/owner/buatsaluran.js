/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const QUERY_ID_CREATE = '8823471724422422';
const DATA_PATH_CREATE = 'xwa2_newsletter_create';

async function wmexCreate(client, name, description) {
	const variables = {
		input: {
			name,
			description: description || null
		}
	};

	const result = await client.query({
		tag: 'iq',
		attrs: {
			id: client.generateMessageTag(),
			type: 'get',
			to: 's.whatsapp.net',
			xmlns: 'w:mex'
		},
		content: [{
			tag: 'query',
			attrs: {
				query_id: QUERY_ID_CREATE
			},
			content: Buffer.from(JSON.stringify({
				variables
			}), 'utf-8')
		}]
	});

	const child = result?.content?.find(n => n.tag === 'result');
	if (!child?.content) throw new Error('Tidak menerima respons dari server WhatsApp.');

	const parsed = JSON.parse(child.content.toString());

	if (parsed.errors?.length) {
		throw new Error(parsed.errors.map(e => e.message || 'Unknown error').join(', '));
	}

	const raw = parsed?.data?.[DATA_PATH_CREATE];
	if (!raw) throw new Error('Server tidak mengembalikan data saluran.');

	const thread = raw.thread_metadata || {};

	return {
		id: raw.id,
		name: thread.name?.text || name,
		description: thread.description?.text || '',
		invite: thread.invite || '',
		subscribers: Number(thread.subscribers_count) || 0,
		verification: thread.verification || 'UNKNOWN'
	};
}

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(
			`*BUAT SALURAN WHATSAPP*\n\n` +
			`Format: *${usedPrefix + command} Nama|Deskripsi|Jumlah*\n\n` +
			`Contoh: *${usedPrefix + command} Info Update|Channel resmi bot|2*\n\n` +
			`Maksimal jumlah: 10 saluran sekaligus.`
		);
	}

	let [name, description, amount] = text.split('|').map(v => (v || '').trim());

	if (!name || name.length < 2) {
		return reply('Nama saluran minimal 2 karakter.');
	}

	let count = parseInt(amount) || 1;
	if (count > 10) count = 10;
	if (count < 1) count = 1;

	try {
		await global.react(client, m, 'loading');

		const results = [];

		for (let i = 0; i < count; i++) {
			const res = await wmexCreate(client, name, description);
			const inviteLink = res.invite
				? `https://whatsapp.com/channel/${res.invite}`
				: res.id
					? `https://whatsapp.com/channel/${res.id.replace('@newsletter', '')}`
					: '-';

			results.push({
				id: res.id,
				name: res.name,
				description: res.description,
				url: inviteLink
			});
		}

		await global.react(client, m, 'success');

		let txt = `*Berhasil Membuat ${results.length} Saluran*\n\n`;
		results.forEach((r, idx) => {
			txt += `*${idx + 1}. ${r.name}*\n` +
				`ID: ${r.id}\n` +
				`Link: ${r.url}\n\n`;
		});

		await reply(txt.trim());

	} catch (err) {
		console.error('[BUATSALURAN ERROR]', err);
		await global.react(client, m, 'error');
		return reply(`Gagal membuat saluran: ${err.message}`);
	}
};

handler.help = ['buatsaluran <nama>|<deskripsi>|<jumlah>'];
handler.tags = ['owner'];
handler.command = /^(buatsaluran|createsaluran|createnewsletter|createch)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
