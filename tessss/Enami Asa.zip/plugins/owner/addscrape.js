/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';

const SCRAPE_DIR = path.join(process.cwd(), 'scrape');
if (!fs.existsSync(SCRAPE_DIR)) fs.mkdirSync(SCRAPE_DIR, { recursive: true });

const checkSyntax = (filePath) => {
    return new Promise((resolve) => {
        exec(`node -c "${filePath}"`, (err, stdout, stderr) => {
            if (err) {
                resolve({ valid: false, error: stderr || err.message });
            } else {
                resolve({ valid: true });
            }
        });
    });
};

const handler = async (m, { args, usedPrefix, command, isOwner }) => {
    if (!isOwner) return m.reply(global.mess?.owner || 'Khusus Owner!');

    const filename = args[0] ? (args[0].endsWith('.js') ? args[0] : `${args[0]}.js`) : '';
    if (!filename) return m.reply(`*Contoh:* \`${usedPrefix + command} tiktok.js <code/reply_code>\``);

    let code = '';
    if (m.quoted && m.quoted.text) {
        code = m.quoted.text;
    } else {
        code = args.slice(1).join(' ');
    }

    if (!code.trim()) {
        return m.reply('❌ Masukkan kodenya atau reply pesan berisi kode scraper!');
    }

    const targetPath = path.join(SCRAPE_DIR, filename);
    const tempPath = path.join(SCRAPE_DIR, `.temp_${Date.now()}_${filename}`);

    fs.writeFileSync(tempPath, code, 'utf-8');

    const testResult = await checkSyntax(tempPath);
    if (!testResult.valid) {
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        return m.reply(`❌ *SINTAKS ERROR (node -c)*\n\n\`\`\`${testResult.error}\`\`\``);
    }

    fs.renameSync(tempPath, targetPath);
    return m.reply(`✅ File scraper \`scrape/${filename}\` berhasil disimpan dan lolos uji sintaks *node -c*!`);
};

handler.help = ['addscrape <nama> <code/reply>'];
handler.tags = ['owner'];
handler.command = /^(addscrape|savescrape)$/i;
handler.owner = true;
handler.noJadiBot = true;

export default handler;
