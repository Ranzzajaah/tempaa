/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	let [jid, target] = (text || '').split('|').map(v => (v || '').trim());

	if (!jid || !target) {
		return reply(
			`*INVITE ADMIN SALURAN*\n\n` +
			`Format: *${usedPrefix + command} id_saluran@newsletter|62812xxxxxxx*\n\n` +
			`Contoh: *${usedPrefix + command} 120363xxx@newsletter|6283150850721*`
		);
	}

	if (!jid.endsWith('@newsletter')) jid += '@newsletter';
	const targetJid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

	try {
		await global.react(client, m, 'loading');

		await client.query({
			tag: 'iq',
			attrs: {
				id: client.generateMessageTag(),
				type: 'set',
				xmlns: 'w:newsletter',
				to: jid
			},
			content: [{
				tag: 'invite',
				attrs: {},
				content: [{
					tag: 'admin',
					attrs: {
						jid: targetJid
					},
					content: undefined
				}]
			}]
		});

		await global.react(client, m, 'success');
		return reply(`*Undangan Admin Berhasil Dikirim*\n\nSaluran: ${jid}\nTarget: ${targetJid}`);
	} catch (err) {
		console.error('[INVITECH ERROR]', err);
		await global.react(client, m, 'error');
		return reply(`Gagal mengundang admin saluran: ${err.message || err}`);
	}
};

handler.help = ['invitech <id_saluran>|<nomor>'];
handler.tags = ['owner'];
handler.command = /^(invitech|inviteadminch|addadminch)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
