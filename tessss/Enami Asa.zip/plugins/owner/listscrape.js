/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const SCRAPE_DIR = path.join(process.cwd(), 'scrape');

const handler = async (m, { usedPrefix, isOwner }) => {
    if (!isOwner) return m.reply(global.mess?.owner || 'Khusus Owner!');

    if (!fs.existsSync(SCRAPE_DIR)) return m.reply('📂 Folder `scrape/` belum ada.');

    const files = fs.readdirSync(SCRAPE_DIR).filter(f => f.endsWith('.js'));
    if (!files.length) return m.reply('📂 Folder `scrape/` masih kosong.');

    let teks = '';
    files.forEach((f, i) => {
        const stat = fs.statSync(path.join(SCRAPE_DIR, f));
        const size = (stat.size / 1024).toFixed(2);
        teks += `> *${i + 1}.* ${f} (${size} KB)\n`;
    });

    const header = `*Info scrape files*
- *File scraper:* ${files.length}
- *Folder:* scrape/

*Command valid*
- ${usedPrefix}getscrape <nama atau nomor>
- ${usedPrefix}addscrape <nama.js> (reply kodenya)
- ${usedPrefix}delscrape <nama atau nomor>\n\n`;

    return m.reply(header + teks);
};

handler.help = ['listscrape'];
handler.tags = ['owner'];
handler.command = /^(listscrape|ls|scraperlist|scrapes)$/i;
handler.owner = true;
handler.noJadiBot = true;

export default handler;
