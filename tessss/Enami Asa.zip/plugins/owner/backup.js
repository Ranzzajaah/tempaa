/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import axios from 'axios';
import FormData from 'form-data';

const handler = async (m, { sock, reply, text, usedPrefix, command }) => {
	const d = new Date();
	const date = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

	function jam(tz = 'Asia/Jakarta') {
		return new Date().toLocaleTimeString('id-ID', {
			timeZone: tz,
			hour: '2-digit',
			minute: '2-digit',
			second: '2-digit',
		});
	}

	const arg = text ? text.trim().toLowerCase() : '';
	let isFullSetting = global.includeFullSettings ?? false;
	if (arg === 'true' || arg === '1' || arg === 'full') {
		isFullSetting = true;
	} else if (arg === 'false' || arg === '0' || arg === 'placeholder') {
		isFullSetting = false;
	}

	const settingsPath = path.join(process.cwd(), 'settings.js');
	let originalSettingsContent = null;

	try {
		await reply('⏳ *Sedang memproses backup...* Mohon tunggu sebentar.');

		if (!isFullSetting && fs.existsSync(settingsPath)) {
			originalSettingsContent = fs.readFileSync(settingsPath, 'utf-8');
			const sanitizedContent = originalSettingsContent
				.replace(/(global\.tokengh\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.plta\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.pltc\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.cftoken\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.cfzone\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.cfaccount\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.tgToken\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(global\.tgChatId\s*=\s*['"])[^'"]*(['"];)/g, '$1xxx$2')
				.replace(/(['"]https?:\/\/api\.kyzzz\.xyz['"]:\s*['"])[^'"]*(['"])/g, '$1xxx$2');
			fs.writeFileSync(settingsPath, sanitizedContent, 'utf-8');
		}

		const name = (global.namaBot || 'bot').toLowerCase().replace(/[^a-z0-9_]/g, '') || 'bot';
		const excludeDirs = ['node_modules', 'session', 'Auth', 'package-lock.json', 'yarn.lock', '.npm', '.cache', '.git', 'sessions_jadibot', 'data/trash', 'logs', 'database'];
		const excludePatterns = [
			'plugins/maker/Iqcbyrin.png',
			'plugins/maker/fonts/emoji-apple-image.json',
			'*.log',
			'logs/*',
			'database/*',
			'data/*.db*',
			'*.db',
			'*.db-shm',
			'*.db-wal'
		];

		if (!isFullSetting) {
			excludePatterns.push('plugins/nsfw/*', 'plugins/nsfw');
		}

		const filesToZip = fs
			.readdirSync(process.cwd())
			.filter((f) => !excludeDirs.includes(f) && f !== '')
			.map((f) => `"${f}"`)
			.join(' ');

		if (!filesToZip.length) {
			if (originalSettingsContent) fs.writeFileSync(settingsPath, originalSettingsContent, 'utf-8');
			return reply('Tidak ada file yang dapat di-backup.');
		}

		const excludeArgs = excludePatterns.map(p => `-x "${p}"`).join(' ');
		execSync(`zip -r ${name}.zip ${filesToZip} ${excludeArgs}`);

		if (originalSettingsContent) {
			fs.writeFileSync(settingsPath, originalSettingsContent, 'utf-8');
			originalSettingsContent = null;
		}

		const zipPath = `./${name}.zip`;
		const stats = fs.statSync(zipPath);
		const fileSizeInMB = (stats.size / (1024 * 1024)).toFixed(2);

		const caption = `📦 *Backup Script*\n📊 Size: ${fileSizeInMB} MB`;

		const tgToken = global.tgToken || global.telegramToken || process.env.TG_TOKEN || '';
		const tgChatId = global.tgChatId || global.telegramChatId || '';

		if (!tgToken || !tgChatId) {
			return reply('❌ Pengiriman backup gagal: `tgToken` atau `tgChatId` belum dikonfigurasi di settings.js!');
		}

		try {
			const form = new FormData();
			form.append('chat_id', tgChatId);
			form.append('caption', caption.replace(/\*/g, ''));
			form.append('document', fs.createReadStream(zipPath), {
				filename: `${name}.zip`,
				contentType: 'application/zip'
			});

			await axios.post(`https://api.telegram.org/bot${tgToken}/sendDocument`, form, {
				headers: form.getHeaders(),
				timeout: 60000
			});

			await reply(`✅ Backup script berhasil dikirim ke Telegram! (${fileSizeInMB} MB)`);
		} catch (tgErr) {
			console.error('[Backup Telegram Send Error]', tgErr?.response?.data || tgErr?.message || tgErr);
			reply('❌ Gagal mengirim file backup ke Telegram:\n' + (tgErr?.response?.data?.description || tgErr?.message || tgErr));
		}

		try {
			fs.unlinkSync(zipPath);
		} catch {}

	} catch (err) {
		if (originalSettingsContent) {
			try { fs.writeFileSync(settingsPath, originalSettingsContent, 'utf-8'); } catch {}
		}
		console.error('[Backup Error]', err);

		if (err.message.includes('zip: not found') || err.message.includes("'zip' is not recognized")) {
			reply("❌ Gagal: Command 'zip' tidak ditemukan pada OS.\n(Di Linux/Termux: `pkg install zip` atau `apt install zip`)");
		} else {
			reply('❌ Terjadi kesalahan saat melakukan backup:\n' + err.message);
		}
	}
};

handler.help = ['backup [true/false/full]'];
handler.tags = ['owner'];
handler.command = ['backup', 'bck', 'backupsc'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;