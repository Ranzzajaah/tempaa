/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

const handler = async (m, { conn, sock, args, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const pkgPath = path.join(process.cwd(), 'package.json');

	if (!fs.existsSync(pkgPath)) {
		return reply('❌ File `package.json` tidak ditemukan.');
	}

	const sub = (args[0] || '').toLowerCase();

	if (sub === 'now' || sub === 'all' || sub === 'force') {
		await reply('⏳ *Sedang memperbarui semua dependencies ke versi terbaru...*\n_Mohon tunggu sebentar..._');
		await global.react(client, m, 'loading');

		try {
			const { stdout, stderr } = await execPromise('npm update --save', { timeout: 180000 });
			const log = (stdout || stderr || 'Semua package sudah berhasil diperbarui.').trim();

			await global.react(client, m, 'success');
			return reply(
				`✅ *SEMUA DEPENDENCIES BERHASIL DIPERBARUI!*\n\n` +
				`📋 *Log Output:*\n\`\`\`\n${log.slice(-1500)}\n\`\`\``
			);
		} catch (err) {
			console.error('[UPDATE EXEC ERROR]', err);
			await global.react(client, m, 'error');
			return reply(`❌ *Gagal memperbarui dependencies:*\n\`\`\`\n${(err.stderr || err.message).slice(-1500)}\n\`\`\``);
		}
	}

	await reply('🔍 *Memeriksa pembaruan package di package.json...*\n_Sedang memeriksa versi terbaru dari npm registry..._');
	await global.react(client, m, 'loading');

	try {
		let outdatedJson = {};
		try {
			const { stdout } = await execPromise('npm outdated --json');
			outdatedJson = JSON.parse(stdout || '{}');
		} catch (errOutdated) {
			if (errOutdated.stdout) {
				try {
					outdatedJson = JSON.parse(errOutdated.stdout);
				} catch {}
			}
		}

		const entries = Object.entries(outdatedJson);

		const pkgJson = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
		const allDeps = {
			...(pkgJson.dependencies || {}),
			...(pkgJson.devDependencies || {})
		};
		const totalDeps = Object.keys(allDeps).length;

		if (!entries.length) {
			await global.react(client, m, 'success');
			return reply(
				`📦 *DEPENDENCIES CHECKER*\n\n` +
				`• Total Dependencies: *${totalDeps} Package*\n` +
				`• Status: ✅ *Semua package sudah menggunakan versi terbaru!*\n\n` +
				`💡 _Ketik \`${usedPrefix + command} now\` jika ingin memaksa update ulang._`
			);
		}

		let txt = `📦 *HASIL CEK UPDATE DEPENDENCIES*\n\n` +
			`• Total Terdaftar: *${totalDeps} Package*\n` +
			`• Perlu Update: *${entries.length} Package*\n\n` +
			`📋 *DAFTAR PACKAGE YANG TERSEDIA UPDATE:*\n\n`;

		entries.forEach(([pkg, info], idx) => {
			txt += `*${idx + 1}. ${pkg}*\n` +
				`  ├ 📌 Versi Saat Ini : \`${info.current || 'N/A'}\`\n` +
				`  ├ 🎯 Versi Wanted   : \`${info.wanted || 'N/A'}\`\n` +
				`  ╰ 🚀 Versi Terbaru  : \`${info.latest || 'N/A'}\`\n\n`;
		});

		txt += `⚡ *Cara Update Semua:*\n` +
			`Ketik: \`${usedPrefix + command} now\``;

		await global.react(client, m, 'success');
		await reply(txt.trim());

	} catch (e) {
		console.error('[UPDATE CHECK ERROR]', e);
		await global.react(client, m, 'error');
		return reply(`❌ Gagal memeriksa update package: ${e.message}`);
	}
};

handler.help = ['update', 'update now'];
handler.tags = ['owner'];
handler.command = /^(update|npmupdate|pkgupdate)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
