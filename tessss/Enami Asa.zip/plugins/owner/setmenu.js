/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { setMenuType, setGroupMenuType, getSettings, getGroup } from "../../lib/database.js";

const handler = async (m, { args, reply, usedPrefix, isOwner, isAdmin }) => {
	const botSettings = await getSettings();
	const groupData = m.isGroup ? await getGroup(m.chat) : null;
	const currentGlobal = botSettings?.menuType || global.menuType || 1;
	const currentGroup = groupData?.menuType || 0;

	const isTargetGc = ['gc', 'group', 'grup'].includes(args[0]?.toLowerCase());
	const isTargetGlobal = ['global', 'bot', 'all'].includes(args[0]?.toLowerCase());

	let rawVal = args[0];
	if (isTargetGc || isTargetGlobal) {
		rawVal = args[1];
	}

	const isReset = rawVal?.toLowerCase() === 'reset' || rawVal === '0';
	const type = isReset ? 0 : parseInt(rawVal);

	if (!rawVal || (!['0', '1', '2', '3'].includes(String(type)) && !isReset) || isNaN(type)) {
		const groupInfo = m.isGroup 
			? `\n👥 *Menu Grup Ini:* ${currentGroup === 0 ? `Mengikuti Global (Tipe ${currentGlobal})` : `Tipe ${currentGroup} (Khusus)`}\n` 
			: '\n';
		return reply(
			`*⚙️ PENGATURAN TAMPILAN MENU BOT*\n\n` +
			`🌐 *Menu Global Bot:* Tipe ${currentGlobal}` +
			groupInfo +
			`*Format Penggunaan:*\n` +
			(isOwner ? `• *${usedPrefix}setmenu <1/2/3>* : Ubah menu global bot (Owner)\n` : '') +
			(m.isGroup ? `• *${usedPrefix}setmenu gc <1/2/3>* : Ubah khusus grup ini\n` +
			`• *${usedPrefix}setmenu reset* : Kembalikan grup ke menu global\n` : '') +
			(isOwner ? `• *${usedPrefix}setmenu global <1/2/3>* : Ubah menu global bot\n` : '') +
			`\n*Pilihan Tampilan Menu:*\n` +
			`• *1*: Menu Standard (Location + Custom Buttons)\n` +
			`• *2*: Menu Allmenu (LinkPreview / Image Full List)\n` +
			`• *3*: Menu BloksWidget (A2UI Card Header + Single Select List & Buttons)`
		);
	}

	if (isReset) {
		if (!m.isGroup) return reply(`⚙️ Reset hanya berlaku untuk pengaturan menu grup.`);
		if (!isOwner && !isAdmin) return reply(`❌ Hanya Admin atau Owner yang dapat me-reset menu grup ini!`);
		await setGroupMenuType(m.chat, 0);
		return reply(`✅ Pengaturan menu grup berhasil di-reset. Grup ini sekarang mengikuti menu global bot (Tipe ${currentGlobal}).`);
	}

	if (isTargetGc || (!isOwner && m.isGroup)) {
		if (!isOwner && !isAdmin) return reply(`❌ Hanya Admin atau Owner yang dapat mengubah menu grup ini!`);
		if (type === 0) {
			await setGroupMenuType(m.chat, 0);
			return reply(`✅ Pengaturan menu grup berhasil di-reset ke global (Tipe ${currentGlobal}).`);
		}
		await setGroupMenuType(m.chat, type);
		return reply(`✅ Tampilan menu *KHUSUS GRUP INI* berhasil disimpan ke database (Menu Tipe ${type}).`);
	}

	if (!isOwner) return reply(`❌ Hanya Owner bot yang dapat mengubah pengaturan menu global!`);
	if (type === 0) return reply(`⚙️ Tipe menu global harus bernilai 1, 2, atau 3.`);
	
	await setMenuType(type);
	if (m.isGroup) {
		await setGroupMenuType(m.chat, 0);
	}
	return reply(`✅ Tampilan menu *GLOBAL BOT* berhasil diubah ke *Menu Tipe ${type}* dan tersimpan di database.`);
};

handler.help = ['setmenu <1/2/3>'];
handler.tags = ['owner', 'group'];
handler.command = ['setmenu', 'setmenutype'];
handler.register = false;
handler.noJadiBot = true;

export default handler;
