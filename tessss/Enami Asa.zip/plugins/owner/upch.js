/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { PassThrough } from 'stream'
import ffmpeg from 'fluent-ffmpeg'

const TYPE_MAP = {
	imageMessage: 'image',
	videoMessage: 'video',
	ptvMessage: 'ptv',
	audioMessage: 'audio',
	stickerMessage: 'sticker'
}

const unwrapContainer = (msg = {}) => {
	while (true) {
		const next =
			msg?.ephemeralMessage?.message ||
			msg?.viewOnceMessage?.message ||
			msg?.viewOnceMessageV2?.message ||
			msg?.viewOnceMessageV2Extension?.message ||
			msg?.documentWithCaptionMessage?.message ||
			msg?.editedMessage?.message ||
			msg?.forwardedNewsletterMessageInfo?.message

		if (!next) break
		msg = next
	}
	return msg
}

const detect = (target, isQuoted) => {
	if (!target?.mtype) return null

	let mtype = target.mtype
	let data = isQuoted ? target : target.msg

	if (!TYPE_MAP[mtype]) {
		const inner = unwrapContainer({ [mtype]: data })
		const innerType = Object.keys(inner || {})[0]
		if (innerType && TYPE_MAP[innerType]) {
			mtype = innerType
			data = inner[innerType]
		}
	}

	const type = TYPE_MAP[mtype]
	if (!type || !data) return null

	return { type, data }
}

const toVN = buffer =>
	new Promise((resolve, reject) => {
		const input = new PassThrough()
		const output = new PassThrough()
		const chunks = []

		input.end(buffer)

		ffmpeg(input)
			.noVideo()
			.audioCodec('libopus')
			.format('ogg')
			.on('error', reject)
			.on('end', () => resolve(Buffer.concat(chunks)))
			.pipe(output)

		output.on('data', c => chunks.push(c))
	})

let handler = async (m, { sock, usedPrefix, command }) => {
	if (!global.idch) return m.reply('global.idch belum diset! isi di settings.js')

	const isQuoted = !!m.quoted
	const quoted = m.quoted || m
	const media = detect(quoted, isQuoted)

	if (!media) {
		return m.reply(
			`Reply foto/video/audio/voice/sticker/PTV lalu ketik *${usedPrefix + command}*`
		)
	}

	let buffer = await quoted.download()
	let mime = media.data.mimetype || ''

	const send = {}

	if (media.type == 'image') {
		send.image = buffer
		send.caption = media.data.caption || ''
	}

	if (media.type == 'video') {
		send.video = buffer
		send.caption = media.data.caption || ''
	}

	if (media.type == 'ptv') {
		send.video = buffer
		send.ptv = true
	}

	if (media.type == 'sticker') {
		send.sticker = buffer
	}

	if (media.type == 'audio') {
		send.audio = mime.includes('opus')
			? buffer
			: await toVN(buffer)

		send.ptt = true
		send.mimetype = 'audio/ogg; codecs=opus'
	}

	try {
		await sock.sendMessage(global.idch, send)
		m.reply(`✅ ${media.type} berhasil diupload.`)
	} catch (e) {
		m.reply(e.message || String(e))
	}
}

handler.command = ['upch', 'sendch']
handler.owner = true

handler.noJadiBot = true;

export default handler
