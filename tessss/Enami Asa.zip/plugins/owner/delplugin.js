/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const getAllPluginFiles = (baseDir) => {
  const files = []
  if (!fs.existsSync(baseDir)) return files
  const categories = fs.readdirSync(baseDir).filter(f =>
    fs.statSync(path.join(baseDir, f)).isDirectory()
  )
  for (const cat of categories) {
    const catPath = path.join(baseDir, cat)
    const jsFiles = fs.readdirSync(catPath).filter(f => f.endsWith('.js'))
    for (const file of jsFiles) {
      files.push(`${cat}/${file}`)
    }
  }
  return files
}

const normalizeInput = (s) => (s || '')
  .replace(/[\u200B-\u200D\uFEFF]/g, '')
  .replace(/[０-９]/g, (d) => String.fromCharCode(d.charCodeAt(0) - 0xFEE0))
  .trim()

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
  try {
    const baseDir = path.join(__dirname, '../../plugins')
    const allFiles = getAllPluginFiles(baseDir)

    if (!text) {
      return reply(`Contoh:\n*${usedPrefix + command}* folder/namafile.js\n*${usedPrefix + command}* 5\n\nKetik *${usedPrefix}listplugin* untuk lihat nomor file.`)
    }

    const input = normalizeInput(text)
    let targetRelPath

    if (/^\d+$/.test(input)) {
      const idx = parseInt(input) - 1
      if (idx < 0 || idx >= allFiles.length) {
        return reply(`Nomor *${input}* tidak valid. Total plugin: ${allFiles.length}`)
      }
      targetRelPath = allFiles[idx]
    } else {
      if (!input.endsWith('.js')) return reply(`Nama file harus berakhiran *.js*\nContoh: *maker/brat.js*`)
      targetRelPath = input
    }

    const targetPath = path.join(baseDir, targetRelPath)
    if (!fs.existsSync(targetPath)) return reply(`Plugin *${targetRelPath}* tidak ditemukan.`)

    fs.unlinkSync(targetPath)
    return reply(`✅ Berhasil menghapus plugin *${targetRelPath}*`)

  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan saat menghapus plugin.')
  }
}

handler.command = ['delplugin','dp']
handler.owner = true
handler.noJadiBot = true

export default handler
