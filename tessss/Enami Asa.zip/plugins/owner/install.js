/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { exec } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!text) {
		return reply(
			`📦 *NPM PACKAGE INSTALLER*\n\n` +
			`Gunakan perintah ini untuk menginstall dependency npm baru.\n\n` +
			`📌 *Contoh:* \`${usedPrefix + command} axios fluent-ffmpeg\`\n` +
			`📌 *Versi Spesifik:* \`${usedPrefix + command} sharp@latest\``
		);
	}

	const pkgName = text.trim();
	await reply(`⏳ *Sedang menginstall package:* \`${pkgName}\`\n_Mohon tunggu sebentar..._`);
	await global.react(client, m, 'loading');

	try {
		const { stdout, stderr } = await execPromise(`npm install ${pkgName} --save`, { timeout: 120000 });
		const output = (stdout || stderr || 'Instalasi selesai tanpa log output.').trim();

		await global.react(client, m, 'success');
		await reply(
			`✅ *BERHASIL MENGINSTALL PACKAGE*\n\n` +
			`📦 *Package:* \`${pkgName}\`\n\n` +
			`📋 *Log Output:*\n\`\`\`\n${output.slice(-1500)}\n\`\`\``
		);
	} catch (err) {
		console.error('[INSTALL ERROR]', err);
		await global.react(client, m, 'error');
		return reply(
			`❌ *GAGAL MENGINSTALL PACKAGE*\n\n` +
			`📦 *Package:* \`${pkgName}\`\n\n` +
			`⚠️ *Error:*\n\`\`\`\n${(err.stderr || err.message || 'Unknown error').slice(-1500)}\n\`\`\``
		);
	}
};

handler.help = ['install <package>', 'npmi <package>'];
handler.tags = ['owner'];
handler.command = /^(install|npmi|addpkg)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
