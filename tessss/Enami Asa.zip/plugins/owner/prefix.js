/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { args, usedPrefix, command, updateData }) => {
	const saveDb = async (col, val) => {
		try {
			await updateData('settings', 'bot', col, val);
		} catch (e) {
			console.error('Db Error:', e);
		}
	};

	if (command === 'setprefix') {
		if (!args[0])
			return m.reply(`*Cara penggunan:*
- ${usedPrefix}setprefix [new prefix]

*Contoh penggunaan*
- ${usedPrefix}setprefix /`);

		const newPrefix = args[0];

		global.prefix = newPrefix;
		await saveDb('prefix', newPrefix);

		return m.reply(`Prefix *[ ${usedPrefix} ]* berhasil di ubah menjadi *[ ${newPrefix} ]*`);
	}

	if (command === 'delprefix') {
		global.prefix = '.';
		await saveDb('prefix', '.');

		return m.reply(`Prefix berhasil di hapus!`);
	}

	if (command === 'prefix') {
		const mode = args[0] ? args[0].toLowerCase() : '';

		if (mode === 'on') {
			if (global.multiprefix) return m.reply('Sudah dalam mode aktif!');
			let p = global.prefix || '.';
			global.multiprefix = true;
			await saveDb('multiprefix', 1);
			return m.reply(`*Prefix ON ✅*

Gunakan awalan prefix *${p}* untuk memulai bot!

${usedPrefix}setprefix *untuk mengganti prefix*
${usedPrefix}prefix off *agar tanpa prefix*`);
		}

		if (mode === 'off') {
			if (!global.multiprefix) return m.reply('Sudah dalam mode offline!');

			global.multiprefix = false;
			await saveDb('multiprefix', 0);
			return m.reply(`*Prefix OFF ✅*

*Gunakan bot tanpa awalan prefix*
${usedPrefix}prefix on *agar menggunakan prefix*`);
		}

		let status = global.multiprefix ? 'ON' : 'OFF';
		let p = global.prefix || '.';

		let msg = `*Prefix settings*
- Mode prefix : *${status}*
- Prefix saat ini : *${p}*

*Command :*
- ${usedPrefix}prefix on *menggunakan prefix*
- ${usedPrefix}prefix off *tanpa prefix*
- ${usedPrefix}setprefix *settings prefix*`;

		return m.reply(msg);
	}
};

handler.command = ['prefix', 'setprefix', 'delprefix'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
