/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, reply, command, getGroup, updateData, getMutedGroups }) => {
	if (!m.isGroup && command !== 'listmute') return reply(mess.group);

	if (command === 'mute') {
		const chatDb = await getGroup(m.chat);

		if (chatDb.mute === 1) {
			return reply('*Grup* ini sudah di *mute*');
		}

		await updateData('groups', m.chat, 'mute', 1);
		return reply('Grup ini *berhasil di mute*');
	}

	if (command === 'unmute') {
		const chatDb = await getGroup(m.chat);

		if (chatDb.mute === 0) {
			return reply('Grup ini tidak di *mute*');
		}

		await updateData('groups', m.chat, 'mute', 0);
		return reply('Grup ini *berhasil di unmute*');
	}

	if (command === 'listmute') {
		const list = await getMutedGroups();

		if (!list.length) {
			return reply('Tidak ada Grup Chat yang sedang di-mute.');
		}

		let teks = '*List group di mute*\n\n';

		const rows = await Promise.all(
			list.map(async (row, i) => {
				let nama = 'Unknown';

				try {
					const meta = await sock.groupMetadata(row.id);
					nama = meta.subject;
				} catch {}

				return `- Name : ${nama}\n- ID Grup : ${row.id}\n`;
			})
		);

		teks += rows.join('\n');

		return reply(teks);
	}
};

handler.command = ['mute', 'unmute', 'listmute'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
