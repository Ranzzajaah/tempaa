/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	const botNumber = sock.user.id;
	if (!text)
		return reply(`*Cara penggunan:*
- ${usedPrefix + command} ./nama_filenya.js
- ${usedPrefix + command} ./nama_foldernya/nama_filenya.js`);

	let filePath = text.trim();

	if (!fs.existsSync(filePath)) {
		return reply(`File tidak ditemukan: *${filePath}*`);
	}

	if (!fs.statSync(filePath).isFile()) {
		return reply(`Path tersebut folder tidak bisa\n*${usedPrefix}listfile* untuk melihat detail`);
	}

	try {
		let buffer = fs.readFileSync(filePath);
		let fileName = path.basename(filePath);

		await sock.sendMessage(botNumber, {
			document: buffer,
			fileName,
			mimetype: 'application/octet-stream',
			caption: `*Success get file*\n- Target: *${filePath}*`,
		});

		await reply(`📬 *File berhasil diambil!*\nFile telah dikirim ke *private chat bot*.`);
	} catch (err) {
		console.log(err);
		return reply('❌ Gagal mengirim file.');
	}
};

handler.command = ['getfile'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
