/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const handler = async (m, { sock, reply, usedPrefix }) => {
  try {
    const baseDir = path.join(__dirname, '../../plugins')
    if (!fs.existsSync(baseDir)) return reply('Folder ./plugins tidak ditemukan.')

    const categories = fs.readdirSync(baseDir).filter(f =>
      fs.statSync(path.join(baseDir, f)).isDirectory()
    )

    let totalFiles = 0
    let teks = ''
    let globalIndex = 1

    for (const category of categories) {
      const catPath = path.join(baseDir, category)
      const files = fs.readdirSync(catPath).filter(f => f.endsWith('.js'))
      totalFiles += files.length

      teks += `\n\`${category.charAt(0).toUpperCase() + category.slice(1)}\`\n`
      for (const file of files) {
        teks += `> *${globalIndex}.* ${category}/${file}\n`
        globalIndex++
      }
    }

    const header = `*Info plugin files*
- *File plugin:* ${totalFiles}
- *Total folder:* ${categories.length}

*Command valid*
- ${usedPrefix}getplugin <path atau nomor>
- ${usedPrefix}addplugin <path> (reply codenya)
- ${usedPrefix}delplugin <path atau nomor>
- ${usedPrefix}cari <query>\n`

    return reply(header + teks)
  } catch (err) {
    console.error(err)
    reply('Terjadi kesalahan saat membaca daftar plugin.')
  }
}

handler.command = ['listplugin','lp']
handler.owner = true
handler.noJadiBot = true

export default handler
