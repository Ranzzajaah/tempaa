/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, isOwner, command, reply }) => {
	if (!isOwner) {
		return reply(global.mess.owner);
	}
	if (m.isGroup) {
		return reply(global.mess.private);
	}

	try {
		const isPin = command === "pinchat";
		await sock.chatModify({ pin: isPin }, m.chat);
		reply(isPin ? "📌 Chat berhasil disematkan (Pin)!" : "📌 Chat berhasil dilepas sematannya (Unpin)!");
	} catch (e) {
		console.error("[PINCHAT ERROR]:", e.message);
		reply("❌ Gagal mengubah status pin chat.");
	}
};

handler.help = ["pinchat", "unpinchat"];
handler.tags = ["owner"];
handler.command = ["pinchat", "unpinchat"];
handler.owner = true;

export default handler;