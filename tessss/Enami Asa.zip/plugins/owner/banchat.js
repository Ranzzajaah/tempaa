/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getGroup, updateData, getBanchatGroups } from "../../lib/database.js";
const handler = async (m, { sock, reply, command, getMutedGroups }) => {

	if (command === 'banchat') {
		if (!m.isGroup) return reply('❌ Command ini hanya bisa digunakan di dalam grup!');

		const chatDb = await getGroup(m.chat);

		if (chatDb.banchat === 1) {
			return reply('⚠️ Grup ini sudah di-banchat!');
		}

		await updateData('groups', m.chat, 'banchat', 1);
		return reply('✅ Mode *banchat* AKTIF untuk grup ini.\n\nBot tidak akan merespons command apapun di grup ini.');
	}

	if (command === 'unbanchat') {
		if (!m.isGroup) return reply('❌ Command ini hanya bisa digunakan di dalam grup!');

		const chatDb = await getGroup(m.chat);

		if (chatDb.banchat === 0) {
			return reply('✅ Grup ini tidak sedang di-banchat!');
		}

		await updateData('groups', m.chat, 'banchat', 0);
		return reply('✅ Mode *banchat* telah NONAKTIF untuk grup ini.\n\nBot kembali merespons command di grup ini.');
	}

	if (command === 'listbanchat') {
		const list = await getBanchatGroups();

		if (!list.length) {
			return reply('📭 Tidak ada grup yang sedang di-banchat.');
		}

		const rows = await Promise.all(
			list.map(async (row, i) => {
				let nama = 'Unknown';
				try {
					const meta = await sock.groupMetadata(row.id);
					nama = meta.subject;
				} catch {}
				return `${i + 1}. *${nama}*\n   ID: ${row.id}`;
			})
		);

		return reply(`🚫 *List Grup Di-Banchat*\nTotal: ${list.length} grup\n\n${rows.join('\n\n')}`);
	}
};

handler.command = ['banchat', 'unbanchat', 'listbanchat'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
