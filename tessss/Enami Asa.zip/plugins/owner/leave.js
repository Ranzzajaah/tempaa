/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	let targetJid = '';

	if (text) {
		const clean = text.trim();
		if (clean.endsWith('@g.us')) {
			targetJid = clean;
		} else if (/^\d+$/.test(clean)) {
			targetJid = `${clean}@g.us`;
		} else if (clean.includes('chat.whatsapp.com')) {
			const match = clean.match(/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i);
			if (match) {
				try {
					const inviteInfo = await sock.groupGetInviteInfo(match[1]);
					if (inviteInfo?.id) {
						targetJid = `${inviteInfo.id}@g.us`;
					}
				} catch (err) {
					return reply(`❌ Gagal mendapatkan ID grup dari link: ${err?.message || err}`);
				}
			}
		}
	}

	if (!targetJid && m.isGroup) {
		targetJid = m.chat;
	}

	if (!targetJid) {
		return reply(
			`📌 *Gunakan format:*\n\n` +
			`• *${usedPrefix + command}* (di dalam grup)\n` +
			`• *${usedPrefix + command} <ID_Grup>*\n` +
			`  _Contoh: ${usedPrefix + command} 120363012345678901@g.us_\n` +
			`• *${usedPrefix + command} <Link_Grup>*\n` +
			`  _Contoh: ${usedPrefix + command} https://chat.whatsapp.com/ExAmPlEcOdE123_`
		);
	}

	try {
		await sock.sendMessage(targetJid, { text: '👋 Bot keluar dari grup. Sampai jumpa!' }).catch(() => null);
		await sock.groupLeave(targetJid);
		reply(`✅ Berhasil keluar dari grup:\n\`${targetJid}\``);
	} catch (err) {
		console.error('[LEAVE ERROR]', err);
		reply(`❌ Gagal keluar dari grup:\n${err?.message || err}`);
	}
};

handler.command = ['leave'];
handler.owner = true;
handler.register = true;

handler.noJadiBot = true;

export default handler;
