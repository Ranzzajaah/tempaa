/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getDevice } from '@whiskeysockets/baileys';
import { getTrustedBots, addTrustedBot, removeTrustedBot } from "../../lib/database.js";
const handler = async (m, {
	sock,
	conn,
	command,
	usedPrefix,
	args
}) => {
	conn = sock || conn;
	const db = getTrustedBots();

	if (command === 'trustlistbot') {
		const list = Object.entries(db);
		if (!list.length) return m.reply('Belum ada bot yang di-trust.');

		let teks = `*≡ T R U S T - L I S T ≡*\n\n`;
		let mentions = [];

		list.forEach(([jid, data], i) => {
			const num = jid.split('@')[0];
			const trustedByNum = data.trustedBy?.split('@')[0] || '?';
			teks += `${i + 1}. @${num}\n`;
			teks += `├ Device: ${data.device || 'Unknown'}\n`;
			teks += `├ Number: ${num}\n`;
			teks += `└ Trusted By: @${trustedByNum}\n\n`;
			mentions.push(jid);
			if (data.trustedBy) mentions.push(data.trustedBy);
		});

		return conn.sendMessage(m.chat, {
			text: teks.trim(),
			mentions: [...new Set(mentions)]
		}, {
			quoted: m
		});
	}

	let target;
	if (m.quoted) {
		target = m.quoted.sender;
	} else if (m.mentionedJid?.[0]) {
		target = m.mentionedJid[0];
	} else if (args[0]) {
		target = args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
	}

	if (!target) return m.reply(`Mention atau reply bot yang mau di-trust/untrust.\n\nContoh:\n${usedPrefix + command} @bot`);

	const num = target.split('@')[0];

	if (command === 'untrustbot') {
		if (!db[target]) {
			return conn.sendMessage(m.chat, {
				text: `@${num} tidak ada di trust list.`,
				mentions: [target]
			}, { quoted: m });
		}
		removeTrustedBot(target);
		return conn.sendMessage(m.chat, {
			text: `✅ @${num} berhasil dihapus dari trust list.`,
			mentions: [target]
		}, { quoted: m });
	}

	if (db[target]) {
		return conn.sendMessage(m.chat, {
			text: `@${num} sudah ada di trust list.`,
			mentions: [target]
		}, { quoted: m });
	}

	let device = 'Unknown';
	try {
		const msgId = m.quoted?.id || m.quoted?.key?.id || '';
		if (msgId) device = getDevice(msgId);
	} catch {}

	const pushName = m.quoted?.pushName || num;

	addTrustedBot(target, {
		pushName,
		device,
		trustedBy: m.sender
	});

	return conn.sendMessage(m.chat, {
		text: `✅ @${num} berhasil ditambahkan ke trust list.\n├ Device: ${device}\n└ Number: ${num}`,
		mentions: [target]
	}, { quoted: m });
};

handler.command = ['trustbot', 'untrustbot', 'trustlistbot'];
handler.tags = ['owner'];
handler.owner = true;

handler.noJadiBot = true;

export default handler;
