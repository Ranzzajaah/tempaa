/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const handler = async (m, { sock, args, reply, usedPrefix }) => {
	const q = m.quoted ? m.quoted : m;
	const mime = (q.msg || q).mimetype || q.mimetype || (q.imageMessage ? 'image/jpeg' : '') || '';

	if (!/image/.test(mime)) {
		return reply(`Reply foto dulu untuk set thumb custom!\n\nContoh: reply foto lalu kirim\n${usedPrefix}setthumbfile menu4.jpg`);
	}

	const namaFile = args[0] ? args[0].replace(/[^a-zA-Z0-9._-]/g, '') : `thumb_${Date.now()}.jpg`;
	const savePath = `media/${namaFile}`;

	let buffer = null;
	if (typeof q.download === 'function') {
		buffer = await q.download().catch(() => null);
	}
	if (!buffer && q.msg) {
		buffer = await sock.downloadM(q.msg, 'image').catch(() => null);
	}
	if (!buffer) {
		buffer = await sock.downloadM(q, 'image').catch(() => null);
	}

	if (!buffer || buffer.length === 0) {
		return reply('❌ Gagal mendownload foto dari reply.');
	}

	if (!fs.existsSync('media')) fs.mkdirSync('media', { recursive: true });
	fs.writeFileSync(savePath, buffer);

	return reply(`Foto berhasil disimpan ke *${savePath}*\n\nGunakan \`${usedPrefix}setreply ${namaFile}\` atau \`${usedPrefix}setthumb 1/2/3\` untuk mengaktifkannya.`);
};

handler.command = ['setthumbfile'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
