/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { delay } from '@whiskeysockets/baileys';

if (!global._bungkamUsers) {
	global._bungkamUsers = new Set();
}

async function deleteByDmsg(sock, chatId, stanzaId) {
	try {
		const tempId = await sock.relayMessage(
			chatId,
			{
				groupStatusMessageV2: {
					message: {
						extendedTextMessage: {
							text: '',
							contextInfo: {
								isGroupStatus: true,
							},
						},
					},
				},
			},
			{}
		);

		const tempId2 = await sock.relayMessage(
			chatId,
			{
				protocolMessage: {
					key: {
						jid: chatId,
						fromMe: true,
						id: tempId,
					},
					type: 14,
					editedMessage: {
						extendedTextMessage: {
							text: '\0',
							contextInfo: {
								isGroupStatus: false,
							},
						},
					},
				},
			},
			{
				messageId: stanzaId,
			}
		);

		await delay(80);

		await Promise.allSettled([
			sock.sendMessage(chatId, {
				delete: {
					remoteJid: chatId,
					id: tempId,
					fromMe: true,
				},
			}),
			sock.sendMessage(chatId, {
				delete: {
					remoteJid: chatId,
					id: tempId2,
					fromMe: true,
				},
			}),
		]);
	} catch (err) {
		console.error('[Bungkam Dmsg Error]', err?.message || err);
	}
}

function toCleanPhoneJid(jid, sock) {
	if (!jid) return null;
	if (typeof sock?.getJid === 'function') {
		const res = sock.getJid(jid);
		if (res && !res.endsWith('@lid')) {
			const clean = res.split('@')[0].split(':')[0];
			return clean + '@s.whatsapp.net';
		}
	}
	const clean = jid.split('@')[0].split(':')[0];
	return clean + '@s.whatsapp.net';
}

const handler = async (m, { sock, args, text, command, reply, isOwner }) => {
	if (!isOwner) return reply(mess.owner);

	let rawTarget = null;

	if (m.quoted) {
		rawTarget = m.quoted.sender || m.quoted.key?.participant;
	} else if (m.mentionedJid && m.mentionedJid.length > 0) {
		rawTarget = m.mentionedJid[0];
	} else if (text) {
		const cleanNumber = text.replace(/[^0-9]/g, '');
		if (cleanNumber.length >= 7) {
			rawTarget = cleanNumber + '@s.whatsapp.net';
		}
	}

	const targetJid = toCleanPhoneJid(rawTarget, sock);
	const chatId = m.chat;

	if (command === 'bungkam') {
		if (!targetJid) {
			return reply(`*Cara Penggunaan:*\n• Reply pesan target ketik *.bungkam*\n• Ketik *.bungkam @tag*\n• Ketik *.bungkam 628xxx*`);
		}

		const key = `${chatId}:${targetJid}`;
		if (global._bungkamUsers.has(key)) {
			return sock.sendMessage(chatId, {
				text: `⚠️ @${targetJid.split('@')[0]} sudah dalam status *dibungkam* di grup ini!`,
				mentions: [targetJid]
			}, { quoted: m });
		}

		global._bungkamUsers.add(key);
		if (rawTarget && rawTarget !== targetJid) {
			global._bungkamUsers.add(`${chatId}:${rawTarget}`);
		}

		if (m.quoted && m.quoted.id) {
			await deleteByDmsg(sock, chatId, m.quoted.id);
		}

		return sock.sendMessage(chatId, {
			text: `🔇 *BUNGKAM AKTIF*\n\nTarget: @${targetJid.split('@')[0]}\nStatus: Pesan target akan otomatis dihapus menggunakan sistem *dmsg* di grup ini.`,
			mentions: [targetJid]
		}, { quoted: m });
	}

	if (command === 'unbungkam') {
		if (!targetJid) {
			return reply(`*Cara Penggunaan:*\n• Reply pesan target ketik *.unbungkam*\n• Ketik *.unbungkam @tag*\n• Ketik *.unbungkam 628xxx*`);
		}

		const key = `${chatId}:${targetJid}`;
		global._bungkamUsers.delete(key);
		if (rawTarget) {
			global._bungkamUsers.delete(`${chatId}:${rawTarget}`);
		}

		return sock.sendMessage(chatId, {
			text: `🔊 *BUNGKAM DIMATIKAN*\n\nTarget: @${targetJid.split('@')[0]}\nStatus: Bebas mengirim pesan kembali.`,
			mentions: [targetJid]
		}, { quoted: m });
	}

	if (command === 'listbungkam') {
		const listInChat = [];
		for (const k of global._bungkamUsers) {
			const [cId, sJid] = k.split(':');
			if (cId === chatId && sJid.endsWith('@s.whatsapp.net')) {
				listInChat.push(sJid);
			}
		}

		const uniqueList = [...new Set(listInChat)];

		if (!uniqueList.length) {
			return reply('📭 Tidak ada target yang sedang dibungkam di grup ini.');
		}

		const teks = `🔇 *Daftar User Dibungkam (Dmsg):*\n\n` +
			uniqueList.map((jid, i) => `${i + 1}. @${jid.split('@')[0]}`).join('\n') +
			`\n\n_Total: ${uniqueList.length} user_`;

		return sock.sendMessage(chatId, {
			text: teks,
			mentions: uniqueList
		}, { quoted: m });
	}
};

handler.before = async (m, { sock, isOwner }) => {
	if (!m.sender || !m.chat) return;
	if (m.fromMe || isOwner) return;

	const senderClean = toCleanPhoneJid(m.sender, sock);
	const rawSender = m.key?.participant || m.sender;

	const isTarget = 
		global._bungkamUsers?.has(`${m.chat}:${senderClean}`) ||
		global._bungkamUsers?.has(`${m.chat}:${rawSender}`);

	if (isTarget) {
		const stanzaId = m.key?.id;
		if (stanzaId) {
			await deleteByDmsg(sock, m.chat, stanzaId);
		}
	}
};

handler.help = ['bungkam', 'unbungkam', 'listbungkam'];
handler.tags = ['owner'];
handler.command = ['bungkam', 'unbungkam', 'listbungkam'];
handler.owner = true;
handler.noJadiBot = true;
handler.group = true;

export default handler;
