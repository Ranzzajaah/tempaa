/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const thumbNames = { 1: 'menu.jpg', 2: 'menu2.jpg', 3: 'menu3.jpg' };

const handler = async (m, { reply }) => {
	const idx = global.thumbIndex || 0;
	return reply(`*Settings ${global.namaBot || 'Bot'}*\n\n` +
		`• Nama bot     : ${global.namaBot || '-'}\n` +
		`• Owner        : ${global.namaOwner || '-'}\n` +
		`• Website      : ${global.website || '-'}\n` +
		`• Thumb aktif  : ${thumbNames[idx] ? `thumb ${idx} (${thumbNames[idx]})` : 'custom'} — ${global.fotoreply || 'media/menu.jpg'}\n` +
		`• Mode         : ${global.public ? 'Public' : 'Self'}\n\n` +
		`*Commands:*\n` +
		`.setthumb 1/2/3 — ganti thumbnail bawaan\n` +
		`.setweb <url> — ganti website link\n` +
		`.setreply — reply foto untuk ganti foto reply\n` +
		`.setthumbfile — upload thumb baru ke media/\n` +
		`.setsong — upload lagu menu baru\n` +
		`.setowner <nama> — ganti nama owner`
	);
};

handler.command = ['settings'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
