/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { args, usedPrefix, command, isOwner }) => {
    if (!isOwner) return m.reply(global.mess?.owner || "Khusus Owner!");

    const opt = (args[0] || "").toLowerCase();
    if (!["on", "off", "enable", "disable", "1", "0"].includes(opt)) {
        return m.reply(`🛠️ *PENGATURAN AUTO BLOCK PM*\n\nGunakan:\n• \`${usedPrefix + command} on\` (Aktifkan auto block & catat DB)\n• \`${usedPrefix + command} off\` (Nonaktifkan)`);
    }

    const isEnable = ["on", "enable", "1"].includes(opt);
    if (typeof global.setAntipm === "function") {
        await global.setAntipm(isEnable);
    }

    return m.reply(`✅ Fitur Auto Block PM & Hama DB berhasil di *${isEnable ? "AKTIFKAN" : "NONAKTIFKAN"}*.`);
};

handler.command = ["antipm", "setantipm", "autoblockpm"];
handler.tags = ["owner"];
handler.help = ["antipm <on/off>"];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
