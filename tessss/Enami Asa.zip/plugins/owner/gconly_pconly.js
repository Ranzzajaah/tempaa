import { setBotMode } from '../../lib/database.js';

const handler = async (m, { reply, args, command, usedPrefix, updateData }) => {
  let status = (args[0] || "").toLowerCase();
  if (!["on", "off"].includes(status)) {
    return reply(`Contoh: ${usedPrefix + command} on/off`);
  }

  const isEnable = status === "on";

  try {
    if (command === "pconly") {
      const targetMode = isEnable ? "onlypv" : "public";
      global.mode = targetMode;
      global.public = targetMode === "public";
      await setBotMode(targetMode);
      return reply(`Mode *ONLYPV (pconly)* berhasil di${isEnable ? 'aktifkan' : 'matikan'}`);
    } 
    
    if (command === "gconly") {
      const targetMode = isEnable ? "onlygc" : "public";
      global.mode = targetMode;
      global.public = targetMode === "public";
      await setBotMode(targetMode);
      return reply(`Mode *ONLYGC (gconly)* berhasil di${isEnable ? 'aktifkan' : 'matikan'}`);
    }

  } catch (e) {
    console.error(e);
    reply('Gagal menyimpan ke database.');
  }
};

handler.command = ["pconly", "gconly"];
handler.owner = true;
handler.noJadiBot = true;

export default handler;