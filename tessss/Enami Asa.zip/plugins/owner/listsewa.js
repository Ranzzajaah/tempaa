/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getAllSewa, formatSewaTime } from "../../lib/database.js";

const handler = async (m, { isOwner, reply }) => {
	if (!isOwner) return reply(global.mess?.owner || '🍓 Akses Khusus Owner!');
	if (m.isBaileys) return reply('ngapain 😂?');

	const list = getAllSewa();
	if (!list.length) return reply('Tidak ada grup dalam daftar sewa.');

	const now = Date.now();
	let teks = `📋 *LIST DAFTAR SEWA GRUP*\n\n• Total: ${list.length} Grup\n\n`;
	for (const [i, item] of list.entries()) {
		const remaining = item.expired - now;
		const status = remaining > 0 ? `Aktif (${formatSewaTime(remaining)})` : 'Expired';
		const expDate = new Date(item.expired).toLocaleString('id-ID', {
			timeZone: 'Asia/Jakarta',
			dateStyle: 'medium',
			timeStyle: 'short'
		});

		teks += `${i + 1}. ID: ${item.jid}\n• Status: ${status}\n• Expired: ${expDate} WIB\n\n`;
	}
	return reply(teks.trim());
};

handler.help = ['listsewa'];
handler.tags = ['owner'];
handler.command = ['listsewa', 'sewalist', 'daftarsewa'];
handler.category = 'owner';
handler.owner = true;
handler.noJadiBot = true;

export default handler;
