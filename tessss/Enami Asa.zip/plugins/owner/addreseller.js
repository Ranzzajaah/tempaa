/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { addReseller } from "../../lib/database.js";
const handler = async (m, { args, usedPrefix }) => {
	const target = args[0]
		? args[0]
		: m.mentionedJid && m.mentionedJid[0]
			? m.mentionedJid[0]
			: m.quoted
				? m.quoted.sender
				: null;

	if (!target) {
		return m.reply(`❌ *Format Salah!*\n\nContoh: *${usedPrefix}addreseller 628xxxx* atau tag user.`);
	}

	const added = await addReseller(target);
	return m.reply(`✅ *BERHASIL MENAMBAHKAN RESELLER PANEL*\n\nUser *@${added.split('@')[0]}* sekarang memiliki akses membuat panel 1GB - 10GB & Unlimited!`);
};

handler.command = ['addreseller', 'addrespanel'];
handler.category = 'owner';
handler.description = 'Tambah user Reseller Panel';
handler.owner = true;
handler.noJadiBot = true;

export default handler;
