/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import fs from 'fs';

const handler = async (m, { sock, text, command, reply, example, usedPrefix }) => {
	if (!text.includes('./')) return reply(example(`filenya mana?\n\nContoh: ${usedPrefix + command} ./package.json\n\n*sambil reply file nya!*`));
	let files = fs.readdirSync(text.split(m.quoted.fileName)[0]);
	if (!files.includes(m.quoted.fileName)) return reply('File not found');
	let media = await downloadContentFromMessage(m.quoted, 'document');
	let buffer = Buffer.from([]);
	for await (const chunk of media) {
		buffer = Buffer.concat([buffer, chunk]);
	}
	fs.writeFileSync(text, buffer);
	reply(`process . . .`);
	await sleep(5000);
	reply(`Berhasil mengganti file *${q}*`);
};

handler.command = ['gfl', 'gantifile', 'ubahfile'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
