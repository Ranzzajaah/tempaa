/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getResellerList } from "../../lib/database.js";
const handler = async (m) => {
	const list = getResellerList();
	if (!list || list.length === 0) {
		return m.reply(`📌 *LIST RESELLER PANEL*\n\nBelum ada user reseller panel.`);
	}

	let msg = `🔑 *LIST RESELLER PANEL*\n\n`;
	list.forEach((item, index) => {
		msg += `${index + 1}. @${item.jid.split('@')[0]}\n`;
	});
	msg += `\n🔰 *Total:* ${list.length} reseller panel`;

	return m.reply(msg);
};

handler.command = ['listreseller', 'listrespanel'];
handler.category = 'owner';
handler.description = 'Tampilkan daftar user Reseller Panel';
handler.owner = true;
handler.noJadiBot = true;

export default handler;
