/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	let targetJid = (text || '').trim();

	if (!targetJid) {
		return reply(
			`*HAPUS SALURAN*\n\n` +
			`Format: *${usedPrefix + command} <id_saluran>*\n` +
			`Contoh: *${usedPrefix + command} 120363xxx@newsletter*`
		);
	}

	if (!targetJid.endsWith('@newsletter')) {
		targetJid += '@newsletter';
	}

	try {
		await client.newsletterDelete(targetJid);
		await global.react(client, m, 'success');
		return reply(`*Saluran Berhasil Dihapus*\n\nID: ${targetJid}`);
	} catch (err) {
		console.error('[HAPUSSALURAN ERROR]', err);
		await global.react(client, m, 'error');
		return reply(`*Gagal menghapus saluran*\nError: ${err.message || err}`);
	}
};

handler.help = ['hapussaluran <id>'];
handler.tags = ['owner'];
handler.command = /^(hapussaluran|delsaluran|delch|hapusch)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
