/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getPremiumList } from "../../lib/database.js";
const handler = async (m, { sock, reply }) => {
	if (m.isBaileys) return reply('ngapain 😂?');

	const list = getPremiumList();
	if (list.length < 1) return reply('Tidak ada user premium saat ini.');

	let teks = `*✨ List Pengguna Premium*\n\n`;
	list.forEach((row, i) => {
		const num = row.jid.split('@')[0];
		teks += `${i + 1}. @${num}\n   ┗ Ditambah: ${row.added_at}\n`;
	});

	await sock.sendMessage(m.chat, { text: teks, mentions: list.map(r => r.jid) }, { quoted: m });
};

handler.command = ['listprem', 'listpremium'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
