/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, text, usedPrefix, command, args, reply }) => {
	const client = conn || sock || global.mainSock;

	let target = m.mentionedJid?.[0] || (m.quoted ? (m.quoted.sender || m.quoted.participant) : null);
	let reason = '';

	if (target) {
		const raw = text || '';
		reason = raw.replace(/@\d+/g, '').trim() || 'Melanggar aturan bot';
	} else if (args[0]) {
		const targetNum = args[0].replace(/[^0-9]/g, '');
		if (targetNum.length >= 5) {
			target = `${targetNum}@s.whatsapp.net`;
			reason = args.slice(1).join(' ').trim() || 'Melanggar aturan bot';
		}
	}

	if (!target) {
		return reply(
			`*BAN USER DARI BOT*\n\n` +
			`Format:\n` +
			`• *${usedPrefix + command} @tag [alasan]*\n` +
			`• *${usedPrefix + command} 628xxxx [alasan]*\n` +
			`• Reply pesan target lalu ketik *${usedPrefix + command} [alasan]*`
		);
	}

	const targetNum = target.split('@')[0];
	const isTargetOwner = (global.owner || []).some(o => String(o).replace(/[^0-9]/g, '') === targetNum);

	if (isTargetOwner) {
		return reply('❌ Tidak dapat membanned Owner bot!');
	}

	try {
		await getUser(target);
		await updateUser(target, { banned: 1, banReason: reason });
		await global.react(client, m, 'success');

		await reply(
			`*USER BERHASIL DIBANNED*\n\n` +
			`Target: @${targetNum}\n` +
			`Alasan: ${reason}\n\n` +
			`_User tidak dapat menggunakan semua perintah bot lagi._`,
			null,
			{ mentions: [target] }
		);
	} catch (e) {
		console.error('[BANUSER ERROR]', e);
		await global.react(client, m, 'error');
		return reply(`Gagal membanned user: ${e.message}`);
	}
};

handler.help = ['banuser @tag [alasan]', 'ban <nomor>'];
handler.tags = ['owner'];
handler.command = /^(banuser|ban|blockuser)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
