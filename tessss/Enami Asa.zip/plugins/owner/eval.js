/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import util from 'util';
import { exec } from 'child_process';

let handler = async (m, { sock, reply, mess, command, text, usedPrefix }) => {
	const body = (m.text || '').trim();
	const baseCommand = (command || '').toLowerCase();
	let codeBody = text || '';

	let isReturnEval = false;

	if (baseCommand === '=>' || body.startsWith('=>')) {
		isReturnEval = true;
	}

	if (baseCommand === '>' || baseCommand === '=>' || baseCommand === '$') {
		const prfxLen = usedPrefix ? usedPrefix.length : 0;
		if (body.startsWith('=>')) {
			codeBody = body.slice(2).trim();
		} else if (body.startsWith('>') || body.startsWith('$')) {
			codeBody = body.slice(1).trim();
		} else if (prfxLen > 0) {
			const cmdLen = baseCommand.length;
			codeBody = body.slice(prfxLen + cmdLen).trim();
		}
	}

	switch (baseCommand) {
		case 'ambilq':
		case 'q':
			try {
				if (!m.quoted) return reply(`Ex: ${usedPrefix || ''}q (reply pesannya)`);
				const result = m.quoted;
				const output = util.inspect(result, { depth: 5 });
				await sock.sendMessage(m.chat, { text: output }, { quoted: m });
			} catch (err) {
				await sock.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
			}
			break;

		case 'eval':
		case '>':
		case '=>':
			try {
				let code = codeBody;
				if (!code) return reply(`Contoh: > kodenya atau => kodenya`);

				if (isReturnEval && !code.startsWith('return ')) {
					code = `return ${code}`;
				}

				const conn = sock;
				const client = sock;
				const kyzz = sock;
				const bot = sock;
				const hirara = sock;

				const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
				const fn = new AsyncFunction(
					'sock', 'conn', 'client', 'kyzz', 'bot', 'hirara', 'm', 'reply', 'text', 'mess', 'util', 'usedPrefix',
					`return (async () => { ${code} })()`
				);
				let result = await fn(sock, conn, client, kyzz, bot, hirara, m, reply, text, mess, util, usedPrefix);

				if (typeof result !== 'string') result = util.inspect(result);

				await sock.sendMessage(m.chat, { text: result }, { quoted: m });
			} catch (err) {
				await sock.sendMessage(m.chat, { text: util.format(err) }, { quoted: m });
			}
			break;

		case '$':
			const shellCommand = codeBody;
			if (!shellCommand) return reply(`Contoh: $ command_nya`);

			exec(shellCommand, (err, stdout, stderr) => {
				if (err) return sock.sendMessage(m.chat, { text: err.toString() }, { quoted: m });
				if (stdout) return sock.sendMessage(m.chat, { text: util.format(stdout) }, { quoted: m });
				if (stderr) return sock.sendMessage(m.chat, { text: util.format(stderr) }, { quoted: m });

				return sock.sendMessage(m.chat, { text: 'Done (No output)' }, { quoted: m });
			});
			break;

		default:
			break;
	}
};

handler.help = ['>', '=>', '$', 'eval'];
handler.tags = ['owner'];
handler.command = ['eval', '>', '$'];
handler.customPrefix = /^([>=$])/;
handler.owner = true;
handler.noJadiBot = true;

export default handler;