let handler = async (m, { sock }) => {

	if (!m.quoted || !m.quoted.message) {
		return m.reply('Reply status/story nya')
	}

	try {

		let msg = m.quoted.message
		let type = Object.keys(msg)[0]

		let content

		if (type === 'groupStatusMessageV2') {

			content = msg[type].message
			type = Object.keys(content)[0]

		} else {

			content = msg
		}

		if (content?.[type]?.contextInfo) {
			delete content[type].contextInfo
		}

		await sock.relayMessage(
			m.chat,
			content,
			{}
		)

		m.reply('Berhasil mengambil story')

	} catch (e) {

		console.error(e)

		m.reply(
			'Gagal mengambil story\n\n' +
			e.message
		)
	}
}

handler.command = ['getsw', 'gsw']
handler.noJadiBot = true

export default handler