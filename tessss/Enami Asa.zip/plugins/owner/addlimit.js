const handler = async (m, { sock, text, usedPrefix, command, getUser, updateUser }) => {
  // 1. Tentukan target (dari tag/mention atau reply pesan)
  let who;
  if (m.isGroup) {
    who = m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : false);
  } else {
    // Jika di private chat dan me-reply pesan
    who = m.quoted ? m.quoted.sender : m.chat;
  }

  if (!who) {
    return m.reply(
      `❌ Tag atau balas pesan pengguna yang ingin ditambahkan limitnya!\n\n` +
      `*Contoh Penggunaan:*\n` +
      `› \`${usedPrefix + command} @user 50\``
    );
  }

  // 2. Ekstrak nominal angka dari teks
  let txt = text.replace('@' + who.split('@')[0], '').trim();
  let amount = parseInt(txt);

  if (isNaN(amount) || amount <= 0) {
    return m.reply(`❌ Masukkan nominal angka yang valid!\n\n*Contoh:* \`${usedPrefix + command} @user 50\``);
  }

  try {
    // 3. Ambil data user dari Database SQLite (menggunakan helper bawaan)[cite: 3, 5]
    const targetUser = await getUser(who);
    
    // Jika user belum pernah berinteraksi/terdaftar
    if (!targetUser) {
      return m.reply(`❌ Pengguna tersebut belum terdaftar di database bot.`);
    }

    // Ambil limit saat ini (fallback ke 0 jika belum ada)
    const currentLimit = targetUser.limit || targetUser.limit_val || 0;
    const newLimit = currentLimit + amount;

    // 4. Simpan limit baru ke Database SQLite
    await updateUser(who, { limit: newLimit });

    // 5. Kirim pesan konfirmasi
    await sock.sendMessage(m.chat, { 
      text: `✅ *LIMIT BERHASIL DITAMBAHKAN*\n\n` +
            `› *Target:* @${who.split('@')[0]}\n` +
            `› *Ditambahkan:* +${amount}\n` +
            `› *Total Limit Sekarang:* ${newLimit}`, 
      mentions: [who] 
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply(`❌ Terjadi kesalahan saat menyimpan ke database.`);
  }
};

handler.help = ['addlimit <@user> <jumlah>'];
handler.tags = ['owner'];
handler.command = ['addlimit', 'tambahlimit'];
handler.owner = true;
handler.group = false;

export default handler;