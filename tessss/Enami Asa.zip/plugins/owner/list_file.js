/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const ignoredFolders = ['sessions', 'session', 'auth', 'Auth', '.sessions', 'node_modules', 'npm', '.npm', '_npm', '.git', 'tmp', 'temp'];

function getAllFiles(dir, fileList = []) {
	const files = fs.readdirSync(dir);

	for (let file of files) {
		const fullPath = path.join(dir, file);
		const relPath = path.relative(process.cwd(), fullPath);
		if (ignoredFolders.some((folder) => relPath.startsWith(folder))) continue;

		const stat = fs.statSync(fullPath);

		if (stat.isDirectory()) {
			getAllFiles(fullPath, fileList);
		} else {
			fileList.push(fullPath);
		}
	}

	return fileList;
}

const handler = async (m, { sock, reply, usedPrefix }) => {
	try {
		const root = process.cwd();
		const allFiles = getAllFiles(root);

		let text = `*LIST ALL FILES*\n`;

		allFiles.forEach((f, i) => {
			text += `> ./${f.replace(root + '/', '')}\n`;
		});
		text += `\n*COMMAND VALID*
- ${usedPrefix}gantifile
- ${usedPrefix}getfile`;

		reply(text);
	} catch (err) {
		console.log(err);
		reply('❌ Error saat mengambil list file.');
	}
};

handler.command = ['listfile', 'lf', 'listfiles'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
