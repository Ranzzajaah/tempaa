/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { createCanvas } from '@napi-rs/canvas';

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawBar(ctx, x, y, w, h, val, max, color1, color2) {
  rrp(ctx, x, y, w, h, h / 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.fill();
  const fillW = Math.max(h, w * Math.min(1, Math.max(0, val / (max || 1))));
  const g = ctx.createLinearGradient(x, 0, x + fillW, 0);
  g.addColorStop(0, color1);
  g.addColorStop(1, color2);
  rrp(ctx, x, y, fillW, h, h / 2);
  ctx.fillStyle = g;
  ctx.fill();
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function generateDbStatsCanvas({ mainSize, walSize, shmSize, totalSize, totalUsers, totalGroups, registeredUsers, pageSize, pageCount }) {
  const W = 850, H = 480;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#fdfbf7');
  bgGrad.addColorStop(0.5, '#f7f0e6');
  bgGrad.addColorStop(1, '#f1e6d6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 700; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 14);
  ctx.strokeStyle = '#c9956e';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  rrp(ctx, p + 5, p + 5, W - p * 2 - 10, H - p * 2 - 10, 10);
  ctx.strokeStyle = 'rgba(201, 149, 110, 0.35)';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = 'bold 26px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText('DATABASE STORAGE STATS', p + 30, p + 50);

  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText('SQLITE WAL ENGINE', W - p - 170, p + 48);

  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(p + 30, p + 70);
  ctx.lineTo(W - p - 30, p + 70);
  ctx.stroke();

  const col1X = p + 35;
  let currY = p + 110;

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText('FILE STORAGE USAGE', col1X, currY);

  currY += 25;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`Main DB (database.db): ${formatBytes(mainSize)}`, col1X, currY);
  drawBar(ctx, col1X, currY + 8, 330, 10, mainSize, totalSize || 1, '#c9956e', '#8c502b');

  currY += 38;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`WAL Log (-wal): ${formatBytes(walSize)}`, col1X, currY);
  drawBar(ctx, col1X, currY + 8, 330, 10, walSize, totalSize || 1, '#d97706', '#f59e0b');

  currY += 38;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`SHM Index (-shm): ${formatBytes(shmSize)}`, col1X, currY);
  drawBar(ctx, col1X, currY + 8, 330, 10, shmSize, totalSize || 1, '#dc2626', '#ef4444');

  const col2X = col1X + 380;
  let currY2 = p + 110;

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText('RECORD ROWS & USERS', col2X, currY2);

  currY2 += 25;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`Total Users: ${totalUsers.toLocaleString('id-ID')}`, col2X, currY2);
  drawBar(ctx, col2X, currY2 + 8, 330, 10, totalUsers, totalUsers || 1, '#059669', '#10b981');

  currY2 += 38;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`Registered Users: ${registeredUsers.toLocaleString('id-ID')}`, col2X, currY2);
  drawBar(ctx, col2X, currY2 + 8, 330, 10, registeredUsers, totalUsers || 1, '#2563eb', '#60a5fa');

  currY2 += 38;
  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText(`Group Data: ${totalGroups.toLocaleString('id-ID')}`, col2X, currY2);
  drawBar(ctx, col2X, currY2 + 8, 330, 10, totalGroups, totalGroups || 1, '#7c3aed', '#a78bfa');

  const boxY = H - p - 80;
  rrp(ctx, col1X, boxY, W - p * 2 - 70, 58, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.85)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = '13px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText(`TOTAL STORAGE: ${formatBytes(totalSize)}`, col1X + 20, boxY + 25);
  ctx.fillText(`PAGE SIZE: ${formatBytes(pageSize)} | PAGES: ${pageCount}`, col1X + 20, boxY + 44);

  ctx.font = 'bold 15px sans-serif';
  ctx.fillStyle = '#15803d';
  ctx.textAlign = 'right';
  ctx.fillText('HEALTHY ✓', W - p - 50, boxY + 35);

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock, isOwner }) => {
  const dbDir = path.join(process.cwd(), 'data');
  const dbPath = path.join(dbDir, 'database.db');
  const walPath = path.join(dbDir, 'database.db-wal');
  const shmPath = path.join(dbDir, 'database.db-shm');

  const getFileSize = (p) => {
    try {
      return fs.existsSync(p) ? fs.statSync(p).size : 0;
    } catch (_) {
      return 0;
    }
  };

  const mainSize = getFileSize(dbPath);
  const walSize = getFileSize(walPath);
  const shmSize = getFileSize(shmPath);
  const totalSize = mainSize + walSize + shmSize;

  let totalUsers = 0, registeredUsers = 0, totalGroups = 0;
  let pageSize = 4096, pageCount = 0;

  try {
    const Database = (await import('better-sqlite3')).default;
    const db = new Database(dbPath, { readonly: true });
    totalUsers = db.prepare('SELECT COUNT(*) as c FROM users').get()?.c || 0;
    registeredUsers = db.prepare('SELECT COUNT(*) as c FROM users WHERE registered = 1').get()?.c || 0;
    totalGroups = db.prepare('SELECT COUNT(*) as c FROM groups').get()?.c || 0;
    pageSize = db.pragma('page_size', { simple: true }) || 4096;
    pageCount = db.pragma('page_count', { simple: true }) || 0;
    db.close();
  } catch (_) {}

  const cardBuffer = await generateDbStatsCanvas({
    mainSize,
    walSize,
    shmSize,
    totalSize,
    totalUsers,
    totalGroups,
    registeredUsers,
    pageSize,
    pageCount
  }).catch(() => null);

  const caption = `🗄️ *DATABASE STATS & STORAGE*\n\n` +
    `📁 *Ukuran Berkas*\n` +
    `• database.db : ${formatBytes(mainSize)}\n` +
    `• -wal Log   : ${formatBytes(walSize)}\n` +
    `• -shm Index : ${formatBytes(shmSize)}\n` +
    `• *Total     : ${formatBytes(totalSize)}*\n\n` +
    `📊 *Pengguna & Grup*\n` +
    `• Total Pengguna : ${totalUsers.toLocaleString('id-ID')}\n` +
    `• Terdaftar      : ${registeredUsers.toLocaleString('id-ID')}\n` +
    `• Total Grup     : ${totalGroups.toLocaleString('id-ID')}\n\n` +
    `⚙️ *SQLite Info*\n` +
    `• Ukuran Halaman : ${formatBytes(pageSize)}\n` +
    `• Jumlah Halaman : ${pageCount.toLocaleString('id-ID')}`;

  if (cardBuffer) {
    await sock.sendMessage(m.chat, {
      image: cardBuffer,
      caption
    }, { quoted: m });
  } else {
    m.reply(caption);
  }
};

handler.command = ['dbstats', 'dbsize', 'dbinfo'];
handler.category = 'owner';
handler.description = 'Cek ukuran dan statistik SQLite database';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
