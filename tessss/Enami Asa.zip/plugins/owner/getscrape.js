/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from "fs";
import path from "path";

const SCRAPE_DIR = path.join(process.cwd(), "scrape");

let AIRich = null;
try {
	const mb = await import("../../lib/helper-bails.js");
	AIRich = mb.AIRich || null;
} catch {}

const handler = async (m, { sock, conn, text, command, usedPrefix, isOwner, reply }) => {
	const client = sock || conn || global.mainSock;
	if (!isOwner) return reply(global.mess?.owner || "Khusus Owner!");

	if (!fs.existsSync(SCRAPE_DIR)) return reply("📂 Folder `scrape/` belum ada.");
	const files = fs.readdirSync(SCRAPE_DIR).filter(f => f.endsWith(".js"));

	if (!text) {
		return reply(
			`📂 *GET SCRAPE CODE*\n\n` +
			`Contoh Penggunaan:\n` +
			`• *${usedPrefix + command} ngl.js*\n` +
			`• *${usedPrefix + command} 1*\n\n` +
			`Ketik *${usedPrefix}listscrape* untuk melihat nomor & daftar scraper.`
		);
	}

	const input = text.trim();
	let targetFile = null;

	if (/^\d+$/.test(input)) {
		const idx = parseInt(input, 10) - 1;
		if (idx < 0 || idx >= files.length) {
			return reply(`❌ Nomor *${input}* tidak valid. Total scraper: ${files.length}`);
		}
		targetFile = files[idx];
	} else {
		targetFile = input.endsWith(".js") ? input : `${input}.js`;
	}

	const targetPath = path.join(SCRAPE_DIR, targetFile);
	if (!fs.existsSync(targetPath)) {
		return reply(`❌ Scraper *${targetFile}* tidak ditemukan.\n\nKetik *${usedPrefix}listscrape* untuk lihat daftar.`);
	}

	const fileContent = fs.readFileSync(targetPath, "utf-8");
	const filename = path.basename(targetPath);
	const ext = path.extname(filename).slice(1).toLowerCase() || "javascript";
	const lang = (ext === "js" || ext === "mjs" || ext === "cjs") ? "javascript" : (ext === "html" || ext === "htm" ? "html" : (ext === "json" ? "json" : ext));

	const heading = `### 📂 Scraper: ${targetFile}`;
	const meta = `*File:* scrape/${targetFile}\n*Size:* ${fileContent.length} bytes\n*Type:* ${ext.toUpperCase()}`;
	const pills = [targetFile, `${fileContent.length}b`, "SCRAPER"];

	if (AIRich && fileContent.length < 65000) {
		try {
			const rich = new AIRich(client);
			if (heading) rich.addText(heading);
			if (meta) rich.addMetadata(meta);
			const cleanPills = pills.filter(Boolean).map(String);
			if (cleanPills.length) rich.addSuggest(cleanPills);
			rich.addCode(lang, fileContent);
			return await rich.send(m.chat, { quoted: m });
		} catch (errRich) {
			console.error("[GETSCRAPE AIRICH ERROR]", errRich);
		}
	}

	return await client.sendMessage(
		m.chat,
		{
			document: fs.readFileSync(targetPath),
			fileName: filename,
			mimetype: "application/javascript",
			caption: `📂 *SCRAPER SOURCE CODE*\n📌 *File:* scrape/${targetFile}\n📊 *Size:* ${fileContent.length} bytes`
		},
		{ quoted: m }
	);
};

handler.help = ["getscrape <nama/nomor>"];
handler.tags = ["owner"];
handler.command = /^(getscrape|gs|readscrape)$/i;
handler.owner = true;
handler.noJadiBot = true;

export default handler;
