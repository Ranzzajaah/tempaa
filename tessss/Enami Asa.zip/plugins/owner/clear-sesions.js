/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const handler = async (m, { sock, reply }) => {
	const pathAuth = './Auth';
	const pathTrash = './data/trash';

	if (!fs.existsSync(pathAuth)) fs.mkdirSync(pathAuth, { recursive: true });
	if (!fs.existsSync(pathTrash)) fs.mkdirSync(pathTrash, { recursive: true });
	const dirsesi = fs.readdirSync(pathAuth).filter((e) => e !== 'creds.json');
	const dirsampah = fs.readdirSync(pathTrash).filter((e) => e !== 'tmp');

	for (const file of dirsesi) {
		try {
			fs.unlinkSync(`${pathAuth}/${file}`);
		} catch (e) {
			console.error(`Gagal hapus ${file}:`, e.message);
		}
	}

	for (const file of dirsampah) {
		try {
			fs.unlinkSync(`${pathTrash}/${file}`);
		} catch (e) {
			console.error(`Gagal hapus ${file}:`, e.message);
		}
	}

	reply(`*Berhasil membersihkan sampah ✅*
- *${dirsesi.length}* sampah session
- *${dirsampah.length}* sampah file`);
};

handler.command = ['clsesi', 'clearsesion', 'clearsesi'];
handler.owner = true;
handler.noJadiBot = true

export default handler;
