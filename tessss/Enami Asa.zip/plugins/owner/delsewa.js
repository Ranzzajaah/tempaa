/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getSewaGroup, removeSewaGroup } from "../../lib/database.js";

const handler = async (m, { args, command, prefix, isOwner, reply }) => {
	if (!isOwner) return reply(global.mess?.owner || '🍓 Akses Khusus Owner!');
	if (m.isBaileys) return reply('ngapain 😂?');

	let targetJid = null;
	if (args[0] && args[0].includes('@g.us')) {
		targetJid = args[0];
	} else if (m.isGroup) {
		targetJid = m.chat;
	}

	if (!targetJid) {
		return reply(`• Di dalam grup: ${prefix + command}\n• Di private chat: ${prefix + command} <id_grup>`);
	}

	const exists = getSewaGroup(targetJid);
	if (!exists) {
		return reply(`Grup ${targetJid} tidak terdaftar dalam sewa.`);
	}

	const removed = removeSewaGroup(targetJid);
	return reply(removed ? `✅ Berhasil menghapus sewa grup ${targetJid}` : `Gagal menghapus sewa.`);
};

handler.help = ['delsewa'];
handler.tags = ['owner'];
handler.command = ['delsewa', 'hapussewa', 'deletesewa'];
handler.category = 'owner';
handler.owner = true;
handler.noJadiBot = true;

export default handler;
