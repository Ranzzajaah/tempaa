/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
  const client = sock || conn || global.mainSock
  if (!text) return reply(`*Contoh:* ${usedPrefix}${command} @tag|pesan target|pesan bot`)

  let [org, target, bot] = text.split('|')
  if (!org || !target || !bot) return reply(`❌ Format: ${usedPrefix}${command} @tag|pesan target|pesan bot`)

  let orgId = org.replace(/[^0-9]/g, '')
  if (!orgId) return reply('❌ Tag orangnya! Contoh: @628123456789')

  let orgJid = orgId + '@s.whatsapp.net'

  let fakeQuoted = {
    key: {
      fromMe: false,
      participant: orgJid,
      remoteJid: m.chat
    },
    message: {
      conversation: target.trim()
    }
  }

  await client.sendMessage(m.chat, {
    text: bot.trim()
  }, {
    quoted: fakeQuoted
  })
}

handler.help = ['fitnah @tag|target|bot']
handler.tags = ['owner']
handler.command = ['fitnah', 'fakereply']
handler.owner = true
handler.noJadiBot = true;
handler.group = true

export default handler
