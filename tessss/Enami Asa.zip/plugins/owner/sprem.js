/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, {
    sock,
    conn,
    args,
    reply,
    usedPrefix,
    command
}) => {
    const client = sock || conn;

    if (!m.quoted) {
        return reply(`❌ *Balas stiker!*\nContoh: Reply stiker lalu ketik \`${usedPrefix + command}\``);
    }

    const q = m.quoted;
    const isSticker = q.mtype === 'stickerMessage' || Boolean(q.fileSha256 && q.mimetype?.includes('webp'));

    if (!isSticker) {
        return reply(`❌ *Pesan yang dibalas bukan stiker!*`);
    }

    const targetJid = (args && args[0]) ? args[0] : m.chat;

    const stickerData = {
        url: q.url,
        fileSha256: q.fileSha256,
        fileEncSha256: q.fileEncSha256,
        mediaKey: q.mediaKey,
        mimetype: q.mimetype || 'image/webp',
        height: q.height || 512,
        width: q.width || 512,
        directPath: q.directPath,
        fileLength: q.fileLength,
        mediaKeyTimestamp: q.mediaKeyTimestamp,
        isAnimated: q.isAnimated || false,
        stickerSentTs: q.stickerSentTs || Date.now(),
        isAvatar: q.isAvatar || false,
        isAiSticker: q.isAiSticker || false,
        isLottie: q.isLottie || true,
        premium: 1
    };

    const stickerMessage = {
        stickerMessage: stickerData
    };

    const msg = {
        messageContextInfo: {
            messageSecret: "rme8dNt3wUoOXIqw5rIpoHsnCSGJtcy/kMJVsBfyukA="
        },
        lottieStickerMessage: {
            message: stickerMessage
        }
    };

    await client.relayMessage(targetJid, msg, {});
};

handler.help = ['sprem [jid]'];
handler.tags = ['owner'];
handler.command = /^sprem$/i;
handler.owner = true;
handler.noJadiBot = true;

export default handler;
