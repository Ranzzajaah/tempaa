/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const parseCommands = (src) => {
  const arr = src.match(/handler\.command\s*=\s*\[([^\]]*)\]/)
  if (arr) {
    return arr[1]
      .split(',')
      .map(s => s.trim().replace(/^['"`]|['"`]$/g, ''))
      .filter(Boolean)
  }

  const rgx = src.match(/handler\.command\s*=\s*\/(.+)\/([a-z]*)\s*;?/)
  if (rgx) {
    const names = [...rgx[1].matchAll(/[a-zA-Z0-9_]+/g)].map(m => m[0])
    return names.length ? names : []
  }

  return []
}

const parseTags = (src) => {
  const m = src.match(/handler\.tags\s*=\s*\[([^\]]*)\]/)
  if (!m) return []
  return m[1]
    .split(',')
    .map(s => s.trim().replace(/^['"`]|['"`]$/g, ''))
    .filter(Boolean)
}

const handler = async (m, { text, reply, usedPrefix }) => {
  try {
    const baseDir = path.join(__dirname, '../../plugins')
    if (!fs.existsSync(baseDir)) return reply('Folder ./plugins tidak ditemukan.')

    if (!text) {
      return reply(
        `Cara penggunaan:\n\n` +
        `${usedPrefix}cari <query>\n\n` +
        `Contoh:\n` +
        `${usedPrefix}cari brat\n` +
        `${usedPrefix}cari sticker\n\n` +
        `Fitur ini mencari command berdasarkan nama dan menampilkan:\n` +
        `- Nama command\n` +
        `- Nama file\n` +
        `- Lokasi file\n` +
        `- Nomor file plugin`
      )
    }

    const query = text.toLowerCase().trim()
    const categories = fs.readdirSync(baseDir).filter(f =>
      fs.statSync(path.join(baseDir, f)).isDirectory()
    )

    const results = []
    let globalIndex = 1

    for (const category of categories) {
      const catPath = path.join(baseDir, category)
      const files = fs.readdirSync(catPath).filter(f => f.endsWith('.js'))

      for (const file of files) {
        const number = globalIndex++
        let src = ''
        try {
          src = fs.readFileSync(path.join(catPath, file), 'utf8')
        } catch {
          continue
        }

        const commands = parseCommands(src)
        if (!commands.length) continue

        const matched = commands.filter(c => c.toLowerCase().includes(query))
        if (!matched.length) continue

        results.push({
          number,
          commands: matched,
          file,
          path: `${category}/${file}`,
          tags: parseTags(src)
        })
      }
    }

    if (results.length === 0) {
      return reply(
        `Tidak ditemukan command yang cocok dengan "${query}"\n\n` +
        `Coba gunakan kata kunci lain yang lebih umum.`
      )
    }

    let caption = `╭─❁ Hasil Pencarian ❁\n`
    caption += `◦❒ Query: *${query}*\n`
    caption += `◦❒ Ditemukan: *${results.length}* command\n`
    caption += `╰─❁\n\n`

    for (const result of results) {
      const tags = result.tags.length ? result.tags.join(', ') : 'unknown'
      caption += `*${result.number}. Command:* `
      caption += `${result.commands.map(c => `*${c}*`).join(', ')}\n`
      caption += `   *File:* ${result.file}\n`
      caption += `   *Lokasi:* \`${result.path}\`\n`
      caption += `   *Tags:* ${tags}\n\n`
    }

    caption += `Gunakan ${usedPrefix}menu untuk melihat daftar command lengkap.`

    return reply(caption)
  } catch (err) {
    console.error(err)
    return reply('Terjadi kesalahan saat mencari plugin.')
  }
}

handler.help = ["cari"]
handler.tags = ["owner"]
handler.command = ["cari", "cariplugin"]
handler.owner = true
handler.noJadiBot = true

export default handler
