/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { delay } from '@whiskeysockets/baileys';

const handler = async (m, { conn }) => {
	if (!m.quoted) {
		return m.reply('Reply pesan yang ingin diproses.');
	}

	try {
		const chatId = m.chat;
		const stanzaId = m.quoted.id; 

		const tempId = await conn.relayMessage(
			chatId,
			{
				groupStatusMessageV2: {
					message: {
						extendedTextMessage: {
							text: '',
							contextInfo: {
								isGroupStatus: true,
							},
						},
					},
				},
			},
			{}
		);

		const tempId2 = await conn.relayMessage(
			chatId,
			{
				protocolMessage: {
					key: {
						jid: chatId,
						fromMe: true,
						id: tempId,
					},
					type: 14,
					editedMessage: {
						extendedTextMessage: {
							text: '\0',
							contextInfo: {
								isGroupStatus: false,
							},
						},
					},
				},
			},
			{
				messageId: stanzaId,
			}
		);

		await delay(100);

		await Promise.allSettled([
			conn.sendMessage(chatId, {
				delete: {
					remoteJid: chatId,
					id: tempId,
					fromMe: true,
				},
			}),
			conn.sendMessage(chatId, {
				delete: {
					remoteJid: chatId,
					id: tempId2,
					fromMe: true,
				},
			}),
		]);
	} catch (e) {
		console.error('[dmsg]', e);
		await m.reply('Error: ' + (e?.message || e));
	}
};

handler.help = ['dmsg'];
handler.tags = ['owner'];
handler.command = ['dmsg'];
handler.owner = true;
handler.noJadiBot = true;
handler.group = true;

export default handler;
