/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { addOwner, isOwnerJid } from "../../lib/database.js";
const handler = async (m, { sock, args, reply, example }) => {
	if (m.isBaileys) return m.reply('ngapain 😂?');

	let nomor = args[0]
		? args[0].replace(/[^0-9]/g, '')
		: m.quoted
			? m.quoted.sender.replace(/[^0-9]/g, '')
			: m.mentionedJid?.[0]
				? m.mentionedJid[0].replace(/[^0-9]/g, '')
				: null;
	if (!nomor) return reply(example(`reply/tag/@nomor`));
	const jid = nomor + '@s.whatsapp.net';
	const cek = await sock.onWhatsApp(jid);
	if (!cek?.length) return reply(`Nomor tidak terdaftar di WhatsApp!`);
	if (isOwnerJid(jid)) return reply(`@${nomor} sudah ada di daftar owner.`);
	await addOwner(jid);
	await sock.sendMessage(m.chat, {
		text: `✅ Berhasil menambahkan @${nomor} ke daftar owner.`,
		mentions: [jid]
	}, { quoted: m });
};

handler.command = ['addown', 'addowner'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
