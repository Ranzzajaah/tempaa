/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const handler = async (m, { sock, reply, usedPrefix }) => {
	const quoted = m.quoted;
	if (!quoted || !quoted.msg?.mimetype?.startsWith('audio')) {
		return reply(`Reply audio dulu untuk set lagu menu!\n\nContoh: reply audio lalu kirim\n${usedPrefix}setsong`);
	}

	const savePath = 'media/menu.opus';
	const stream = await quoted.download?.();
	if (!stream) return reply('❌ Gagal mengunduh audio.');

	fs.writeFileSync(savePath, stream);
	if (fs.existsSync('media/menu.mp3')) try { fs.unlinkSync('media/menu.mp3'); } catch (_) {}

	return reply(`✅ Audio menu berhasil diupdate!\nSaved to: ${savePath}`);
};

handler.command = ['setsong'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
