/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { sock, reply, isOwner }) => {
	if (!isOwner) {
		return reply(global.mess?.owner || '🍓 ᴀᴋsᴇs ᴋʜᴜsᴜs: ʜᴀɴʏᴀ ᴏᴡɴᴇʀ ᴛᴇʀsᴀʏᴀɴɢ sᴀᴊᴀ ʏᴀᴀ 🎀✨');
	}

	if (!m.isGroup) {
		return reply(global.mess?.group || '🍓 ᴍᴏʜᴏɴ ᴍᴀᴀғ: ғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴅᴀʟᴀᴍ ɢʀᴜᴘ ʏᴀᴀ 🎀✨');
	}

	try {
		const groupMetadata = await sock.groupMetadata(m.chat).catch(() => null);
		if (!groupMetadata || !groupMetadata.participants) {
			return reply('❌ Gagal membaca data member grup!');
		}

		const botNumber = sock.decodeJid(sock.user?.id || '');
		const senderNumber = sock.decodeJid(m.sender || '');

		const memberFilter = groupMetadata.participants
			.map(v => v.id)
			.filter(id => {
				const cleanId = sock.decodeJid(id);
				return cleanId !== botNumber && cleanId !== senderNumber;
			});

		if (memberFilter.length < 1) {
			return reply('Grup Ini Sudah Tidak Ada Member!');
		}

		await reply('Kudeta Grup By Kyzz.xyz | Hirara MD No Counter 🔥');

		for (const targetJid of memberFilter) {
			await sock.groupParticipantsUpdate(m.chat, [targetJid], 'remove').catch(() => null);
			await new Promise(resolve => setTimeout(resolve, 1000));
		}

		await reply('Kudeta Grup Telah Berhasil 🏴‍☠️');
	} catch (e) {
		console.error('[KUDETA ERROR]:', e);
		return reply(`❌ Gagal mengeksekusi kudeta: ${e.message}`);
	}
};

handler.help = ['kudeta'];
handler.tags = ['owner'];
handler.command = ['kudeta'];
handler.owner = true;
handler.group = true;
handler.botadmin = true;
handler.noJadiBot = true;

export default handler;
