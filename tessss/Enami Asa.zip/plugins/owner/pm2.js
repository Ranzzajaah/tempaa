/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { exec } from 'child_process';
import util from 'util';
import os from 'os';

const execPromise = util.promisify(exec);

const formatBytes = (bytes) => {
	if (!bytes || bytes === 0) return '0 B';
	const k = 1024;
	const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
	const i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const formatDuration = (ms) => {
	const s = Math.floor((ms / 1000) % 60);
	const m = Math.floor((ms / (1000 * 60)) % 60);
	const h = Math.floor((ms / (1000 * 60 * 60)) % 24);
	const d = Math.floor(ms / (1000 * 60 * 60 * 24));
	const parts = [];
	if (d > 0) parts.push(`${d}d`);
	if (h > 0) parts.push(`${h}h`);
	if (m > 0) parts.push(`${m}m`);
	parts.push(`${s}s`);
	return parts.join(' ');
};

const handler = async (m, { conn, sock, args, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const sub = (args[0] || '').toLowerCase();
	const target = args[1] || 'Hirara';

	if (!sub || sub === 'status' || sub === 'list') {
		try {
			const { stdout } = await execPromise('pm2 jlist');
			const list = JSON.parse(stdout);

			if (!Array.isArray(list) || !list.length) {
				return reply('ℹ️ *PM2 Manager:*\nTidak ada process list yang sedang berjalan di PM2.');
			}

			const now = Date.now();
			let txt = `⚡ *PM2 PROCESS MANAGER*\n\n`;
			txt += `🖥️ *Host:* ${os.hostname()} (${os.type()} ${os.arch()})\n`;
			txt += `📊 *Total App:* ${list.length} Process\n\n`;

			list.forEach((app, idx) => {
				const statusEmoji = app.pm2_env?.status === 'online' ? '🟢' : '🔴';
				const uptime = app.pm2_env?.pm_uptime ? formatDuration(now - app.pm2_env.pm_uptime) : '0s';
				const memory = formatBytes(app.monit?.memory || 0);
				const cpu = `${app.monit?.cpu || 0}%`;
				const restarts = app.pm2_env?.restart_time || 0;

				txt += `*${idx + 1}. [${statusEmoji}] ${app.name}* (ID: \`${app.pm_id}\`)\n`;
				txt += `  ├ ⚙️ *Status:* \`${app.pm2_env?.status || 'unknown'}\`\n`;
				txt += `  ├ 📈 *CPU / RAM:* \`${cpu}\` / \`${memory}\`\n`;
				txt += `  ├ ⏳ *Uptime:* \`${uptime}\`\n`;
				txt += `  ╰ ↺  *Restarts:* \`${restarts}x\`\n\n`;
			});

			txt += `📌 *Perintah Kontrol:*\n` +
				`• \`${usedPrefix + command} restart <name/id/all>\`\n` +
				`• \`${usedPrefix + command} stop <name/id/all>\`\n` +
				`• \`${usedPrefix + command} start <name/config>\`\n` +
				`• \`${usedPrefix + command} reload <name/all>\`\n` +
				`• \`${usedPrefix + command} logs [lines]\`\n` +
				`• \`${usedPrefix + command} flush\` (hapus log)`;

			return reply(txt.trim());
		} catch (err) {
			console.error('[PM2 LIST ERROR]', err);
			return reply(`❌ Gagal mengambil status PM2: ${err.message}`);
		}
	}

	if (sub === 'restart' || sub === 'res') {
		await reply(`⏳ *Merestart process PM2:* \`${target}\`...`);
		try {
			await execPromise(`pm2 restart ${target}`);
			return reply(`✅ Berhasil merestart process PM2: \`${target}\``);
		} catch (e) {
			return reply(`❌ Gagal merestart: ${e.stderr || e.message}`);
		}
	}

	if (sub === 'stop') {
		await reply(`⏳ *Menghentikan process PM2:* \`${target}\`...`);
		try {
			await execPromise(`pm2 stop ${target}`);
			return reply(`🛑 Berhasil menghentikan process PM2: \`${target}\``);
		} catch (e) {
			return reply(`❌ Gagal stop process: ${e.stderr || e.message}`);
		}
	}

	if (sub === 'start') {
		await reply(`⏳ *Menjalankan process PM2:* \`${target}\`...`);
		try {
			await execPromise(`pm2 start ${target}`);
			return reply(`▶️ Berhasil menjalankan process PM2: \`${target}\``);
		} catch (e) {
			return reply(`❌ Gagal start process: ${e.stderr || e.message}`);
		}
	}

	if (sub === 'reload') {
		await reply(`⏳ *Reloading process PM2:* \`${target}\`...`);
		try {
			await execPromise(`pm2 reload ${target}`);
			return reply(`🔄 Berhasil reload process PM2: \`${target}\``);
		} catch (e) {
			return reply(`❌ Gagal reload process: ${e.stderr || e.message}`);
		}
	}

	if (sub === 'logs' || sub === 'log') {
		const lines = parseInt(args[1]) || 20;
		try {
			const { stdout, stderr } = await execPromise(`pm2 logs Hirara --lines ${lines} --nostream`);
			const out = (stdout || stderr || 'Tidak ada log').trim();
			return reply(`📋 *PM2 LOGS (Last ${lines} lines):*\n\`\`\`\n${out.slice(-2500)}\n\`\`\``);
		} catch (e) {
			return reply(`❌ Gagal membaca log PM2: ${e.message}`);
		}
	}

	if (sub === 'flush') {
		try {
			await execPromise('pm2 flush');
			return reply('🧹 *Berhasil membersihkan seluruh log PM2!*');
		} catch (e) {
			return reply(`❌ Gagal membersihkan log: ${e.message}`);
		}
	}

	return reply(
		`❌ *Pilihan sub-command tidak valid!*\n\n` +
		`Gunakan:\n` +
		`• \`${usedPrefix + command} status\`\n` +
		`• \`${usedPrefix + command} restart <name/all>\`\n` +
		`• \`${usedPrefix + command} stop <name/all>\`\n` +
		`• \`${usedPrefix + command} start <name/config>\`\n` +
		`• \`${usedPrefix + command} logs <lines>\`\n` +
		`• \`${usedPrefix + command} flush\``
	);
};

handler.help = ['pm2', 'pm2 restart', 'pm2 logs', 'pm2 flush'];
handler.tags = ['owner'];
handler.command = /^(pm2|process|pm2mgr)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
