/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';

const DEFAULT_GROUP_LINK = 'https://chat.whatsapp.com/JidDCH3B5bhKhJkV25iEp4?s=cl&p=a&mlu=4';

const handler = async (m, { sock, conn, args, usedPrefix, command, reply }) => {
	const client = sock || conn;

	reply('⏳ *Memproses backup /root/kyzz-apis...* Mohon tunggu sebentar.');

	const targetLink = args[0] || DEFAULT_GROUP_LINK;
	let targetJid = m.chat;

	const match = targetLink.match(/chat\.whatsapp\.com\/([A-Za-z0-9]{20,24})/i);
	const inviteCode = match ? match[1] : null;

	if (inviteCode) {
		try {
			const info = await client.groupGetInviteInfo(inviteCode).catch(() => null);
			if (info?.id) {
				targetJid = info.id.endsWith('@g.us') ? info.id : `${info.id}@g.us`;
				await client.groupAcceptInvite(inviteCode).catch(() => null);
			}
		} catch (e) {
			console.error('[BACKUPAPI INVITE RESOLVE ERROR]', e.message);
		}
	}

	const tmpDir = path.join(process.cwd(), 'tmp');
	if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

	const zipFileName = 'kyzz-apis.zip';
	const zipFilePath = path.join(tmpDir, zipFileName);

	const sourceDir = '/root/kyzz-apis';
	if (!fs.existsSync(sourceDir)) {
		return reply(`❌ Direktori '${sourceDir}' tidak ditemukan di server.`);
	}

	const zipCmd = `zip -r "${zipFilePath}" "${sourceDir}" -x "*/node_modules/*" "*/.next/*" "*/.git/*" "*/backups/*" "*/logs/*" "*.log" "*/temp_downloads/*" "*/tmp/*"`;

	exec(zipCmd, { maxBuffer: 1024 * 1024 * 50 }, async (err, stdout, stderr) => {
		try {
			if (err || !fs.existsSync(zipFilePath)) {
				console.error('[BACKUPAPI ZIP ERROR]', err || stderr);
				return reply('❌ Gagal membuat file zip backup kyzz-apis.');
			}

			const stats = fs.statSync(zipFilePath);
			const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);

			const caption = `📦 *Backup kyzz-apis*\n📊 Size: ${fileSizeMB} MB`;

			await client.sendMessage(targetJid, {
				document: fs.readFileSync(zipFilePath),
				mimetype: 'application/zip',
				fileName: zipFileName,
				caption: caption
			});

			if (targetJid !== m.chat) {
				await reply(`✅ Backup kyzz-apis berhasil dikirim! (${fileSizeMB} MB)`);
			}
		} catch (e) {
			console.error('[BACKUPAPI SEND ERROR]', e);
			reply('❌ Terjadi kesalahan saat mengirimkan file backup.');
		} finally {
			try {
				if (fs.existsSync(zipFilePath)) fs.unlinkSync(zipFilePath);
			} catch (_) {}
		}
	});
};

handler.help = ['backupapi [link_grup]', 'backupapis'];
handler.tags = ['owner'];
handler.command = ['backupapi', 'backupapis'];
handler.owner = true;

handler.noJadiBot = true;

export default handler;
