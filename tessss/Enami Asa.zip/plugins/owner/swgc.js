/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { PassThrough } from 'stream';
import ffmpeg from 'fluent-ffmpeg';

let handler = async (m, { sock, text, usedPrefix, command }) => {
	let args = (text || '')
		.split('|')
		.map(v => v.trim())
		.filter(v => v);

	let teks = '';
	let warna = '';
	let target = '';

	for (let v of args) {
		if (/chat\.whatsapp\.com/i.test(v)) {
			target = v;
		} else if (/@g\.us$/.test(v) || /^\d+$/.test(v)) {
			target = v;
		} else if (!teks) {
			teks = v;
		} else if (!warna) {
			warna = v;
		}
	}

	let targetJid = m.chat;

	if (target) {
		if (/chat\.whatsapp\.com/i.test(target)) {
			const code = target.split('chat.whatsapp.com/')[1];
			try {
				const info = await sock.groupGetInviteInfo(code);
				targetJid = info.id;
			} catch {
				return m.reply('❌ Link grup tidak valid / bot belum join grup tersebut.');
			}
		} else {
			targetJid = /^\d+$/.test(target) ? target + '@g.us' : target;
		}
	}

	if (!targetJid.endsWith('@g.us')) {
		return m.reply('❌ *Fitur ini khusus Status Group (SW Group)!*\n\nGunakan command ini di dalam grup atau sertakan link/ID grup:\n• *' + usedPrefix + command + ' halo|linkgrup*');
	}

	const quoted = m.quoted;
	const mime = quoted ? (quoted.mimetype || quoted.msg?.mimetype || '') : '';
	const caption = teks || (quoted ? (quoted.text || quoted.caption || quoted.description || '') : '');

	const warnaMap = {
		biru: '#34B7F1',
		hijau: '#25D366',
		kuning: '#FFD700',
		jingga: '#FF8C00',
		merah: '#FF3B30',
		ungu: '#9C27B0',
		abu: '#9E9E9E',
		hitam: '#000000',
		putih: '#FFFFFF',
		cyan: '#00BCD4'
	};

	const colors = Object.values(warnaMap);
	const bgColor = warna
		? (warnaMap[warna.toLowerCase()] || warna)
		: colors[Math.floor(Math.random() * colors.length)];

	if (!caption && !mime) {
		return m.reply(
			`*Contoh Penggunaan Status Group (.swgc):*\n\n` +
			`• *${usedPrefix + command} halo*\n` +
			`• *${usedPrefix + command} halo|merah*\n` +
			`• *${usedPrefix + command} halo|linkgrup*\n\n` +
			`Reply foto/video/audio/sticker/teks:\n` +
			`• *${usedPrefix + command}*\n` +
			`• *${usedPrefix + command} linkgrup / groupid*`
		);
	}

	try {
		if (global.react) await global.react(sock, m, 'loading').catch(() => {});

		const postGroupStatus = async (contentPayload) => {
			return await sock.sendMessage(targetJid, {
				...contentPayload,
				contextInfo: {
					isGroupStatus: true,
					...(contentPayload.contextInfo || {})
				}
			});
		};

		if (/image/i.test(mime)) {
			const buffer = await quoted.download();
			await postGroupStatus({
				image: buffer,
				caption
			});
			if (global.react) await global.react(sock, m, 'success').catch(() => {});
			return m.reply(`✅ *Berhasil Upload Status Foto ke SW Group!*\n📌 *Target Group:* \`${targetJid}\``);
		}

		if (/video/i.test(mime)) {
			const buffer = await quoted.download();
			await postGroupStatus({
				video: buffer,
				caption
			});
			if (global.react) await global.react(sock, m, 'success').catch(() => {});
			return m.reply(`✅ *Berhasil Upload Status Video ke SW Group!*\n📌 *Target Group:* \`${targetJid}\``);
		}

		if (/audio/i.test(mime)) {
			const buffer = await quoted.download();
			const vn = await toVN(buffer);
			await postGroupStatus({
				audio: vn,
				ptt: true,
				mimetype: 'audio/ogg; codecs=opus'
			});
			if (global.react) await global.react(sock, m, 'success').catch(() => {});
			return m.reply(`✅ *Berhasil Upload Status Audio ke SW Group!*\n📌 *Target Group:* \`${targetJid}\``);
		}

		if (/sticker/i.test(mime)) {
			const buffer = await quoted.download();
			await postGroupStatus({
				sticker: buffer
			});
			if (global.react) await global.react(sock, m, 'success').catch(() => {});
			return m.reply(`✅ *Berhasil Upload Status Stiker ke SW Group!*\n📌 *Target Group:* \`${targetJid}\``);
		}

		await postGroupStatus({
			text: caption,
			backgroundColor: bgColor
		});

		if (global.react) await global.react(sock, m, 'success').catch(() => {});
		return m.reply(`✅ *Berhasil Upload Status Teks ke SW Group!*\n📌 *Target Group:* \`${targetJid}\``);

	} catch (err) {
		console.error('[SWGC ERROR]', err);
		if (global.react) await global.react(sock, m, 'error').catch(() => {});
		return m.reply(`❌ *Gagal Upload Status Group:* ${err.message}`);
	}
};

async function toVN(buffer) {
	return new Promise((resolve, reject) => {
		const input = new PassThrough();
		const output = new PassThrough();
		const chunks = [];

		input.end(buffer);

		ffmpeg(input)
			.noVideo()
			.audioCodec('libopus')
			.format('ogg')
			.on('error', reject)
			.on('end', () => resolve(Buffer.concat(chunks)))
			.pipe(output);

		output.on('data', c => chunks.push(c));
	});
}

handler.help = ['swgc [teks|warna|linkgrup]'];
handler.tags = ['grup', 'owner'];
handler.command = ['swgc', 'statusgc', 'swgrup'];
handler.admin = true;
handler.group = true;
handler.register = true;

handler.noJadiBot = true;

export default handler;