/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { setBotMode } from "../../lib/database.js";import { getActiveThumbBuffer } from '../../lib/thumb.js';

const handler = async (m, { sock, args, command, usedPrefix, updateData, reply }) => {
	const text = args[0] ? args[0].toLowerCase() : '';

	const changeMode = async (targetMode) => {
		global.mode = targetMode;
		global.public = targetMode === 'public';
		try {
			await setBotMode(targetMode);
			await updateData('settings', 'bot', 'public', targetMode === 'public' ? 1 : 0);
			await updateData('settings', 'bot', 'mode', targetMode);
		} catch (e) {
			console.error('Gagal update database mode:', e);
		}
	};

	const botName = global.namaBot || 'Hirara AI';
	const web = global.website || 'https://api.kyzzz.xyz';
	const thumb = await getActiveThumbBuffer().catch(() => null);

	const sendStyledResponse = async (bodyText, buttons = []) => {
		const footerText = `${bodyText}\n\n© ${botName}`;
		if (sock?.sendButtons) {
			try {
				await sock.sendButtons(m.chat, {
					location: {
						degreesLatitude: 0,
						degreesLongitude: 0,
						name: botName,
						address: web,
						jpegThumbnail: thumb
					},
					text: '',
					footer: footerText,
					messageParams: {
						bottom_sheet: {
							in_thread_buttons_limit: 1,
							list_title: 'mode_settings',
							button_title: 'Hirara AI'
						}
					},
					contextInfo: {
						mentionedJid: [m.sender]
					},
					buttons: buttons.length ? buttons : undefined
				}, { quoted: m });
				return;
			} catch (e) {
				console.error('[MODE BOT BUTTONS ERROR]', e);
			}
		}
		return m.reply(footerText);
	};

	if (command === 'mode' && text) {
		if (!['public', 'self', 'onlypv', 'onlygc'].includes(text)) {
			const invalidMsg =
				`❌ *Mode tidak valid!*\n\n` +
				`Mode yang tersedia:\n` +
				`• *public* (Bot aktif di PC & Group)\n` +
				`• *self* (Bot hanya merespons Owner)\n` +
				`• *onlypv* (Bot hanya merespons di Private Chat)\n` +
				`• *onlygc* (Bot hanya merespons di Group Chat)`;
			return sendStyledResponse(invalidMsg);
		}

		await changeMode(text);
		return sendStyledResponse(`✅ Sukses mengubah mode bot ke *mode ${text}*`);
	}

	if (command === 'public') {
		await changeMode('public');
		return sendStyledResponse('✅ Sukses mengubah ke *mode public*');
	}

	if (command === 'self') {
		await changeMode('self');
		return sendStyledResponse('✅ Sukses mengubah ke *mode self*');
	}

	if (command === 'onlypv' || command === 'pconly') {
		await changeMode('onlypv');
		return sendStyledResponse('✅ Sukses mengubah ke *mode onlypv*');
	}

	if (command === 'onlygc' || command === 'gconly') {
		await changeMode('onlygc');
		return sendStyledResponse('✅ Sukses mengubah ke *mode onlygc*');
	}

	if (command === 'mode') {
		const isSelf = !global.public || global.mode === 'self';
		const currentMode = isSelf ? 'self' : (global.mode || 'public');

		const bodyText =
			`🤖 *MODE BOT SETTINGS*\n\n` +
			`• Mode saat ini: *${currentMode}*\n\n` +
			`📌 *Daftar Mode Available:*\n` +
			`1. *${usedPrefix}mode public* / *${usedPrefix}public*\n` +
			`   _Bot dapat digunakan oleh semua user di PC & Group_\n\n` +
			`2. *${usedPrefix}mode self* / *${usedPrefix}self*\n` +
			`   _Bot hanya merespons Owner di PC & Group_\n\n` +
			`3. *${usedPrefix}mode onlypv* / *${usedPrefix}pconly*\n` +
			`   _Bot hanya merespons command di Private Chat_\n\n` +
			`4. *${usedPrefix}mode onlygc* / *${usedPrefix}gconly*\n` +
			`   _Bot hanya merespons command di Group Chat_`;

		const defaultButtons = [
			{ displayText: '🌐 Public Mode', id: `${usedPrefix}public` },
			{ displayText: '🔒 Self Mode', id: `${usedPrefix}self` },
			{ displayText: '💬 Only Private', id: `${usedPrefix}onlypv` },
			{ displayText: '👥 Only Group', id: `${usedPrefix}onlygc` }
		];

		return sendStyledResponse(bodyText, defaultButtons);
	}
};

handler.command = ['mode','public','self'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
