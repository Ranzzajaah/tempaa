/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const map = { 1: 'media/menu.jpg', 2: 'media/menu2.jpg', 3: 'media/menu3.jpg' };

const handler = async (m, { args, reply, usedPrefix }) => {
	const idx = parseInt(args[0]);
	if (![1, 2, 3].includes(idx)) {
		return reply(`Gunakan: ${usedPrefix}setthumb 1/2/3\n\nThumb tersedia:\n- 1: media/menu.jpg\n- 2: media/menu2.jpg\n- 3: media/menu3.jpg`);
	}
	if (!fs.existsSync(map[idx])) return reply(`File ${map[idx]} tidak ada.`);

	global.thumbIndex = idx;
	global.fotoreply = map[idx];

	return reply(`Thumbnail berhasil diganti ke *thumb ${idx}* (${map[idx]})\n\nSemua reply bot (termasuk did you mean & menu) otomatis ikut pakai thumb ini.`);
};

handler.command = ['setthumb'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
