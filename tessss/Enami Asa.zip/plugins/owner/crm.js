import fs from 'fs';
import path from 'path';
import os from 'os';
import { proto } from '@whiskeysockets/baileys';
import Database from 'better-sqlite3';

let AIRich = null;
try {
  const mb = await import('../../lib/helper-bails.js');
  AIRich = mb.AIRich || null;
} catch {}

const MIME_MAP = { json: 'application/json', js: 'application/javascript', txt: 'text/plain' };

const PROTO_ENUM_MAP = {
  NONE: 0, VIDEO: 4, IMAGE: 4, VIDEO_STATUS: 5, ALL: 0,
  CLOSE_FRIENDS: 2, SANS_SERIF: 0, SERIF: 1, NORICAN_REGULAR: 2,
  BRYNDAN_WRITE: 3, BEBASNEUE_REGULAR: 4, OSWALD_HEAVY: 5,
  DEFAULT: 0, PARENT: 1, CHANGED_IN_CHAT: 0, LID: 1,
};

const WRAPPER_KEYS = [
  'ephemeralMessage',
  'viewOnceMessage',
  'viewOnceMessageV2',
  'viewOnceMessageV2Extension',
  'documentWithCaptionMessage',
  'editedMessage',
  'ptvMessage',
];

// ---------- db ----------

const DB_DIR = path.join(os.homedir?.() ? '.' : '.', 'database');
const DB_PATH = path.join(DB_DIR, 'crm.db');

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS crm_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT
);
`);

const REQUIRED_COLUMNS = {
  action: 'TEXT',
  chat_jid: 'TEXT',
  sender_jid: 'TEXT',
  msg_id: 'TEXT',
  msg_type: 'TEXT',
  source: 'TEXT',
  unwrap_chain: 'TEXT',
  raw_json: 'TEXT',
  created_at: 'INTEGER'
};

const existingCols = new Set(db.prepare(`PRAGMA table_info(crm_logs)`).all().map(c => c.name));
for (const [col, type] of Object.entries(REQUIRED_COLUMNS)) {
  if (!existingCols.has(col)) {
    db.exec(`ALTER TABLE crm_logs ADD COLUMN ${col} ${type}`);
  }
}

db.exec(`
CREATE INDEX IF NOT EXISTS idx_crm_chat ON crm_logs(chat_jid);
CREATE INDEX IF NOT EXISTS idx_crm_msgid ON crm_logs(msg_id);
`);

const insertLog = db.prepare(`
  INSERT INTO crm_logs (action, chat_jid, sender_jid, msg_id, msg_type, source, unwrap_chain, raw_json, created_at)
  VALUES (@action, @chat_jid, @sender_jid, @msg_id, @msg_type, @source, @unwrap_chain, @raw_json, @created_at)
`);

function logAction({ action, chat, sender, id, msgType, source, chain, rawMsg }) {
  try {
    insertLog.run({
      action,
      chat_jid: chat || null,
      sender_jid: sender || null,
      msg_id: id || null,
      msg_type: msgType || null,
      source: source || null,
      unwrap_chain: chain?.length ? chain.join('>') : null,
      raw_json: rawMsg ? safeStoreJson(rawMsg) : null,
      created_at: Date.now()
    });
  } catch (e) {
    console.error('[crm][db]', e.message);
  }
}

function safeStoreJson(obj) {
  return JSON.stringify(obj, (k, v) => (v?.type === 'Buffer' && Array.isArray(v.data) ? `<Buffer:${v.data.length}b>` : v));
}

const HELP = `⚠️ *Reply pesan dulu!*

*.crm* — Raw Message & Deep Inspector
› *.crm*          → Exec-ready relayMessage snippet (file)
› *.crm -snip*    → Relay snippet dengan code block (AIRich)
› *.crm -quoted*  → Ekstrak deep content pesan yang di-reply orang tersebut
› *.crm -full*    → Ambil pesan lengkap beserta wrapper & contextInfo
› *.crm -relay*   → Tampilin JID target relay
› *.crm -option*  → Tampilin relay options
› *.crm -message* → Isi content relay (JSON)
› *.crm -info*    → Informasi detail metadata
› *.crm -key*     → Message Key
› *.crm -ctx*     → ContextInfo & quoted detail
› tambahkan *-file* untuk paksa kirim sebagai file

*.crm2* — Ambil data murni dari cache \`conn.chats\`
*.insp* — Ringkasan metadata pesan setara \`.crm -info\`
*.adn*  — AdditionalNodes inspector (deep search + fallback)
*.relay [jid] [-samekey]* — Re-relay pesan yang di-reply`;

// ---------- Proto & Helper Deep Functions ----------

function fixEnums(obj) {
  if (Array.isArray(obj)) return obj.map(fixEnums);
  if (obj && typeof obj === 'object') {
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) return obj;
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, fixEnums(v)]));
  }
  if (typeof obj === 'string' && obj in PROTO_ENUM_MAP) return PROTO_ENUM_MAP[obj];
  return obj;
}

function prepareForRelay(obj) {
  if (Array.isArray(obj)) return obj.map(prepareForRelay);
  if (obj && typeof obj === 'object') {
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) return obj;
    const res = {};
    for (const [k, v] of Object.entries(obj)) {
      if (k.endsWith('Json')) {
        if (typeof v === 'object' && v !== null) {
          res[k] = JSON.stringify(prepareForRelay(v));
        } else if (typeof v === 'string') {
          res[k] = v;
        } else {
          res[k] = String(v ?? '');
        }
      } else {
        res[k] = prepareForRelay(v);
      }
    }
    return res;
  }
  return obj;
}

function normalizePayloadForRelay(rawMsg) {
  let fixed = prepareForRelay(fixEnums(rawMsg));

  if (fixed?.interactiveMessage?.nativeFlowMessage) {
    if (!fixed.interactiveMessage.nativeFlowMessage.messageParamsJson || fixed.interactiveMessage.nativeFlowMessage.messageParamsJson === '{}') {
      fixed.interactiveMessage.nativeFlowMessage.messageParamsJson = JSON.stringify({ v: '1' });
    }
  }

  if (fixed && isInteractiveType(getMsgType(fixed))) {
    fixed = {
      viewOnceMessage: {
        message: fixed
      }
    };
  }

  return fixed;
}

function parseAsJsonObjectOrArray(str) {
  if (typeof str !== 'string' || !str.trim()) return null;
  const trimmed = str.trim();
  if (!(trimmed.startsWith('{') || trimmed.startsWith('['))) return null;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed !== null && typeof parsed === 'object') return parsed;
  } catch {}
  return null;
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function safeJson(obj, indent = 2, depth = 0, currentKey = '') {
  const pad = ' '.repeat(indent * (depth + 1));
  const closePad = ' '.repeat(indent * depth);

  if (obj === null) return 'null';
  if (obj === undefined) return 'undefined';
  if (obj?.type === 'Buffer' && Array.isArray(obj.data)) return `"<Buffer ${obj.data.length} bytes>"`;

  if (Array.isArray(obj)) {
    if (!obj.length) return '[]';
    const items = obj.map(v => pad + safeJson(v, indent, depth + 1, currentKey));
    return `[\n${items.join(',\n')}\n${closePad}]`;
  }

  if (typeof obj === 'object') {
    const keys = Object.keys(obj);
    if (!keys.length) return '{}';
    const entries = keys.map(k => `${pad}${JSON.stringify(k)}: ${safeJson(obj[k], indent, depth + 1, k)}`);
    return `{\n${entries.join(',\n')}\n${closePad}}`;
  }

  if (typeof obj === 'string') {
    if (!currentKey.endsWith('Json')) {
      const asJsonObj = parseAsJsonObjectOrArray(obj);
      if (asJsonObj !== null) return safeJson(asJsonObj, indent, depth, currentKey);
    }
    return JSON.stringify(obj);
  }

  return JSON.stringify(obj);
}

function getMsgType(msg) {
  return Object.keys(msg || {}).find(k => !['messageContextInfo', 'senderKeyDistributionMessage'].includes(k)) || 'unknownMessage';
}

function isInteractiveType(type) {
  return ['buttonsMessage', 'listMessage', 'templateMessage', 'interactiveMessage', 'eventMessage'].includes(type);
}

function shortStr(str, n = 28) {
  str = String(str ?? '-');
  return str.length > n ? str.slice(0, 12) + '...' + str.slice(-8) : str;
}

function getSize(obj) {
  try {
    const b = Buffer.byteLength(JSON.stringify(obj), 'utf8');
    return b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`;
  } catch { return '-'; }
}

function countKeys(obj, depth = 0) {
  if (depth > 5 || typeof obj !== 'object' || !obj) return 0;
  return Object.values(obj).reduce((n, v) => n + 1 + (typeof v === 'object' && v ? countKeys(v, depth + 1) : 0), 0);
}

function getTimestamp(quoted, rawMsg, msgType) {
  const candidates = [
    quoted?.messageTimestamp, quoted?.t, quoted?.timestamp,
    quoted?.vM?.messageTimestamp, quoted?.vM?.t, quoted?.vM?.key?.messageTimestamp,
    quoted?.msg?.messageTimestamp, rawMsg?.[msgType]?.contextInfo?.timestamp,
  ];
  for (const c of candidates) {
    if (c === undefined || c === null) continue;
    const num = Number(c);
    if (Number.isFinite(num) && num > 0) return num;
  }
  return null;
}

function decodeProto(rawObj) {
  if (!rawObj) return null;
  try {
    return proto.WebMessageInfo.toObject(
      proto.WebMessageInfo.fromObject(rawObj),
      { enums: Number, longs: Number, bytes: String, defaults: false }
    );
  } catch {
    return null;
  }
}

function unwrapMessage(msg, preserveContext = true) {
  let current = msg;
  const chain = [];
  let guard = 0;
  let savedContext = null;

  while (current && typeof current === 'object' && guard < 10) {
    guard++;
    const keys = Object.keys(current);
    
    const typeKey = getMsgType(current);
    if (current[typeKey]?.contextInfo) {
      savedContext = current[typeKey].contextInfo;
    }

    const wrapperKey = keys.find(k => WRAPPER_KEYS.includes(k));
    if (!wrapperKey) break;
    const inner = current[wrapperKey]?.message;
    if (!inner) break;
    chain.push(wrapperKey);
    current = inner;
  }

  if (preserveContext && savedContext) {
    const finalType = getMsgType(current);
    if (current[finalType] && typeof current[finalType] === 'object' && !current[finalType].contextInfo) {
      current[finalType].contextInfo = savedContext;
    }
  }

  return { msg: current || msg, chain };
}

function extractDeepQuoted(quoted) {
  if (!quoted) return null;
  
  const msgObj = quoted.message || quoted.fakeObj?.message || quoted.vM?.message;
  if (!msgObj) return null;

  const msgType = getMsgType(msgObj);
  const ctxQuoted = msgObj?.[msgType]?.contextInfo?.quotedMessage
    || msgObj?.contextInfo?.quotedMessage
    || quoted.vM?.message?.[msgType]?.contextInfo?.quotedMessage;

  if (ctxQuoted) {
    return unwrapMessage(ctxQuoted).msg;
  }

  if (quoted.quoted?.message) {
    return unwrapMessage(quoted.quoted.message).msg;
  }

  return null;
}

function getMsgSource(conn, quoted, options = {}, m = null) {
  const attempts = [
    () => {
      if (conn.loadMessage && quoted.id) {
        try {
          const stored = conn.loadMessage(quoted.id);
          if (stored) return { type: 'store', raw: stored };
        } catch {}
      }
      return null;
    },
    () => (quoted.vM ? { type: 'vM', raw: quoted.vM } : null),
    () => {
      const cached = conn.chats?.[quoted.chat || '']?.messages?.[quoted.id];
      if (cached) return { type: 'conn.chats cache', raw: cached };
      return null;
    },
    () => {
      if (global.store?.messages?.[quoted.chat]) {
        const msgMap = global.store.messages[quoted.chat];
        const found = msgMap?.get?.(quoted.id) || msgMap?.array?.find?.(m => m.key?.id === quoted.id);
        if (found) return { type: 'global.store', raw: found };
      }
      return null;
    },
    () => {
      // Extract from contextInfo quotedMessage
      const ctxQuoted = m?.msg?.contextInfo?.quotedMessage
        || m?.message?.[m?.mtype]?.contextInfo?.quotedMessage
        || quoted?.contextInfo?.quotedMessage;

      if (ctxQuoted) {
        return { type: 'contextInfo.quotedMessage', raw: { message: ctxQuoted } };
      }
      return null;
    },
    () => {
      const rawMsg = quoted.fakeObj?.message || quoted.message || quoted.msg || quoted._message;
      if (rawMsg) return { type: 'quoted.message (direct)', raw: { key: quoted.vM?.key || { id: quoted.id }, message: rawMsg } };
      return null;
    },
    () => {
      // Reconstruct from m.quoted properties
      if (quoted && typeof quoted === 'object') {
        if (quoted.mtype && quoted[quoted.mtype]) {
          return { type: 'm.quoted.mtype', raw: { message: { [quoted.mtype]: quoted[quoted.mtype] } } };
        }

        const clone = { ...quoted };
        delete clone.key;
        delete clone.id;
        delete clone.chat;
        delete clone.sender;
        delete clone.fromMe;
        delete clone.mtype;
        delete clone.isBaileys;
        delete clone.broadcast;
        delete clone.isGroup;
        delete clone.mentionedJid;
        delete clone.vM;
        delete clone.fakeObj;
        delete clone.msg;
        delete clone._message;

        if (Object.keys(clone).length > 0) {
          const type = quoted.mtype || getMsgType(clone);
          if (type && type !== 'unknownMessage') {
            return { type: 'm.quoted (reconstructed)', raw: { message: { [type]: clone } } };
          }
          return { type: 'm.quoted (direct)', raw: { message: clone } };
        }
      }
      return null;
    }
  ];

  for (const attempt of attempts) {
    const result = attempt();
    if (!result) continue;

    // 1. Try decoding with decodeProto
    const decoded = decodeProto(result.raw);
    if (decoded?.message) {
      const { msg: unwrapped, chain } = unwrapMessage(decoded.message, !options.full);
      return { type: result.type, msg: unwrapped, chain, fullRaw: decoded };
    }

    // 2. If result.raw has a .message property directly
    if (result.raw?.message) {
      const { msg: unwrapped, chain } = unwrapMessage(result.raw.message, !options.full);
      return { type: result.type, msg: unwrapped, chain, fullRaw: result.raw };
    }

    // 3. If result.raw IS the message content directly (e.g. { conversation: '...' })
    if (typeof result.raw === 'object' && !result.raw.key) {
      const { msg: unwrapped, chain } = unwrapMessage(result.raw, !options.full);
      return { type: result.type, msg: unwrapped, chain, fullRaw: { message: result.raw } };
    }
  }

  return { type: null, msg: null, chain: [], fullRaw: null };
}

function getRawMsg(conn, quoted, options = {}, m = null) {
  const { type, msg, chain, fullRaw } = getMsgSource(conn, quoted, options, m);
  if (!msg) return { msg: null, source: type, chain: [], fullRaw: null };
  return { msg, source: type, chain, fullRaw };
}

function getRawMsgFromCache(conn, chat, id) {
  const cached = conn.chats?.[chat]?.messages?.[id];
  if (!cached) return { msg: null, source: null, chain: [] };
  const decoded = decodeProto(cached);
  if (decoded?.message) {
    const { msg: unwrapped, chain } = unwrapMessage(decoded.message);
    return { msg: unwrapped, source: 'conn.chats cache', chain };
  }
  if (cached?.message) {
    const { msg: unwrapped, chain } = unwrapMessage(cached.message);
    return { msg: unwrapped, source: 'conn.chats cache', chain };
  }
  return { msg: null, source: 'conn.chats cache', chain: [] };
}

function getQuotedKey(conn, quoted, chat, sender, id) {
  if (quoted.vM?.key) return quoted.vM.key;
  const stored = conn.loadMessage?.(id);
  if (stored?.key) return stored.key;
  return { remoteJid: chat, fromMe: !!quoted.fromMe, id, ...(chat?.endsWith('@g.us') ? { participant: sender } : {}) };
}

function findAdditionalNodesDeep(obj, depth = 0, maxDepth = 6) {
  if (depth > maxDepth || !obj || typeof obj !== 'object') return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = findAdditionalNodesDeep(item, depth + 1, maxDepth);
      if (found) return found;
    }
    return null;
  }
  if ('additionalNodes' in obj) {
    const val = obj.additionalNodes;
    if (val && (Array.isArray(val) ? val.length : Object.keys(val).length)) return val;
  }
  for (const v of Object.values(obj)) {
    if (v && typeof v === 'object') {
      const found = findAdditionalNodesDeep(v, depth + 1, maxDepth);
      if (found) return found;
    }
  }
  return null;
}

function getAdditionalNodes(quoted, rawMsg, msgType) {
  const ctx = (rawMsg?.[msgType] || {}).contextInfo || {};
  const shallow = [quoted?.additionalNodes, quoted?.vM?.additionalNodes, ctx?.additionalNodes, rawMsg?.additionalNodes];
  for (const c of shallow) {
    if (c && (Array.isArray(c) ? c.length : Object.keys(c).length)) return { nodes: c, synthetic: false };
  }

  const deep = findAdditionalNodesDeep(quoted?.vM) || findAdditionalNodesDeep(rawMsg);
  if (deep) return { nodes: deep, synthetic: false };

  if (isInteractiveType(msgType)) {
    return {
      nodes: [
        {
          tag: 'biz',
          attrs: {},
          content: [
            {
              tag: 'interactive',
              attrs: { type: 'native_flow', v: '1' },
              content: [
                {
                  tag: 'native_flow',
                  attrs: { v: '9', name: 'mixed' }
                }
              ]
            }
          ]
        }
      ],
      synthetic: true
    };
  }

  return { nodes: null, synthetic: false };
}

function buildFileName(tag, ext, msgType) {
  const safeType = String(msgType || 'unknownMessage').replace(/[^a-zA-Z0-9]/g, '') || 'unknownMessage';
  if (!tag || tag === 'raw') return `${safeType}.${ext}`;
  return `${safeType}-${tag}.${ext}`;
}

async function sendAsFile(conn, m, content, tag, ext, caption, msgType) {
  const filename = buildFileName(tag, ext, msgType);
  const filePath = path.join(os.tmpdir(), filename);
  const mimetype = MIME_MAP[ext] || 'application/octet-stream';
  fs.writeFileSync(filePath, content, 'utf8');
  try {
    await conn.sendMessage(m.chat, { document: fs.readFileSync(filePath), mimetype, fileName: filename, caption }, { quoted: m });
  } finally {
    fs.unlink(filePath, () => {});
  }
}

async function sendAsCode(conn, m, { heading, meta, pills = [], code, language = 'json' }) {
  if (AIRich) {
    try {
      const rich = new AIRich(conn);
      if (heading) rich.addText(heading);
      if (meta) rich.addMetadata(meta);
      const cleanPills = pills.filter(Boolean).map(String);
      if (cleanPills.length) rich.addSuggest(cleanPills);
      rich.addCode(language, code);
      return await rich.send(m.chat, { quoted: m });
    } catch {}
  }
  const text = `${heading ? heading + '\n\n' : ''}${meta ? meta + '\n\n' : ''}\`\`\`${language}\n${code}\n\`\`\``;
  return conn.sendMessage(m.chat, { text }, { quoted: m });
}

async function sendAuto(conn, m, { heading, meta, pills, code, language, fileTag, fileExt, fileCaption, msgType, forceFile = false }) {
  if (forceFile || code.length > 5000) {
    const fileBody = heading
      ? `${heading.replace(/^#+\s*/, '// ')}\n${meta ? meta.split('\n').map(l => '// ' + l).join('\n') + '\n\n' : ''}${code}`
      : code;
    return sendAsFile(conn, m, fileBody, fileTag, fileExt, fileCaption, msgType);
  }
  return sendAsCode(conn, m, { heading, meta, pills, code, language });
}

async function react(conn, m, emoji) {
  return conn.sendMessage(m.chat, { react: { text: emoji, key: m.reactKey || m.key } });
}

// ---------- Main Handlers ----------

async function runCrm(m, { conn, args }, { fromCache = false } = {}) {
  if (!m.quoted) return m.reply(HELP);
  await react(conn, m, '⏳');

  try {
    const quoted = m.quoted;
    const chat = quoted.chat || m.chat || '-';
    const id = quoted.id || '-';
    const flag = args.join(' ').toLowerCase().trim();
    const isFull = flag.includes('-full');
    const isGetQuoted = flag.includes('-quoted');

    let { msg: rawMsg, source, chain } = fromCache 
      ? getRawMsgFromCache(conn, chat, id) 
      : getRawMsg(conn, quoted, { full: isFull }, m);

    if (isGetQuoted) {
      const deepQuoted = extractDeepQuoted(quoted);
      if (deepQuoted) {
        rawMsg = deepQuoted;
        source = 'contextInfo.quotedMessage (deep extracted)';
      } else {
        await react(conn, m, '❌');
        return m.reply('❌ Pesan ini tidak mereply/mengutip pesan lain (quotedMessage tidak ditemukan).');
      }
    }

    if (!rawMsg) {
      await react(conn, m, '❌');
      return m.reply(fromCache
        ? '❌ Tidak ada di cache conn.chats.\nPesan mungkin dikirim sebelum bot online, atau cache sudah ter-replace.'
        : '❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const msgType = getMsgType(rawMsg);
    const forceFile = flag.includes('-file');
    const sender = quoted.sender || quoted.participant || '-';
    const size = getSize(rawMsg);
    const keys = countKeys(rawMsg);
    const tsRaw = getTimestamp(quoted, rawMsg, msgType);
    const ts = tsRaw ? new Date(tsRaw * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-';

    logAction({ action: fromCache ? 'crm2' : 'crm', chat, sender, id, msgType, source, chain, rawMsg });

    const meta = `• Type    : ${msgType}
• Source  : ${source}${chain.length ? ` (unwrapped: ${chain.join(' > ')})` : ''}
• Chat    : ${shortStr(chat)}
• ID      : ${id}
• Sender  : ${sender.replace('@s.whatsapp.net', '')}
• Time    : ${ts}
• Size    : ${size}  Keys: ${keys}`;

    if (flag.includes('-info')) {
      await sendAuto(conn, m, { heading: '# 📋 Message Info', meta, pills: [msgType, chat, id], code: meta, language: 'text', fileTag: 'info', fileExt: 'txt', fileCaption: `📋 *Message Info*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    if (flag.includes('-key')) {
      const key = getQuotedKey(conn, quoted, chat, sender, id);
      await sendAuto(conn, m, { heading: '# 🔑 Message Key', meta, pills: [msgType, chat, id], code: safeJson(key), language: 'json', fileTag: 'key', fileExt: 'json', fileCaption: `🔑 *Message Key*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    if (flag.includes('-ctx')) {
      const ctx = (rawMsg[msgType] || {}).contextInfo || rawMsg?.contextInfo || null;
      if (!ctx) {
        await react(conn, m, '❌');
        return m.reply('❌ Tidak ada contextInfo di pesan ini.');
      }
      await sendAuto(conn, m, { heading: '# 📎 Context Info', meta, pills: [msgType, chat, id], code: safeJson(ctx), language: 'json', fileTag: 'ctx', fileExt: 'json', fileCaption: `📎 *Context Info*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    if (flag.includes('-type')) {
      await m.reply(`📌 *Type:* \`${msgType}\`\n📦 *Size:* ${size}\n🔢 *Keys:* ${keys}`);
      return react(conn, m, '✅');
    }

    if (flag.includes('-relay')) {
      await sendAuto(conn, m, { heading: '# 🎯 Relay Target (jid)', meta, pills: [msgType, chat, id], code: safeJson(chat), language: 'json', fileTag: 'relay-jid', fileExt: 'json', fileCaption: `🎯 *Relay Target (jid)*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    const { nodes: addNodes } = getAdditionalNodes(quoted, rawMsg, msgType);

    if (flag.includes('-option')) {
      const relayOption = addNodes ? { additionalNodes: addNodes } : {};
      await sendAuto(conn, m, { heading: '# ⚙️ Relay Options', meta, pills: [msgType, chat, id], code: safeJson(relayOption), language: 'json', fileTag: 'relay-option', fileExt: 'json', fileCaption: `⚙️ *Relay Options*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    const fixedContent = normalizePayloadForRelay(rawMsg);

    if (flag.includes('-message')) {
      await sendAuto(conn, m, { heading: '# 📨 Relay Message Content', meta, pills: [msgType, chat, id], code: safeJson(fixedContent), language: 'json', fileTag: 'relay-message', fileExt: 'json', fileCaption: `📨 *Relay Message Content*\n\n${meta}`, msgType, forceFile });
      return react(conn, m, '✅');
    }

    let relayOptionsStr = '{}';
    if (addNodes) {
      relayOptionsStr = safeJson({ additionalNodes: addNodes }, 2);
    }

    const execCode = `await conn.relayMessage(
  m.chat,
  ${safeJson(fixedContent)},
  ${relayOptionsStr}
);`;

    const wantSnip = flag.includes('-snip');

    if (forceFile || !wantSnip) {
      await sendAsFile(conn, m, execCode, 'snip', 'js', `⚡ *Relay Snippet*\n\n${meta}`, msgType);
    } else {
      await sendAsCode(conn, m, {
        heading: `# ⚡ ${capitalize(msgType)} Relay Snippet`,
        meta,
        pills: [msgType, chat, id],
        code: execCode,
        language: 'javascript'
      });
    }
    return react(conn, m, '✅');

  } catch (e) {
    console.error('[crm]', e);
    await react(conn, m, '❌');
    return m.reply(`❌ ${e.message}`);
  }
}

async function runInsp(m, ctx) {
  return runCrm(m, { ...ctx, args: ['-info', ...ctx.args] }, { fromCache: false });
}

// ---------- adn ----------

async function runAdn(m, { conn, args }) {
  if (!m.quoted) return m.reply(HELP);
  await react(conn, m, '⏳');

  try {
    const quoted = m.quoted;
    const { msg: rawMsg, source, chain } = getRawMsg(conn, quoted, {}, m);

    if (!rawMsg) {
      await react(conn, m, '❌');
      return m.reply('❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const chat = quoted.chat || m.chat || '-';
    const id = quoted.id || '-';
    const msgType = getMsgType(rawMsg);
    const flag = args.join(' ').toLowerCase().trim();
    const nofilter = flag.includes('-nofilter');
    const wantSnip = flag.includes('-snip');

    const { nodes, synthetic } = getAdditionalNodes(quoted, rawMsg, msgType);

    logAction({ action: 'adn', chat, sender: quoted.sender, id, msgType, source, chain, rawMsg: nodes });

    if (!nodes) {
      await react(conn, m, '❌');
      return m.reply('❌ Tidak ada additionalNodes yang ketemu di proto ini.');
    }

    const shaped = nofilter ? nodes : fixEnums(nodes);
    const meta = `• Type    : ${msgType}
• Source  : ${source}${chain.length ? ` (unwrapped: ${chain.join(' > ')})` : ''}
• Filter  : ${nofilter ? 'off (-nofilter)' : 'on'}
• Origin  : ${synthetic ? 'synthetic fallback' : 'extracted from message'}`;

    if (wantSnip) {
      const code = `const additionalNodes = ${safeJson(shaped)};`;
      await sendAuto(conn, m, { heading: `# 🍔 ${capitalize(msgType)} AdditionalNode Snippet`, meta, pills: [msgType, chat, id], code, language: 'javascript', fileTag: 'adn-snip', fileExt: 'js', fileCaption: '⚡ *AdditionalNode Snippet*', msgType });
      return react(conn, m, '✅');
    }

    await sendAuto(conn, m, { heading: '# 🍔 AdditionalNodes', meta, pills: [msgType, chat, id], code: safeJson(shaped), language: 'json', fileTag: 'adn', fileExt: 'json', fileCaption: '🍔 *AdditionalNodes*', msgType });
    return react(conn, m, '✅');

  } catch (e) {
    console.error('[adn]', e);
    await react(conn, m, '❌');
    return m.reply(`❌ ${e.message}`);
  }
}

// ---------- relay ----------

async function runRelay(m, { conn, args }) {
  if (!m.quoted) return m.reply(HELP);
  await react(conn, m, '⏳');

  try {
    const quoted = m.quoted;
    const { msg: rawMsg, source, chain } = getRawMsg(conn, quoted, {}, m);

    if (!rawMsg) {
      await react(conn, m, '❌');
      return m.reply('❌ Tidak bisa ambil raw message dari store/vM/cache/quoted manapun.');
    }

    const flags = args.map(a => a.toLowerCase());
    const sameKey = flags.includes('-samekey');
    const targetJid = args.find(a => !a.startsWith('-')) || m.chat;
    const msgType = getMsgType(rawMsg);
    
    const fixedContent = normalizePayloadForRelay(rawMsg);

    const { nodes: addNodes } = getAdditionalNodes(quoted, rawMsg, msgType);

    const relayOptions = {
      ...(sameKey ? { messageId: quoted.id } : {}),
      ...(addNodes ? { additionalNodes: addNodes } : {})
    };

    await conn.relayMessage(targetJid, fixedContent, relayOptions);

    logAction({ action: 'relay', chat: targetJid, sender: quoted.sender, id: quoted.id, msgType, source, chain, rawMsg: fixedContent });

    return react(conn, m, '✅');

  } catch (e) {
    console.error('[relay]', e);
    await react(conn, m, '❌');
    return m.reply(`❌ Gagal relay: ${e.message}`);
  }
}

// ---------- handler ----------

let handler = async (m, ctx) => {
  const cmd = String(ctx.command || '').toLowerCase();
  if (cmd === 'crm2') return runCrm(m, ctx, { fromCache: true });
  if (cmd === 'insp') return runInsp(m, ctx);
  if (cmd === 'adn') return runAdn(m, ctx);
  if (cmd === 'relay') return runRelay(m, ctx);
  return runCrm(m, ctx, { fromCache: false });
};

handler.help = ['crm', 'rawmsg', 'crm2', 'insp', 'adn', 'relay'];
handler.tags = ['owner'];
handler.command = /^(crm|rawmsg|crm2|insp|adn|relay)$/i;
handler.owner = true;

handler.noJadiBot = true;

export default handler;