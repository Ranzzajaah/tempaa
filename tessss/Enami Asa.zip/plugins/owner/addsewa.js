/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { addSewaGroup, getSewaGroup, formatSewaTime } from "../../lib/database.js";

const parseDuration = (input) => {
	if (!input) return null;
	const text = String(input).trim().toLowerCase();
	const match = text.match(/^(\d+)\s*(d|hari|b|bln|bulan|m|month|th|thn|tahun|y|year|jam|h|hour)?$/i);
	if (!match) return null;

	const val = parseInt(match[1], 10);
	if (isNaN(val) || val <= 0) return null;

	const unit = (match[2] || 'd').toLowerCase();
	switch (unit) {
		case 'd':
		case 'hari':
			return val * 24 * 60 * 60 * 1000;
		case 'b':
		case 'bln':
		case 'bulan':
		case 'm':
		case 'month':
			return val * 30 * 24 * 60 * 60 * 1000;
		case 'th':
		case 'thn':
		case 'tahun':
		case 'y':
		case 'year':
			return val * 365 * 24 * 60 * 60 * 1000;
		case 'jam':
		case 'h':
		case 'hour':
			return val * 60 * 60 * 1000;
		default:
			return val * 24 * 60 * 60 * 1000;
	}
};

const handler = async (m, { sock, conn, hirara, args, command, prefix, isOwner, reply }) => {
	if (!isOwner) return reply(global.mess?.owner || '🍓 Akses Khusus Owner!');
	if (m.isBaileys) return reply('ngapain 😂?');

	const client = sock || conn || hirara || global.mainSock;
	let targetJid = null;
	let durationInput = null;

	if (m.isGroup) {
		if (args.length === 1) {
			targetJid = m.chat;
			durationInput = args[0];
		} else if (args.length >= 2) {
			if (args[0].includes('@g.us')) {
				targetJid = args[0];
				durationInput = args[1];
			} else if (args[1].includes('@g.us')) {
				targetJid = args[1];
				durationInput = args[0];
			} else {
				targetJid = m.chat;
				durationInput = args[0];
			}
		}
	} else {
		if (args.length >= 2) {
			if (args[0].includes('@g.us')) {
				targetJid = args[0];
				durationInput = args[1];
			} else if (args[1].includes('@g.us')) {
				targetJid = args[1];
				durationInput = args[0];
			}
		}
	}

	if (!targetJid || !durationInput) {
		return reply(
			`• *Di dalam grup:* ${prefix + command} 30d (atau 1b / 1th)\n` +
			`• *Di private chat / via ID:* ${prefix + command} 120363xxx@g.us 30d\n\n` +
			`*Format Durasi:*\n` +
			`• 1d / 7d / 30d (Hari)\n` +
			`• 1b / 3b / 6b (Bulan)\n` +
			`• 1th (Tahun)`
		);
	}

	const durationMs = parseDuration(durationInput);
	if (!durationMs) {
		return reply(`Format durasi salah! Contoh: 1d, 30d, 1b, 1th`);
	}

	let groupSubject = targetJid;
	try {
		const meta = await client.groupMetadata(targetJid).catch(() => null);
		if (meta?.subject) groupSubject = meta.subject;
	} catch (_) {}

	const success = addSewaGroup(targetJid, durationMs);
	if (!success) return reply('Gagal menyimpan data sewa grup.');

	const updatedSewa = getSewaGroup(targetJid);
	const remainingText = formatSewaTime(updatedSewa.expired - Date.now());
	const expireDateStr = new Date(updatedSewa.expired).toLocaleString('id-ID', {
		timeZone: 'Asia/Jakarta',
		dateStyle: 'full',
		timeStyle: 'medium'
	});

	const successMsg =
		`✅ *BERHASIL MENAMBAH SEWA GRUP*\n\n` +
		`• Grup: ${groupSubject}\n` +
		`• ID: ${targetJid}\n` +
		`• Durasi: ${durationInput}\n` +
		`• Total Sisa Waktu: ${remainingText}\n` +
		`• Expired: ${expireDateStr} WIB`;

	await reply(successMsg);

	if (targetJid !== m.chat) {
		try {
			await client.sendMessage(targetJid, {
				text: `🎉 *SEWA BOT TELAH DIAKTIFKAN*\n\n• Sisa Waktu: ${remainingText}\n• Expired: ${expireDateStr} WIB`
			});
		} catch (_) {}
	}
};

handler.help = ['addsewa'];
handler.tags = ['owner'];
handler.command = ['addsewa', 'sewa'];
handler.category = 'owner';
handler.owner = true;
handler.noJadiBot = true;

export default handler;
