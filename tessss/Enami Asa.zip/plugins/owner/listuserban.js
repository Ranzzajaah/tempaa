/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { db } from "../../lib/database.js";import { jidDecode } from '@whiskeysockets/baileys';

const decodeJid = (jid) => {
	if (!jid) return jid;
	if (/:\d+@/gi.test(jid)) {
		const decode = jidDecode(jid) || {};
		return (decode.user && decode.server && `${decode.user}@${decode.server}`) || jid;
	}
	return jid;
};

const handler = async (m, { conn, sock, args, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const page = parseInt(args[0]) || 1;
	const perPage = 25;
	const offset = (page - 1) * perPage;

	try {
		const totalRow = db.prepare('SELECT COUNT(*) as count FROM users WHERE banned = 1').get();
		const totalBanned = totalRow?.count || 0;

		if (totalBanned === 0) {
			return reply('ℹ️ *Tidak ada user yang sedang dibanned.*');
		}

		const totalPages = Math.ceil(totalBanned / perPage);
		if (page > totalPages) {
			return reply(`❌ Halaman tidak ditemukan! Total hanya ada *${totalPages} halaman*.`);
		}

		const bannedUsers = db.prepare(
			'SELECT id, nama, name, nomor, banReason FROM users WHERE banned = 1 ORDER BY id ASC LIMIT ? OFFSET ?'
		).all(perPage, offset);

		const decodedMentions = [];
		let txt = `🚫 *DAFTAR USER TERBANNED*\n\n` +
			`• Total Banned: *${totalBanned.toLocaleString('id-ID')} Orang*\n` +
			`• Halaman: *${page} / ${totalPages}*\n\n`;

		bannedUsers.forEach((u, i) => {
			const rawJid = u.id || (u.nomor ? `${u.nomor}@s.whatsapp.net` : '');
			const decoded = decodeJid(rawJid);
			if (decoded) decodedMentions.push(decoded);

			const num = (decoded ? decoded.split('@')[0] : u.nomor) || 'unknown';
			const name = u.nama || u.name || 'User';
			const reason = u.banReason || 'Tidak ada alasan';

			txt += `*${offset + i + 1}.* @${num}\n` +
				`   ├ 👤 *Nama   :* ${name}\n` +
				`   ╰ ⚠️ *Alasan :* ${reason}\n\n`;
		});

		txt += `💡 *Cara Unban User:*\n` +
			`Ketik: \`${usedPrefix}unban @tag\` atau \`${usedPrefix}unban <nomor>\``;

		await client.sendMessage(m.chat, {
			text: txt.trim(),
			mentions: decodedMentions
		}, { quoted: m });

	} catch (err) {
		console.error('[LISTUSERBAN ERROR]', err);
		return reply(`❌ Gagal mengambil daftar user banned: ${err.message}`);
	}
};

handler.help = ['listuserban [halaman]'];
handler.tags = ['owner'];
handler.command = /^(listuserban|listban|listbanned|bannedlist|listuserbanned)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
