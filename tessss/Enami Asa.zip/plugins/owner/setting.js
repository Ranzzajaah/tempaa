/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const handler = async (m, { sock, args, command, reply, usedPrefix }) => {

	if (command === 'setthumb') {
		const idx = parseInt(args[0]);
		if (![1, 2, 3].includes(idx)) {
			return reply(`Gunakan: ${usedPrefix}setthumb 1/2/3\n\nThumb tersedia:\n- 1: media/menu.jpg\n- 2: media/menu2.jpg\n- 3: media/menu3.jpg`);
		}
		const map = { 1: 'media/menu.jpg', 2: 'media/menu2.jpg', 3: 'media/menu3.jpg' };
		if (!fs.existsSync(map[idx])) return reply(`File ${map[idx]} tidak ada.`);
		global.thumbIndex = idx;
		global.fotoreply = map[idx];
		return reply(`Thumbnail berhasil diganti ke *thumb ${idx}* (${map[idx]})`);
	}

	if (command === 'setweb') {
		if (!args[0]) return reply(`Gunakan: ${usedPrefix}setweb <url>\n\nContoh:\n${usedPrefix}setweb https://domainanda.com\n\nWeb sekarang: ${global.website || '-'}`);
		let url = args[0];
		if (!url.startsWith('http')) url = 'https://' + url;
		global.website = url;
		return reply(`Website berhasil diubah ke:\n${url}`);
	}

	if (command === 'setreply') {
		const q = m.quoted ? m.quoted : m;
		const mime = (q.msg || q).mimetype || q.mimetype || (q.imageMessage ? 'image/jpeg' : '') || '';
		if (!/image/.test(mime)) {
			return reply(`Reply foto dulu buat ganti foto reply!\n\nContoh: reply foto lalu ketik\n${usedPrefix}setreply\natau dengan nama custom:\n${usedPrefix}setreply custom.jpg`);
		}
		const namaFile = args[0] ? args[0].replace(/[^a-zA-Z0-9._-]/g, '') : `reply_${Date.now()}.jpg`;
		const savePath = `media/${namaFile}`;
		let buffer = typeof q.download === 'function' ? await q.download().catch(() => null) : null;
		if (!buffer && q.msg) buffer = await sock.downloadM(q.msg, 'image').catch(() => null);
		if (!buffer) buffer = await sock.downloadM(q, 'image').catch(() => null);
		if (!buffer || buffer.length === 0) return reply('❌ Gagal mendownload foto.');

		if (!fs.existsSync('media')) fs.mkdirSync('media', { recursive: true });
		fs.writeFileSync(savePath, buffer);
		global.fotoreply = savePath;
		global.thumbIndex = 0;
		return reply(`Foto reply berhasil diubah!\nDisimpan ke: *${savePath}*`);
	}

	if (command === 'setthumbfile') {
		const q = m.quoted ? m.quoted : m;
		const mime = (q.msg || q).mimetype || q.mimetype || (q.imageMessage ? 'image/jpeg' : '') || '';
		if (!/image/.test(mime)) {
			return reply(`Reply foto dulu untuk set thumb custom!\n\nContoh: reply foto lalu kirim\n${usedPrefix}setthumbfile menu4.jpg`);
		}
		const namaFile = args[0] ? args[0].replace(/[^a-zA-Z0-9._-]/g, '') : `thumb_${Date.now()}.jpg`;
		const savePath = `media/${namaFile}`;
		let buffer = typeof q.download === 'function' ? await q.download().catch(() => null) : null;
		if (!buffer && q.msg) buffer = await sock.downloadM(q.msg, 'image').catch(() => null);
		if (!buffer) buffer = await sock.downloadM(q, 'image').catch(() => null);
		if (!buffer || buffer.length === 0) return reply('❌ Gagal mendownload foto.');

		if (!fs.existsSync('media')) fs.mkdirSync('media', { recursive: true });
		fs.writeFileSync(savePath, buffer);
		return reply(`Foto berhasil disimpan ke *${savePath}*\n\nGunakan .setreply ${namaFile} untuk aktifkan.`);
	}

	if (command === 'setsong') {
		const quoted = m.quoted;
		if (!quoted || !quoted.msg?.mimetype?.startsWith('audio')) {
			return reply(`Reply audio dulu untuk set lagu menu!\n\nContoh: reply audio lalu kirim\n${usedPrefix}setsong`);
		}
		const savePath = 'media/menu.mp3';
		const stream = await sock.downloadM(quoted.msg, 'audio');
		fs.writeFileSync(savePath, stream);
		return reply(`Audio menu berhasil diupdate!\nDisimpan ke: ${savePath}`);
	}

	if (command === 'settings') {
		const thumbNames = { 1: 'menu.jpg', 2: 'menu2.jpg', 3: 'menu3.jpg' };
		return reply(`*Settings ${global.namaBot || 'Bot'}*\n\n` +
			`• Nama bot     : ${global.namaBot || '-'}\n` +
			`• Website      : ${global.website || '-'}\n` +
			`• Thumb aktif  : thumb ${global.thumbIndex || 1} (${thumbNames[global.thumbIndex || 1]})\n` +
			`• Foto reply   : ${global.fotoreply || '-'}\n` +
			`• Mode         : ${global.public ? 'Public' : 'Self'}\n\n` +
			`*Commands:*\n` +
			`.setthumb 1/2/3 — ganti thumbnail\n` +
			`.setweb <url> — ganti website link\n` +
			`.setreply — reply foto untuk ganti foto reply\n` +
			`.setthumbfile — upload thumb baru ke media/\n` +
			`.setsong — upload lagu menu baru`
		);
	}
};

handler.command = ['setthumb','setweb','setsong'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
