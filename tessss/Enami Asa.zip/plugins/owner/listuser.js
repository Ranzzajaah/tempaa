/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { db } from "../../lib/database.js";import { jidDecode } from '@whiskeysockets/baileys';

const decodeJid = (jid) => {
	if (!jid) return jid;
	if (/:\d+@/gi.test(jid)) {
		const decode = jidDecode(jid) || {};
		return (decode.user && decode.server && `${decode.user}@${decode.server}`) || jid;
	}
	return jid;
};

const handler = async (m, { conn, sock, args, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const page = parseInt(args[0]) || 1;
	const perPage = 25;
	const offset = (page - 1) * perPage;

	try {
		const totalRow = db.prepare('SELECT COUNT(*) as count FROM users WHERE registered = 1').get();
		const totalUsers = totalRow?.count || 0;

		if (totalUsers === 0) {
			return reply('ℹ️ Belum ada user yang terdaftar di database bot.');
		}

		const totalPages = Math.ceil(totalUsers / perPage);
		if (page > totalPages) {
			return reply(`❌ Halaman tidak ditemukan! Total hanya ada *${totalPages} halaman*.`);
		}

		const users = db.prepare(
			'SELECT id, nama, name, nomor, level, limit_val, money, banned FROM users WHERE registered = 1 ORDER BY id ASC LIMIT ? OFFSET ?'
		).all(perPage, offset);

		const decodedMentions = [];
		let txt = `👥 *DAFTAR USER TERDAFTAR*\n\n` +
			`• Total User: *${totalUsers.toLocaleString('id-ID')} Orang*\n` +
			`• Halaman: *${page} / ${totalPages}*\n\n`;

		users.forEach((u, i) => {
			const rawJid = u.id || (u.nomor ? `${u.nomor}@s.whatsapp.net` : '');
			const decoded = decodeJid(rawJid);
			if (decoded) decodedMentions.push(decoded);

			const num = (decoded ? decoded.split('@')[0] : u.nomor) || 'unknown';
			const name = u.nama || u.name || 'User';
			const bannedTag = u.banned ? ' 🚫 [BANNED]' : '';

			txt += `*${offset + i + 1}.* @${num}${bannedTag}\n` +
				`   ├ 👤 *Nama  :* ${name}\n` +
				`   ├ 🎖️ *Level :* ${u.level || 1}\n` +
				`   ├ 🎟️ *Limit :* ${u.limit_val ?? 20}\n` +
				`   ╰ 💰 *Uang  :* Rp ${(u.money || 0).toLocaleString('id-ID')}\n\n`;
		});

		txt += `💡 *Navigasi Halaman:*\n` +
			`Ketik: \`${usedPrefix + command} <halaman>\` (Contoh: \`${usedPrefix + command} 2\`)`;

		await client.sendMessage(m.chat, {
			text: txt.trim(),
			mentions: decodedMentions
		}, { quoted: m });

	} catch (err) {
		console.error('[LISTUSER ERROR]', err);
		return reply(`❌ Gagal mengambil daftar user: ${err.message}`);
	}
};

handler.help = ['listuser [halaman]'];
handler.tags = ['owner'];
handler.command = /^(listuser|userlist|listusers|allusers)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
