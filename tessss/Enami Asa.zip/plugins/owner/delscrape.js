/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const SCRAPE_DIR = path.join(process.cwd(), 'scrape');

const handler = async (m, { text, command, usedPrefix, isOwner }) => {
    if (!isOwner) return m.reply(global.mess?.owner || 'Khusus Owner!');

    if (!fs.existsSync(SCRAPE_DIR)) return m.reply('📂 Folder `scrape/` belum ada.');
    const files = fs.readdirSync(SCRAPE_DIR).filter(f => f.endsWith('.js'));

    if (!text) {
        return m.reply(
            `🗑️ *DELETE SCRAPE*\n\n` +
            `Contoh Penggunaan:\n` +
            `• *${usedPrefix + command} ngl.js*\n` +
            `• *${usedPrefix + command} 1*\n\n` +
            `Ketik *${usedPrefix}listscrape* untuk melihat nomor & daftar scraper.`
        );
    }

    const input = text.trim();
    let targetFile = null;

    if (/^\d+$/.test(input)) {
        const idx = parseInt(input, 10) - 1;
        if (idx < 0 || idx >= files.length) {
            return m.reply(`❌ Nomor *${input}* tidak valid. Total scraper: ${files.length}`);
        }
        targetFile = files[idx];
    } else {
        targetFile = input.endsWith('.js') ? input : `${input}.js`;
    }

    const targetPath = path.join(SCRAPE_DIR, targetFile);
    if (!fs.existsSync(targetPath)) {
        return m.reply(`❌ Scraper *${targetFile}* tidak ditemukan.\n\nKetik *${usedPrefix}listscrape* untuk lihat daftar.`);
    }

    fs.unlinkSync(targetPath);
    return m.reply(`✅ Berhasil menghapus scraper \`scrape/${targetFile}\``);
};

handler.help = ['delscrape <nama/nomor>'];
handler.tags = ['owner'];
handler.command = /^(delscrape|dfscrape|deletescrape|ds)$/i;
handler.owner = true;
handler.noJadiBot = true;

export default handler;

