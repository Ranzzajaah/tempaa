/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	const args = (text || '').split('|');

	if (args.length < 2 || !args[0].trim() || !args[1].trim()) {
		return reply(
			`*BUAT GRUP BARU*\n\n` +
			`Format:\n` +
			`*${usedPrefix + command} Nama | 628xxx,628yyy*\n` +
			`*${usedPrefix + command} Nama | 628xxx,628yyy | DurasiMenit*\n\n` +
			`Contoh:\n` +
			`*${usedPrefix + command} Tim Bot | 628123456789,628987654321 | 60*`
		);
	}

	const name = args[0].trim();
	const participantStr = args[1].trim();
	const durationStr = args[2] ? args[2].trim() : '';

	if (name.length < 2) {
		return reply('Nama grup minimal 2 karakter.');
	}

	const participants = participantStr
		.split(/[,;\s]+/)
		.map(n => n.replace(/[^0-9]/g, ''))
		.filter(n => n.length >= 5)
		.map(n => n + '@s.whatsapp.net');

	if (participants.length === 0) {
		return reply('Nomor peserta tidak valid. Masukkan minimal 1 nomor yang benar.');
	}

	let durationMs = 0;
	let durationMins = 0;
	if (durationStr) {
		durationMins = parseInt(durationStr.replace(/[^0-9]/g, ''), 10);
		if (!isNaN(durationMins) && durationMins > 0) {
			durationMs = durationMins * 60 * 1000;
		}
	}

	try {
		await global.react(client, m, 'loading');

		const group = await client.groupCreate(name, participants);

		let successTxt =
			`*Grup Berhasil Dibuat*\n\n` +
			`Nama: ${name}\n` +
			`ID: ${group.id}\n` +
			`Peserta: ${participants.length} orang\n`;

		if (durationMs > 0) {
			successTxt += `\nMasa Aktif: ${durationMins} menit\n(Grup akan otomatis dihapus dan member dikeluarkan saat waktu habis)\n`;
		}

		await global.react(client, m, 'success');
		await reply(successTxt.trim());

		if (durationMs > 0) {
			setTimeout(async () => {
				try {
					const groupMeta = await client.groupMetadata(group.id);
					const botNum = (client.user?.id || '').split(':')[0].replace(/[^0-9]/g, '');
					const botJid = `${botNum}@s.whatsapp.net`;
					const membersToKick = (groupMeta.participants || [])
						.map(p => p.id)
						.filter(id => id !== botJid);

					await client.sendMessage(group.id, {
						text: `*Masa Aktif Grup Telah Habis*\n\nWaktu grup ini telah berakhir. Bot akan mengeluarkan semua member dan keluar.`
					});

					if (membersToKick.length > 0) {
						await client.groupParticipantsUpdate(group.id, membersToKick, 'remove');
					}

					await client.groupLeave(group.id);
				} catch (e) {
					console.error(`[BUATGRUP AUTO LEAVE ERROR] ${group.id}:`, e.message);
				}
			}, durationMs);
		}

	} catch (err) {
		console.error('[BUATGRUP ERROR]', err);
		await global.react(client, m, 'error');
		return reply(`Gagal membuat grup: ${err.message}`);
	}
};

handler.help = ['buatgrup <nama>|<nomor1,nomor2>', 'buatgrup <nama>|<nomor>|<durasi>'];
handler.tags = ['owner'];
handler.command = /^(buatgrup|creategroup|newgroup|creategc)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
