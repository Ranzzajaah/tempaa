/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';

const handler = async (m, { sock, conn, reply, usedPrefix, command }) => {
	const client = sock || conn || global.mainSock;

	const restartData = {
		chat: m.chat,
		sender: m.sender,
		time: Date.now(),
		key: m.key
	};

	try {
		fs.writeFileSync('./tmp/restart.json', JSON.stringify(restartData, null, 2), 'utf-8');
	} catch (e) {
		console.error('[RESTART SAVE ERROR]', e);
	}

	await reply('⏳ *sᴇᴅᴀɴɢ ᴍᴇʀᴇsᴛᴀʀᴛ ʙᴏᴛ...* 🎀✨\n_ᴛᴜɴɢɢᴜ sᴇʙᴇɴᴛᴀʀ ʏᴀᴀ, ɴᴀɴᴛɪ ᴀᴋᴜ ᴋᴀsɪʜ ᴋᴀʙᴀʀ ᴋᴀʟᴀᴜ sᴜᴅᴀʜ ᴏɴʟɪɴᴇ ʟᴀɢɪ!_ 🌸');

	setTimeout(() => {
		process.exit(0);
	}, 1500);
};

handler.help = ['restart'];
handler.tags = ['owner'];
handler.command = ['restart', 'reboot'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
