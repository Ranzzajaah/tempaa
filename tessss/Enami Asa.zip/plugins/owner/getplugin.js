/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let AIRich = null;
try {
	const mb = await import("../../lib/helper-bails.js");
	AIRich = mb.AIRich || null;
} catch {}

const getAllPluginFiles = (baseDir) => {
	const files = [];
	if (!fs.existsSync(baseDir)) return files;

	const walk = (dir, relDir = "") => {
		const items = fs.readdirSync(dir);
		for (const item of items) {
			const fullPath = path.join(dir, item);
			const relPath = relDir ? path.join(relDir, item) : item;
			if (fs.statSync(fullPath).isDirectory()) {
				walk(fullPath, relPath);
			} else if (item.endsWith(".js")) {
				files.push(relPath.replace(/\\/g, "/"));
			}
		}
	};

	walk(baseDir);
	return files;
};

const handler = async (m, { conn, sock, text, command, reply, usedPrefix }) => {
	const client = conn || sock || global.mainSock;
	try {
		const baseDir = path.join(__dirname, "../../plugins");
		const allFiles = getAllPluginFiles(baseDir);

		if (!text) {
			return reply(
				`📂 *GET PLUGIN CODE*\n\n` +
				`Contoh Penggunaan:\n` +
				`• *${usedPrefix + command} game/tetris.js*\n` +
				`• *${usedPrefix + command} tetris*\n` +
				`• *${usedPrefix + command} 5*\n\n` +
				`Ketik *${usedPrefix}listplugin* untuk melihat nomor & daftar plugin.`
			);
		}

		const input = text.trim();
		let targetRelPath = null;

		if (/^\d+$/.test(input)) {
			const idx = parseInt(input, 10) - 1;
			if (idx < 0 || idx >= allFiles.length) {
				return reply(`❌ Nomor *${input}* tidak valid. Total plugin: ${allFiles.length}`);
			}
			targetRelPath = allFiles[idx];
		} else {
			const cleanInput = input.endsWith(".js") ? input : `${input}.js`;

			if (allFiles.includes(cleanInput)) {
				targetRelPath = cleanInput;
			} else {
				const found = allFiles.find(f => path.basename(f).toLowerCase() === path.basename(cleanInput).toLowerCase());
				if (found) {
					targetRelPath = found;
				} else {
					const partial = allFiles.find(f => f.toLowerCase().includes(input.toLowerCase()));
					if (partial) {
						targetRelPath = partial;
					}
				}
			}
		}

		if (!targetRelPath) {
			return reply(`❌ Plugin *${input}* tidak ditemukan di folder ./plugins`);
		}

		const targetPath = path.join(baseDir, targetRelPath);
		if (!fs.existsSync(targetPath)) {
			return reply(`❌ File *${targetRelPath}* tidak ditemukan.`);
		}

		const fileContent = fs.readFileSync(targetPath, "utf8");
		const filename = path.basename(targetPath);
		const ext = path.extname(filename).slice(1).toLowerCase() || "javascript";
		const lang = (ext === "js" || ext === "mjs" || ext === "cjs") ? "javascript" : (ext === "html" || ext === "htm" ? "html" : (ext === "json" ? "json" : ext));

		const heading = `### 📂 Plugin: ${targetRelPath}`;
		const meta = `*File:* ${targetRelPath}\n*Size:* ${fileContent.length} bytes\n*Type:* ${ext.toUpperCase()}`;
		const pills = [targetRelPath, `${fileContent.length}b`, ext.toUpperCase()];

		if (AIRich && fileContent.length < 65000) {
			try {
				const rich = new AIRich(client);
				if (heading) rich.addText(heading);
				if (meta) rich.addMetadata(meta);
				const cleanPills = pills.filter(Boolean).map(String);
				if (cleanPills.length) rich.addSuggest(cleanPills);
				rich.addCode(lang, fileContent);
				return await rich.send(m.chat, { quoted: m });
			} catch (errRich) {
				console.error("[GETPLUGIN AIRICH ERROR]", errRich);
			}
		}

		return await client.sendMessage(
			m.chat,
			{
				document: fs.readFileSync(targetPath),
				fileName: filename,
				mimetype: "application/javascript",
				caption: `📂 *PLUGIN SOURCE CODE*\n📌 *Path:* ${targetRelPath}\n📊 *Size:* ${fileContent.length} bytes`
			},
			{ quoted: m }
		);

	} catch (err) {
		console.error("[GETPLUGIN ERROR]", err);
		return reply(`❌ Terjadi kesalahan saat membaca plugin:\n\`\`\`${err.message || err}\`\`\``);
	}
};

handler.help = ["getplugin <nama/nomor>", "getp <nama/nomor>"];
handler.tags = ["owner"];
handler.category = "owner";
handler.description = "Ambil kode plugin dengan format AI Rich Code Block ala .crm";
handler.command = ["getplugin", "gp"];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
