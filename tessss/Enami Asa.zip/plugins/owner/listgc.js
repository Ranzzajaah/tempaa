/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { jidDecode } from '@whiskeysockets/baileys';

const resolveCreatorNumber = (jid, participants = []) => {
	if (!jid) return null;

	if (jid.endsWith('@s.whatsapp.net')) {
		const decoded = jidDecode(jid);
		const user = decoded?.user || jid.split('@')[0].split(':')[0];
		return user.replace(/[^0-9]/g, '');
	}

	if (jid.endsWith('@lid') || jid.includes('@lid')) {
		const rawLid = jid.split('@')[0].split(':')[0];

		const found = participants.find(p => {
			if (p.lid && (p.lid === jid || p.lid.startsWith(rawLid))) return true;
			if (p.id && (p.id === jid || p.id.startsWith(rawLid))) return true;
			return false;
		});

		if (found?.id && found.id.endsWith('@s.whatsapp.net')) {
			const decoded = jidDecode(found.id);
			return (decoded?.user || found.id.split('@')[0].split(':')[0]).replace(/[^0-9]/g, '');
		}

		if (found?.phoneNumber) {
			return String(found.phoneNumber).replace(/[^0-9]/g, '');
		}
	}

	const clean = jid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
	return clean || null;
};

const handler = async (m, { sock, conn, hirara, isOwner, reply }) => {
	if (!isOwner) return reply(global.mess?.owner || '🍓 Akses Khusus Owner!');

	const client = sock || conn || hirara || global.mainSock;

	try {
		reply(global.mess?.wait || '⏳ _Mengambil daftar seluruh grup bot..._');

		const groupsData = await client.groupFetchAllParticipating();
		const gcList = Object.values(groupsData || {});

		if (!gcList.length) {
			return reply('❌ Bot saat ini tidak bergabung dalam grup WhatsApp manapun.');
		}

		let teks = `📋 *LIST ALL GROUP CHATS*\n\n` +
			`• 📊 *Total Grup:* ${gcList.length} Grup\n\n`;

		const mentions = [];

		for (const [index, u] of gcList.entries()) {
			const status = u.announce ? '🔒 Hanya Admin' : '🔓 Terbuka';
			const participants = u.participants || [];
			const participantsCount = participants.length;

			const rawCreatorJid = u.subjectOwner || u.owner || null;
			const creatorNum = resolveCreatorNumber(rawCreatorJid, participants);

			let creatorDisplay = 'Sudah Keluar';
			if (creatorNum) {
				creatorDisplay = `@${creatorNum}`;
				const creatorJid = `${creatorNum}@s.whatsapp.net`;
				if (!mentions.includes(creatorJid)) mentions.push(creatorJid);
			}

			teks += `*${index + 1}. ${u.subject || 'Tanpa Nama'}*\n` +
				`• 🆔 *ID:* \`${u.id}\`\n` +
				`• 👥 *Member:* ${participantsCount.toLocaleString('id-ID')} Anggota\n` +
				`• 📌 *Status:* ${status}\n` +
				`• 👑 *Pembuat:* ${creatorDisplay}\n\n`;
		}

		await client.sendMessage(m.chat, {
			text: teks.trim(),
			mentions
		}, { quoted: m });
	} catch (err) {
		console.error('[listgc error]:', err);
		reply(`❌ Gagal mengambil daftar grup: ${err.message || err}`);
	}
};

handler.help = ['listgc', 'listgrup'];
handler.tags = ['owner'];
handler.command = ['listgc', 'listgrup', 'grouplist', 'gclist'];
handler.category = 'owner';
handler.description = 'Tampilkan seluruh daftar grup yang diikuti oleh bot beserta nomor pembuat';
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
