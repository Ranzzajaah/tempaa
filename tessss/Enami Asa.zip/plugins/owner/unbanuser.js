/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, sock, text, usedPrefix, command, args, reply }) => {
	const client = conn || sock || global.mainSock;

	let target = m.mentionedJid?.[0] || (m.quoted ? (m.quoted.sender || m.quoted.participant) : null);

	if (!target && args[0]) {
		const targetNum = args[0].replace(/[^0-9]/g, '');
		if (targetNum.length >= 5) {
			target = `${targetNum}@s.whatsapp.net`;
		}
	}

	if (!target) {
		return reply(
			`*UNBAN USER DARI BOT*\n\n` +
			`Format:\n` +
			`• *${usedPrefix + command} @tag*\n` +
			`• *${usedPrefix + command} 628xxxx*\n` +
			`• Reply pesan target lalu ketik *${usedPrefix + command}*`
		);
	}

	const targetNum = target.split('@')[0];

	try {
		const user = await getUser(target);
		if (!user || !user.banned) {
			return reply(`ℹ️ User @${targetNum} tidak dalam status banned.`, null, { mentions: [target] });
		}

		await updateUser(target, { banned: 0, banReason: '' });
		await global.react(client, m, 'success');

		await reply(
			`*USER BERHASIL DI-UNBAN*\n\n` +
			`Target: @${targetNum}\n` +
			`Status: Aktif kembali\n\n` +
			`_User sudah dapat menggunakan perintah bot._`,
			null,
			{ mentions: [target] }
		);
	} catch (e) {
		console.error('[UNBANUSER ERROR]', e);
		await global.react(client, m, 'error');
		return reply(`Gagal meng-unban user: ${e.message}`);
	}
};

handler.help = ['unbanuser @tag', 'unban <nomor>'];
handler.tags = ['owner'];
handler.command = /^(unbanuser|unban|unblockuser)$/i;
handler.owner = true;
handler.noJadiBot = true;
handler.register = true;

export default handler;
