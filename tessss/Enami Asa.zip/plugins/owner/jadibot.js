/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import NodeCache from 'node-cache';
import chalk from 'chalk';
import {
	makeWASocket,
	useMultiFileAuthState,
	fetchLatestBaileysVersion,
	DisconnectReason,
	makeCacheableSignalKeyStore,
	Browsers,
	jidDecode
} from '@whiskeysockets/baileys';

import ConfigBaileys from '../../lib/config.js';
import { handler_cmd } from '../../src/handler.js';
import makeHelper from '../../lib/helper-bails.js';

const bots = new Map();
const reconnectAttempts = new Map();
const sessionsDir = path.join(process.cwd(), 'sessions_jadibot');
const pairingInProgress = new Set();

if (!fs.existsSync(sessionsDir)) {
	fs.mkdirSync(sessionsDir, { recursive: true });
}

const groupCache = new NodeCache({
	stdTTL: 5 * 60,
	useClones: false,
});

const normalizeNumber = (num = '') => String(num).replace(/[^0-9]/g, '');

async function startJadiBot(number, m = null, isStart = false) {
	const cleanNumber = normalizeNumber(number);
	if (!cleanNumber) return null;

	const sessionPath = path.join(sessionsDir, cleanNumber);

	const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
	const { version: v } = await fetchLatestBaileysVersion().catch(() => ({ version: [2, 3000, 1015901307] }));

	const clients = makeWASocket({
		printQRInTerminal: false,
		logger: pino({ level: 'silent' }),
		version: v,
		browser: Browsers.ubuntu('Chrome'),
		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
		},
		syncFullHistory: false
	});

	makeHelper(clients);
	clients.isJadiBot = true;

	clients.ev.on('creds.update', saveCreds);

	clients.getJid = (jid) => {
		if (!jid?.endsWith('@lid')) return jid;
		for (const key of groupCache.keys()) {
			const group = groupCache.get(key);
			const user = group?.participants?.find(p => p.lid === jid || p.id === jid);
			if (user) return user.phoneNumber || user.jid || user.id;
		}
		return jid;
	};

	clients.decodeJid = (jid) => {
		if (!jid) return jid;
		if (/:\d+@/gi.test(jid)) {
			let decode = jidDecode(jid) || {};
			return (decode.user && decode.server && decode.user + '@' + decode.server) || jid;
		}
		return jid;
	};

	clients.getCachedGroupMetadata = async (jid) => {
		let metadata = groupCache.get(jid);
		if (!metadata) {
			metadata = await clients.groupMetadata(jid);
			groupCache.set(jid, metadata);
		}
		return metadata;
	};

	clients.ev.on('connection.update', async (update) => {
		const { connection, lastDisconnect } = update;

		if (connection === 'connecting') {
			console.log(chalk.yellow(`[Jadibot] Connecting: ${cleanNumber}`));
		}

		if (connection === 'open') {
			console.log(chalk.green(`[Jadibot] Connected: ${cleanNumber}`));
			reconnectAttempts.set(cleanNumber, 0);

			bots.set(cleanNumber, {
				socket: clients,
				session: sessionPath
			});

			if (m?.chat && !isStart) {
				try {
					const thumb = global.getThumbBuffer ? global.getThumbBuffer() : '';
					await global.mainSock.sendButtons(m.chat, {
						location: {
							degreesLatitude: 0,
							degreesLongitude: 0,
							address: `Jadibot Connected • ${cleanNumber}`,
							jpegThumbnail: thumb ? (typeof thumb === 'string' ? Buffer.from(thumb, 'base64') : thumb) : Buffer.alloc(0),
						},
						text: `🎉 *Jadibot Connected!*\n\n• Nomor Bot: *${cleanNumber}*\n• Status: *Active*\n• Session: *Saved & Reusable*`,
						footer: `${global.namaBot || 'Bot'} • Jadibot System`,
						buttons: [
							{ id: `.listjadibot`, text: '📋 List Jadibot' },
							{ id: `.stopjadibot ${cleanNumber}`, text: '⏹️ Stop Jadibot' }
						]
					}, { quoted: m });
				} catch {}
			}
		}

		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
			console.log(chalk.red(`[Jadibot] Connection closed for ${cleanNumber}: ${reason}`));

			bots.delete(cleanNumber);

			if (reason === DisconnectReason.loggedOut || reason === DisconnectReason.badSession) {
				console.log(chalk.red(`[Jadibot] Session logged out/bad session: ${cleanNumber}`));
				if (fs.existsSync(sessionPath)) {
					try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
				}
				reconnectAttempts.delete(cleanNumber);
				return;
			}

			const currentAttempts = (reconnectAttempts.get(cleanNumber) || 0) + 1;
			reconnectAttempts.set(cleanNumber, currentAttempts);

			if (currentAttempts > 5) {
				console.log(chalk.red(`[Jadibot] Max reconnect attempts reached for ${cleanNumber}`));
				reconnectAttempts.delete(cleanNumber);
				return;
			}

			const delayMs = Math.min(30000, 5000 * currentAttempts);
			console.log(chalk.yellow(`[Jadibot] Reconnecting ${cleanNumber} in ${delayMs / 1000}s (Attempt ${currentAttempts}/5)...`));

			setTimeout(async () => {
				try {
					await startJadiBot(cleanNumber, m, true);
				} catch (e) {
					console.error(`[Jadibot] Reconnect failed:`, e);
				}
			}, delayMs);
		}
	});

	if (!state.creds.registered && !pairingInProgress.has(cleanNumber)) {
		pairingInProgress.add(cleanNumber);

		setTimeout(async () => {
			try {
				if (state.creds.registered) return;
				const code = await clients.requestPairingCode(cleanNumber);
				const formattedCode = code ? code.match(/.{1,4}/g)?.join('-') || code : code;

				if (m?.chat) {
					const thumb = global.getThumbBuffer ? global.getThumbBuffer() : '';
					await global.mainSock.sendButtons(m.chat, {
						location: {
							degreesLatitude: 0,
							degreesLongitude: 0,
							address: `Pairing Code • ${cleanNumber}`,
							jpegThumbnail: thumb ? (typeof thumb === 'string' ? Buffer.from(thumb, 'base64') : thumb) : Buffer.alloc(0),
						},
						text: `📱 *JADIBOT PAIRING CODE*\n\nPairing Code kamu: *${formattedCode}*\n\n*Langkah Tautan:*\n1. Buka WhatsApp di HP target\n2. Klik Titik Tiga (⋮) > Perangkat Tertaut\n3. Klik *Tautkan dengan nomor telepon*\n4. Masukkan kode di atas: *${formattedCode}*`,
						footer: `Kode berlaku selama 2 menit`,
						buttons: [
							{ copy: formattedCode, text: '📋 Copy Pairing Code' }
						]
					}, { quoted: m });
				}
			} catch (e) {
				console.error('[Jadibot] Pairing Error:', e);
				if (m?.chat) {
					try {
						await m.reply(`❌ *Gagal membuat Pairing Code:*\n${e.message || 'Unknown error'}`);
					} catch {}
				}
				try { await clients.logout(); } catch {}
				if (fs.existsSync(sessionPath)) {
					try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
				}
			} finally {
				pairingInProgress.delete(cleanNumber);
			}
		}, 3000);
	}

	clients.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			if (chatUpdate.type !== 'notify') return;
			const msg = chatUpdate.messages?.[0];
			if (!msg || !msg.message) return;
			if (msg.key.fromMe && !global.bot) return;
			const m2 = await ConfigBaileys(clients, msg);
			m2.isJadiBot = true;
			await handler_cmd(clients, m2, chatUpdate);
		} catch (e) {
			console.error('[Jadibot] Message handle error:', e);
		}
	});

	return clients;
}

const autoStartSavedSessions = async () => {
	if (!fs.existsSync(sessionsDir)) return;
	const folders = fs.readdirSync(sessionsDir).filter(f => {
		const full = path.join(sessionsDir, f);
		return fs.statSync(full).isDirectory() && fs.existsSync(path.join(full, 'creds.json'));
	});

	if (folders.length) {
		console.log(chalk.cyan(`[Jadibot] Auto-reloading ${folders.length} saved jadibot sessions...`));
		for (const folder of folders) {
			try {
				await startJadiBot(folder, null, true);
				await new Promise(r => setTimeout(r, 2000));
			} catch (e) {
				console.error(`[Jadibot] Failed auto-start session ${folder}:`, e);
			}
		}
	}
};

setTimeout(() => {
	autoStartSavedSessions().catch(() => {});
}, 8000);

const handler = async (m, { command, args, usedPrefix, isPremium, isOwner, isJadiBot, sock }) => {
	const checkBot = m.isJadiBot || isJadiBot || sock?.isJadiBot;

	switch (command) {
		case 'jadibot': {
			if (checkBot) {
				return m.reply('Fitur ini tidak bisa digunakan oleh *jadibot*!');
			}
			if (!isOwner && !isPremium) {
				return m.reply(global.mess?.vip || 'Fitur ini khusus User Premium!');
			}

			const number = normalizeNumber(args[0] || (m.sender ? m.sender.split('@')[0] : ''));

			if (!number) {
				return m.reply(`Masukkan nomor HP terdaftar di WhatsApp!\n\nContoh: *${usedPrefix}jadibot 628xxxx*`);
			}

			if (bots.has(number)) {
				return m.reply(`⚠️ Jadibot untuk nomor *${number}* sudah aktif!`);
			}

			await m.reply(`⌛ Sedang membuat Pairing Code untuk *${number}*...`);
			await startJadiBot(number, m);
			break;
		}

		case 'listjadibot':
		case 'listbot': {
			if (bots.size === 0) {
				return m.reply('ℹ️ Tidak ada jadibot yang sedang aktif saat ini.');
			}

			let text = `🤖 *LIST JADIBOT AKTIF (${bots.size}):*\n\n`;
			let i = 1;
			for (const [num] of bots) {
				text += `${i++}. @${num}\n`;
			}

			return m.reply(text, null, { mentions: Array.from(bots.keys()).map(n => n + '@s.whatsapp.net') });
		}

		case 'stopjadibot':
		case 'stopbot': {
			if (checkBot) {
				return m.reply('Fitur ini tidak bisa digunakan oleh *jadibot*!');
			}
			if (!isOwner && !isPremium) {
				return m.reply(global.mess?.vip || 'Fitur ini khusus User Premium!');
			}

			const number = normalizeNumber(args[0] || '');

			if (!number) {
				return m.reply(`Masukkan nomor jadibot yang ingin dimatikan!\nContoh: *${usedPrefix}stopjadibot 628xxx*\n\nKetik *${usedPrefix}listjadibot* untuk melihat daftar.`);
			}

			const bot = bots.get(number);
			if (!bot) {
				return m.reply(`❌ Nomor *${number}* tidak ditemukan dalam daftar jadibot aktif.`);
			}

			bots.delete(number);
			reconnectAttempts.delete(number);

			try {
				await bot.socket.logout();
			} catch {}

			if (bot.session && fs.existsSync(bot.session)) {
				try { fs.rmSync(bot.session, { recursive: true, force: true }); } catch {}
			}

			m.reply(`✅ *Jadibot* untuk nomor *${number}* berhasil dimatikan dan session telah dihapus!`);
			break;
		}
	}
};

handler.help = ['jadibot', 'listjadibot', 'stopjadibot'];
handler.tags = ['owner'];
handler.command = ['jadibot', 'listjadibot', 'stopjadibot'];
handler.isEffect = true;

handler.noJadiBot = true;
export default handler;