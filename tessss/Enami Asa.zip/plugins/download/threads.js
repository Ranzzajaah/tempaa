import axios from 'axios';
import * as cheerio from 'cheerio';
import FormData from 'form-data';

// Helper fetch buffer media dengan HTTP Header yang aman dari proteksi stream/CORS
async function getBuffer(url) {
    if (!url) return null;
    try {
        const res = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Referer": "https://threadsmate.net/"
            },
            responseType: 'arraybuffer',
            timeout: 30000
        });
        return Buffer.from(res.data);
    } catch (err) {
        console.error(`[GETBUFFER ERROR] (${url}) ->`, err.message);
        return null;
    }
}

// Scraper Threadsmate
async function threadsmate(url) {
    const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    // 1. GET Homepage untuk mengambil Session Cookie & CSRF Token
    const home = await axios.get("https://threadsmate.net/id", {
        headers: { "User-Agent": UA }
    });

    const cookie = home.headers["set-cookie"]
        ?.find(c => c.startsWith("session_data="))
        ?.split(";")[0] || "";

    const $ = cheerio.load(home.data);
    const hidden = $('input[type="hidden"]').first();

    const tokenName = hidden.attr("name");
    const tokenValue = hidden.val();

    if (!tokenName || !tokenValue) {
        throw new Error("CSRF token Threadsmate tidak ditemukan.");
    }

    // 2. POST Action untuk mengambil data unduhan
    const form = new FormData();
    form.append("url", url);
    form.append(tokenName, tokenValue);
    form.append("lang", "id");

    const { data } = await axios.post(
        "https://threadsmate.net/action",
        form,
        {
            headers: {
                ...form.getHeaders(),
                "Cookie": cookie,
                "Origin": "https://threadsmate.net",
                "Referer": "https://threadsmate.net/id",
                "User-Agent": UA,
                "Accept": "*/*",
                "X-Requested-With": "XMLHttpRequest"
            }
        }
    );

    if (data.error) {
        throw new Error("Gagal memproses tautan Threads melalui Threadsmate.");
    }

    // =========================
    // PARSER HTML RESPONSE
    // =========================
    const $$ = cheerio.load(data.html);

    const metadata = {
        title: $$(".hover-underline").attr("title") || $$(".hover-underline").text().trim() || 'Threads Media',
        username: $$(".threadsmate-downloader-middle span").first().text().replace("@", "").trim() || 'unknown',
        author: $$(".threadsmate-downloader-middle span").first().text().trim() || 'Unknown',
        avatar: $$(".threadsmate-downloader-left > img").first().attr("src") || null
    };

    const thumbnail = [];
    const video = [];
    const images = [];
    const audio = [];

    $$(".download-items").each((i, el) => {
        const item = $$(el);
        const thumb = item.find("img[data-src]").attr("data-src") || item.find("img").attr("src");

        if (thumb && !thumbnail.includes(thumb)) thumbnail.push(thumb);

        const btn = item.find("a");
        const link = btn.attr("href");
        if (!link) return;

        const text = btn.text().toLowerCase();
        let ext = "";

        try {
            const u = new URL(link);
            const filename = u.searchParams.get("filename") || decodeURIComponent(u.pathname);
            ext = filename.split(".").pop().toLowerCase();
        } catch {}

        if (text.includes("audio") || ext === "m4a" || ext === "mp3") {
            audio.push({ id: audio.length + 1, extension: ext || 'mp3', url: link });
            return;
        }

        if (text.includes("video") || ext === "mp4" || link.includes("/v2?")) {
            video.push({ id: video.length + 1, extension: "mp4", thumbnail: thumb, url: link });
            return;
        }

        images.push({ id: images.length + 1, extension: ext || "jpg", thumbnail: thumb, url: link });
    });

    return {
        status: true,
        type: video.length && images.length ? "mixed" : video.length ? (video.length > 1 ? "video_carousel" : "video") : (images.length > 1 ? "image_carousel" : images.length ? "image" : "unknown"),
        metadata,
        thumbnail,
        video,
        images,
        audio,
        total: {
            video: video.length,
            images: images.length,
            audio: audio.length,
            thumbnail: thumbnail.length
        }
    };
}

const handler = async (m, { sock, text, usedPrefix, command }) => {
    if (!text) {
        return sock.sendMessage(m.chat, { 
            text: `📌 *Contoh Penggunaan:*\n• ${usedPrefix}${command} https://www.threads.net/@username/post/...` 
        }, { quoted: m });
    }

    const targetUrl = text.trim().split(/\s+/)[0];

    if (!targetUrl || !/(https?:\/\/)?(www\.)?threads\.(net|com)\/.+/i.test(targetUrl)) {
        return sock.sendMessage(m.chat, { text: '❌ Berikan URL Threads yang valid!' }, { quoted: m });
    }

    try {
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const result = await threadsmate(targetUrl);
        if (!result.status) {
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, { text: '❌ Gagal mengambil data dari Threads.' }, { quoted: m });
        }

        const meta = result.metadata;
        const statsText = `*THREADS DOWNLOADER*

📌 *Author:* ${meta.author} (@${meta.username})
📝 *Caption:* ${meta.title}

📦 *Media:* ${result.total.video} Video, ${result.total.images} Foto`.trim();

        // 1. Jika berupa Carousel Foto / Campuran (Multiple Media)
        if (result.images.length > 0) {
            await sock.sendMessage(m.chat, { text: statsText }, { quoted: m });

            for (let img of result.images) {
                const imgBuf = await getBuffer(img.url);
                if (imgBuf) {
                    await sock.sendMessage(m.chat, { image: imgBuf }, { quoted: m });
                }
            }
        }

        // 2. Jika berupa Video (Tunggal / Carousel)
        if (result.video.length > 0) {
            for (let i = 0; i < result.video.length; i++) {
                const vid = result.video[i];
                const vidBuf = await getBuffer(vid.url);
                if (!vidBuf) continue;

                const caption = result.video.length === 1 ? statsText : `🎥 Video (${i + 1}/${result.video.length})\n\n${statsText}`;

                // Dikirim sebagai video standar agar tombol "Diteruskan" (Forward) aktif di WhatsApp
                const sentMsg = await sock.sendMessage(m.chat, {
                    video: vidBuf,
                    caption: caption
                }, { quoted: m });

                // Jika ada tombol interaktif internal bot untuk opsi tambahan
                if (typeof sock.sendButtons === 'function' && result.audio.length > 0) {
                    try {
                        await sock.sendButtons(m.chat, {
                            text: '🎵 Postingan ini memiliki audio terlampir.',
                            footer: `Threads Downloader • ${global.namaBot || 'Bot'}`,
                            buttons: [
                                { id: `${usedPrefix}${command} ${targetUrl}`, text: '🎵 Download Audio' }
                            ]
                        }, { quoted: sentMsg });
                    } catch (_) {}
                }
            }
        }

        // 3. Jika hanya Audio saja
        if (result.audio.length > 0 && result.video.length === 0 && result.images.length === 0) {
            for (let aud of result.audio) {
                const audBuf = await getBuffer(aud.url);
                if (audBuf) {
                    await sock.sendMessage(m.chat, {
                        audio: audBuf,
                        mimetype: 'audio/mpeg',
                        fileName: `Threads_Audio_${aud.id}.mp3`
                    }, { quoted: m });
                }
            }
        }

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[THREADS DOWNLOADER ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return sock.sendMessage(m.chat, { text: `❌ Terjadi kesalahan:\n${error.message}` }, { quoted: m });
    }
};

handler.help = ['threads <url>'];
handler.tags = ['downloader'];
handler.command = ['threads','thdl'];

export default handler;