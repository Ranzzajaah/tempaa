/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'
import { searchApkPure } from '../../scrape/apkpure.js'

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'

function extractPackageName(url) {
  if (!url) return null
  const playMatch = url.match(/[?&]id=([a-zA-Z0-9._]+)/i)
  if (playMatch) return playMatch[1]
  const cleanUrl = url.split('?')[0].replace(/\/+$/, '')
  const parts = cleanUrl.split('/')
  const lastPart = parts[parts.length - 1]
  return lastPart && lastPart.includes('.') ? lastPart : null
}

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : ''
	const rawInput = (text || quotedText || '').trim()
	const urlMatch = rawInput.match(/https?:\/\/[^\s]+/i)
	const targetInput = urlMatch ? urlMatch[0] : rawInput

	if (!targetInput) {
		return reply(`*APKPure Direct Downloader*\n\nContoh:\n${usedPrefix}${command} com.whatsapp\n${usedPrefix}${command} https://apkpure.com/id/whatsapp-messenger/com.whatsapp\n\nAtau reply pesan yang berisi nama package / link aplikasi!`)
	}

	let packageName = null
	let title = targetInput

	if (targetInput.startsWith('http://') || targetInput.startsWith('https://')) {
		packageName = extractPackageName(targetInput)
	} else if (targetInput.includes('.')) {
		packageName = targetInput.trim()
	} else {
		reply(global.mess.wait)
		const results = await searchApkPure(targetInput).catch(() => [])
		if (results && results.length > 0) {
			packageName = results[0].packageName
			title = results[0].title
		}
	}

	if (!packageName) {
		return reply('❌ Package name aplikasi tidak valid atau tidak ditemukan.')
	}

	reply(global.mess.wait)

	try {
		const apkUrl = `https://d.apkpure.com/b/APK/${packageName}?version=latest`

		const response = await axios.get(apkUrl, {
			responseType: 'arraybuffer',
			headers: {
				'User-Agent': USER_AGENT
			},
			timeout: 60000
		})

		const buffer = Buffer.from(response.data)
		const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2)

		if (buffer.length < 1000) {
			const xapkUrl = `https://d.apkpure.com/b/XAPK/${packageName}?version=latest`
			const xapkRes = await axios.get(xapkUrl, {
				responseType: 'arraybuffer',
				headers: { 'User-Agent': USER_AGENT },
				timeout: 60000
			})
			const xbuf = Buffer.from(xapkRes.data)
			const xsizeMB = (xbuf.length / (1024 * 1024)).toFixed(2)

			return await sock.sendMessage(m.chat, {
				document: xbuf,
				mimetype: 'application/vnd.android.package-archive',
				fileName: `${packageName}.xapk`,
				caption: `📱 *APKPure Downloader (XAPK)*\n\n📌 *Package:* \`${packageName}\`\n📦 *Ukuran:* ${xsizeMB} MB`
			}, { quoted: m })
		}

		return await sock.sendMessage(m.chat, {
			document: buffer,
			mimetype: 'application/vnd.android.package-archive',
			fileName: `${packageName}.apk`,
			caption: `📱 *APKPure Downloader*\n\n📌 *Package:* \`${packageName}\`\n📦 *Ukuran:* ${sizeMB} MB`
		}, { quoted: m })

	} catch (e) {
		console.error('[APKDL ERROR]', e)
		return reply('❌ Gagal mengunduh APK. File mungkin terlalu besar untuk WhatsApp / koneksi server terputus.')
	}
}

handler.help = ['apkdl <package_name/url>']
handler.tags = ['downloader']
handler.command = ['apkdl', 'apkdownload', 'dapk']
handler.limit = true;
handler.register = true

export default handler
