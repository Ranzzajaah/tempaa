import crypto from "crypto";

const TWEET_QUERY_HASH = "tmhPpO5sDermwYmq3h034A";
const BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";

function tweetIdFromUrl(input) {
    const s = String(input || "").trim();
    if (/^\d{5,25}$/.test(s)) return s;
    const m = s.match(/(?:twitter|x)\.com\/[^/]+\/status(?:es)?\/(\d+)/i);
    return m ? m[1] : null;
}

function buildEndpoint(tweetId) {
    const variables = {
        tweetId,
        withCommunity: false,
        includePromotedContent: false,
        withVoice: false
    };
    const features = {
        creator_subscriptions_tweet_preview_api_enabled: true,
        responsive_web_edit_tweet_api_enabled: true,
        view_counts_everywhere_api_enabled: true,
        longform_notetweets_consumption_enabled: true,
        responsive_web_twitter_article_tweet_consumption_enabled: true,
        tweet_awards_web_tipping_enabled: false,
        freedom_of_speech_not_reach_fetch_enabled: true,
        standardized_nudges_misinfo: true,
        rweb_video_timestamps_enabled: true,
        longform_notetweets_rich_text_read_enabled: true,
        longform_notetweets_inline_media_enabled: true,
        responsive_web_graphql_exclude_directive_enabled: true,
        verified_phone_label_enabled: false,
        responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
        responsive_web_graphql_timeline_navigation_enabled: true,
        responsive_web_enhance_cards_enabled: false
    };
    const toggles = {
        withArticleRichContentState: true,
        withArticlePlainText: false
    };
    const qs = new URLSearchParams({
        variables: JSON.stringify(variables),
        features: JSON.stringify(features),
        fieldToggles: JSON.stringify(toggles)
    });
    return `https://api.x.com/graphql/${TWEET_QUERY_HASH}/TweetResultByRestId?${qs}`;
}

function bestMp4(variants) {
    if (!Array.isArray(variants)) return null;
    const mp4 = variants.filter(v => v.content_type === "video/mp4");
    mp4.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
    return mp4[0] || variants[0] || null;
}

function shapeMedia(rawMedia) {
    if (!Array.isArray(rawMedia)) return [];
    return rawMedia.map(m => {
        const base = {
            id: m.id_str || null,
            type: m.type,
            width: m.original_info?.width || null,
            height: m.original_info?.height || null,
            preview: m.media_url_https || null
        };
        if (m.type === "photo") {
            const u = m.media_url_https || "";
            return {
                ...base,
                mime: "image/jpeg",
                download_url: u ? `${u}?name=orig` : null
            };
        }
        if (m.type === "video" || m.type === "animated_gif") {
            const variants = m.video_info?.variants || [];
            const best = bestMp4(variants);
            return {
                ...base,
                mime: best?.content_type || "video/mp4",
                download_url: best?.url || null
            };
        }
        return { ...base, mime: "application/octet-stream", download_url: m.media_url_https || null };
    });
}

function shapeAuthor(userResult) {
    if (!userResult) return null;
    const core = userResult.core || {};
    const legacy = userResult.legacy || {};
    const avatar = userResult.avatar?.image_url || legacy.profile_image_url_https || null;
    return {
        id: userResult.rest_id || null,
        username: core.screen_name || legacy.screen_name || null,
        name: core.name || legacy.name || "",
        avatar: avatar ? avatar.replace("_normal.", "_400x400.") : null
    };
}

function shapeStats(legacy, result) {
    return {
        likes: Number(legacy?.favorite_count) || 0,
        retweets: Number(legacy?.retweet_count) || 0,
        replies: Number(legacy?.reply_count) || 0,
        views: Number(result?.views?.count) || 0
    };
}

function shapeTweet(result, requestedUrl) {
    if (!result) return null;
    const inner = result.tweet || result;
    const legacy = inner.legacy;
    if (!legacy) return null;

    const user = inner.core?.user_results?.result;
    const noteTweet = inner.note_tweet?.note_tweet_results?.result;
    const fullText = noteTweet?.text || legacy.full_text || "";

    return {
        id: inner.rest_id || result.rest_id,
        url: requestedUrl,
        text: fullText,
        author: shapeAuthor(user),
        stats: shapeStats(legacy, inner),
        media: shapeMedia(legacy.extended_entities?.media)
    };
}

async function xTweet(input) {
    const id = tweetIdFromUrl(input);
    if (!id) throw new Error("Invalid X/Twitter URL — must contain /status/<id>");

    const res = await fetch(buildEndpoint(id), {
        headers: {
            "authorization": `Bearer ${BEARER}`,
            "content-type": "application/json",
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "origin": "https://x.com",
            "referer": "https://x.com/",
            "user-agent": UA
        }
    });

    if (!res.ok) {
        const body = await res.text().catch(() => "");
        throw new Error(`X returned HTTP ${res.status}${body ? " :: " + body.slice(0, 180) : ""}`);
    }

    const data = await res.json();
    const result = data?.data?.tweetResult?.result;

    if (!result || Object.keys(result).length === 0) {
        throw new Error("Tweet not found or unavailable.");
    }
    if (result.__typename === "TweetUnavailable" || result.__typename === "TweetTombstone") {
        throw new Error("Tweet unavailable or removed.");
    }

    return shapeTweet(result, typeof input === "string" ? input : `https://x.com/i/status/${id}`);
}

async function getBuffer(url) {
    if (!url) return null;
    try {
        const res = await fetch(url);
        if (!res.ok) return null;
        const arrayBuffer = await res.arrayBuffer();
        return Buffer.from(arrayBuffer);
    } catch {
        return null;
    }
}

function formatNumber(num) {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

const handler = async (m, { sock, text, usedPrefix, command }) => {
    if (!text) {
        return sock.sendMessage(m.chat, { 
            text: `📌 *Contoh Penggunaan:*\n• ${usedPrefix}${command} https://x.com/username/status/...` 
        }, { quoted: m });
    }

    const targetUrl = text.trim().split(/\s+/)[0];
    if (!targetUrl || !/(twitter|x)\.com\/.+\/status/i.test(targetUrl)) {
        return sock.sendMessage(m.chat, { text: '❌ Berikan URL Twitter/X yang valid!' }, { quoted: m });
    }

    try {
        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const tweet = await xTweet(targetUrl);
        if (!tweet) {
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, { text: '❌ Gagal mengambil data tweet.' }, { quoted: m });
        }

        const authorName = tweet.author?.name || 'Unknown';
        const username = tweet.author?.username || 'unknown';
        const stats = tweet.stats;

        const statsText = `*TWITTER / X DOWNLOADER*

👤 *Author:* ${authorName} (@${username})
💬 *Tweet:* ${tweet.text}

📊 *Statistik:*
├ ❤️ *Likes:* ${formatNumber(stats.likes)}
├ 🔄 *Retweets:* ${formatNumber(stats.retweets)}
└ 👁️ *Views:* ${formatNumber(stats.views)}`.trim();

        if (tweet.media && tweet.media.length > 0) {
            if (tweet.media.length > 1) {
                await sock.sendMessage(m.chat, { text: statsText }, { quoted: m });
                for (let i = 0; i < tweet.media.length; i++) {
                    const med = tweet.media[i];
                    const buf = await getBuffer(med.download_url);
                    if (!buf) continue;

                    if (med.type === 'photo') {
                        await sock.sendMessage(m.chat, { image: buf }, { quoted: m });
                    } else {
                        await sock.sendMessage(m.chat, { video: buf }, { quoted: m });
                    }
                }
            } else {
                const med = tweet.media[0];
                const buf = await getBuffer(med.download_url);
                if (!buf) {
                    await sock.sendMessage(m.chat, { text: statsText }, { quoted: m });
                    return;
                }

                if (med.type === 'photo') {
                    await sock.sendMessage(m.chat, {
                        image: buf,
                        caption: statsText
                    }, { quoted: m });
                } else {
                    // Video dikirim sebagai video standar agar tombol Diteruskan (Forward) aktif
                    await sock.sendMessage(m.chat, {
                        video: buf,
                        caption: statsText
                    }, { quoted: m });
                }
            }
        } else {
            await sock.sendMessage(m.chat, { text: statsText }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[TWITTER ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return sock.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${error.message}` }, { quoted: m });
    }
};

handler.help = ['twitter <url>', 'x <url>'];
handler.tags = ['downloader'];
handler.command = ['twitter', 'x', 'xdl', 'twdl'];

export default handler;