/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import sharp from 'sharp';

function formatDuration(val) {
	if (!val || val === '-' || val === 'N/A') return '-';
	if (typeof val === 'string' && val.includes(':')) return val;
	const sec = parseInt(val, 10);
	if (isNaN(sec)) return String(val);
	const h = Math.floor(sec / 3600);
	const m = Math.floor((sec % 3600) / 60);
	const s = sec % 60;
	if (h > 0) {
		return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
	}
	return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

async function getThumbJpegBuffer(url) {
	if (!url) return null;
	try {
		const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 5000 });
		const rawBuf = Buffer.from(res.data);
		return await sharp(rawBuf)
			.resize(300, 300, { fit: 'cover' })
			.toFormat('jpeg', { quality: 75 })
			.toBuffer();
	} catch (e) {
		return null;
	}
}

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = sock || conn;
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : '';
	const rawInput = (text || quotedText || '').trim();
	const urlMatch = rawInput.match(/https?:\/\/(?:www\.)?(?:youtube\.com|youtu\.be)\/[^\s]+/i);
	const targetQuery = urlMatch ? urlMatch[0] : rawInput;

	if (!targetQuery) {
		return reply(`Masukan judul lagu yang ingin dicari atau link YouTube!\n\nContoh: \`${usedPrefix}${command} Evaluasi - Hindia\`\nAtau reply pesan yang berisi judul/link YouTube!`);
	}

	const sendReact = (emoji) => client.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {});

	if (global.mess?.wait) reply(global.mess.wait);
	await sendReact('🕒');

	try {
		const isUrl = /^https?:\/\//i.test(targetQuery);
		let targetUrl = targetQuery;
		let title = '';
		let thumbnail = '';
		let duration = '';
		let channel = '';
		let views = 'N/A';

		if (!isUrl) {
			const searchApi = global.API('kyzz', '/api/search/yts', { q: targetQuery }, 'apikey');
			const searchRes = await axios.get(searchApi, { timeout: 12000 });
			const searchData = searchRes.data;

			if (!searchData?.status || !Array.isArray(searchData?.results) || searchData.results.length === 0) {
				await sendReact('✖️');
				return reply(`Lagu *${targetQuery}* tidak ditemukan.`);
			}

			const first = searchData.results[0];
			targetUrl = first.url || `https://youtu.be/${first.id}`;
			title = first.title || '';
			thumbnail = first.thumbnails && first.thumbnails[0] ? first.thumbnails[0].url : (first.image || '');
			duration = typeof first.duration === 'object' ? (first.duration?.text || '') : String(first.duration || '');
			channel = typeof first.channel === 'object' ? (first.channel?.name || '') : String(first.channel || '');
			views = first.view_count ? Number(first.view_count).toLocaleString() : (first.views || 'N/A');
		}

		const dlApi = global.API('kyzz', '/api/download/ytmp3', { url: targetUrl }, 'apikey');
		const [dlRes, thumbBuffer] = await Promise.all([
			axios.get(dlApi, { timeout: 35000 }),
			thumbnail ? getThumbJpegBuffer(thumbnail) : Promise.resolve(null)
		]);

		const dlData = dlRes.data;
		if (!dlData?.status || !dlData?.result?.downloadUrl) {
			await sendReact('✖️');
			return reply(`Gagal mengunduh audio untuk lagu *${title || targetQuery}*.`);
		}

		const audioUrl = dlData.result.downloadUrl;
		const trackTitle = title || dlData.result.title || 'YouTube Music';
		const trackChannel = channel || 'YouTube';
		const rawDuration = duration || dlData.result.duration || 'N/A';
		const trackDuration = formatDuration(rawDuration);

		const captionText = `🎵 *${trackTitle}*\n\n» Channel : ${trackChannel}\n» Durasi : ${trackDuration}\n» Views : ${views}\n» Link : ${targetUrl}`;

		if (client && typeof client.sendButtons === 'function') {
			await client.sendButtons(m.chat, {
				location: {
					degreesLatitude: 0,
					degreesLongitude: 0,
					name: trackTitle,
					address: `Channel: ${trackChannel} • Durasi: ${trackDuration}`,
					jpegThumbnail: thumbBuffer
				},
				text: '',
				footer: captionText
			}, { quoted: m });
		} else {
			await client.sendMessage(m.chat, {
				location: {
					degreesLatitude: 0,
					degreesLongitude: 0,
					name: trackTitle,
					address: `Channel: ${trackChannel} • Durasi: ${trackDuration}`,
					jpegThumbnail: thumbBuffer
				},
				caption: captionText
			}, { quoted: m });
		}

		await client.sendMessage(m.chat, {
			audio: { url: audioUrl },
			mimetype: 'audio/mpeg',
			fileName: `${trackTitle.replace(/[\\/:*?"<>|]/g, '')}.mp3`,
			ptt: false
		}, { quoted: m });

		await sendReact('✅');
	} catch (e) {
		console.error('[PLAY ERROR]', e);
		await sendReact('✖️');
		return reply(e.message || String(e));
	}
};

handler.help = ['play <judul>'];
handler.tags = ['downloader'];
handler.command = /^(play|ytmp3|ytplay)$/i;
handler.limit = true;
handler.register = true;

export default handler;