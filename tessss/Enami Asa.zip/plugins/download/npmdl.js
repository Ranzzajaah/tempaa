import path from 'path'

const handler = async (m, { sock, text, usedPrefix, command }) => {
    if (!text) throw `Masukin url/nama package npm bro\n\nContoh: ${usedPrefix}${command} https://www.npmjs.com/package/express\nAtau: ${usedPrefix}${command} express`

    const react = (emoji) => sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } })

    await react('🕒')

    try {
        let pkg = text.trim()
        let ver = null

        if (pkg.startsWith('http')) {
            const urlPath = new URL(pkg).pathname
            pkg = urlPath.split('/package/')[1]

            if (pkg.includes('/v/')) {
                const parts = pkg.split('/v/')
                pkg = parts[0]
                ver = parts[1]
            }
        } else if (pkg.includes('@') && !pkg.startsWith('@')) {
            const parts = pkg.split('@')
            pkg = parts[0]
            ver = parts[1]
        }

        const endpoint = ver
            ? `https://registry.npmjs.org/${encodeURIComponent(pkg)}/${ver}`
            : `https://registry.npmjs.org/${encodeURIComponent(pkg)}/latest`

        const metaRes = await fetch(endpoint)
        const meta = await metaRes.json()

        if (!meta || !meta.dist || !meta.dist.tarball) {
            await react('✖️')
            throw `Package *${pkg}* gak ketemu`
        }

        const tarballUrl = meta.dist.tarball
        const fileName = path.basename(new URL(tarballUrl).pathname)

        const res = await fetch(tarballUrl)

        if (!res.ok) {
            await react('✖️')
            throw `Gagal download tarball, status ${res.status}`
        }

        const buffer = Buffer.from(await res.arrayBuffer())

        await sock.sendMessage(m.chat, {
            document: buffer,
            fileName,
            mimetype: 'application/gzip',
            caption: `📦 ${meta.name}@${meta.version}\n» Size : ${(buffer.length / 1024).toFixed(2)} KB\n» Tarball : ${tarballUrl}`
        }, { quoted: m })

        await react('✅')
    } catch (e) {
        await react('✖️')
        throw `Gagal proses package: ${e.message || e}`
    }
}

handler.help = ['npmdl <url/nama package>']
handler.tags = ['tools']
handler.command = ['npmdl', 'npmpkg']
handler.limit = true
handler.register = true

export default handler