/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { snapDouyin } from '../../scrape/snapdouyin.js';

const handler = async (m, { sock, conn, text, usedPrefix, command, reply }) => {
	const client = sock || conn || global.mainSock || global.conn;
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : '';
	const rawInput = (text || quotedText || '').trim();
	const urlMatch = rawInput.match(/https?:\/\/(?:[a-zA-Z0-9_-]+\.)?douyin\.com\/[^\s]+/i) || rawInput.match(/https?:\/\/[^\s]+/i);
	const targetUrl = urlMatch ? urlMatch[0] : rawInput;

	if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
		return reply(`🍓 ᴍᴏʜᴏɴ ᴍᴀᴀғ: ᴍᴀsᴜᴋᴋᴀɴ ʟɪɴᴋ ᴅᴏᴜʏɪɴ ʏᴀᴀ 🎀✨\n\n📌 *ᴄᴏɴᴛᴏʜ:* \`${usedPrefix + command} https://v.douyin.com/xxxx/\`\nAtau reply pesan yang berisi tautan Douyin!`);
	}

	await client.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

	try {
		const result = await snapDouyin(targetUrl);

		if (!result.video && !result.audio) {
			throw new Error('ɢᴀɢᴀʟ ᴍᴇɴɢᴜɴᴅᴜʜ ᴠɪᴅᴇᴏ ᴍᴀᴜᴘᴜɴ ᴀᴜᴅɪᴏ ᴅᴏᴜʏɪɴ.');
		}

		if (result.video) {
			const caption = `🍓 *ᴅᴏᴜʏɪɴ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ* 🎀✨\n\n` +
				`• 📌 *ᴊᴜᴅᴜʟ:* ${result.title}\n` +
				`• 📊 *ᴋᴜᴀʟɪᴛᴀs:* ${result.videoMeta?.quality || 'HD'}\n` +
				`• ⏱️ *ᴅᴜʀᴀsɪ:* ${result.duration || '-'}\n\n` +
				`✨ _sᴜᴋsᴇs ᴅɪᴜɴᴅᴜʜ ʏᴀᴀ_ 🎀`;

			await client.sendMessage(
				m.chat,
				{
					video: result.video,
					caption: caption,
					mimetype: 'video/mp4'
				},
				{ quoted: m }
			);
		}

		if (result.audio) {
			await client.sendMessage(
				m.chat,
				{
					audio: result.audio,
					mimetype: 'audio/mp4',
					ptt: false
				},
				{ quoted: m }
			);
		}

		await client.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
	} catch (e) {
		console.error('[DOUYIN ERROR]:', e);
		await client.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
		await reply(`❌ ᴛᴇʀᴊᴀᴅɪ ᴋᴇsᴀʟᴀʜᴀɴ: ${e.message || 'ɢᴀɢᴀʟ ᴍᴇɴɢᴜɴᴅᴜʜ ᴅᴏᴜʏɪɴ 🎀✨'}`);
	}
};

handler.help = ['douyin <url>'];
handler.tags = ['download'];
handler.command = ['douyin', 'douyindl', 'snapdouyin'];
handler.limit = true;

export default handler;
