/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : ''
	const rawInput = (text || quotedText || '').trim()
	const urlMatch = rawInput.match(/https?:\/\/(?:www\.)?(?:twitter\.com|x\.com)\/[^\s]+/i) || rawInput.match(/https?:\/\/[^\s]+/i)
	const targetUrl = urlMatch ? urlMatch[0] : rawInput

	if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
		return reply(`*Twitter / X Downloader*\n\nContoh:\n${usedPrefix}${command} https://x.com/user/status/123456789\nAtau reply pesan yang berisi link Twitter/X!`)
	}

	reply(global.mess.wait)

	try {
		const apiUrl = global.API('kyzz', '/api/download/twitter', { url: targetUrl }, 'apikey')
		const { data } = await axios.get(apiUrl, { timeout: 20000 }).catch(() => ({ data: null }))

		if (data && data.status && data.result) {
			const res = data.result
			const mediaUrl = res.url || res.video || res.HD || res.SD
			if (mediaUrl) {
				if (mediaUrl.includes('.mp4')) {
					return await sock.sendMessage(m.chat, { video: { url: mediaUrl }, caption: `🐦 *Twitter/X Media*\n\n${res.caption || ''}` }, { quoted: m })
				} else {
					return await sock.sendMessage(m.chat, { image: { url: mediaUrl }, caption: `🐦 *Twitter/X Media*\n\n${res.caption || ''}` }, { quoted: m })
				}
			}
		}

		return reply('❌ Gagal mengambil media dari Twitter/X.')
	} catch (e) {
		console.error('[TWITTER ERROR]', e)
		return reply('❌ Terjadi kesalahan saat mengunduh dari Twitter/X.')
	}
}

handler.help = ['twitter <url>']
handler.tags = ['downloader']
handler.command = ['twitter','twit']
handler.limit = true;
handler.register = true

export default handler
