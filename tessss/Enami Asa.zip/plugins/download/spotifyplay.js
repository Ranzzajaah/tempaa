import axios from 'axios';
import FormData from 'form-data';
import { searchSpotiDown } from '../../scrape/spotidown.js';
import { AIRich } from '../../lib/helper-bails.js';
import { uguu } from '../../lib/Uploader.js';

function escapeHtml(str = '') {
	return String(str)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#39;');
}

async function getCoverDataUri(url) {
	if (!url) return 'https://open.spotifycdn.com/cdn/images/favicon.0f31d2ea.ico';
	try {
		const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 9000 });
		const b64 = Buffer.from(res.data).toString('base64');
		const mime = res.headers['content-type'] || 'image/jpeg';
		return `data:${mime};base64,${b64}`;
	} catch (e) {
		return url;
	}
}

/**
 * Konversi audio menjadi streamable direct URL (Content-Type: audio/mpeg, tanpa header attachment)
 */
async function getStreamableAudioUrl(downloadUrl, title = 'track') {
	if (!downloadUrl) return '';
	try {
		const res = await axios.get(downloadUrl, {
			responseType: 'arraybuffer',
			timeout: 25000,
			headers: {
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
			}
		});

		const buf = Buffer.from(res.data);
		const filename = `${title.replace(/[^a-zA-Z0-9_-]/g, '_')}.mp3`;

		// Coba upload ke uguu
		try {
			const uUrl = await uguu(buf, filename);
			if (uUrl && uUrl.startsWith('http')) return uUrl.trim();
		} catch (e) {
			console.warn('[UGUU STREAM UPLOAD FAILED]', e.message);
		}

		// Fallback upload ke litterbox
		try {
			const form = new FormData();
			form.append('reqtype', 'fileupload');
			form.append('time', '24h');
			form.append('fileToUpload', buf, filename);

			const lbRes = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
				headers: form.getHeaders(),
				timeout: 20000
			});

			if (typeof lbRes.data === 'string' && lbRes.data.startsWith('http')) {
				return lbRes.data.trim();
			}
		} catch (e) {
			console.warn('[LITTERBOX STREAM UPLOAD FAILED]', e.message);
		}
	} catch (err) {
		console.warn('[STREAM CONVERSION ERROR]', err.message);
	}

	return downloadUrl;
}

function createSpotifyHtml(meta, coverSrc, streamAudioUrl) {
	const title = escapeHtml(meta.title || 'Unknown Title');
	const artist = escapeHtml(meta.artist || 'Unknown Artist');
	const album = escapeHtml(meta.album || 'Spotify Track');
	const duration = escapeHtml(meta.duration || '0:00');
	const audioUrl = streamAudioUrl || meta.download_url || '';

	return `<style>
* {
	box-sizing: border-box;
	margin: 0;
	padding: 0;
	-webkit-tap-highlight-color: transparent;
	user-select: none;
	-webkit-user-select: none;
	-webkit-touch-callout: none;
}
html, body {
	width: 100%;
	height: 100%;
	margin: 0;
	padding: 0;
	background: #09090b;
	color: #ffffff;
	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
	overflow-x: hidden;
}
.player-container {
	width: 100%;
	min-height: 100vh;
	box-sizing: border-box;
	display: flex;
	flex-direction: column;
	justify-content: space-between;
	padding: 16px 18px 20px 18px;
	background: linear-gradient(180deg, #18181c 0%, #101014 45%, #08080a 100%);
	position: relative;
	overflow: hidden;
}
.top-bar {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding-bottom: 8px;
	border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}
.brand-pill {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	background: rgba(30, 215, 96, 0.15);
	border: 1px solid rgba(30, 215, 96, 0.4);
	padding: 6px 14px;
	border-radius: 20px;
	font-size: 11px;
	font-weight: 800;
	letter-spacing: 0.8px;
	color: #1ed760;
	text-transform: uppercase;
}
.equalizer {
	display: flex;
	align-items: flex-end;
	gap: 3.5px;
	height: 20px;
}
.eq-bar {
	width: 4px;
	background: #1ed760;
	border-radius: 2px;
	animation: bounce 1.1s ease-in-out infinite alternate;
}
.eq-bar:nth-child(1) { height: 6px; animation-delay: 0.1s; }
.eq-bar:nth-child(2) { height: 18px; animation-delay: 0.4s; }
.eq-bar:nth-child(3) { height: 11px; animation-delay: 0.2s; }
.eq-bar:nth-child(4) { height: 20px; animation-delay: 0.5s; }
@keyframes bounce {
	0% { height: 4px; }
	100% { height: 20px; }
}
.paused .eq-bar {
	animation-play-state: paused;
	height: 4px;
}
.cover-section {
	display: flex;
	justify-content: center;
	align-items: center;
	margin: 8px 0;
}
.cover-wrapper {
	width: 100%;
	max-width: 290px;
	aspect-ratio: 1/1;
	border-radius: 22px;
	overflow: hidden;
	background: #181818;
	box-shadow: 0 16px 40px rgba(0, 0, 0, 0.8), 0 0 35px rgba(30, 215, 96, 0.2);
	display: flex;
	align-items: center;
	justify-content: center;
	position: relative;
	cursor: pointer;
}
.cover-img {
	width: 100%;
	height: 100%;
	object-fit: cover;
	display: block;
	border-radius: 22px;
	transition: transform 0.5s ease;
}
.cover-img.playing {
	transform: scale(1.02);
}
.cover-play-overlay {
	position: absolute;
	width: 58px;
	height: 58px;
	background: rgba(0, 0, 0, 0.6);
	backdrop-filter: blur(6px);
	border-radius: 50%;
	display: flex;
	align-items: center;
	justify-content: center;
	border: 2px solid rgba(255, 255, 255, 0.35);
	transition: opacity 0.25s ease, transform 0.25s ease;
}
.cover-wrapper.is-playing .cover-play-overlay {
	opacity: 0;
	pointer-events: none;
	transform: scale(0.75);
}
.track-info {
	display: flex;
	flex-direction: column;
	gap: 4px;
	padding: 0 4px;
}
.track-title {
	font-size: 20px;
	font-weight: 800;
	color: #ffffff;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
	letter-spacing: -0.3px;
}
.track-artist {
	font-size: 14px;
	font-weight: 600;
	color: #1ed760;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
.track-album {
	font-size: 11.5px;
	font-weight: 400;
	color: #a1a1aa;
	white-space: nowrap;
	overflow: hidden;
	text-overflow: ellipsis;
}
.status-badge {
	font-size: 11.5px;
	font-weight: 600;
	color: #1ed760;
	display: flex;
	align-items: center;
	gap: 6px;
	margin-top: 3px;
	min-height: 18px;
}
.progress-container {
	display: flex;
	flex-direction: column;
	gap: 6px;
	padding: 0 4px;
}
.progress-bar-bg {
	width: 100%;
	height: 6px;
	background: rgba(255, 255, 255, 0.18);
	border-radius: 6px;
	position: relative;
	cursor: pointer;
	overflow: hidden;
}
.progress-bar-fill {
	height: 100%;
	width: 0%;
	background: #1ed760;
	border-radius: 6px;
	transition: width 0.1s linear;
}
.time-display {
	display: flex;
	justify-content: space-between;
	font-size: 11.5px;
	color: #a1a1aa;
	font-variant-numeric: tabular-nums;
	font-weight: 600;
}
.controls {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 2px 8px;
}
.ctrl-btn {
	background: none;
	border: none;
	cursor: pointer;
	color: #ffffff;
	display: flex;
	align-items: center;
	justify-content: center;
	transition: all 0.2s ease;
	outline: none;
	padding: 8px;
	border-radius: 50%;
}
.ctrl-btn:active {
	transform: scale(0.9);
}
.play-btn {
	width: 62px;
	height: 62px;
	min-width: 62px;
	min-height: 62px;
	background: #1ed760;
	border-radius: 50%;
	color: #000000;
	box-shadow: 0 8px 25px rgba(30, 215, 96, 0.5);
	padding: 0;
	transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.play-btn:active {
	transform: scale(0.92);
}
.vol-row {
	display: flex;
	align-items: center;
	gap: 12px;
	padding: 0 8px;
}
.vol-slider {
	flex: 1;
	-webkit-appearance: none;
	appearance: none;
	height: 4px;
	background: rgba(255, 255, 255, 0.18);
	border-radius: 2px;
	outline: none;
}
.vol-slider::-webkit-slider-thumb {
	-webkit-appearance: none;
	appearance: none;
	width: 14px;
	height: 14px;
	border-radius: 50%;
	background: #1ed760;
	cursor: pointer;
}
.footer-badge {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding-top: 10px;
	border-top: 1px solid rgba(255, 255, 255, 0.08);
	font-size: 10.5px;
	color: #71717a;
}
.quality-tag {
	background: rgba(30, 215, 96, 0.15);
	color: #1ed760;
	border: 1px solid rgba(30, 215, 96, 0.3);
	padding: 3px 8px;
	border-radius: 6px;
	font-weight: 700;
}
</style>

<div class="player-container">
	<div class="top-bar">
		<div class="brand-pill">
			<svg width="16" height="16" viewBox="0 0 24 24" fill="#1ed760">
				<path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.495 17.306c-.215.352-.674.464-1.026.248-2.812-1.718-6.353-2.106-10.523-1.152-.403.092-.807-.162-.9-.564-.092-.403.162-.808.564-.901 4.568-1.044 8.503-.604 11.637 1.343.353.216.464.674.248 1.026zm1.467-3.263c-.27.44-.848.58-1.288.31-3.218-1.977-8.125-2.55-11.933-1.393-.497.15-1.025-.133-1.176-.63-.151-.497.133-1.025.63-1.176 4.354-1.321 9.775-.681 13.456 1.583.44.27.58.848.311 1.288zm.126-3.41c-3.858-2.29-10.222-2.502-13.88-1.391-.59.18-1.22-.16-1.399-.75-.179-.59.16-1.22.75-1.4 4.212-1.279 11.238-1.03 15.666 1.597.531.314.707 1.002.392 1.533-.314.531-1.002.707-1.533.392z"/>
			</svg>
			Spotify Player
		</div>
		<div class="equalizer paused" id="equalizer">
			<div class="eq-bar"></div>
			<div class="eq-bar"></div>
			<div class="eq-bar"></div>
			<div class="eq-bar"></div>
		</div>
	</div>

	<div class="cover-section">
		<div class="cover-wrapper" id="coverWrapper" title="Ketuk untuk Play/Pause">
			<img src="${coverSrc}" alt="${title}" class="cover-img" id="coverImg">
			<div class="cover-play-overlay" id="coverOverlay">
				<svg width="34" height="34" viewBox="0 0 24 24" fill="#ffffff"><path d="M8 5v14l11-7z"/></svg>
			</div>
		</div>
	</div>

	<div class="track-info">
		<div class="track-title">${title}</div>
		<div class="track-artist">${artist}</div>
		<div class="track-album">${album}</div>
		<div class="status-badge" id="statusText">▶ Ketuk tombol Play untuk memutar</div>
	</div>

	<div class="progress-container">
		<div class="progress-bar-bg" id="progressBg" title="Geser durasi">
			<div class="progress-bar-fill" id="progressFill"></div>
		</div>
		<div class="time-display">
			<span id="currentTime">0:00</span>
			<span id="totalTime">${duration}</span>
		</div>
	</div>

	<div class="controls">
		<button class="ctrl-btn" id="rewindBtn" title="Mundur 10 detik">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="#ffffff"><path d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z"/></svg>
		</button>
		<button class="ctrl-btn" id="prevBtn" title="Ulang lagu">
			<svg width="24" height="24" viewBox="0 0 24 24" fill="#ffffff"><path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/></svg>
		</button>
		<button class="ctrl-btn play-btn" id="playBtn" title="Play/Pause">
			<svg id="playIcon" width="28" height="28" viewBox="0 0 24 24" fill="#000000" style="display:block;margin:auto;"><path d="M8 5v14l11-7z"/></svg>
			<svg id="pauseIcon" width="28" height="28" viewBox="0 0 24 24" fill="#000000" style="display:none;margin:auto;"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
		</button>
		<button class="ctrl-btn" id="forwardBtn" title="Maju 10 detik">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="#ffffff"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg>
		</button>
		<button class="ctrl-btn" id="loopBtn" title="Ulangi lagu">
			<svg id="loopIcon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#b3b3b3" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
				<polyline points="17 1 21 5 17 9"></polyline>
				<path d="M3 11V9a4 4 0 0 1 4-4h14"></path>
				<polyline points="7 23 3 19 7 15"></polyline>
				<path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
			</svg>
		</button>
	</div>

	<div class="vol-row">
		<button class="ctrl-btn" id="muteBtn" title="Mute/Unmute" style="padding:4px;">
			<svg id="volIcon" width="18" height="18" viewBox="0 0 24 24" fill="#b3b3b3">
				<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
			</svg>
			<svg id="muteIcon" width="18" height="18" viewBox="0 0 24 24" fill="#ef4444" style="display:none;">
				<path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
			</svg>
		</button>
		<input type="range" class="vol-slider" id="volSlider" min="0" max="1" step="0.05" value="1" title="Volume">
	</div>

	<div class="footer-badge">
		<span class="quality-tag">HQ 320kbps</span>
		<span>spotidown.app • Hirara AI</span>
	</div>

	<audio id="audioElement" preload="auto" playsinline src="${audioUrl}"></audio>
</div>

<script>
(function() {
	const audio = document.getElementById('audioElement');
	const playBtn = document.getElementById('playBtn');
	const playIcon = document.getElementById('playIcon');
	const pauseIcon = document.getElementById('pauseIcon');
	const coverWrapper = document.getElementById('coverWrapper');
	const coverImg = document.getElementById('coverImg');
	const equalizer = document.getElementById('equalizer');
	const progressBg = document.getElementById('progressBg');
	const progressFill = document.getElementById('progressFill');
	const currentTimeEl = document.getElementById('currentTime');
	const totalTimeEl = document.getElementById('totalTime');
	const statusText = document.getElementById('statusText');
	const loopBtn = document.getElementById('loopBtn');
	const loopIcon = document.getElementById('loopIcon');
	const rewindBtn = document.getElementById('rewindBtn');
	const forwardBtn = document.getElementById('forwardBtn');
	const prevBtn = document.getElementById('prevBtn');
	const muteBtn = document.getElementById('muteBtn');
	const volIcon = document.getElementById('volIcon');
	const muteIcon = document.getElementById('muteIcon');
	const volSlider = document.getElementById('volSlider');

	let isLooping = false;
	let lastVolume = 1;

	function formatTime(s) {
		if (isNaN(s) || s < 0) return '0:00';
		const m = Math.floor(s / 60);
		const sec = Math.floor(s % 60);
		return m + ':' + (sec < 10 ? '0' : '') + sec;
	}

	function setPlayingUI(playing) {
		if (playing) {
			playIcon.style.display = 'none';
			pauseIcon.style.display = 'block';
			coverImg.classList.add('playing');
			coverWrapper.classList.add('is-playing');
			equalizer.classList.remove('paused');
			statusText.textContent = '▶ Sedang Memutar Musik';
			statusText.style.color = '#1ed760';
		} else {
			playIcon.style.display = 'block';
			pauseIcon.style.display = 'none';
			coverImg.classList.remove('playing');
			coverWrapper.classList.remove('is-playing');
			equalizer.classList.add('paused');
			statusText.textContent = '⏸ Musik Dijeda (Ketuk untuk Memutar)';
			statusText.style.color = '#a1a1aa';
		}
	}

	function togglePlay() {
		if (!audio) return;
		if (audio.paused) {
			statusText.textContent = '⏳ Memuat musik...';
			statusText.style.color = '#eab308';
			const p = audio.play();
			if (p !== undefined) {
				p.then(function() {
					setPlayingUI(true);
				}).catch(function(err) {
					console.error('Play error:', err);
					setPlayingUI(false);
					statusText.textContent = '⚠️ ' + (err.message || 'Ketuk lagi untuk memutar');
					statusText.style.color = '#ef4444';
				});
			}
		} else {
			audio.pause();
			setPlayingUI(false);
		}
	}

	if (playBtn) playBtn.addEventListener('click', function(e) { e.stopPropagation(); togglePlay(); });
	if (coverWrapper) coverWrapper.addEventListener('click', togglePlay);

	if (audio) {
		audio.addEventListener('play', function() { setPlayingUI(true); });
		audio.addEventListener('pause', function() { setPlayingUI(false); });

		audio.addEventListener('timeupdate', function() {
			if (!audio.duration) return;
			const pct = (audio.currentTime / audio.duration) * 100;
			progressFill.style.width = pct + '%';
			currentTimeEl.textContent = formatTime(audio.currentTime);
		});

		audio.addEventListener('loadedmetadata', function() {
			if (audio.duration && !isNaN(audio.duration)) {
				totalTimeEl.textContent = formatTime(audio.duration);
			}
		});

		audio.addEventListener('canplay', function() {
			if (statusText.textContent.includes('Memuat')) {
				statusText.textContent = '▶ Siap diputar (Ketuk Play)';
				statusText.style.color = '#1ed760';
			}
		});

		audio.addEventListener('ended', function() {
			if (!isLooping) {
				setPlayingUI(false);
				progressFill.style.width = '0%';
				currentTimeEl.textContent = '0:00';
				statusText.textContent = ' Lagu Selesai Diputar';
				statusText.style.color = '#a1a1aa';
			}
		});

		audio.addEventListener('error', function() {
			console.error('Audio load error:', audio.error);
			setPlayingUI(false);
			statusText.textContent = '❌ Format audio belum siap, coba ketuk kembali';
			statusText.style.color = '#ef4444';
		});
	}

	if (progressBg && audio) {
		progressBg.addEventListener('click', function(e) {
			const rect = progressBg.getBoundingClientRect();
			const clickX = e.clientX - rect.left;
			const ratio = Math.max(0, Math.min(1, clickX / rect.width));
			if (audio.duration) {
				audio.currentTime = ratio * audio.duration;
			}
		});
	}

	if (rewindBtn && audio) {
		rewindBtn.addEventListener('click', function(e) {
			e.stopPropagation();
			audio.currentTime = Math.max(0, audio.currentTime - 10);
		});
	}

	if (forwardBtn && audio) {
		forwardBtn.addEventListener('click', function(e) {
			e.stopPropagation();
			if (audio.duration) {
				audio.currentTime = Math.min(audio.duration, audio.currentTime + 10);
			}
		});
	}

	if (prevBtn && audio) {
		prevBtn.addEventListener('click', function(e) {
			e.stopPropagation();
			audio.currentTime = 0;
			if (audio.paused) togglePlay();
		});
	}

	if (loopBtn && audio) {
		loopBtn.addEventListener('click', function(e) {
			e.stopPropagation();
			isLooping = !isLooping;
			audio.loop = isLooping;
			if (isLooping) {
				loopIcon.setAttribute('stroke', '#1ed760');
			} else {
				loopIcon.setAttribute('stroke', '#b3b3b3');
			}
		});
	}

	if (volSlider && audio) {
		volSlider.addEventListener('input', function() {
			audio.volume = parseFloat(volSlider.value);
			if (audio.volume === 0) {
				volIcon.style.display = 'none';
				muteIcon.style.display = 'block';
			} else {
				volIcon.style.display = 'block';
				muteIcon.style.display = 'none';
			}
		});
	}

	if (muteBtn && audio) {
		muteBtn.addEventListener('click', function(e) {
			e.stopPropagation();
			if (audio.volume > 0) {
				lastVolume = audio.volume;
				audio.volume = 0;
				volSlider.value = 0;
				volIcon.style.display = 'none';
				muteIcon.style.display = 'block';
			} else {
				audio.volume = lastVolume || 1;
				volSlider.value = audio.volume;
				volIcon.style.display = 'block';
				muteIcon.style.display = 'none';
			}
		});
	}
})();
</script>`;
}

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = sock || conn;

	if (!text) {
		return reply(
			`🎧 *Spotify Music Player*\n\n` +
			`Kirimkan judul lagu atau link Spotify yang ingin diputar di HTML player.\n\n` +
			`*Contoh Penggunaan:*\n` +
			`• *${usedPrefix + command}* CHOOM BABYMONSTER\n` +
			`• *${usedPrefix + command}* Alan Walker Faded\n` +
			`• *${usedPrefix + command}* https://open.spotify.com/track/7ouMYWpwJ422jRcDASZB7P`
		);
	}

	reply(global.mess?.wait || '⌛ *Sedang memproses lagu Spotify ke dalam HTML Player...* Mohon tunggu!');

	try {
		const track = await searchSpotiDown(text.trim());

		if (!track || !track.title) {
			return reply(`❌ Lagu *"${text}"* tidak ditemukan di Spotify.`);
		}

		// Ambil gambar cover dan konversi ke data URI Base64 agar selalu tampil pasti (anti-blokir CSP/CORS)
		const coverDataUri = await getCoverDataUri(track.image);

		// Siapkan audio stream URL yang mendukung audio/mpeg murni (tanpa header Content-Disposition: attachment)
		const streamAudioUrl = await getStreamableAudioUrl(track.download_url, track.title);

		const htmlPayload = createSpotifyHtml(track, coverDataUri, streamAudioUrl);

		const trustedSources = [
			'hirara.dev',
			'api.kyzzz.xyz',
			'kyzzz.xyz',
			'kyu4me.biz.id',
			'spotidown.app',
			'rapid.spotidown.app',
			'i.scdn.co',
			'spotify.com',
			'open.spotifycdn.com',
			'uguu.se',
			'd.uguu.se',
			'n.uguu.se',
			'a.uguu.se',
			'b.uguu.se',
			'c.uguu.se',
			'litter.catbox.moe',
			'catbox.moe'
		];

		// Kirim Rich Message HTML Interaktif (Lagu diputar di dalam HTML)
		try {
			const rich = new AIRich(client);
			rich.addHtml(htmlPayload, {
				text: `🎧 Spotify Play: ${track.title} - ${track.artist}`,
				trustedSources
			});
			await rich.send(m.chat, { quoted: m });
		} catch (errRich) {
			console.warn('[SPOTIFY RICH HTML FALLBACK TO RELAY]', errRich?.message || errRich);
			await client.relayMessage(
				m.chat,
				{
					botForwardedMessage: {
						message: {
							richResponseMessage: {
								messageType: 1,
								submessages: [{ messageType: 2, messageText: `🎧 Spotify Play: ${track.title} - ${track.artist}` }],
								unifiedResponse: {
									data: Buffer.from(JSON.stringify({
										response_id: 'spotify-' + Date.now(),
										sections: [{
											view_model: {
												primitive: {
													__typename: 'GenAIaeacdsnwHtmlPrimitive',
													payload: htmlPayload,
													trusted_sources: trustedSources
												},
												__typename: 'GenAISingleLayoutViewModel'
											}
										}]
									})).toString('base64')
								}
							}
						}
					}
				},
				{}
			).catch(() => {});
		}
	} catch (e) {
		console.error('[SPOTIFY PLAY ERROR]', e);
		return reply(`❌ *Terjadi Kesalahan:* ${e?.message || 'Gagal memproses lagu Spotify.'}`);
	}
};

handler.help = ['spotifyplay <judul/link>', 'splay <judul/link>'];
handler.tags = ['downloader'];
handler.command = ['spotifyplay', 'spotiplay', 'splay', 'spotidown', 'spotidl', 'spotifydl', 'spotedown'];
handler.category = 'downloader';
handler.limit = true;
handler.register = true;

export default handler;
