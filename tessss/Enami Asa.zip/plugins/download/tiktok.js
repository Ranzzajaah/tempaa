/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'
import { prepareWAMessageMedia } from '@whiskeysockets/baileys'
import { Carousel } from '../../lib/helper-bails.js'

const formatNumber = (num) => {
	if (!num && num !== 0) return '0'
	if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M'
	if (num >= 1_000) return (num / 1_000).toFixed(1).replace(/\.0$/, '') + 'K'
	return num.toLocaleString('id-ID')
}

const handler = async (m, { sock, text, reply, usedPrefix, command }) => {
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : ''
	const rawInput = (text || quotedText || '').trim()
	const urlMatch = rawInput.match(/https?:\/\/(?:[a-zA-Z0-9_-]+\.)?(?:tiktok\.com|vt\.tiktok\.com|douyin\.com)\/[^\s]+/i) || rawInput.match(/https?:\/\/[^\s]+/i)
	const targetUrl = urlMatch ? urlMatch[0] : rawInput

	if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
		return reply(`*TikTok Downloader*\n\nContoh:\n${usedPrefix}${command} https://vt.tiktok.com/ZS67d26A7/\nAtau reply pesan yang berisi tautan TikTok!`)
	}

	reply(global.mess?.wait || '⏳ Sedang mengunduh media TikTok...')

	try {
		const apiUrl = global.API('kyzz', '/api/download/tiktok', { url: targetUrl }, 'apikey')
		const { data } = await axios.get(apiUrl, { timeout: 20000 })

		if (!data?.status || !data?.result) {
			return reply('❌ Gagal mendapatkan data dari Kyzz API. Pastikan link TikTok valid!')
		}

		const res = data.result
		const isPhoto = res.type === 'photo'
		const photos = res.media?.photos || []
		const videoData = res.media?.video
		const videoUrl = videoData?.directStreamUrl || videoData?.downloadUrl
		const videoHeaders = videoData?.headers || {}

		const authorNick = res.author?.nickname || 'Creator'
		const stats = res.stats || {}
		const title = (res.description || res.title || '').trim()

		const topComment = (Array.isArray(res.topComments) && res.topComments[0])
			? `💬 "${res.topComments[0].text.replace(/\r?\n/g, ' ')}"`
			: ''

		if (isPhoto && photos.length > 0) {
			let carouselSuccess = false
			try {
				const cardPromises = photos.map(async (photoUrl, idx) => {
					try {
						const photoRes = await axios.get(photoUrl, {
							headers: videoHeaders,
							responseType: 'arraybuffer',
							timeout: 20000
						})
						const media = await prepareWAMessageMedia(
							{ image: Buffer.from(photoRes.data) },
							{ upload: sock.waUploadToServer }
						)

						const cardLines = [
							title ? `📝 ${title}` : '',
							`👤 ${authorNick}  •  ❤️ ${formatNumber(stats.likes)}  •  💬 ${formatNumber(stats.comments)}`,
							topComment
						].filter(Boolean).join('\n\n')

						return {
							body: { text: cardLines || `Foto ${idx + 1} dari ${photos.length}` },
							footer: { text: `TikTok Slide [${idx + 1}/${photos.length}]` },
							header: {
								title: `Foto ${idx + 1}/${photos.length}`,
								hasMediaAttachment: true,
								imageMessage: media.imageMessage
							},
							nativeFlowMessage: {
								buttons: [{
									name: "cta_url",
									buttonParamsJson: JSON.stringify({
										display_text: "🔗 Buka di TikTok",
										url: targetUrl
									})
								}]
							}
						}
					} catch (errCard) {
						console.warn(`[TIKTOK CARD WARN ${idx}]:`, errCard.message)
						return null
					}
				})

				const resolvedCards = (await Promise.all(cardPromises)).filter(Boolean)

				if (resolvedCards.length > 0) {
					const carousel = new Carousel(sock)
						.setBody(`✨ *TikTok Slide* (${resolvedCards.length} Foto)`)
						.setFooter(`Geser ke samping ⏩`)

					for (const card of resolvedCards) {
						carousel.addCard(card)
					}

					await carousel.send(m.chat, { quoted: m })
					carouselSuccess = true
				}
			} catch (errCar) {
				console.error('[TIKTOK CAROUSEL ERROR]:', errCar)
			}

			if (!carouselSuccess) {
				reply(`📸 *TikTok Slide*: Mengirim ${photos.length} foto...`)
				for (let i = 0; i < photos.length; i++) {
					const photoRes = await axios.get(photos[i], {
						headers: videoHeaders,
						responseType: 'arraybuffer',
						timeout: 20000
					})
					await sock.sendMessage(m.chat, {
						image: Buffer.from(photoRes.data),
						caption: i === 0 ? (title || 'TikTok Slide') : `[ Foto ${i + 1}/${photos.length} ]`
					}, { quoted: m })
				}
			}
		} else if (videoUrl) {
			const videoRes = await axios.get(videoUrl, {
				headers: videoHeaders,
				responseType: 'arraybuffer',
				timeout: 30000
			})
			const videoCaption = [
				`✨ *TIKTOK VIDEO*`,
				title ? `📝 ${title}` : '',
				`👤 ${authorNick}  •  👁️ ${formatNumber(stats.plays)}  •  ❤️ ${formatNumber(stats.likes)}  •  💬 ${formatNumber(stats.comments)}`,
				topComment
			].filter(Boolean).join('\n\n')

			await sock.sendMessage(m.chat, {
				video: Buffer.from(videoRes.data),
				caption: videoCaption,
				fileName: `${res.id || Date.now()}.mp4`,
				mimetype: 'video/mp4'
			}, { quoted: m })
		} else {
			return reply('❌ Tidak ditemukan media video atau foto pada tautan TikTok tersebut.')
		}

		if (isPhoto && res.music?.playUrl) {
			try {
				const audioRes = await axios.get(res.music.playUrl, {
					headers: videoHeaders,
					responseType: 'arraybuffer',
					timeout: 20000
				})
				await sock.sendMessage(m.chat, {
					audio: Buffer.from(audioRes.data),
					mimetype: 'audio/mpeg',
					fileName: `${res.music.title || res.id || 'audio'}.mp3`
				}, { quoted: m })
			} catch (errAudio) {
				console.warn('[TIKTOK AUDIO SEND WARN]:', errAudio.message)
			}
		}

	} catch (e) {
		console.error('[TIKTOK KYZZ API ERROR]:', e.response?.data || e)
		return reply(`❌ Terjadi kesalahan saat mengunduh TikTok: ${e.message}`)
	}
}

handler.help = ['tiktok <url>']
handler.tags = ['downloader']
handler.command = ['tiktok', 'tt', 'ttdl', 'tiktokdl']
handler.limit = true;

handler.register = true

export default handler
