/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios'
import { searchApkPure } from '../../scrape/apkpure.js'

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
	const client = conn || sock
	const quotedText = m.quoted ? (m.quoted.text || m.quoted.caption || m.quoted.description || m.quoted.msg?.caption || m.quoted.msg?.text || '') : ''
	const rawInput = (text || quotedText || '').trim()

	if (!rawInput) {
		return reply(`*APKPure Downloader & Search*\n\n` +
			`📌 Contoh Pencarian:\n${usedPrefix}${command} WhatsApp\n\n` +
			`📌 Contoh Download Langsung (Package Name):\n${usedPrefix}apkdl com.whatsapp\n\n` +
			`Atau reply pesan yang berisi nama aplikasi/package!`)
	}

	reply(global.mess.wait)

	try {
		const results = await searchApkPure(rawInput)
		if (!results || results.length === 0) {
			return reply('❌ Aplikasi tidak ditemukan di APKPure!')
		}

		const listRows = results.slice(0, 10).map((item, index) => {
			return {
				header: `${index + 1}. ${item.title.slice(0, 20)}`,
				title: item.title,
				description: `Package: ${item.packageName}`,
				id: `${usedPrefix}apkdl ${item.packageName}`
			}
		})

		const listMessage = {
			title: '📥 Unduh Aplikasi',
			sections: [{
				title: `Hasil Pencarian: ${rawInput}`,
				rows: listRows
			}]
		}

		const nativeButtons = [
			{
				name: "single_select",
				buttonParamsJson: JSON.stringify(listMessage)
			}
		]

		if (client.relayMessage) {
			await client.relayMessage(
				m.chat,
				{
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								body: { text: `📱 *APKPURE SEARCH RESULTS*\n\nDitemukan *${results.length}* hasil untuk *"${rawInput}"*.\nSilakan pilih aplikasi dari tombol menu di bawah untuk mengunduh.` },
								footer: { text: `© Hirara AI • APKPure Downloader` },
								nativeFlowMessage: {
									buttons: nativeButtons
								}
							}
						}
					}
				},
				{ quoted: m }
			)
		} else {
			let caption = `📱 *APKPURE SEARCH RESULTS*\n\n`
			results.slice(0, 10).forEach((item, index) => {
				caption += `*${index + 1}. ${item.title}*\n`
				caption += `   📦 Package: \`${item.packageName}\`\n`
				caption += `   📥 Download: \`${usedPrefix}apkdl ${item.packageName}\`\n\n`
			})
			return reply(caption)
		}
	} catch (e) {
		console.error('[APKPURE SEARCH ERROR]', e)
		return reply('❌ Terjadi kesalahan saat mencari aplikasi di APKPure.')
	}
}

handler.help = ['apkpure <nama_aplikasi>']
handler.tags = ['downloader']
handler.command = ['apkpure', 'apksearch', 'apk']
handler.limit = true;
handler.register = true

export default handler
