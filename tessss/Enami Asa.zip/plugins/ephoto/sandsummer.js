/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { ephoto } from '../../lib/ephoto.js';

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	if (!text) return reply(`Masukkan teks!\nContoh: *${usedPrefix}${command}* Hirara AI`);
	await global.react(sock, m, 'loading');
	try {
		const { buffer } = await ephoto('https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html', text);
		await sock.sendMessage(m.chat, {
			image: buffer,
			caption: `✅ *SANDSUMMER Text*\n📝 ${text}`,
		}, { quoted: m, messageId: global.customId() });
		await global.react(sock, m, 'success');
	} catch (e) {
		console.error('[EPHOTO:sandsummer]', e?.message || e);
		await global.react(sock, m, 'error');
		reply(`Gagal generate *sandsummer*.\nReason: ${e?.message || 'Error occurred'}`);
	}
};

handler.command = ['sandsummer'];
handler.limit = true;
handler.category = 'ephoto';
handler.description = 'sandsummer text effect';

handler.register = true;

export default handler;
