const API_BASE_URL = 'https://zelapi.eu.cc/api/v1/premium';
const API_KEY = 'zelapi-ru2eziuyrh02ju'; // API Key Anda

/**
 * Class AmPrem - Mengelola layanan premium account
 */
class AmPrem {
  constructor(apiKey = API_KEY) {
    this.apiKey = apiKey;
    this.baseUrl = API_BASE_URL;
  }

  _getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.apiKey}`
    };
  }

  async sendVerification(email) {
    const response = await fetch(`${this.baseUrl}/send`, {
      method: 'POST',
      headers: this._getHeaders(),
      body: JSON.stringify({ email })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || `HTTP Error: ${response.status}`);
    }

    return {
      success: data.status,
      email: data.email,
      message: data.message,
      instructions: data.instructions
    };
  }

  async verifyLink(email, link) {
    const response = await fetch(`${this.baseUrl}/verif`, {
      method: 'POST',
      headers: this._getHeaders(),
      body: JSON.stringify({ email, link })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || `HTTP Error: ${response.status}`);
    }

    return {
      success: data.status,
      email: data.email,
      premium: data.premium,
      duration: data.duration,
      rawDuration: data.raw_duration,
      message: data.message
    };
  }

  async bulkSend(emails) {
    const response = await fetch(`${this.baseUrl}/bulk`, {
      method: 'POST',
      headers: this._getHeaders(),
      body: JSON.stringify({ emails })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || `HTTP Error: ${response.status}`);
    }

    return {
      success: data.status,
      mode: data.mode,
      total: data.total,
      successCount: data.success,
      failedCount: data.failed,
      results: data.results
    };
  }
}

const api = new AmPrem();

// --- WHATSAPP BOT HANDLER ---
const handler = async (m, { sock, conn, args, reply, usedPrefix, command }) => {
    const client = sock || conn;
    const subCmd = args[0]?.toLowerCase();

    // 1. Menu / Help jika tanpa argumen
    if (!subCmd || subCmd === 'help') {
        return reply(
            `📚 *AM PREM - Bantuan*\n\n` +
            `*Command Tersedia:*\n\n` +
            `1️⃣ \`${usedPrefix + command} send <email>\`\n` +
            `   Kirim link verifikasi ke email\n` +
            `   *Contoh:* \`${usedPrefix + command} send user@gmail.com\`\n\n` +
            `2️⃣ \`${usedPrefix + command} verif <email> <link>\`\n` +
            `   Verifikasi link untuk aktivasi\n` +
            `   *Contoh:* \`${usedPrefix + command} verif user@gmail.com https://...\`\n\n` +
            `3️⃣ \`${usedPrefix + command} bulk <email1> <email2> ...\`\n` +
            `   Kirim verifikasi ke banyak email\n` +
            `   *Contoh:* \`${usedPrefix + command} bulk a@gmail.com b@gmail.com\``
        );
    }

    // 2. Command: send <email>
    if (subCmd === 'send') {
        const email = args[1];
        if (!email || !email.includes('@') || !email.includes('.')) {
            return reply(`❌ Format salah atau email tidak valid!\nContoh: \`${usedPrefix + command} send user@gmail.com\``);
        }

        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        try {
            const result = await api.sendVerification(email);

            if (result.success) {
                let message = `✅ *Link Verifikasi Terkirim!*\n\n` +
                              `📧 Email: ${result.email}\n` +
                              `📝 ${result.message}\n\n` +
                              `*Instruksi:*\n` +
                              (result.instructions ? result.instructions.map((inst, i) => `${i + 1}. ${inst}`).join('\n') : '') +
                              `\n\nSetelah mendapat link, gunakan:\n` +
                              `\`${usedPrefix + command} verif ${email} <link>\``;

                await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
                return reply(message);
            } else {
                await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
                return reply(`❌ Gagal mengirim verifikasi.`);
            }
        } catch (error) {
            console.error('[AMPREM SEND ERROR]', error);
            await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            return reply(`❌ Terjadi kesalahan: ${error.message}`);
        }
    }

    // 3. Command: verif <email> <link>
    if (subCmd === 'verif') {
        const email = args[1];
        const link = args.slice(2).join(' ');

        if (!email || !link || !email.includes('@') || !link.startsWith('http')) {
            return reply(`❌ Format salah!\nContoh: \`${usedPrefix + command} verif user@gmail.com https://...\``);
        }

        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        try {
            const result = await api.verifyLink(email, link);

            if (result.success && result.premium) {
                let message = `🎉 *Premium Berhasil Diaktifkan!*\n\n` +
                              `📧 Email: ${result.email}\n` +
                              `⭐ Status: Premium ✅\n` +
                              `⏱️ Durasi: ${result.duration}\n` +
                              `📝 ${result.message}`;

                await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
                return reply(message);
            } else {
                await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
                return reply(`❌ Verifikasi gagal. Pastikan link benar dan belum expired.`);
            }
        } catch (error) {
            console.error('[AMPREM VERIF ERROR]', error);
            await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            return reply(`❌ Terjadi kesalahan saat verifikasi: ${error.message}`);
        }
    }

    // 4. Command: bulk <email1> <email2> ...
    if (subCmd === 'bulk') {
        const emails = args.slice(1);
        if (emails.length === 0) {
            return reply(`❌ Masukkan minimal 1 email!\nContoh: \`${usedPrefix + command} bulk a@gmail.com b@gmail.com\``);
        }

        const invalidEmails = emails.filter(e => !e.includes('@') || !e.includes('.'));
        if (invalidEmails.length > 0) {
            return reply(`❌ Email tidak valid: ${invalidEmails.join(', ')}`);
        }

        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        try {
            const result = await api.bulkSend(emails);

            let message = `📊 *Bulk Send Selesai!*\n\n` +
                          `📨 Total: ${result.total}\n` +
                          `✅ Berhasil: ${result.successCount}\n` +
                          `❌ Gagal: ${result.failedCount}\n\n`;

            if (result.results && result.results.length > 0) {
                message += `*Detail:*\n`;
                result.results.forEach((r, i) => {
                    const status = r.ok ? '✅' : '❌';
                    message += `${i + 1}. ${status} ${r.email}\n`;
                    if (!r.ok && r.error) message += `   ↳ ${r.error}\n`;
                });
            }

            await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
            return reply(message);
        } catch (error) {
            console.error('[AMPREM BULK ERROR]', error);
            await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
            return reply(`❌ Terjadi kesalahan saat bulk processing: ${error.message}`);
        }
    }
};

handler.help = ['amprem2 <send/verif/bulk>'];
handler.tags = ['owner'];
// Anda bisa memanggil fitur ini dengan .amprem atau .premium
handler.command = ['amprem2', 'am2'];

// Mengunci fitur ini HANYA untuk Owner Bot
handler.owner = true;

export default handler;