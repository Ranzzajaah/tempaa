/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { prepareWAMessageMedia } from '@whiskeysockets/baileys';
import fs from 'fs';

const toSmallCaps = (str) => {
  const smallCapsMap = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
    j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
    s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
  };
  return String(str).toLowerCase().split('').map(c => smallCapsMap[c] || c).join('');
};

const handler = async (m, { conn, sock, isOwner, isPremium, getPluginStats, getMenuData, reply }) => {
	const connection = conn || sock;

	const menuData = typeof getMenuData === 'function' ? getMenuData() : {};
	const categories = Object.keys(menuData)
		.filter(cat => cat !== '-' && !cat.startsWith('-'))
		.sort((a, b) => a.localeCompare(b));

	let totalCommands = 0;
	const categoryStats = [];

	for (const cat of categories) {
		const count = Array.isArray(menuData[cat]) ? menuData[cat].length : 0;
		totalCommands += count;
		categoryStats.push({ category: cat, count });
	}

	const totalCategories = categories.length;

	let caption = `╭─❁ *${toSmallCaps('TOTAL FITUR BOT')}* ❁\n`;
	caption += `│ ✦ ${toSmallCaps('Total Fitur')}: *${totalCommands}*\n`;
	caption += `│ ✦ ${toSmallCaps('Total Kategori')}: *${totalCategories}*\n`;
	caption += `╰─❁\n\n`;

	caption += `╭─❁ *${toSmallCaps('DETAIL PER KATEGORI')}* ❁\n`;
	categoryStats.forEach(item => {
		caption += `│ ✦ ${toSmallCaps(item.category.toUpperCase())}: ${item.count} ${toSmallCaps('fitur')}\n`;
	});
	caption += `╰─❁`;

	const pageUrl = global.website || 'https://api.kyzzz.xyz';

	let thumbBuf = null;
	if (fs.existsSync('./src/wel-good.jpg')) {
		thumbBuf = fs.readFileSync('./src/wel-good.jpg');
	} else if (fs.existsSync('./media/menu.jpg')) {
		thumbBuf = fs.readFileSync('./media/menu.jpg');
	}

	try {
		let image = null;
		if (thumbBuf && connection?.waUploadToServer) {
			try {
				const { imageMessage } = await prepareWAMessageMedia({
					image: thumbBuf
				}, {
					upload: connection.waUploadToServer,
					mediaTypeOverride: 'thumbnail-link'
				});
				image = imageMessage;
				if (image) {
					image.width = 1280;
					image.height = 720;
				}
			} catch (_) {}
		}

		await connection.sendMessage(m.chat, {
			text: `${pageUrl}\n\n${caption}`,
			linkPreview: {
				'matched-text': pageUrl,
				title: `${global.namaBot || 'Bot'} - Total Fitur`,
				description: `${totalCommands} fitur tersedia`,
				previewType: 0,
				...(thumbBuf ? { jpegThumbnail: thumbBuf } : {}),
				...(image ? { highQualityThumbnail: image } : {}),
				linkPreviewMetadata: {
					linkMediaDuration: 0,
					socialMediaPostType: 4
				}
			}
		}, { quoted: m });
	} catch (err) {
		console.error('[TOTALFITUR ERROR]', err);
		if (thumbBuf) {
			await connection.sendMessage(m.chat, {
				image: thumbBuf,
				caption: caption
			}, { quoted: m }).catch(() => m.reply(caption));
		} else {
			await (reply || m.reply)(caption);
		}
	}
};

handler.command = ['totalfitur', 'fitur', 'ttf'];
handler.limit = true;
handler.tags = ['main'];
handler.category = 'main';
handler.description = 'Menampilkan total jumlah fitur/command yang tersedia di bot.';
handler.register = true;

export default handler;
