import fs from 'fs';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { imageToWebp, videoToWebp, writeExifImg, writeExifVid } from '../../lib/webp.js';
import { sendCustomStickerPack, classifySticker } from '../../lib/stickerpack.js';

const getMediaBuffer = async (sock, msgObj) => {
	try {
		const realMsg = msgObj.fakeObj ? msgObj.fakeObj : (msgObj.message ? msgObj : { message: msgObj.msg || msgObj, key: msgObj.key || {} });
		return await downloadMediaMessage(realMsg, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage });
	} catch (e) {
		try {
			if (typeof sock.downloadMediaMessage === 'function') {
				return await sock.downloadMediaMessage(msgObj);
			}
			if (typeof sock.downloadAndSaveMediaMessage === 'function') {
				const p = await sock.downloadAndSaveMediaMessage(msgObj);
				if (p && fs.existsSync(p)) {
					const b = fs.readFileSync(p);
					fs.unlinkSync(p);
					return b;
				}
			}
		} catch (err) {
			console.error('[GET MEDIA BUFFER ERROR]', err.message);
		}
	}
	return null;
};

const handler = async (m, { sock, command, reply, usedPrefix }) => {
	const packName = global.packname || 'Sticker Pack';
	const authorName = global.author || 'Hirara AI';

	let targetMessages = [];
	const qmsg = m.quoted ? m.quoted : m;

	if (m.quoted) {
		const qId = m.quoted.id || m.quoted.key?.id;
		const cachedAlbum = qId ? global.albumCache?.get(qId) : null;

		if (cachedAlbum && Array.isArray(cachedAlbum.messages) && cachedAlbum.messages.length > 0) {
			targetMessages = cachedAlbum.messages;
		} else {
			const qFake = m.quoted.fakeObj || {};
			const qFakeMsg = qFake.message || qFake.msg || {};
			const qMsgObj = m.quoted.message || m.quoted.msg || {};

			if (Array.isArray(m.quoted.messages) && m.quoted.messages.length > 0) {
				targetMessages = m.quoted.messages;
			} else if (Array.isArray(m.quoted.medias) && m.quoted.medias.length > 0) {
				targetMessages = m.quoted.medias;
			} else if (m.quoted.album && Array.isArray(m.quoted.album)) {
				targetMessages = m.quoted.album;
			} else if (qFakeMsg?.albumMessage) {
				const alb = qFakeMsg.albumMessage;
				targetMessages = alb.messages || alb.medias || alb.items || alb.contents || [];
			} else if (qMsgObj?.albumMessage) {
				const alb = qMsgObj.albumMessage;
				targetMessages = alb.messages || alb.medias || alb.items || alb.contents || [];
			} else if (qMsgObj?.interactiveMessage?.carouselMessage?.cards || qFakeMsg?.interactiveMessage?.carouselMessage?.cards) {
				targetMessages = qMsgObj?.interactiveMessage?.carouselMessage?.cards || qFakeMsg?.interactiveMessage?.carouselMessage?.cards;
			}
		}

		if (targetMessages.length <= 1) {
			const rawTs = m.quoted.messageTimestamp || m.quoted.msg?.messageTimestamp || 0;
			const qTs = typeof rawTs === 'number' && !isNaN(rawTs) ? rawTs : 0;
			const qSender = m.quoted.sender || m.quoted.key?.participant || m.quoted.key?.remoteJid;

			const storeMsgs = (global._recentMediaCache?.get(m.chat) || []).concat(global.db?.data?.messages?.[m.chat] || global.store?.messages?.[m.chat]?.array || []);
			if (storeMsgs.length > 0) {
				const albumCluster = storeMsgs.filter(msg => {
					const ts = msg.messageTimestamp || msg.msg?.messageTimestamp || 0;
					const sender = msg.sender || msg.key?.participant || msg.key?.remoteJid;
					const sameSender = qSender ? (sender === qSender) : true;
					const validTime = (qTs > 0 && ts > 0) ? Math.abs(ts - qTs) <= 25 : true;
					return sameSender && validTime;
				});
				if (albumCluster.length > 1) {
					targetMessages = albumCluster;
				}
			}
		}

		if (targetMessages.length === 0) {
			targetMessages = [qmsg];
		}
	} else {
		targetMessages = [m];
	}

	const validMediaList = [];
	for (const msg of targetMessages) {
		const msgBody = msg.message || msg.msg || msg;
		const imgMsg = msgBody.imageMessage || msg.imageMessage;
		const vidMsg = msgBody.videoMessage || msg.videoMessage;
		const stcMsg = msgBody.stickerMessage || msg.stickerMessage;

		const mtype = msg.mtype || (imgMsg ? 'imageMessage' : vidMsg ? 'videoMessage' : stcMsg ? 'stickerMessage' : '');
		const mime = msgBody.mimetype || msg.mimetype || imgMsg?.mimetype || vidMsg?.mimetype || (mtype === 'imageMessage' ? 'image/jpeg' : mtype === 'videoMessage' ? 'video/mp4' : (mtype === 'stickerMessage' ? 'image/webp' : ''));

		if (/image|video|sticker/.test(mime) || /imageMessage|videoMessage|stickerMessage/.test(mtype) || imgMsg || vidMsg || stcMsg) {
			validMediaList.push({ msgObj: msg, mime: mime || 'image/jpeg' });
		}
	}

	if (validMediaList.length === 0 && m.quoted) {
		const recent = (global._recentMediaCache?.get(m.chat) || []);
		if (recent.length > 0) {
			for (const msg of recent) {
				validMediaList.push({ msgObj: msg, mime: 'image/jpeg' });
			}
		}
	}

	if (validMediaList.length === 0) {
		return reply();
	}

	try {
		await global.react(sock, m, 'loading').catch(() => {});

		const stickerBuffers = [];

		for (const { msgObj, mime } of validMediaList) {
			const inner = msgObj.message || msgObj.msg || msgObj;
			if (/video/.test(mime) && (inner.seconds || msgObj.seconds || 0) > 15) {
				continue;
			}

			const buff = await getMediaBuffer(sock, msgObj);
			if (!buff || !Buffer.isBuffer(buff) || buff.length === 0) continue;

			let webpRes;
			if (/image/.test(mime)) {
				webpRes = await writeExifImg(buff, { packname: packName, author: authorName }).catch(() => null);
			} else if (/video/.test(mime)) {
				webpRes = await writeExifVid(buff, { packname: packName, author: authorName }).catch(() => null);
			} else if (/sticker|webp/.test(mime)) {
				webpRes = buff;
			}

			if (webpRes) {
				let finalWebpBuffer = null;
				if (Buffer.isBuffer(webpRes)) {
					finalWebpBuffer = webpRes;
				} else if (typeof webpRes === 'string' && fs.existsSync(webpRes)) {
					finalWebpBuffer = fs.readFileSync(webpRes);
					fs.unlinkSync(webpRes);
				}

				if (finalWebpBuffer) {
					const info = classifySticker(finalWebpBuffer, inner);
					stickerBuffers.push({
						buffer: finalWebpBuffer,
						...info
					});
				}
			}
		}

		if (stickerBuffers.length === 0) {
			await global.react(sock, m, 'error').catch(() => {});
			return reply('❌ Gagal mengonversi media menjadi stiker!');
		}

		if (stickerBuffers.length > 1) {
			await sendCustomStickerPack(sock, m.chat, stickerBuffers, {
				name: packName,
				publisher: authorName,
				quoted: m
			});
		} else {
			await sock.sendMessage(m.chat, { sticker: stickerBuffers[0].buffer }, { quoted: m });
		}

		await global.react(sock, m, 'success').catch(() => {});

	} catch (err) {
		console.error('[STICKER ERROR]', err);
		await global.react(sock, m, 'error').catch(() => {});
		reply('❌ Terjadi kesalahan saat membuat stiker!');
	}
};

handler.command = ['sticker', 'stiker', 'sgif', 's', 'stc'];
handler.register = true;

export default handler;
