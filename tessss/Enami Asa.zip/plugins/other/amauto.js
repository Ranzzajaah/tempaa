import axios from 'axios';
import * as cheerio from 'cheerio';
import https from 'https';
import crypto from 'crypto';
import { URL } from 'url';

const BASE = 'https://alight-motion-premium.site.je';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ==========================================
// FUNGSI BYPASS API (INFINITYFREE / SLOWAES)
// ==========================================
function toHex(arr) {
    return arr.map(n => (n < 16 ? '0' : '') + n.toString(16)).join('').toLowerCase();
}

function mergeCookies(oldCookie = '', setCookiesHeader = []) {
    const map = {};
    if (oldCookie) {
        oldCookie.split('; ').forEach(c => {
            const [k, ...v] = c.split('=');
            if (k) map[k] = v.join('=');
        });
    }
    if (setCookiesHeader) {
        const list = Array.isArray(setCookiesHeader) ? setCookiesHeader : [setCookiesHeader];
        list.forEach(c => {
            const [k, ...v] = c.split(';')[0].split('=');
            if (k) map[k] = v.join('=');
        });
    }
    return Object.entries(map).map(([k, v]) => `${k}=${v}`).join('; ');
}

function solveChallenge(html) {
    try {
        const aMatch = html.match(/a=toNumbers\("([a-f0-9]+)"\)/i);
        const bMatch = html.match(/b=toNumbers\("([a-f0-9]+)"\)/i);
        const cMatch = html.match(/c=toNumbers\("([a-f0-9]+)"\)/i);

        if (!aMatch || !bMatch || !cMatch) return null;

        const aHex = aMatch[1];
        const bHex = bMatch[1];
        const cHex = cMatch[1];

        if (aHex.length !== 32 || bHex.length !== 32 || cHex.length !== 32) return null;

        const key = Buffer.from(aHex, 'hex');
        const iv = Buffer.from(bHex, 'hex');
        const data = Buffer.from(cHex, 'hex');

        const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
        decipher.setAutoPadding(false);

        const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
        if (!decrypted || decrypted.length === 0) return null;

        return toHex([...decrypted]);
    } catch {
        return null;
    }
}

function isChallenge(raw) {
    return typeof raw === 'string' && (raw.includes('slowAES') || raw.includes('toNumbers'));
}

function httpRequest(method, pathStr, body = null, currentCookie = '', followRedirect = true) {
    return new Promise((resolve, reject) => {
        const url = new URL(pathStr, BASE);
        const postData = body ? JSON.stringify(body) : null;

        const options = {
            hostname: url.hostname,
            path: url.pathname + url.search,
            method,
            headers: {
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': USER_AGENT,
                'Origin': BASE,
                'Referer': BASE + '/?i=1',
                ...(currentCookie && { Cookie: currentCookie }),
                ...(postData && {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(postData),
                }),
            },
        };

        const req = https.request(options, (res) => {
            let updatedCookie = mergeCookies(currentCookie, res.headers['set-cookie']);

            if (followRedirect && [301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                return resolve(httpRequest(method, res.headers.location, body, updatedCookie, true));
            }

            let raw = '';
            res.on('data', chunk => (raw += chunk));
            res.on('end', () => {
                let parsed = raw;
                try { parsed = JSON.parse(raw); } catch {}
                resolve({ status: res.statusCode, data: parsed, raw, cookie: updatedCookie });
            });
        });

        req.on('error', reject);
        if (postData) req.write(postData);
        req.end();
    });
}

async function getBypassCookie() {
    let currentCookie = '';
    let res = await httpRequest('GET', '/?i=1', null, currentCookie);
    currentCookie = res.cookie;

    if (isChallenge(res.raw)) {
        const testValue = solveChallenge(res.raw);
        if (testValue) currentCookie = mergeCookies(currentCookie, [`__test=${testValue}`]);
    }

    res = await httpRequest('GET', '/index.php', null, currentCookie);
    currentCookie = res.cookie;

    if (isChallenge(res.raw)) {
        const testValue = solveChallenge(res.raw);
        if (testValue) currentCookie = mergeCookies(currentCookie, [`__test=${testValue}`]);
    }

    return currentCookie;
}

async function sendEceran(email, initialCookie, retry = 0) {
    let cookie = initialCookie;
    const res = await httpRequest('POST', '/index.php?action=send_eceran', { email }, cookie);
    cookie = res.cookie;

    if (isChallenge(res.raw)) {
        if (retry >= 2) return { status: false, data: res.data };
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            cookie = mergeCookies(cookie, [`__test=${testValue}`]);
            return sendEceran(email, cookie, retry + 1);
        }
    }
    return { status: true, data: res.data, cookie };
}

async function verifyEceran(email, link, initialCookie, retry = 0) {
    let cookie = initialCookie;
    const res = await httpRequest('POST', '/index.php?action=verify_eceran', { email, link }, cookie);
    cookie = res.cookie;

    if (isChallenge(res.raw)) {
        if (retry >= 2) return { status: false, data: res.data };
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            cookie = mergeCookies(cookie, [`__test=${testValue}`]);
            return verifyEceran(email, link, cookie, retry + 1);
        }
    }
    return { status: true, data: res.data, cookie };
}

// ==========================================
// FUNGSI EKSTRAK LINK ALIGHT MOTION
// ==========================================
function extractAlightLink(inbox) {
    if (!inbox?.length) return null;
    for (const msg of inbox) {
        for (const link of (msg.links || [])) {
            if (/alight|firebaseapp|oobCode|auth_action/i.test(link)) return link;
        }
        const raw = msg.rawHtml || '';
        const m = raw.match(/https:\/\/[^\s"']*(alight|firebaseapp|oobCode)[^\s"']*/i);
        if (m) return m[0].replace(/&amp;/g, '&');
    }
    return null;
}

// ==========================================
// KELAS GENERATOR EMAIL (Pola Polling V3)
// ==========================================
class GeneratorEmail {
    constructor() {
        this.api = { base: 'https://generator.email/', validate: 'uptime.php' };
        this.h = {
            'User-Agent': USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Origin': 'https://generator.email',
            'Referer': 'https://generator.email/'
        };
        this._cookie = '';
    }

    async _f(u, o, r = 5) {
        for (let i = 0, e; i < r; i++) {
            try {
                const headers = { ...this.h, ...(o.headers || {}) };
                if (this._cookie && !headers.Cookie) headers.Cookie = this._cookie;
                
                const res = await axios({
                    url: u, method: o.method || 'GET', headers,
                    data: o.body, maxRedirects: 5, timeout: 20000,
                    validateStatus: (s) => s < 400, responseType: o._t ? 'text' : 'json'
                });
                
                const sc = res.headers['set-cookie'];
                if (sc) {
                    for (const c of sc) {
                        const [pair] = c.split(';');
                        const [k] = pair.split('=');
                        const keep = this._cookie.split('; ').filter(p => p && !p.startsWith(k + '='));
                        keep.push(pair);
                        this._cookie = keep.join('; ');
                    }
                }
                return o._t ? res.data : res.data;
            } catch (err) {
                e = err.response ? String(err.response.data).slice(0, 150) : err.message;
                if (i === r - 1) throw new Error(e);
            }
        }
    }

    async _v(u, d) {
        try {
            return await this._f(this.api.base + this.api.validate, {
                method: 'POST',
                headers: { ...this.h, 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ usr: u, dmn: d })
            });
        } catch (e) { return { err: e.message }; }
    }

    async generate(domain = '') {
        this._cookie = '';
        try {
            const ck = domain ? `inbox_ctx=${encodeURIComponent(`${domain}/${Math.random().toString(36).slice(2, 10)}/`)}` : '';
            const $ = cheerio.load(await this._f(this.api.base, {
                headers: ck ? { ...this.h, Cookie: ck } : this.h, _t: 1
            }));
            const em = $('#email_ch_text').text();
            
            if (!em) return { success: false, result: 'Gagal generate email' };
            const [u, d] = em.split('@');
            await this._v(u, d);
            
            return { success: true, result: { email: em } };
        } catch (e) {
            return { success: false, result: e.message };
        }
    }

    _parseDetail($) {
        const links = [];
        $('a').each((i, el) => {
            let href = $(el).attr('href');
            if (href) {
                if (!href.startsWith('http')) {
                    try { href = new URL(href, this.api.base).href; } catch {}
                }
                links.push(href);
            }
        });
        const rawHtml = $('.mess_bodiyy').first().html() || '';
        return { rawHtml, links };
    }

    async inbox(email, maxRetries = 36, interval = 5000) {
        const [username, domain] = email.split('@');
        if (!username || !domain) return { success: false, result: 'Email invalid' };

        const inboxCtx = `${domain}/${username}/`;
        this._cookie = `inbox_ctx=${encodeURIComponent(inboxCtx)}`;

        for (let i = 1; i <= maxRetries; i++) {
            try {
                const html = await this._f(this.api.base, {
                    headers: { ...this.h, Cookie: this._cookie }, _t: 1
                });

                const numMatch = html.match(/num_mess:(\d+)/);
                const count = numMatch ? parseInt(numMatch[1]) : 0;

                if (count === 0 || html.includes('Email generator is ready')) {
                    await sleep(interval);
                    continue;
                }

                const paths = [];
                const matches1 = html.match(/loadInboxClientSide\('([^']+)'\)/g) || [];
                for (const m of matches1) {
                    const path = m.match(/loadInboxClientSide\('([^']+)'\)/)?.[1];
                    if (path && path.includes('/') && !paths.includes(path)) paths.push(path);
                }

                const hrefMatches = html.match(/href="([^"]*inbox\d+\/[^"]+)"/g) || [];
                for (const m of hrefMatches) {
                    const path = m.match(/href="([^"]+)"/)?.[1];
                    if (path && path.includes('inbox') && !paths.includes(path)) {
                        paths.push(path.replace(/^\//, ''));
                    }
                }

                if (paths.length === 0) {
                    try {
                        const inbox1Html = await this._f(this.api.base + 'inbox1/', {
                            headers: { ...this.h, Cookie: this._cookie }, _t: 1
                        });
                        const $ = cheerio.load(inbox1Html);
                        const data = this._parseDetail($);
                        if (data.links.length > 0) {
                            return { success: true, result: { email, inbox: [data] } };
                        }
                    } catch (e) {}
                    return { success: false, result: 'No paths found' };
                }

                const ib = [];
                for (const path of paths) {
                    try {
                        const detailHtml = await this._f(this.api.base + 'inbox1/', {
                            headers: {
                                ...this.h, Cookie: `inbox_ctx=${encodeURIComponent(path)}`, 'Referer': this.api.base
                            }, _t: 1
                        });
                        const $ = cheerio.load(detailHtml);
                        const data = this._parseDetail($);
                        ib.push(data);
                    } catch (err) {}
                }

                if (ib.length > 0) {
                    return { success: true, result: { email, inbox: ib } };
                }
                return { success: false, result: 'Gagal mem-parse email.' };

            } catch (err) {
                await sleep(interval);
            }
        }
        return { success: false, result: 'Timeout (Waktu tunggu habis, periksa tautan inbox Anda secara manual)' };
    }
}

// ==========================================
// ALUR UTAMA (Satu Akun)
// ==========================================
async function processFullAuto(domain = '') {
    const gen = new GeneratorEmail();
    let email = '';
    
    try {
        // 1. Dapatkan Sesi Cookie Bypass
        let currentCookie = await getBypassCookie();

        // 2. Generate Email
        const g = await gen.generate(domain);
        if (!g.success) return { success: false, msg: `Gagal membuat email: ${g.result}` };
        email = g.result.email;

        // 3. Kirim Verifikasi
        const sendStatus = await sendEceran(email, currentCookie);
        if (!sendStatus.status) return { success: false, email, msg: `Gagal mengirim undangan.\nDetail: ${JSON.stringify(sendStatus.data)}` };
        currentCookie = sendStatus.cookie;

        // 4. Cek Inbox (Maksimal nunggu ~3 menit)
        const ib = await gen.inbox(email, 36, 5000);
        if (!ib.success || !ib.result.inbox?.length) return { success: false, email, msg: `${ib.result}` };

        // 5. Ekstrak Link
        const link = extractAlightLink(ib.result.inbox);
        if (!link) return { success: false, email, msg: `Link aktivasi tidak ditemukan di dalam kotak masuk email.` };

        // 6. Verifikasi Link
        const v = await verifyEceran(email, link, currentCookie);
        const vData = v.data;

        // PERBAIKAN LOGIKA SUKSES: Membaca status = true
        if (v.status && vData && (vData.status === true || vData.success === true || vData.data)) {
            return { success: true, email: email, duration: '1 Tahun' }; // Hardcode durasi default ke 1 Tahun
        }
        
        return { success: false, email, msg: `Gagal memverifikasi akun.\nDetail: ${JSON.stringify(vData)}` };
    } catch (err) {
        return { success: false, email, msg: err.message };
    }
}

// ==========================================
// HANDLER FITUR BOT WHATSAPP
// ==========================================
const handler = async (m, { sock, conn, args, reply, usedPrefix, command }) => {
    const client = sock || conn;
    
    let count = parseInt(args[0]) || 1;
    let domain = args[1] || '';

    // Membatasi maksimal 3 akun agar bot tidak hang
    if (count > 3) {
        return reply('⚠️ *Batas Maksimal:* Anda hanya bisa membuat maksimal 3 akun sekaligus dalam satu kali perintah untuk menghindari spam/timeout pada bot.');
    }

    try {
        await client.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        
        // Pesan loading pertama kali
        let waitMsg = await client.sendMessage(m.chat, { 
            text: `⏳ *AM PREM AUTO GENERATOR*\n\n` +
                  `Sedang memproses *${count} akun*...\n` +
                  `_Mohon tunggu, proses membaca kotak masuk (inbox) bisa memakan waktu 1-3 menit per akun._` 
        }, { quoted: m });

        let results = [];
        let successCount = 0;

        for (let i = 1; i <= count; i++) {
            const res = await processFullAuto(domain);
            results.push(res);
            if (res.success) successCount++;
            
            if (i < count) await sleep(3000);
        }

        let finalTxt = `乂  *A M   P R E M   A U T O*\n\n`;
        finalTxt += `📊 *Total:* ${count} | ✅ *Sukses:* ${successCount} | ❌ *Gagal:* ${count - successCount}\n\n`;
        finalTxt += `*DETAIL AKUN:*\n`;
        finalTxt += `-----------------------------------\n`;

        results.forEach((r, idx) => {
            if (r.success) {
                finalTxt += `[${idx + 1}] ✅ *SUKSES*\n`;
                finalTxt += `📧 *Email:* ${r.email}\n`;
                finalTxt += `🔗 *Inbox:* https://generator.email/${r.email}\n`;
                finalTxt += `⏳ *Durasi:* ${r.duration}\n`;
            } else {
                finalTxt += `[${idx + 1}] ❌ *GAGAL*\n`;
                if (r.email) {
                    finalTxt += `📧 *Email:* ${r.email}\n`;
                    finalTxt += `🔗 *Inbox:* https://generator.email/${r.email}\n`;
                }
                finalTxt += `ℹ️ *Info:* ${r.msg}\n`;
            }
            finalTxt += `-----------------------------------\n`;
        });

        await client.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
        
        // MENGEDIT PESAN LANGSUNG: Mengganti teks 'waitMsg' dengan hasil akhir
        await client.sendMessage(m.chat, { text: finalTxt, edit: waitMsg.key });

    } catch (error) {
        console.error('[AM AUTO ERROR]', error);
        await client.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
        return reply(`❌ *Terjadi kesalahan sistem:*\n${error.message}`);
    }
};

handler.help = ['amauto [jumlah]'];
handler.tags = ['owner'];
handler.command = ['amauto', 'ampremauto', 'alightauto'];

export default handler;