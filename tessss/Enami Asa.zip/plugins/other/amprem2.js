import https from 'https';
import crypto from 'crypto';
import { URL } from 'url';

const BASE = 'https://alight-motion-premium.site.je';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// Map Sesi Penyimpanan Cookie & Email Per User (Masa Aktif 3 Menit)
const sessions = new Map();

function toHex(arr) {
    return arr.map(n => (n < 16 ? '0' : '') + n.toString(16)).join('').toLowerCase();
}

// Helper penggabung Cookie HTTP
function mergeCookies(oldCookie = '', setCookiesHeader = []) {
    const map = {};
    if (oldCookie) {
        oldCookie.split('; ').forEach(c => {
            const [k, ...v] = c.split('=');
            if (k) map[k] = v.join('=');
        });
    }
    if (setCookiesHeader) {
        const list = Array.isArray(setCookiesHeader) ? setCookiesHeader : [setCookiesHeader];
        list.forEach(c => {
            const [k, ...v] = c.split(';')[0].split('=');
            if (k) map[k] = v.join('=');
        });
    }
    return Object.entries(map).map(([k, v]) => `${k}=${v}`).join('; ');
}

// Decrypt Challenge InfinityFree / slowAES Mode 2 (AES-128-CBC No Padding)
function solveChallenge(html) {
    try {
        const aMatch = html.match(/a=toNumbers\("([a-f0-9]+)"\)/i);
        const bMatch = html.match(/b=toNumbers\("([a-f0-9]+)"\)/i);
        const cMatch = html.match(/c=toNumbers\("([a-f0-9]+)"\)/i);

        if (!aMatch || !bMatch || !cMatch) return null;

        const aHex = aMatch[1];
        const bHex = bMatch[1];
        const cHex = cMatch[1];

        if (aHex.length !== 32 || bHex.length !== 32 || cHex.length !== 32) return null;

        const key = Buffer.from(aHex, 'hex');
        const iv = Buffer.from(bHex, 'hex');
        const data = Buffer.from(cHex, 'hex');

        const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
        decipher.setAutoPadding(false);

        const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
        if (!decrypted || decrypted.length === 0) return null;

        return toHex([...decrypted]);
    } catch {
        return null;
    }
}

function isChallenge(raw) {
    return typeof raw === 'string' && (raw.includes('slowAES') || raw.includes('toNumbers'));
}

// HTTP Request Promise Wrapper
function httpRequest(method, pathStr, body = null, currentCookie = '', followRedirect = true) {
    return new Promise((resolve, reject) => {
        const url = new URL(pathStr, BASE);
        const postData = body ? JSON.stringify(body) : null;

        const options = {
            hostname: url.hostname,
            path: url.pathname + url.search,
            method,
            headers: {
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'User-Agent': USER_AGENT,
                'Origin': BASE,
                'Referer': BASE + '/?i=1',
                ...(currentCookie && { Cookie: currentCookie }),
                ...(postData && {
                    'Content-Type': 'application/json',
                    'Content-Length': Buffer.byteLength(postData),
                }),
            },
        };

        const req = https.request(options, (res) => {
            let updatedCookie = mergeCookies(currentCookie, res.headers['set-cookie']);

            if (followRedirect && [301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                return resolve(httpRequest(method, res.headers.location, body, updatedCookie, true));
            }

            let raw = '';
            res.on('data', chunk => (raw += chunk));
            res.on('end', () => {
                let parsed = raw;
                try { parsed = JSON.parse(raw); } catch {}
                resolve({ status: res.statusCode, data: parsed, raw, cookie: updatedCookie });
            });
        });

        req.on('error', reject);
        if (postData) req.write(postData);
        req.end();
    });
}

// Dapatkan Cookie Bypass awal
async function getBypassCookie() {
    let currentCookie = '';
    let res = await httpRequest('GET', '/?i=1', null, currentCookie);
    currentCookie = res.cookie;

    if (isChallenge(res.raw)) {
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            currentCookie = mergeCookies(currentCookie, [`__test=${testValue}`]);
        }
    }

    res = await httpRequest('GET', '/index.php', null, currentCookie);
    currentCookie = res.cookie;

    if (isChallenge(res.raw)) {
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            currentCookie = mergeCookies(currentCookie, [`__test=${testValue}`]);
        }
    }

    return currentCookie;
}

// Mengirimkan Link ke Email
async function sendEceran(email, initialCookie, retry = 0) {
    let cookie = initialCookie;
    const res = await httpRequest('POST', '/index.php?action=send_eceran', { email }, cookie);
    cookie = res.cookie;

    if (isChallenge(res.raw)) {
        if (retry >= 2) return { status: false, data: res.data };
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            cookie = mergeCookies(cookie, [`__test=${testValue}`]);
            return sendEceran(email, cookie, retry + 1);
        }
    }

    return { status: true, data: res.data, cookie };
}

// Verifikasi Link OOB dari Email
async function verifyEceran(email, link, initialCookie, retry = 0) {
    let cookie = initialCookie;
    const res = await httpRequest('POST', '/index.php?action=verify_eceran', { email, link }, cookie);
    cookie = res.cookie;

    if (isChallenge(res.raw)) {
        if (retry >= 2) return { status: false, data: res.data };
        const testValue = solveChallenge(res.raw);
        if (testValue) {
            cookie = mergeCookies(cookie, [`__test=${testValue}`]);
            return verifyEceran(email, link, cookie, retry + 1);
        }
    }

    return { status: true, data: res.data, cookie };
}

const handler = async (m, { sock, args, usedPrefix, command }) => {
    const subCmd = args[0]?.toLowerCase();

    // ─── 1. MENU UTAMA ────────────────────────────────────────────────────────
    if (!subCmd || !['send', 'verif', 'verify'].includes(subCmd)) {
        const menuText = `乂 *A L I G H T  M O T I O N  P R O*

📌 *Cara Penggunaan:*
1️⃣ \`${usedPrefix + command} send <email>\`
2️⃣ \`${usedPrefix + command} verif <link_dari_email>\`

> 💡 *Catatan:* Sesi verifikasi berlaku selama 3 menit.`.trim();

        return sock.sendMessage(m.chat, { text: menuText }, { quoted: m });
    }

    // ─── 2. SUBCOMMAND: SEND ──────────────────────────────────────────────────
    if (subCmd === 'send') {
        const targetEmail = args[1]?.trim();
        if (!targetEmail || !targetEmail.includes('@')) {
            return sock.sendMessage(m.chat, {
                text: `📌 *Format Salah!*\nMasukkan email target.\n\n*Contoh:*\n\`${usedPrefix + command} send target@gmail.com\``
            }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        try {
            const bypassCookie = await getBypassCookie();
            const sendResult = await sendEceran(targetEmail, bypassCookie);

            if (sendResult.data && (sendResult.data.status === true || sendResult.data.success === true || sendResult.data.code === 200 || typeof sendResult.data === 'object')) {
                // Simpan Sesi (Cookie + Email) Per User selama 3 Menit
                sessions.set(m.sender, {
                    email: targetEmail,
                    cookie: sendResult.cookie,
                    expires: Date.now() + (3 * 60 * 1000)
                });

                const successTxt = `✅ *LINK VERIFIKASI TERKIRIM!*

📧 *Email:* ${targetEmail}
⏱️ *Masa Aktif Sesi:* 3 Menit

📌 *Langkah Selanjutnya:*
1. Buka inbox/spam email Anda.
2. Salin link verifikasi Alight Motion.
3. Ketik perintah: \`${usedPrefix + command} verif <link>\``.trim();

                await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return sock.sendMessage(m.chat, { text: successTxt }, { quoted: m });
            } else {
                await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(m.chat, {
                    text: `❌ *Gagal Mengirim Email:*\n\`\`\`json\n${JSON.stringify(sendResult.data, null, 2)}\n\`\`\``
                }, { quoted: m });
            }
        } catch (err) {
            console.error('[ALIGHT SEND ERROR]', err);
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, { text: `❌ Terjadi kesalahan: ${err.message}` }, { quoted: m });
        }
    }

    // ─── 3. SUBCOMMAND: VERIF ─────────────────────────────────────────────────
    if (subCmd === 'verif' || subCmd === 'verify') {
        const targetLink = args.slice(1).join(' ').trim();
        if (!targetLink) {
            return sock.sendMessage(m.chat, {
                text: `📌 *Format Salah!*\nMasukkan link dari email.\n\n*Contoh:*\n\`${usedPrefix + command} verif https://alightcreative.com/...\``
            }, { quoted: m });
        }

        const userSession = sessions.get(m.sender);
        if (!userSession) {
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, {
                text: `❌ *Sesi Tidak Ditemukan!*\nAnda belum meminta link atau sistem bot baru saja di-restart.\nSilakan ketik \`${usedPrefix + command} send <email>\` terlebih dahulu.`
            }, { quoted: m });
        }

        if (Date.now() > userSession.expires) {
            sessions.delete(m.sender);
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, {
                text: `❌ *Sesi Kedaluwarsa!*\nWaktu 3 menit Anda sudah habis. Silakan lakukan \`${usedPrefix + command} send\` ulang.`
            }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        try {
            const verifyResult = await verifyEceran(userSession.email, targetLink, userSession.cookie);
            const vData = verifyResult.data;

            if (vData && (vData.status === true || vData.success === true || vData.data)) {
                let uid = vData.data?.user?.users?.[0]?.localId || vData.uid || '-';
                let isPremium = vData.data?.premium?.result?.valid ?? true;
                let expiryTime = vData.data?.premium?.result?.expiryTimeMillis;
                let expiryDate = expiryTime ? new Date(expiryTime).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) + ' WIB' : 'Permanen / Aktif';

                const resultTxt = `🎉 *VERIFIKASI ALIGHT MOTION BERHASIL!*

📧 *Email:* ${userSession.email}
🔑 *UID:* \`${uid}\`
💎 *Status Premium:* ${isPremium ? 'AKTIF ✅' : 'TIDAK AKTIF ❌'}
⏳ *Masa Aktif:* 1 Tahun`.trim();

                await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                await sock.sendMessage(m.chat, { text: resultTxt }, { quoted: m });

                // Hapus sesi setelah sukses
                sessions.delete(m.sender);
            } else {
                await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return sock.sendMessage(m.chat, {
                    text: `❌ *Verifikasi Gagal:*\n\`\`\`json\n${JSON.stringify(vData, null, 2)}\n\`\`\``
                }, { quoted: m });
            }
        } catch (err) {
            console.error('[ALIGHT VERIF ERROR]', err);
            await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return sock.sendMessage(m.chat, { text: `❌ Terjadi kesalahan saat verifikasi: ${err.message}` }, { quoted: m });
        }
    }
};

handler.help = ['am <send/verif>'];
handler.tags = ['tools'];
handler.command = ['am'];

export default handler;