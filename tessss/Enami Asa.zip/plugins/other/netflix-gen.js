import axios from 'axios';

const handler = async (m, { sock, text, usedPrefix, command }) => {
  // Berikan reaction loading saat proses berjalan
  await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  // Default ke country 'ID', tapi bisa diubah user dengan menambahkan teks (contoh: .nfgen US)
  const country = text ? text.toUpperCase().trim() : 'ID';
  const apiKey = 'zelapi-ru2eziuyrh02ju'; // API Key dari curl yang kamu berikan

  try {
    const { data } = await axios.get(`https://zelapi.eu.cc/api/v1/netflix/generate?country=$IN`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (!data.status || !data.ok) {
      await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply(`❌ Gagal membuat sesi Netflix.\n\n*Pesan Error:* ${data.error || 'Tidak diketahui'}`);
    }

    // Parsing array accountInfo dari JSON menjadi list string
    let accountDetails = '';
    if (data.accountInfo && Array.isArray(data.accountInfo)) {
      data.accountInfo.forEach(info => {
        accountDetails += `› *${info.label}:* ${info.value}\n`;
      });
    }

    // Format tanggal expired agar rapi (WIB)
    const expiredDate = new Date(data.expires).toLocaleString('id-ID', { 
      timeZone: 'Asia/Jakarta', 
      dateStyle: 'full', 
      timeStyle: 'long' 
    });

    // Susun pesan balasan yang rapi
    const caption = `*─── NETFLIX AUTO LOGIN ───*\n\n` +
      `✅ *Berhasil mendapatkan akun (Region: ${data.country})*\n\n` +
      `*🛒 INFO AKUN*\n` +
      `${accountDetails}\n` +
      `*⚙️ KONEKSI & SISTEM*\n` +
      `› *Proxy:* ${data.proxy}\n` +
      `› *Timezone:* ${data.timezone}\n` +
      `› *Expired Token:* ${expiredDate}\n\n` +
      `*🔗 LINK AUTO LOGIN*\n` +
      `🌐 *Browser:* ${data.browserLink}\n\n` +
      `📱 *Mobile:* ${data.mobileLink}\n\n` +
      `📺 *Smart TV:* ${data.tvLink}\n\n` +
      `_💳 Sisa Kuota API: ${data.quotaRemaining}_ | _Powered by ${data.creator}_`;

    // Kirim pesan dengan status diteruskan (forwarded) agar tampilan lebih bersih
    await sock.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true
      }
    }, { quoted: m });

    // Reaction sukses
    await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (error) {
    // Tangkap error jika API down atau unauthorized
    await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    const errMsg = error.response?.data?.error || error.message;
    m.reply(`❌ *Terjadi kesalahan saat memproses API!*\n\nDetail: ${errMsg}`);
  }
};

handler.help = ['netflixgen'];
handler.tags = ['tools'];
handler.command = ['netflixgacha', 'netflixgen'];
// Jika API key ini berbayar atau pribadi, set handler.owner = true agar hanya bot owner yang bisa pakai
handler.owner = true; 
handler.group = false;

export default handler;