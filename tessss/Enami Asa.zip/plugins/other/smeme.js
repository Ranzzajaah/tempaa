import fs from 'fs'
import path from 'path'
import os from 'os'
import { randomBytes } from 'crypto'
import { execFile } from 'child_process'
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import axios from 'axios'
import sharp from 'sharp'

const EMOJI_CACHE = path.join(process.cwd(), 'tmp', 'emoji-cache')
if (!fs.existsSync(EMOJI_CACHE)) fs.mkdirSync(EMOJI_CACHE, { recursive: true })

const FONT_PATH = path.join(process.cwd(), 'font', 'impact.ttf')
if (fs.existsSync(FONT_PATH)) GlobalFonts.registerFromPath(FONT_PATH, 'Impact')

function tmpFile(ext) {
  return path.join(os.tmpdir(), `smeme-${randomBytes(8).toString('hex')}.${ext}`)
}

function safeUnlink(...paths) {
  for (const p of paths) {
    try { fs.unlinkSync(p) } catch (_) {}
  }
}

function isAnimatedWebp(buffer) {
  if (!buffer || buffer.length < 16) return false
  if (buffer.toString('ascii', 0, 4) !== 'RIFF') return false
  if (buffer.toString('ascii', 8, 12) !== 'WEBP') return false
  return buffer.includes(Buffer.from('ANIM'))
}

// Injeksi EXIF Watermark
function createExif(packname, author) {
  const json = {
    'sticker-pack-id': randomBytes(16).toString('hex'),
    'sticker-pack-name': packname,
    'sticker-pack-publisher': author,
    'emojis': ['']
  }
  const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8')
  const exif = Buffer.concat([
    Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]),
    jsonBuff
  ])
  exif.writeUIntLE(jsonBuff.length, 14, 4)
  return exif
}

async function applyWatermark(inputWebpPath, outputWebpPath, packname, author) {
  const exifPath = tmpFile('exif')
  try {
    const exifBuffer = createExif(packname, author)
    fs.writeFileSync(exifPath, exifBuffer)
    await new Promise((resolve) => {
      execFile('webpmux', ['-set', 'exif', exifPath, inputWebpPath, '-o', outputWebpPath], (err) => {
        if (err) {
          fs.copyFileSync(inputWebpPath, outputWebpPath)
          resolve()
        } else {
          resolve()
        }
      })
    })
  } catch (_) {
    fs.copyFileSync(inputWebpPath, outputWebpPath)
  } finally {
    safeUnlink(exifPath)
  }
}

function emojiToFilename(emoji) {
  return [...emoji]
    .map(char => char.codePointAt(0))
    .filter(codePoint => codePoint !== 0xfe0f)
    .map(codePoint => codePoint.toString(16))
    .join('-') + '.png'
}

async function getEmojiPath(emoji) {
  const fileName = emojiToFilename(emoji)
  const localPath = path.join(EMOJI_CACHE, fileName)

  if (fs.existsSync(localPath)) return localPath

  try {
    const response = await axios.get(
      `https://cdn.jsdelivr.net/npm/emoji-datasource-apple/img/apple/64/${fileName}`,
      { responseType: 'arraybuffer', timeout: 5000 }
    )
    fs.writeFileSync(localPath, Buffer.from(response.data))
    return localPath
  } catch (_) {
    return null
  }
}

function toSegments(text) {
  const emojiRe = /\p{Emoji_Presentation}|\p{Extended_Pictographic}/gu
  const parts = []
  let last = 0

  for (const match of text.matchAll(emojiRe)) {
    if (match.index > last) parts.push({ t: 'text', v: text.slice(last, match.index) })
    parts.push({ t: 'emoji', v: match[0] })
    last = match.index + match[0].length
  }

  if (last < text.length) parts.push({ t: 'text', v: text.slice(last) })

  return parts
}

function segWidth(ctx, seg, size) {
  return seg.t === 'text' ? ctx.measureText(seg.v).width : size * 1.15
}

async function drawMemeText(ctx, segments, isTop) {
  const emojiPathMap = {}

  await Promise.all(
    segments
      .filter(seg => seg.t === 'emoji')
      .map(async seg => {
        emojiPathMap[seg.v] = await getEmojiPath(seg.v)
      })
  )

  let fontSize = 50
  ctx.font = `bold ${fontSize}px Impact, Arial`
  let totalWidth = segments.reduce((sum, seg) => sum + segWidth(ctx, seg, fontSize), 0)

  while (totalWidth > 480 && fontSize > 18) {
    fontSize -= 2
    ctx.font = `bold ${fontSize}px Impact, Arial`
    totalWidth = segments.reduce((sum, seg) => sum + segWidth(ctx, seg, fontSize), 0)
  }

  let startX = (512 - totalWidth) / 2
  let yPos = isTop ? 20 : 512 - fontSize - 30

  for (const seg of segments) {
    if (seg.t === 'text') {
      ctx.fillStyle = 'white'
      ctx.strokeStyle = 'black'
      ctx.lineWidth = Math.max(3, fontSize / 8)
      ctx.strokeText(seg.v, startX, yPos)
      ctx.fillText(seg.v, startX, yPos)
      startX += ctx.measureText(seg.v).width
    } else {
      const emojiPath = emojiPathMap[seg.v]
      if (emojiPath && fs.existsSync(emojiPath)) {
        try {
          const image = await loadImage(emojiPath)
          ctx.drawImage(image, startX, yPos + (fontSize * 0.05), fontSize, fontSize)
        } catch (_) {}
      }
      startX += fontSize * 1.15
    }
  }
}

const unwrapContainer = (msg = {}) => {
  while (true) {
    const next =
      msg?.ephemeralMessage?.message ||
      msg?.viewOnceMessage?.message ||
      msg?.viewOnceMessageV2?.message ||
      msg?.viewOnceMessageV2Extension?.message ||
      msg?.documentWithCaptionMessage?.message ||
      msg?.editedMessage?.message
    if (!next) break
    msg = next
  }
  return msg
}

// Sanitasi non-rekursif untuk mencegah circular reference & error DNS a.whatsapp.net
function cleanMediaObject(obj) {
  if (!obj || typeof obj !== 'object' || Buffer.isBuffer(obj)) return obj

  if (typeof obj.url === 'string' && obj.url.includes('a.whatsapp.net')) {
    if (obj.directPath) {
      obj.url = `https://mmg.whatsapp.net${obj.directPath}`
    } else {
      delete obj.url
    }
  }

  for (const key of ['mediaKey', 'fileSha256', 'fileEncSha256']) {
    if (obj[key] && !Buffer.isBuffer(obj[key])) {
      if (Array.isArray(obj[key]?.data)) {
        obj[key] = Buffer.from(obj[key].data)
      } else if (typeof obj[key] === 'string') {
        try { obj[key] = Buffer.from(obj[key], 'base64') } catch (_) {}
      }
    }
  }
  return obj
}

// Download media aman tanpa impor modul baileys langsung
async function fetchMediaPure(target, client) {
  // Bersihkan properti target langsung tanpa perulangan tak terbatas
  cleanMediaObject(target)
  if (target.msg) cleanMediaObject(target.msg)
  if (target.message) {
    cleanMediaObject(target.message.stickerMessage)
    cleanMediaObject(target.message.imageMessage)
    cleanMediaObject(target.message.videoMessage)
  }

  // 1. Coba download bawaan serializer
  if (typeof target.download === 'function') {
    try {
      const b = await target.download()
      if (b && Buffer.isBuffer(b) && b.length > 0) return b
    } catch (_) {}
  }

  // 2. Coba sock.downloadMediaMessage
  if (typeof client.downloadMediaMessage === 'function') {
    try {
      const b = await client.downloadMediaMessage(target)
      if (b && Buffer.isBuffer(b) && b.length > 0) return b
    } catch (_) {}

    // Fallback: Rekonstruksi WAMessage
    try {
      let rawMsg = target.msg || target.message || target
      let unwrapped = unwrapContainer(rawMsg?.message || rawMsg)
      let mtype = target.mtype || Object.keys(unwrapped || {})[0] || 'stickerMessage'
      const mediaData = cleanMediaObject(unwrapped[mtype] || unwrapped)

      const fakeMessage = {
        key: target.key || { id: target.id, remoteJid: target.chat },
        message: { [mtype]: mediaData }
      }
      const b = await client.downloadMediaMessage(fakeMessage)
      if (b && Buffer.isBuffer(b) && b.length > 0) return b
    } catch (_) {}
  }

  // 3. Fallback: sock.downloadAndSaveMediaMessage
  if (typeof client.downloadAndSaveMediaMessage === 'function') {
    try {
      const tmpSaved = await client.downloadAndSaveMediaMessage(target)
      if (tmpSaved && fs.existsSync(tmpSaved)) {
        const b = fs.readFileSync(tmpSaved)
        safeUnlink(tmpSaved)
        if (b && b.length > 0) return b
      }
    } catch (_) {}
  }

  return null
}

async function processAnimatedWebp(buffer, canvasBuffer, outputPath) {
  const meta = await sharp(buffer, { animated: true }).metadata()
  const pages = meta.pages || 1
  const delays = (meta.delay && meta.delay.length === pages) ? meta.delay : Array(pages).fill(100)

  const frameDir = path.join(os.tmpdir(), `smeme-frames-${randomBytes(6).toString('hex')}`)
  fs.mkdirSync(frameDir, { recursive: true })

  try {
    await Promise.all(
      Array.from({ length: pages }, async (_, i) => {
        const frame = await sharp(buffer, { page: i, pages: 1 })
          .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .composite([{ input: canvasBuffer, top: 0, left: 0 }])
          .png()
          .toBuffer()

        fs.writeFileSync(path.join(frameDir, `frame_${String(i).padStart(4, '0')}.png`), frame)
      })
    )

    const avgDelay = delays.reduce((a, b) => a + b, 0) / delays.length
    const fps = Math.max(1, Math.min(12, Math.round(1000 / (avgDelay || 100))))

    const encode = (quality) => new Promise((resolve, reject) => {
      const ffmpegArgs = [
        '-y',
        '-framerate', String(fps),
        '-i', path.join(frameDir, 'frame_%04d.png'),
        '-c:v', 'libwebp',
        '-lossless', '0',
        '-q:v', String(quality),
        '-compression_level', '4',
        '-loop', '0',
        '-an',
        '-vsync', 'passthrough',
        outputPath
      ]
      execFile('ffmpeg', ffmpegArgs, (err, stdout, stderr) => {
        if (err) reject(new Error(stderr || err.message))
        else resolve()
      })
    })

    await encode(50)

    if (fs.statSync(outputPath).size > 480 * 1024) {
      await encode(30)
    }
  } finally {
    fs.rmSync(frameDir, { recursive: true, force: true })
  }
}

let handler = async (m, { conn, sock, text, usedPrefix, command }) => {
  const client = conn || sock

  const sendReaction = async (emoji) => {
    if (typeof m.react === 'function') {
      return m.react(emoji).catch(() => {})
    }
    return client.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {})
  }

  if (!text) {
    throw `Format Penggunaan:\n${usedPrefix + command} <teks atas>|<teks bawah> [opsional: |packname|author]`
  }

  const isQuoted = !!m.quoted
  const target = isQuoted ? m.quoted : m

  let mime = (target.msg || target).mimetype || target.mediaType || ''
  let mtype = target.mtype || ''

  const isSticker = /webp/i.test(mime) || /sticker/i.test(mtype)
  const isVideo = /video/i.test(mime) || /video/i.test(mtype)
  const isImage = /image/i.test(mime) || /image/i.test(mtype)

  if (!isSticker && !isVideo && !isImage) {
    throw `Kirim langsung atau balas media (*foto, video, atau stiker*) dengan perintah:\n\n${usedPrefix + command} <teks atas>|<teks bawah>`
  }

  await sendReaction('🕒')

  const buffer = await fetchMediaPure(target, client)
  if (!buffer || buffer.length === 0) {
    await sendReaction('❌')
    throw 'Gagal mengunduh berkas media. Kirim ulang medianya lalu coba kembali.'
  }

  const parts = text.split('|').map(v => v?.trim() || '')
  const topRaw = parts[0] || ''
  const bottomRaw = parts[1] || ''
  const packname = parts[2] || global.packname || 'Sticker Meme'
  const author = parts[3] || global.author || 'Bot'

  const isGif = mime === 'image/gif' || target.isAnimated === true
  const isAnimWebp = isSticker && isAnimatedWebp(buffer)
  const isAnimated = isVideo || isGif || isAnimWebp

  const inputExt = isVideo ? 'mp4' : (isGif ? 'gif' : (isSticker ? 'webp' : 'jpg'))

  const inputPath = tmpFile(inputExt)
  const canvasPath = tmpFile('png')
  const rawWebpPath = tmpFile('webp')
  const finalWebpPath = tmpFile('webp')

  try {
    fs.writeFileSync(inputPath, buffer)

    const textCanvas = createCanvas(512, 512)
    const ctx = textCanvas.getContext('2d')
    ctx.textBaseline = 'top'

    if (topRaw) await drawMemeText(ctx, toSegments(topRaw.toUpperCase()), true)
    if (bottomRaw) await drawMemeText(ctx, toSegments(bottomRaw.toUpperCase()), false)

    const canvasBuffer = textCanvas.toBuffer('image/png')
    fs.writeFileSync(canvasPath, canvasBuffer)

    if (isAnimWebp) {
      await processAnimatedWebp(buffer, canvasBuffer, rawWebpPath)
    } else if (!isAnimated) {
      await sharp(buffer)
        .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .composite([{ input: canvasBuffer, top: 0, left: 0 }])
        .webp({ quality: 80 })
        .toFile(rawWebpPath)
    } else {
      const encode = ({ fps, duration, quality }) => new Promise((resolve, reject) => {
        const ffmpegArgs = [
          '-y',
          '-analyzeduration', '20M',
          '-probesize', '10M',
          '-t', String(duration),
          '-i', inputPath,
          '-i', canvasPath,
          '-filter_complex', `[0:v]scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=${fps}[base];[base][1:v]overlay=0:0[v_final]`,
          '-map', '[v_final]',
          '-c:v', 'libwebp',
          '-lossless', '0',
          '-q:v', String(quality),
          '-compression_level', '4',
          '-loop', '0',
          '-an',
          rawWebpPath
        ]
        execFile('ffmpeg', ffmpegArgs, (err, stdout, stderr) => {
          if (err) reject(new Error(stderr || err.message))
          else resolve()
        })
      })

      await encode({ fps: 10, duration: 4, quality: 50 })

      if (fs.statSync(rawWebpPath).size > 480 * 1024) {
        await encode({ fps: 8, duration: 3, quality: 30 })
      }
    }

    await applyWatermark(rawWebpPath, finalWebpPath, packname, author)

    const stickerBuffer = fs.readFileSync(finalWebpPath)
    await client.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m })
    await sendReaction('✨')

  } catch (e) {
    await sendReaction('❌')
    throw `Gagal memproses meme:\n${e.message || e}`
  } finally {
    safeUnlink(inputPath, canvasPath, rawWebpPath, finalWebpPath)
  }
}

handler.help = ['smeme <teks atas>|<teks bawah>']
handler.tags = ['sticker']
handler.command = /^(s(ticker)?meme|smemeimg|smemevid)$/i
handler.limit = true

export default handler