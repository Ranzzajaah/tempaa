import axios from 'axios';

const BASE = 'https://am.neonode.my.id';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152.0.0.0 Safari/537.36';

// Penyimpanan sesi sementara di memori
global.alightSessions = global.alightSessions || {};

async function sendLink(email) {
  try {
    const res = await axios.post(`${BASE}/api/send-link`, { email }, {
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'User-Agent': USER_AGENT,
        'Origin': BASE,
        'Referer': `${BASE}/`
      },
      timeout: 25000,
      validateStatus: () => true
    });

    if (res.status === 429) {
      return { success: false, rateLimit: true, message: 'Server terkena rate limit (429). Coba lagi beberapa saat lagi.' };
    }
    return res.data;
  } catch (err) {
    return { success: false, message: err.message };
  }
}

async function verifyLink(email, magicLink) {
  try {
    const res = await axios.post(`${BASE}/api/verify-link`, { email, magicLink }, {
      headers: {
        'Content-Type': 'application/json',
        'Accept': '*/*',
        'User-Agent': USER_AGENT,
        'Origin': BASE,
        'Referer': `${BASE}/`
      },
      timeout: 25000,
      validateStatus: () => true
    });

    if (res.status === 429) {
      return { success: false, rateLimit: true, message: 'Server terkena rate limit (429). Coba lagi beberapa saat lagi.' };
    }
    return res.data;
  } catch (err) {
    return { success: false, message: err.message };
  }
}

const handler = async (m, { sock, text, usedPrefix, command }) => {
  const sender = m.sender;

  if (!text) {
    return m.reply(
      `*─── ALIGHT MOTION PREMIUM (NEONODE) ───*\n\n` +
      `*Panduan Penggunaan:*\n\n` +
      `1️⃣ *Kirim Verifikasi:*\n` +
      `› \`${usedPrefix + command} send <email>\`\n` +
      `_Contoh:_ \`${usedPrefix + command} send target@gmail.com\`\n\n` +
      `2️⃣ *Verifikasi Link (Batas Waktu 5 Menit):*\n` +
      `› \`${usedPrefix + command} verify <magic_link>\`\n` +
      `_Contoh:_ \`${usedPrefix + command} verify https://alight-creative.firebaseapp.com/...\``
    );
  }

  const [action, ...args] = text.trim().split(' ');
  const payload = args.join(' ').trim();

  // ==================== STEP 1: SEND LINK ====================
  if (action.toLowerCase() === 'send') {
    const email = payload;
    if (!email || !email.includes('@')) {
      return m.reply(`❌ Masukkan format email yang valid.\nContoh: \`${usedPrefix + command} send user@gmail.com\``);
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const sendRes = await sendLink(email);

    if (!sendRes || !sendRes.success) {
      await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply(`❌ Gagal mengirim link:\n${sendRes?.message || 'Terjadi kesalahan pada server.'}`);
    }

    // Bersihkan timeout sebelumnya jika ada permintaan ulang
    if (global.alightSessions[sender]?.timer) {
      clearTimeout(global.alightSessions[sender].timer);
    }

    // Timer sesi otomatis selama 5 menit (300.000 ms)
    const timer = setTimeout(() => {
      if (global.alightSessions[sender]) {
        delete global.alightSessions[sender];
        sock.sendMessage(m.chat, {
          text: `⌛ *Waktu Habis!*\nSesi pendaftaran Alight Motion untuk *${email}* sudah melewati batas 5 menit. Silakan ulangi dengan \`${usedPrefix + command} send <email>\`.`
        }, { quoted: m });
      }
    }, 5 * 60 * 1000);

    // Simpan data email ke dalam sesi aktif pengguna
    global.alightSessions[sender] = {
      email,
      timer,
      createdAt: Date.now()
    };

    await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    return m.reply(
      `✅ *Link verifikasi telah dikirim!*\n\n` +
      `📧 *Email:* ${email}\n` +
      `⏳ *Masa Berlaku Sesi:* 5 Menit\n\n` +
      `Buka email kamu, salin _Magic Link_ Alight Motion, lalu kirim perintah:\n` +
      `› \`${usedPrefix + command} verify <link>\``
    );
  }

  // ==================== STEP 2: VERIFY LINK ====================
  if (action.toLowerCase() === 'verify') {
    const magicLink = payload;
    const session = global.alightSessions[sender];

    if (!session) {
      return m.reply(
        `❌ Tidak ada sesi aktif atau waktu 5 menit telah berakhir.\n` +
        `Silakan kirim ulang email kamu:\n` +
        `› \`${usedPrefix + command} send <email>\``
      );
    }

    if (!magicLink || !magicLink.includes('alight')) {
      return m.reply(`❌ Link tidak valid. Pastikan link berasal dari email Alight Motion.`);
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const verifyRes = await verifyLink(session.email, magicLink);

    if (verifyRes && verifyRes.success) {
      // Hentikan timer dan bersihkan memori sesi
      clearTimeout(session.timer);
      delete global.alightSessions[sender];

      const resData = verifyRes.data || {};
      const featuresList = (resData.features || [])
        .map(feat => `  • ${feat}`)
        .join('\n');

      await sock.sendMessage(m.chat, { react: { text: '🎉', key: m.key } });

      return m.reply(
        `🎉 *PREMIUM BERHASIL DIAKTIFKAN!*\n\n` +
        `📧 *Email:* ${resData.email || session.email}\n` +
        `📦 *Paket:* ${resData.planName || 'Alight Motion Pro'}\n` +
        `🏷️ *Tipe:* ${resData.subscriptionType || 'VIP License'}\n` +
        `📅 *Berlaku Hingga:* ${resData.validUntil || 'Permanen'}\n` +
        `🆔 *Order ID:* \`${resData.orderId || '-'}\`\n\n` +
        `✨ *Fitur Aktif:*\n${featuresList || '  • Akses Penuh Seluruh Efek Pro & Tanpa Watermark'}\n\n` +
        `_Silakan buka aplikasi Alight Motion dan login ulang akun Anda._`
      );
    } else {
      await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return m.reply(
        `❌ *Verifikasi Gagal!*\n` +
        `${verifyRes?.message || 'Link verifikasi tidak valid atau sudah kedaluwarsa.'}\n\n` +
        `Pastikan link disalin utuh dari email.`
      );
    }
  }

  return m.reply(`❌ Aksi tidak valid. Gunakan:\n• \`${usedPrefix + command} send <email>\`\n• \`${usedPrefix + command} verify <link>\``);
};

handler.help = ['am3'];
handler.tags = ['tools'];
handler.command = ['am3'];
handler.owner = false;
handler.group = false;

export default handler;