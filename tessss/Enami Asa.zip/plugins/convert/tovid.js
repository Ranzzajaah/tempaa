/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import fs from 'fs';
import os from 'os';
import path from 'path';
import BodyForm from 'form-data';
import * as cheerio from 'cheerio';

async function webp2mp4Buffer(buffer) {
	const tmpPath = path.join(os.tmpdir(), `tovid_${Date.now()}.webp`);
	try {
		fs.writeFileSync(tmpPath, buffer);
		const form = new BodyForm();
		form.append('new-image-url', '');
		form.append('new-image', fs.createReadStream(tmpPath));

		const upload = await axios({
			method: 'post',
			url: 'https://ezgif.com/webp-to-mp4',
			data: form,
			maxRedirects: 5,
			timeout: 60000,
			headers: {
				...form.getHeaders(),
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
			},
		});

		const $ = cheerio.load(upload.data);
		const file = $('input[name="file"]').attr('value');
		if (!file) throw new Error('Gagal upload ke ezgif (file kosong)');

		const form2 = new BodyForm();
		form2.append('file', file);
		form2.append('convert', 'Convert WebP to MP4!');

		const convert = await axios({
			method: 'post',
			url: 'https://ezgif.com/webp-to-mp4/' + file,
			data: form2,
			maxRedirects: 5,
			timeout: 60000,
			headers: {
				...form2.getHeaders(),
				'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
			},
		});

		const $$ = cheerio.load(convert.data);
		const src = $$('#output > p.outfile > video > source').attr('src');
		if (!src) throw new Error('Gagal ambil link hasil convert!');

		return 'https:' + src;
	} finally {
		if (fs.existsSync(tmpPath)) try { fs.unlinkSync(tmpPath); } catch (_) {}
	}
}

const handler = async (m, { sock, reply, example }) => {
	const quoted = m.quoted ? m.quoted : m;
	const mime = (quoted.msg || quoted).mimetype || '';
	if (!/webp/.test(mime)) return reply(example('reply sticker nya pastikan sticker animated!'));

	reply('⏳ Mohon tunggu, sedang mengonversi stiker ke video...');

	try {
		const mediaBuf = await quoted.download?.();
		if (!mediaBuf) throw new Error('Gagal mengunduh stiker');

		const videoUrl = await webp2mp4Buffer(mediaBuf);

		await sock.sendMessage(
			m.chat,
			{
				video: { url: videoUrl },
				caption: '*Sticker To Video Success 🍀*',
			},
			{ quoted: m }
		);
	} catch (err) {
		console.error('[TOVID ERROR]', err);
		reply('❌ Gagal mengonversi stiker. Pastikan stiker berupa stiker bergerak (animated).');
	}
};

handler.help = ['tovid', 'tovideo'];
handler.category = 'convert';
handler.tags = ['convert'];
handler.command = ['tovid', 'tovideo'];
handler.limit = true;
handler.register = true;

export default handler;
