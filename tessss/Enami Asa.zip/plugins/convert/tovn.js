/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import os from 'os';
import path from 'path';
import { exec } from 'child_process';

const handler = async (m, { sock, reply, example }) => {
	const quoted = m.quoted ? m.quoted : m;
	const mime = (quoted.msg || quoted).mimetype || '';
	if (!/audio|video/.test(mime)) return reply(example('reply ke video atau audio yang ingin dijadikan VN'));

	reply('⏳ Mohon tunggu, sedang memproses VN...');

	const tmpDir = os.tmpdir();
	const time = Date.now();
	const mediaPath = path.join(tmpDir, `vn_in_${time}`);
	const outPath = path.join(tmpDir, `vn_out_${time}.ogg`);

	try {
		const buf = await quoted.download?.();
		if (!buf) throw new Error('Gagal mengunduh media');
		fs.writeFileSync(mediaPath, buf);

		await new Promise((resolve, reject) => {
			exec(`ffmpeg -y -i "${mediaPath}" -vn -c:a libopus -b:a 64k -ac 1 -ar 48000 -map_metadata -1 "${outPath}"`, (err) => {
				if (err) return reject(err);
				resolve();
			});
		});

		const audioBuf = fs.readFileSync(outPath);
		await sock.sendMessage(
			m.chat,
			{
				audio: audioBuf,
				mimetype: 'audio/ogg; codecs=opus',
				ptt: true,
			},
			{ quoted: m }
		);
	} catch (err) {
		console.error('[TOVN ERROR]', err);
		reply('❌ Gagal mengonversi ke VN. Coba lagi nanti.');
	} finally {
		if (fs.existsSync(mediaPath)) try { fs.unlinkSync(mediaPath); } catch (_) {}
		if (fs.existsSync(outPath)) try { fs.unlinkSync(outPath); } catch (_) {}
	}
};

handler.help = ['tovn', 'toptt', 'tovoicenote'];
handler.category = 'convert';
handler.tags = ['convert'];
handler.command = ['toptt', 'tovn', 'tovoicenote'];
handler.limit = true;
handler.register = true;

export default handler;
