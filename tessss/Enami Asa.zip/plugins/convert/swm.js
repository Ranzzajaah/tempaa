/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import { downloadMediaMessage } from '@whiskeysockets/baileys';
import { addExif, writeExifImg, writeExifVid } from '../../lib/webp.js';

const getMediaBuffer = async (sock, msgObj) => {
	try {
		const realMsg = msgObj.fakeObj ? msgObj.fakeObj : (msgObj.message ? msgObj : { message: msgObj.msg || msgObj, key: msgObj.key || {} });
		return await downloadMediaMessage(realMsg, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage });
	} catch (e) {
		try {
			if (typeof sock.downloadMediaMessage === 'function') {
				return await sock.downloadMediaMessage(msgObj);
			}
			if (typeof sock.downloadAndSaveMediaMessage === 'function') {
				const p = await sock.downloadAndSaveMediaMessage(msgObj);
				if (p && fs.existsSync(p)) {
					const b = fs.readFileSync(p);
					fs.unlinkSync(p);
					return b;
				}
			}
		} catch (err) {
			console.error('[GET MEDIA BUFFER ERROR]', err.message);
		}
	}
	return null;
};

const handler = async (m, { sock, conn, text, reply, usedPrefix, command }) => {
	const client = sock || conn;

	const q = m.quoted ? m.quoted : m;
	const inner = q.message || q.msg || q;

	const mime = q.mimetype || q.mediaType || inner.mimetype || inner.imageMessage?.mimetype || inner.videoMessage?.mimetype || inner.stickerMessage?.mimetype || '';
	const mtype = q.mtype || inner.mtype || '';

	const isImage = /image/.test(mime) || mtype === 'imageMessage' || !!inner.imageMessage;
	const isVideo = /video/.test(mime) || mtype === 'videoMessage' || !!inner.videoMessage;
	const isSticker = /webp/.test(mime) || mtype === 'stickerMessage' || !!inner.stickerMessage;

	if (!isImage && !isVideo && !isSticker) {
		return reply(`Kirim atau balas gambar, video, atau stiker dengan caption:\n*${usedPrefix}${command} packname | author*`);
	}

	const seconds = inner.videoMessage?.seconds || q.seconds || inner.seconds || 0;
	if (isVideo && seconds > 15) {
		return reply('❌ Durasi video maksimal 15 detik!');
	}

	const input = (text || '').trim();
	let packname = global.packname || 'Hirara AI';
	let author = global.author || 'Kyzz';

	if (input) {
		if (input.includes('|')) {
			const split = input.split('|');
			packname = split[0].trim() || packname;
			author = split[1].trim() || '';
		} else {
			packname = input;
			author = '';
		}
	}

	try {
		await global.react?.(client, m, 'loading').catch(() => {});

		let mediaBuffer = await getMediaBuffer(client, q);

		if (!mediaBuffer || mediaBuffer.length === 0) {
			await global.react?.(client, m, 'error').catch(() => {});
			return reply('❌ Gagal mengunduh media!');
		}

		let finalSticker = null;

		if (isSticker) {
			finalSticker = await addExif(mediaBuffer, packname, author).catch(() => null);
		} else if (isImage) {
			const res = await writeExifImg(mediaBuffer, { packname, author }).catch(() => null);
			if (typeof res === 'string' && fs.existsSync(res)) {
				finalSticker = fs.readFileSync(res);
				fs.unlinkSync(res);
			} else if (Buffer.isBuffer(res)) {
				finalSticker = res;
			}
		} else if (isVideo) {
			const res = await writeExifVid(mediaBuffer, { packname, author }).catch(() => null);
			if (typeof res === 'string' && fs.existsSync(res)) {
				finalSticker = fs.readFileSync(res);
				fs.unlinkSync(res);
			} else if (Buffer.isBuffer(res)) {
				finalSticker = res;
			}
		}

		if (!finalSticker) {
			await global.react?.(client, m, 'error').catch(() => {});
			return reply('❌ Gagal mengonversi media / mengubah watermark stiker!');
		}

		await client.sendMessage(m.chat, { sticker: finalSticker }, { quoted: m });
		await global.react?.(client, m, 'success').catch(() => {});

	} catch (e) {
		console.error('[SWM ERROR]', e);
		await global.react?.(client, m, 'error').catch(() => {});
		return reply('❌ Terjadi kesalahan saat memproses stiker!');
	}
};

handler.help = ['swm <packname | author>'];
handler.tags = ['convert'];
handler.command = ['swm', 'stikerwm', 'stickerwm'];
handler.limit = true;

handler.register = true;
handler.premium = false;

export default handler;
