/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const MIME_TYPES = {
	'js': 'application/javascript',
	'html': 'text/html',
	'htm': 'text/html',
	'css': 'text/css',
	'json': 'application/json',
	'txt': 'text/plain',
	'md': 'text/markdown',
	'py': 'text/x-python',
	'php': 'application/x-httpd-php',
	'xml': 'application/xml',
	'yaml': 'text/yaml',
	'yml': 'text/yaml',
	'sh': 'application/x-sh',
	'bat': 'application/x-msdownload',
	'sql': 'application/sql',
	'rb': 'application/x-ruby',
	'pl': 'application/x-perl',
	'c': 'text/x-c',
	'cpp': 'text/x-c++',
	'java': 'text/x-java',
	'go': 'text/x-go'
};

const ALLOWED_EXTENSIONS = Object.keys(MIME_TYPES);

const getMimeType = (ext) => MIME_TYPES[ext] || 'application/octet-stream';

const handler = async (m, { conn, sock, text, args, usedPrefix, command, reply }) => {
	const client = conn || sock || global.mainSock;
	if (!args[0]) {
		return reply(`❌ Cara penggunaan:\n*${usedPrefix + command} <namafile.ext>*\n\nContoh: *${usedPrefix + command} script.js*`);
	}

	const fileName = args[0].trim();
	const ext = fileName.split('.').pop().toLowerCase();

	if (!ALLOWED_EXTENSIONS.includes(ext)) {
		return reply(`❌ Ekstensi .${ext} tidak didukung!\n\nEkstensi yang diizinkan:\n${ALLOWED_EXTENSIONS.map(e => '.' + e).join(', ')}`);
	}

	if (!/^[a-zA-Z0-9._-]+\.[a-zA-Z0-9]+$/.test(fileName)) {
		return reply('❌ Nama file tidak valid! Gunakan hanya huruf, angka, titik, strip, dan underscore.');
	}

	let messageText = '';
	if (m.quoted) {
		if (m.quoted.text) {
			messageText = m.quoted.text;
		} else {
			return reply('❌ Pesan yang di-reply tidak mengandung teks!');
		}
	} else if (text) {
		messageText = text.replace(fileName, '').trim();
	}

	if (!messageText) {
		return reply(`❌ Tidak ada konten untuk disimpan!\n\nReply pesan yang berisi teks/kode, lalu ketik:\n*${usedPrefix + command} ${fileName}*`);
	}

	const tmpDir = path.join(process.cwd(), 'tmp');
	if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

	const filePath = path.join(tmpDir, fileName);

	try {
		fs.writeFileSync(filePath, messageText, 'utf-8');
		const fileSize = fs.statSync(filePath).size;
		const fileSizeKB = (fileSize / 1024).toFixed(2);

		const fileBuffer = fs.readFileSync(filePath);
		await client.sendMessage(m.chat, {
			document: fileBuffer,
			mimetype: getMimeType(ext),
			fileName: fileName,
			caption: `📄 *${fileName}*\n📦 Ukuran: ${fileSizeKB} KB`
		}, { quoted: m });
	} catch (e) {
		console.error('[TOFILE ERROR]', e);
		return reply(global.mess?.error || '❌ Gagal menyimpan file!');
	} finally {
		try {
			if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
		} catch {}
	}
};

handler.help = ['tofile <namafile.ext>'];
handler.tags = ['convert'];
handler.command = /^(tofile|tf)$/i;
handler.limit = true;
handler.register = true;

export default handler;
