/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { downloadMediaMessage } from '@whiskeysockets/baileys'
import { addExif } from '../../lib/webp.js'

const handler = async (m, { sock, conn, text, reply, usedPrefix, command }) => {
	const client = sock || conn

	if (!m.quoted) {
		return reply(`Balas stiker dengan *${usedPrefix}${command} packname | author*`)
	}

	const q = m.quoted
	const mime = q.mimetype || q.mediaType || ''
	const isSticker = q.mtype === 'stickerMessage' || mime.includes('webp')

	if (!isSticker) {
		return reply('❌ Balas sebuah stiker!')
	}

	const input = (text || '').trim()
	let packname = global.packname || 'Hirara AI'
	let author = global.author || 'Kyzz'

	if (input) {
		if (input.includes('|')) {
			const split = input.split('|')
			packname = split[0].trim() || packname
			author = split[1].trim() || ''
		} else {
			packname = input
			author = ''
		}
	}

	try {
		let mediaBuffer = await downloadMediaMessage(
			{ message: q.message || q.msg || q, key: q.key },
			'buffer',
			{},
			{ reuploadRequest: client.updateMediaMessage }
		).catch(() => null)

		if (!mediaBuffer || mediaBuffer.length === 0) {
			if (typeof q.download === 'function') {
				mediaBuffer = await q.download()
			}
		}

		if (!mediaBuffer || mediaBuffer.length === 0) {
			return reply('❌ Gagal mengunduh stiker.')
		}

		const finalSticker = await addExif(mediaBuffer, packname, author).catch(() => null)

		if (!finalSticker) {
			return reply('❌ Gagal mengubah watermark stiker.')
		}

		await client.sendMessage(m.chat, { sticker: finalSticker }, { quoted: m })

	} catch (e) {
		console.error('[WM STICKER ERROR]', e.message)
		return reply('❌ Gagal mengubah watermark stiker.')
	}
}

handler.help = ['wm packname | author', 'take packname | author']
handler.tags = ['convert']
handler.command = ['wm', 'take', 'watermark']
handler.limit = true;

handler.register = true
handler.premium = false

export default handler
