/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import os from 'os';
import path from 'path';
import { exec } from 'child_process';

const handler = async (m, { sock, command, usedPrefix, reply }) => {
	const quoted = m.quoted || m;
	const mime = quoted.mimetype || '';

	if (!quoted) return reply('Reply sticker yang mau dikonversi!');
	if (!/webp/.test(mime)) return reply(`Balas stiker dengan caption *${usedPrefix + command}*`);

	const tmpDir = os.tmpdir();
	const time = Date.now();
	const mediaPath = path.join(tmpDir, `stk_${time}.webp`);
	const outputPath = path.join(tmpDir, `stk_${time}.png`);

	try {
		const buf = await quoted.download?.();
		if (!buf) throw new Error('Gagal mengunduh stiker');
		fs.writeFileSync(mediaPath, buf);

		await new Promise((resolve, reject) => {
			exec(`ffmpeg -y -i "${mediaPath}" "${outputPath}"`, (err) => {
				if (err) return reject(err);
				resolve();
			});
		});

		const buffer = fs.readFileSync(outputPath);
		await sock.sendMessage(m.chat, { image: buffer, caption: '*Berhasil dikonversi ke gambar!*' }, { quoted: m });
	} catch (e) {
		console.error('[TOIMAGE ERROR]', e);
		reply('❌ Gagal mengonversi stiker ke gambar!');
	} finally {
		if (fs.existsSync(mediaPath)) try { fs.unlinkSync(mediaPath); } catch (_) {}
		if (fs.existsSync(outputPath)) try { fs.unlinkSync(outputPath); } catch (_) {}
	}
};

handler.help = ['toimage', 'toimg'];
handler.category = 'convert';
handler.tags = ['convert'];
handler.command = ['toimage', 'toimg'];
handler.limit = true;
handler.register = true;

export default handler;
