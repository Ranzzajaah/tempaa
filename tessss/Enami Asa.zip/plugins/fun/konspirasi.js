/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const CONSPIRACY_FUN = [
    'Burung itu sebenarnya drone pengawas pemerintah.',
    'Kucing tidur 16 jam sehari karena merencanakan dominasi dunia.',
    'Setiap kali WiFi lambat, itu karena tetangga lagi download alam semesta paralel.',
    'Semua kaus kaki yang hilang di mesin cuci sebenarnya diculik dimensi lain.',
    'Bulan sebenarnya adalah satelit buatan raksasa yang dipakai untuk pemancar mimpi manusia.',
    'Cermin di rumah kita sebenarnya pintu ke dimensi lain yang cuma terbuka kalau kita gak lihat.'
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m) => {
    return m.reply(`👽 *TEORI KONSPIRASI RANDOM*

${pick(CONSPIRACY_FUN)}

_(murni untuk hiburan ya!)_`);
};

handler.help = ['konspirasi'];
handler.tags = ['fun'];
handler.command = ['konspirasi', 'conspiracy'];
handler.limit = true;
handler.register = true;

export default handler;
