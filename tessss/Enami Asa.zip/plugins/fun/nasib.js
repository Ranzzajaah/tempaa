/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const KONDISI = [
  'Mendadak nemu duit cepek di saku celana lama',
  'Di-chat gebetan duluan tapi cuma nanya tugas',
  'Pesanan makanan dibonusin kerupuk 2 bungkus',
  'Kena cipratan genangan air pas lagi rapi-rapinya',
  'Disapa kasir minimarket pake senyuman manis beneran',
  'Kejatuhan rezeki tak terduga dari keluarga jauh',
  'Kaki kesandung kaki meja yang padahal nggak gerak',
  'Lolos dari razia lalu lintas secara ajaib',
  'Diajak nongkrong gratis dibayarin sultan',
  'Paket belanjaan online sampai lebih cepat dari perkiraan'
];

const SARAN = [
  'Jangan lupa sedekah dan traktir kawan sebangku.',
  'Pasang muka cuek padahal hati udah berdebar.',
  'Mending tidur siang dan jangan buka sosmed mantan.',
  'Beli es teh manis jumbo buat meredakan tensi hidup.',
  'Gunakan baju warna cerah biar aura hoki makin mancar.'
];

const getCleanTag = (jid) => {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
};

const handler = async (m, { hirara, conn, sock }) => {
  const client = hirara || conn || sock || global.mainSock || global.sock;
  const senderTag = getCleanTag(m.sender);
  const hoki = Math.floor(Math.random() * 81) + 20;
  const cinta = Math.floor(Math.random() * 91) + 10;
  const rezeki = Math.floor(Math.random() * 91) + 10;

  const eventToday = KONDISI[Math.floor(Math.random() * KONDISI.length)];
  const advice = SARAN[Math.floor(Math.random() * SARAN.length)];

  const text = `🔮 *RAMALAN NASIB & AURA HARI INI* 🔮\n\n` +
    `👤 *Nama:* @${senderTag}\n\n` +
    `📊 *Statistik Keberuntungan:*\n` +
    `• 🍀 Hoki: *${hoki}%* ${hoki > 70 ? '🔥 Sangat Beruntung!' : '🌤️ Standar Saja'}\n` +
    `• 💖 Asmara: *${cinta}%* ${cinta > 75 ? '💘 Bau-bau Jadian!' : '🥀 Masih Abu-abu'}\n` +
    `• 💰 Rezeki: *${rezeki}%* ${rezeki > 70 ? '💸 Dompet Tebal!' : '🍂 Hemat Dulu Ya'}\n\n` +
    `⚡ *Kejadian Hari Ini:* \n"${eventToday}"\n\n` +
    `💡 *Saran Mbah Dukun:* \n_${advice}_`;

  return client.sendMessage(m.chat, { text, mentions: [m.sender] }, { quoted: m });
};

handler.help = ['nasib', 'cekharini'];
handler.tags = ['fun'];
handler.command = ['nasib', 'ceknasib', 'hariini'];
handler.limit = true;
handler.category = 'fun';

export default handler;
