/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const jidNum = (jid = '') => String(jid).split('@')[0].split(':')[0];

const handler = async (m, { hirara, conn }) => {
    const client = hirara || conn;
    const target = (m.mentionedJid && m.mentionedJid[0]) || (m.quoted ? m.quoted.sender : null);
    const lines = [
        'punya energi positif yang menular ke orang sekitarnya!',
        'selalu bikin orang sekitar nyaman dan tersenyum.',
        'punya potensi besar dan aura yang memikat!',
        'adalah orang hebat yang pantas dibanggakan.',
        'punya hati yang tulus dan selalu menghangatkan suasana.'
    ];
    const puji = pick(lines);
    if (target) {
        return client.sendMessage(m.chat, {
            text: `✨ @${jidNum(target)} ${puji}`,
            mentions: [target]
        }, { quoted: m });
    } else {
        return m.reply(`✨ Kamu ${puji}`);
    }
};

handler.help = ['compliment [@user]'];
handler.tags = ['fun'];
handler.command = ['compliment', 'puji'];
handler.limit = true;
handler.register = true;

export default handler;
