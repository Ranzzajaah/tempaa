/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const DATING_REASONS = [
	'Karena senyumannya bikin meleleh seharian! 😍',
	'Karena kalau ngobrol nyambung banget dari A-Z! 🗣️',
	'Karena tatapan matanya bikin salah tingkah! 😳',
	'Karena sering jajanin kopi estetik tiap weekend! ☕',
	'Karena kalau berantem langsung dikirim makanan enak! 🍕',
	'Karena humornya sefrekuensi bikin ketawa melulu! 🤣'
];

const handler = async (m, { hirara, conn, sock, text, usedPrefix }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		return client.sendMessage(m.chat, { text: `👩‍❤️‍👨 *CEK POTENSI PACARAN*\n\nTag gebetan atau ketik namanya!\nContoh: *${usedPrefix}pacarcheck @user*` }, { quoted: m });
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (m.quoted?.sender === targetJid && m.quoted?.pushName) ? m.quoted.pushName : `@${cleanTag}`;
		}
	}

	const rate = Math.floor(Math.random() * 51) + 50;
	const reason = DATING_REASONS[Math.floor(Math.random() * DATING_REASONS.length)];

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '👩‍❤️‍👨 CEK POTENSI PACARAN',
		badgeText: `💖 ${rate}% MATCH`,
		titleBg: '#ec4899',
		badgeBg: '#ffea00',
		name: cardName,
		rate,
		categoryLabel: 'Status Gebetan',
		categoryValue: rate > 75 ? 'Calon Pacar Idaman 💕' : 'Bisa Diusahakan 💓',
		descLabel: 'Alasan Cocok Pacaran',
		descValue: reason,
		footerText: 'Gunakan .tembak @user untuk jadian berpacaran!',
		barColor: '#ec4899',
		ppUrl
	}).catch(() => null);

	const replyText = `👩‍❤️‍👨 *HASIL CEK POTENSI PACARAN* 👩‍❤️‍👨\n\n` +
		`👤 *Target:* ${captionTag}\n` +
		`💖 *Potensi Pacaran:* *${rate}%*\n` +
		`💡 *Alasan:* _"${reason}"_\n\n` +
		`👉 _Gunakan .tembak ${captionTag} untuk melamar jadian sekarang!_ 💕`;

	await client?.sendMessage(m.chat, { react: { text: '💖', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['pacarcheck', 'cekpacar', 'pacaranrate'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek tingkat potensi menjadi pacar idaman dengan Canvas';
handler.register = true;

export default handler;
