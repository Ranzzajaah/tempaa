/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const KHODAM_LIST = [
	{ name: 'Sapu Lidi Sakti 🧹', desc: 'Suka nyapu kenangan mantan tapi debunya masuk mata.' },
	{ name: 'Kucing Oren Rusuh 🐱', desc: 'Hobi kayang di atas genteng tetangga jam 2 malem.' },
	{ name: 'Tutup Termos Lepas 🫖', desc: 'Bikin air cepet dingin kayak respon chat si dia.' },
	{ name: 'Pocong Ngesot Kepleset 👻', desc: 'Mau nakut-nakutin malah masuk parit.' },
	{ name: 'Tuyul Skena Ngopi 🎧', desc: 'Duit ga dicolong, malah diajak nongkrong di coffee shop estetik.' },
	{ name: 'Kuntilanak Gamers 🎮', desc: 'Ketawanya bukan hihihi tapi wkwkwk kena kill di Mobile Legends.' },
	{ name: 'Sendal Jepit Swallow Ijo 🩴', desc: 'Legendaris, sering ilang sebelah di masjid pas jumatan.' },
	{ name: 'Rempeyek Renyah Melempem 🍘', desc: 'Keliatan gahar pas digigit langsung loyo.' },
	{ name: 'Kabel Charger Kendor 🔌', desc: 'Harus ditekuk 90 derajat dulu baru mau ngecas.' },
	{ name: 'Cireng Isi Angin 🥟', desc: 'Keliatan gede pas digigit isinya cuma harapan palsu.' },
	{ name: 'Kulkas 2 Pintu Rusak 🧊', desc: 'Pintu atas dingin, pintu bawah buat nyimpen sendal.' },
	{ name: 'Naga Indosiar Terbang Rendah 🐉', desc: 'Grafik 144p, sering nabrak tiang jemuran warga.' },
	{ name: 'Galon Kosong Bunyi Tong 🪣', desc: 'Nyaring bunyinya, kosong isinya persis dompet akhir bulan.' },
	{ name: 'Kecoa Terbang Mode Tempur 🪳', desc: 'Ditakuti bapak-bapak berkumis tebal sekalipun.' },
	{ name: 'Bebek Racing Knalpot Brong 🦆', desc: 'Kwek-kwek tapi suaranya ngeblar di gang sempit.' }
];

const handler = async (m, { hirara, conn, sock, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		targetJid = m.sender;
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	const khodam = KHODAM_LIST[Math.floor(Math.random() * KHODAM_LIST.length)];
	const power = Math.floor(Math.random() * 50) + 50;

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🔮 CEK KHODAM PENDAMPING',
		badgeText: `⚡ ${power}% POWER`,
		titleBg: '#a855f7',
		badgeBg: '#ffea00',
		name: cardName,
		rate: power,
		categoryLabel: 'Khodam Sakti',
		categoryValue: khodam.name,
		descLabel: 'Tuah / Efek Khodam',
		descValue: khodam.desc,
		footerText: 'Khodam ini setia mengawasimu 24 jam sehari!',
		barColor: '#a855f7',
		ppUrl
	}).catch(() => null);

	const replyText = `🔮 *CEK KHODAM PENDAMPING GAIB* 🔮\n\n` +
		`👤 *Pemilik:* ${captionTag}\n` +
		`👹 *Khodam:* ${khodam.name}\n` +
		`⚡ *Kekuatan Gaib:* ${power}%\n` +
		`📜 *Deskripsi:* _"${khodam.desc}"_\n\n` +
		`_Catatan: Khodam ini selalu mengawasimu 24 jam sehari!_ 👁️`;

	await client?.sendMessage(m.chat, { react: { text: '🔮', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['cekkhodam', 'khodam'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek Khodam pendamping gaib sakti pengguna dengan kartu Canvas';
handler.register = true;

export default handler;
