/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const handler = async (m, { text, hirara, conn, sock }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let target = text ? text.trim() : '';

	if (m.mentionedJid && m.mentionedJid[0]) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!target) {
		targetJid = m.sender;
	}

	if (targetJid) {
		target = `@${getCleanTag(targetJid)}`;
	}

	const lebat = Math.floor(Math.random() * 101);
	const panjang = (Math.random() * 8 + 0.5).toFixed(1);
	const kondisi = ['mulus licin porselen ✨', 'tipis-tipis estetik 🍃', 'kribo gemoy 🦱', 'rapi habis di-trim ✂️', 'hutan amazon rindang 🌲'][Math.floor(Math.random() * 5)];
	const aroma = ['wangi vanilla manis 🍨', 'aroma pandan segar 🌿', 'wangi downy mystique 🌸', 'harum sabun bayi 👶'][Math.floor(Math.random() * 4)];

	const caption = `🫣 *ʜᴀsɪʟ ᴄᴇᴋ ᴊᴇᴍʙᴜᴛ* 🫣\n\n• 👤 *ᴛᴀʀɢᴇᴛ:* ${target}\n• 📊 *ᴋᴇʟᴇʙᴀᴛᴀɴ:* ${lebat}%\n• 📏 *ᴘᴀɴᴊᴀɴɢ:* ${panjang} cm\n• 🌿 *ᴋᴏɴᴅɪsɪ:* ${kondisi}\n• 👃 *ᴀʀᴏᴍᴀ:* ${aroma}`;

	const mentions = targetJid ? [targetJid] : [];
	return client.sendMessage(m.chat, { text: caption, mentions }, { quoted: m });
};

handler.help = ['cekjembut <@tag/nama>'];
handler.tags = ['fun'];
handler.command = ['cekjembut'];
handler.limit = true;

export default handler;
