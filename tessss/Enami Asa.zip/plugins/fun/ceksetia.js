/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const SETIA_REASONS = [
	'Karena hatinya hanya terpaut pada satu nama selamanya! 💖',
	'Karena anti melirik ke lawan jenis lain kalau udah sayang. 😍',
	'Karena kalau berjanji selalu ditepati sampai akhir. 🤝',
	'Masih agak sering lirak-lirik tapi tetap ingat jalan pulang. 😅',
	'Setia banget kalau lagi ada maunya aja nih! 🙈'
];

const handler = async (m, { hirara, conn, sock, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		targetJid = m.sender;
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	const rate = Math.floor(Math.random() * 51) + 50;
	const reason = SETIA_REASONS[Math.floor(Math.random() * SETIA_REASONS.length)];

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🔒 CEK TINGKAT KESETIAAN',
		badgeText: `💖 ${rate}% SETIA`,
		titleBg: '#16a34a',
		badgeBg: '#ffea00',
		name: cardName,
		rate,
		categoryLabel: 'Status Kesetiaan',
		categoryValue: rate > 75 ? 'Setia Setengah Mati 💎' : 'Cukup Setia 💚',
		descLabel: 'Catatan Kesetiaan',
		descValue: reason,
		footerText: 'Pertahankan kesetiaanmu karena setia itu mahal harganya!',
		barColor: '#22c55e',
		ppUrl
	}).catch(() => null);

	const replyText = `🔒 *CEK TINGKAT KESETIAAN* 🔒\n\n` +
		`👤 *Subjek:* ${captionTag}\n` +
		`💖 *Persentase Kesetiaan:* *${rate}%*\n` +
		`📜 *Catatan Kesetiaan:* _"${reason}"_\n\n` +
		`_Pertahankan kesetiaanmu karena setia itu mahal harganya!_ 💎`;

	await client?.sendMessage(m.chat, { react: { text: '🔒', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['ceksetia', 'setiacheck'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek tingkat persentase kesetiaan seseorang terhadap pasangannya dengan Canvas';
handler.register = true;

export default handler;
