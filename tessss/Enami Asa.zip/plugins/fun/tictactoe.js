/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createCanvas } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY } from '../../canvas/canvas-font.js';

global.tictactoeSessions = global.tictactoeSessions || new Map();
const activeTTTSessions = global.tictactoeSessions;

const WINNING_COMBOS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], 
  [0, 3, 6], [1, 4, 7], [2, 5, 8], 
  [0, 4, 8], [2, 4, 6]             
];

function getChatKey(jid) {
  if (!jid) return '';
  const cleanJid = jid.split(':')[0];
  if (cleanJid.includes('@')) return cleanJid;
  return jid;
}

function getCleanNumber(jid) {
  if (!jid || typeof jid !== 'string') return '';
  const userPortion = jid.split('@')[0].split(':')[0];
  return userPortion.replace(/[^0-9]/g, '');
}

function isSamePlayer(jid1, jid2) {
  if (!jid1 || !jid2) return false;
  if (jid1 === jid2) return true;
  const num1 = getCleanNumber(jid1);
  const num2 = getCleanNumber(jid2);
  if (num1 && num2 && num1 === num2) return true;
  return false;
}

function isStopCommand(input) {
  if (!input) return false;
  const clean = input.trim().toLowerCase();
  return (
    clean === 'stop' ||
    clean === 'menyerah' ||
    clean === 'nyerah' ||
    clean === 'surrender' ||
    clean === 'batal' ||
    clean.endsWith(' stop') ||
    clean.endsWith(' menyerah') ||
    clean.endsWith(' nyerah')
  );
}

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

async function generateTTTCanvas({ board, playerX, playerO, turn, winner, winningCombo, isAI, betMoney = 0 }) {
  await ensureCanvasFonts().catch(() => null);

  const W = 800;
  const H = 930;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#fdfbf7');
  bgGrad.addColorStop(0.5, '#f7f0e6');
  bgGrad.addColorStop(1, '#f1e6d6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 800; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 18);
  ctx.strokeStyle = '#15803d'; 
  ctx.lineWidth = 3;
  ctx.stroke();

  rrp(ctx, p + 5, p + 5, W - p * 2 - 10, H - p * 2 - 10, 14);
  ctx.strokeStyle = 'rgba(21, 128, 61, 0.3)';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const headY = p + 18;
  rrp(ctx, p + 20, headY, W - (p + 20) * 2, 60, 12);
  ctx.fillStyle = '#15803d';
  ctx.fill();

  ctx.font = `bold 24px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('⚔️ TIC-TAC-TOE SHOWDOWN ⚔️', W / 2, headY + 30);

  const cardY = headY + 75;
  if (betMoney > 0) {
    const betText = `💰 TARUHAN: $${betMoney.toLocaleString('id-ID')}`;
    rrp(ctx, W / 2 - 140, cardY - 8, 280, 28, 8);
    ctx.fillStyle = '#d97706';
    ctx.fill();
    ctx.font = `bold 13px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText(betText, W / 2, cardY + 6);
  }

  const cardW = 345;
  const cardH = 92;
  const playerCardY = cardY + (betMoney > 0 ? 25 : 5);

  const isTurnX = turn === 'X' && !winner;
  rrp(ctx, p + 20, playerCardY, cardW, cardH, 14);
  ctx.fillStyle = isTurnX ? '#ffffff' : '#f8fafc';
  ctx.fill();
  ctx.strokeStyle = isTurnX ? '#2563eb' : 'rgba(37, 99, 235, 0.25)';
  ctx.lineWidth = isTurnX ? 3 : 1.5;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.font = `bold 20px ${FONT_FAMILY}`;
  ctx.fillStyle = '#2563eb';
  ctx.fillText('❌ PLAYER X', p + 40, playerCardY + 36);

  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#1e293b';
  ctx.fillText(playerX.name, p + 40, playerCardY + 66);

  if (isTurnX) {
    rrp(ctx, p + cardW - 105, playerCardY + 14, 90, 26, 8);
    ctx.fillStyle = '#2563eb';
    ctx.fill();
    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText('GILIRAN', p + cardW - 60, playerCardY + 31);
  }

  const isTurnO = turn === 'O' && !winner;
  const p2X = W - (p + 20) - cardW;
  rrp(ctx, p2X, playerCardY, cardW, cardH, 14);
  ctx.fillStyle = isTurnO ? '#ffffff' : '#f8fafc';
  ctx.fill();
  ctx.strokeStyle = isTurnO ? '#dc2626' : 'rgba(220, 38, 38, 0.25)';
  ctx.lineWidth = isTurnO ? 3 : 1.5;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.font = `bold 20px ${FONT_FAMILY}`;
  ctx.fillStyle = '#dc2626';
  ctx.fillText('⭕ PLAYER O', p2X + 20, playerCardY + 36);

  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#1e293b';
  ctx.fillText(isAI ? '🤖 Bot AI (Hard)' : playerO.name, p2X + 20, playerCardY + 66);

  if (isTurnO) {
    rrp(ctx, p2X + cardW - 105, playerCardY + 14, 90, 26, 8);
    ctx.fillStyle = '#dc2626';
    ctx.fill();
    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText('GILIRAN', p2X + cardW - 60, playerCardY + 31);
  }

  const boardSize = 500;
  const boardX = (W - boardSize) / 2;
  const boardY = playerCardY + 110;

  rrp(ctx, boardX, boardY, boardSize, boardSize, 20);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  const cellSize = boardSize / 3;

  ctx.strokeStyle = 'rgba(21, 128, 61, 0.2)';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';

  for (let i = 1; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(boardX + i * cellSize, boardY + 20);
    ctx.lineTo(boardX + i * cellSize, boardY + boardSize - 20);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(boardX + 20, boardY + i * cellSize);
    ctx.lineTo(boardX + boardSize - 20, boardY + i * cellSize);
    ctx.stroke();
  }

  board.forEach((val, idx) => {
    const col = idx % 3;
    const row = Math.floor(idx / 3);
    const cx = boardX + col * cellSize + cellSize / 2;
    const cy = boardY + row * cellSize + cellSize / 2;

    if (val === 'X') {
      const pOffset = 42;
      const x1 = boardX + col * cellSize + pOffset;
      const y1 = boardY + row * cellSize + pOffset;
      const x2 = boardX + (col + 1) * cellSize - pOffset;
      const y2 = boardY + (row + 1) * cellSize - pOffset;

      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 14;
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.moveTo(x2, y1);
      ctx.lineTo(x1, y2);
      ctx.stroke();
    } else if (val === 'O') {
      const r = cellSize / 2 - 38;
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 14;
      ctx.lineCap = 'round';

      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    } else {
      rrp(ctx, cx - 22, cy - 22, 44, 44, 10);
      ctx.fillStyle = '#f1f5f9';
      ctx.fill();
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.font = `bold 20px ${FONT_FAMILY}`;
      ctx.fillStyle = '#64748b';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText((idx + 1).toString(), cx, cy);
    }
  });

  if (winningCombo) {
    const [a, , c] = winningCombo;
    const colA = a % 3, rowA = Math.floor(a / 3);
    const colC = c % 3, rowC = Math.floor(c / 3);

    const startX = boardX + colA * cellSize + cellSize / 2;
    const startY = boardY + rowA * cellSize + cellSize / 2;
    const endX = boardX + colC * cellSize + cellSize / 2;
    const endY = boardY + rowC * cellSize + cellSize / 2;

    const winColor = board[a] === 'X' ? '#2563eb' : '#dc2626';
    ctx.strokeStyle = winColor;
    ctx.lineWidth = 12;
    ctx.lineCap = 'round';

    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(endX, endY);
    ctx.stroke();
  }

  const statusY = boardY + boardSize + 18;
  let bannerBg = '#ffffff';
  let bannerBorder = '#15803d';
  let bannerTextColor = '#15803d';
  let bannerText = `👉 Giliran: ${turn === 'X' ? playerX.name : (isAI ? 'Bot AI' : playerO.name)} (Pilih angka 1-9)`;

  if (winner) {
    if (winner === 'draw') {
      bannerText = '🤝 GAME OVER - PERMAINAN SERI!';
      bannerBg = '#f1f5f9';
      bannerBorder = '#64748b';
      bannerTextColor = '#334155';
    } else if (winner === 'X') {
      bannerText = `🎉 PERMAINAN DIMENANGKAN OLEH ${playerX.name.toUpperCase()} (X)!`;
      bannerBg = '#eff6ff';
      bannerBorder = '#2563eb';
      bannerTextColor = '#1d4ed8';
    } else if (winner === 'O') {
      bannerText = `🎉 PERMAINAN DIMENANGKAN OLEH ${isAI ? 'BOT AI' : playerO.name.toUpperCase()} (O)!`;
      bannerBg = '#fef2f2';
      bannerBorder = '#dc2626';
      bannerTextColor = '#b91c1c';
    }
  }

  rrp(ctx, p + 20, statusY, W - (p + 20) * 2, 54, 12);
  ctx.fillStyle = bannerBg;
  ctx.fill();
  ctx.strokeStyle = bannerBorder;
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.font = `bold 18px ${FONT_FAMILY}`;
  ctx.fillStyle = bannerTextColor;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(bannerText, W / 2, statusY + 27);

  return canvas.toBuffer('image/png');
}

function checkBoardWinner(b, nextTurn = null) {
  for (const combo of WINNING_COMBOS) {
    const [a, bIdx, c] = combo;
    if (b[a] && b[a] === b[bIdx] && b[a] === b[c]) {
      return { winner: b[a], combo };
    }
  }

  const emptyIndices = [];
  b.forEach((cell, idx) => {
    if (cell === null) emptyIndices.push(idx);
  });

  if (emptyIndices.length === 0) {
    return { winner: 'draw' };
  }

  if (emptyIndices.length === 1) {
    const lastIdx = emptyIndices[0];
    const testTurn = nextTurn || 'X';

    b[lastIdx] = testTurn;
    let canWin = false;
    for (const combo of WINNING_COMBOS) {
      const [a, bIdx, c] = combo;
      if (b[a] && b[a] === b[bIdx] && b[a] === b[c]) {
        canWin = true;
        break;
      }
    }
    b[lastIdx] = null;

    if (!canWin) {
      return { winner: 'draw' };
    }
  }

  return null;
}

function getBestMove(b) {
  let bestScore = -Infinity;
  let move;

  for (let i = 0; i < 9; i++) {
    if (b[i] === null) {
      b[i] = 'O';
      let score = minimax(b, 0, false);
      b[i] = null;
      if (score > bestScore) {
        bestScore = score;
        move = i;
      }
    }
  }
  return move;
}

function minimax(b, depth, isMaximizing) {
  const res = checkBoardWinner(b);
  if (res) {
    if (res.winner === 'O') return 10 - depth;
    if (res.winner === 'X') return depth - 10;
    if (res.winner === 'draw') return 0;
  }

  if (isMaximizing) {
    let bestScore = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (b[i] === null) {
        b[i] = 'O';
        let score = minimax(b, depth + 1, false);
        b[i] = null;
        bestScore = Math.max(score, bestScore);
      }
    }
    return bestScore;
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < 9; i++) {
      if (b[i] === null) {
        b[i] = 'X';
        let score = minimax(b, depth + 1, true);
        b[i] = null;
        bestScore = Math.min(score, bestScore);
      }
    }
    return bestScore;
  }
}

async function processMove(m, { hirara, session, moveIndex, chatKey, updateUser, getUser }) {
  const chatJid = m.chat || m.key?.remoteJid;
  const senderJid = m.sender;

  const isPlayerX = isSamePlayer(senderJid, session.playerX.jid) || (session.playerX.altJid && isSamePlayer(senderJid, session.playerX.altJid));
  let isPlayerO = session.isAI ? false : (isSamePlayer(senderJid, session.playerO.jid) || (session.playerO.altJid && isSamePlayer(senderJid, session.playerO.altJid)));

  if (!session.isAI && !isPlayerX && !isPlayerO) {
    if (session.turn === 'O') {
      session.playerO.altJid = senderJid;
      isPlayerO = true;
    } else if (session.turn === 'X') {
      session.playerX.altJid = senderJid;
    }
  }

  if (isPlayerX && m.pushName && (!session.playerX.name || session.playerX.name.startsWith('@'))) {
    session.playerX.name = m.pushName;
  }
  if (isPlayerO && m.pushName && (!session.playerO.name || session.playerO.name.startsWith('@'))) {
    session.playerO.name = m.pushName;
  }

  if ((session.turn === 'X' && !isPlayerX) || (session.turn === 'O' && !isPlayerO)) {
    const nextJid = session.turn === 'X' ? session.playerX.jid : session.playerO.jid;
    const cleanMention = getCleanNumber(nextJid);
    return hirara.sendMessage(chatJid, { text: `⚠️ Sekarang giliran @${cleanMention}!`, mentions: [nextJid] }, { quoted: m });
  }

  if (session.board[moveIndex] !== null) {
    return hirara.sendMessage(chatJid, { text: '⚠️ Kotak tersebut sudah diisi! Pilih angka kotak lain yang masih kosong (1-9).' }, { quoted: m });
  }

  session.board[moveIndex] = session.turn;
  const nextTurn = session.turn === 'X' ? 'O' : 'X';
  let result = checkBoardWinner(session.board, nextTurn);

  if (!result && session.isAI && session.turn === 'X') {
    session.turn = 'O';
    const aiMove = getBestMove(session.board);
    if (aiMove !== undefined && aiMove !== null) {
      session.board[aiMove] = 'O';
      result = checkBoardWinner(session.board, 'X');
    }
    session.turn = 'X';
  } else if (!result) {
    session.turn = nextTurn;
  }

  const winningCombo = result?.combo || null;
  const winner = result?.winner || null;

  const imgBuffer = await generateTTTCanvas({
    board: session.board,
    playerX: session.playerX,
    playerO: session.playerO,
    turn: session.turn,
    winner,
    winningCombo,
    isAI: session.isAI,
    betMoney: session.betMoney || 0
  });

  let captionText = '';
  let mentions = [];

  if (winner) {
    activeTTTSessions.delete(chatKey);
    const bet = session.betMoney || 0;

    if (winner === 'draw') {
      captionText = `🤝 *GAME OVER - SERI!* 🤝\n\nPermainan berakhir seimbang! Uang taruhan dikembalikan.`;
    } else {
      const winnerJid = winner === 'X' ? session.playerX.jid : session.playerO.jid;
      const loserJid = winner === 'X' ? session.playerO.jid : session.playerX.jid;
      const winnerName = winner === 'X' ? session.playerX.name : (session.isAI ? 'Bot AI' : session.playerO.name);

      if (bet > 0 && typeof updateUser === 'function' && typeof getUser === 'function') {
        try {
          const winnerUser = await getUser(winnerJid);
          const loserUser = session.isAI ? null : await getUser(loserJid);

          if (winnerUser) {
            winnerUser.money = (winnerUser.money || 0) + bet;
            await updateUser(winnerJid, { money: winnerUser.money });
          }

          if (loserUser) {
            loserUser.money = Math.max(0, (loserUser.money || 0) - bet);
            await updateUser(loserJid, { money: loserUser.money });
          }
        } catch (e) {
          console.error('[TTT Payout Error]', e);
        }
      }

      captionText = `🏆 *GAME OVER - MENANG!* 🏆\n\n` +
        `Selamat kepada *${winnerName}* (@${getCleanNumber(winnerJid)}) yang memenangkan pertandingan Tic-Tac-Toe!`;

      if (bet > 0) {
        captionText += `\n💰 *Hadiah Taruhan:* +$${bet.toLocaleString('id-ID')}`;
      }

      mentions.push(winnerJid);
    }
  } else {
    const nextJid = session.turn === 'X' ? session.playerX.jid : session.playerO.jid;
    captionText = `❌ *TIC-TAC-TOE BOARD* ⭕\n\n` +
      `👤 *Player X:* ${session.playerX.name}\n` +
      `👤 *Player O:* ${session.isAI ? '🤖 Bot AI' : session.playerO.name}\n` +
      (session.betMoney ? `💰 *Taruhan:* $${session.betMoney.toLocaleString('id-ID')}\n\n` : `\n`) +
      `👉 *Giliran:* @${getCleanNumber(nextJid)} (${session.turn})\n` +
      `📌 Langsung ketik angka *1 - 9* di chat untuk menaruh simbol.\n` +
      `🏳️ Ketik *stop* atau *menyerah* untuk menghentikan game.`;
    mentions.push(nextJid);
  }

  return hirara.sendMessage(chatJid, {
    image: imgBuffer,
    caption: captionText,
    mentions
  }, { quoted: m });
}

const handler = async (m, { hirara, text, usedPrefix, command, user, getUser, updateUser }) => {
  const chatJid = m.chat || m.key?.remoteJid;
  const chatKey = getChatKey(chatJid);
  const senderJid = m.sender;
  const args = (text || '').trim().split(/\s+/);
  const input = args[0]?.toLowerCase() || '';

  let session = activeTTTSessions.get(chatKey);

  if (isStopCommand(input) || isStopCommand(m.text)) {
    if (!session) {
      return hirara.sendMessage(chatJid, { text: '❌ Tidak ada sesi Tic-Tac-Toe yang aktif di chat ini.' }, { quoted: m });
    }
    activeTTTSessions.delete(chatKey);
    return hirara.sendMessage(chatJid, { text: `🏳️ Game Tic-Tac-Toe berhasil dihentikan oleh @${getCleanNumber(senderJid)}.`, mentions: [senderJid] }, { quoted: m });
  }

  if (session && /^[1-9]$/.test(input)) {
    const moveIndex = parseInt(input, 10) - 1;
    return processMove(m, { hirara, session, moveIndex, chatKey, updateUser, getUser });
  }

  if (session) {
    return hirara.sendMessage(chatJid, {
      text: `⚠️ *Sesi Tic-Tac-Toe sedang berlangsung!*\n\n` +
        `👉 Giliran: @${getCleanNumber(session.turn === 'X' ? session.playerX.jid : session.playerO.jid)}\n` +
        `📌 Ketik angka *1 - 9* untuk memilih kotak.\n` +
        `🏳️ Ketik *${usedPrefix}${command} stop* atau *stop* untuk menghentikan.`,
      mentions: [session.turn === 'X' ? session.playerX.jid : session.playerO.jid]
    }, { quoted: m });
  }

  let betMoney = 0;
  for (const arg of args) {
    if (/^\d+$/.test(arg)) {
      const num = parseInt(arg, 10);
      if (num > 0) betMoney = num;
    }
  }

  const mentioned = m.mentionedJid || m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  let isAI = false;
  let opponentJid = null;
  let opponentName = '';

  const isAIRequest = args.some(a => ['ai', 'bot', 'solo'].includes(a.toLowerCase()));

  if (isAIRequest) {
    isAI = true;
    opponentJid = hirara.user?.id || 'bot@s.whatsapp.net';
    opponentName = 'Bot AI';
  } else if (mentioned.length > 0) {
    opponentJid = mentioned[0];
    if (isSamePlayer(opponentJid, senderJid)) {
      return hirara.sendMessage(chatJid, { text: '❌ Kamu tidak bisa menantang diri sendiri! Tag teman lain atau ketik `.ttt ai`.' }, { quoted: m });
    }
    opponentName = `@${getCleanNumber(opponentJid)}`;
  } else if (m.quoted?.sender) {
    opponentJid = m.quoted.sender;
    if (isSamePlayer(opponentJid, senderJid)) {
      return hirara.sendMessage(chatJid, { text: '❌ Kamu tidak bisa menantang diri sendiri! Tag teman lain atau ketik `.ttt ai`.' }, { quoted: m });
    }
    opponentName = `@${getCleanNumber(opponentJid)}`;
  } else {
    return hirara.sendMessage(chatJid, {
      text: `❌ *CARA MENGGUNAKAN TIC-TAC-TOE TARUHAN*\n\n` +
        `🔹 *Lawan Bot AI:* \`${usedPrefix}${command} ai\` / \`${usedPrefix}${command} 1000 ai\`\n` +
        `🔹 *Tantang Teman:* \`${usedPrefix}${command} @user\` / \`${usedPrefix}${command} 5000 @user\`\n` +
        `🔹 *Mainkan Langkah:* Ketik angka \`1 - 9\`\n` +
        `🔹 *Hentikan Game:* \`${usedPrefix}${command} stop\` atau ketik \`stop\``
    }, { quoted: m });
  }

  if (betMoney > 0) {
    const senderUser = user || (typeof getUser === 'function' ? await getUser(senderJid) : null);
    const senderMoney = senderUser?.money || 0;

    if (senderMoney < betMoney) {
      return hirara.sendMessage(chatJid, {
        text: `❌ Uang kamu tidak cukup untuk taruhan ini!\n\n💰 *Uang Kamu:* $${senderMoney.toLocaleString('id-ID')}\n🎯 *Taruhan:* $${betMoney.toLocaleString('id-ID')}`
      }, { quoted: m });
    }

    if (!isAI && opponentJid) {
      const oppUser = typeof getUser === 'function' ? await getUser(opponentJid) : null;
      const oppMoney = oppUser?.money || 0;
      if (oppMoney < betMoney) {
        return hirara.sendMessage(chatJid, {
          text: `❌ Uang @${getCleanNumber(opponentJid)} tidak cukup untuk taruhan ini!\n\n💰 *Uang Lawan:* $${oppMoney.toLocaleString('id-ID')}\n🎯 *Taruhan:* $${betMoney.toLocaleString('id-ID')}`,
          mentions: [opponentJid]
        }, { quoted: m });
      }
    }
  }

  const senderName = m.pushName || `@${getCleanNumber(senderJid)}`;

  const newSession = {
    board: Array(9).fill(null),
    playerX: { jid: senderJid, name: senderName },
    playerO: { jid: opponentJid, name: opponentName },
    turn: 'X',
    isAI,
    betMoney,
    createdAt: Date.now()
  };

  activeTTTSessions.set(chatKey, newSession);

  const initialBuffer = await generateTTTCanvas({
    board: newSession.board,
    playerX: newSession.playerX,
    playerO: newSession.playerO,
    turn: newSession.turn,
    winner: null,
    winningCombo: null,
    isAI,
    betMoney
  });

  let captionText = `🎮 *GAME TIC-TAC-TOE TARUHAN DIMULAI!* 🎮\n\n` +
    `❌ *Player X:* ${senderName}\n` +
    `⭕ *Player O:* ${isAI ? '🤖 Bot AI' : opponentName}\n`;

  if (betMoney > 0) {
    captionText += `💰 *Taruhan:* $${betMoney.toLocaleString('id-ID')}\n`;
  }

  captionText += `\n👉 *Giliran:* @${getCleanNumber(senderJid)} (X)\n` +
    `📌 Langsung ketik angka *1 - 9* di chat untuk menaruh simbol.\n` +
    `🏳️ Ketik *${usedPrefix}${command} stop* atau *stop* untuk menghentikan game.`;

  return hirara.sendMessage(chatJid, {
    image: initialBuffer,
    caption: captionText,
    mentions: [senderJid, opponentJid]
  }, { quoted: m });
};

handler.before = async (m, { hirara, updateUser, getUser }) => {
  if (!m.text) return;
  const chatJid = m.chat || m.key?.remoteJid;
  const chatKey = getChatKey(chatJid);
  const session = activeTTTSessions.get(chatKey);

  if (!session) return;

  const rawText = m.text.trim();

  if (isStopCommand(rawText)) {
    activeTTTSessions.delete(chatKey);
    await hirara.sendMessage(chatJid, { text: `🏳️ Game Tic-Tac-Toe berhasil dihentikan oleh @${getCleanNumber(m.sender)}.`, mentions: [m.sender] }, { quoted: m });
    return true;
  }

  const numMatch = rawText.match(/^[./#!]?t*t*t*\s*([1-9])$/i) || rawText.match(/^([1-9])$/);
  if (numMatch) {
    const moveIndex = parseInt(numMatch[1], 10) - 1;
    await processMove(m, { hirara, session, moveIndex, chatKey, updateUser, getUser });
    return true;
  }
};

handler.command = ['tictactoe','ttt'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Main game Tic-Tac-Toe interaktif visual Canvas dengan fitur taruhan uang RPG';
handler.register = false;

export default handler;
