/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const ANSWERS = [
    'Ya, pasti!', 'Tidak diragukan lagi.', 'Sepertinya begitu.',
    'Tanya lagi nanti.', 'Lebih baik tidak kuberitahu sekarang.',
    'Jangan terlalu berharap.', 'Sangat meragukan.', 'Tidak mungkin.', 'Bisa jadi.',
    'Peluangnya 100%!'
];

const handler = async (m, { text, args }) => {
    const q = (args.join(' ') || text || '').trim();
    return m.reply(`🎱 *MAGIC 8-BALL*

${q ? `❓ *Pertanyaan:* "${q}"

` : ''}🔮 *Jawaban:* *${pick(ANSWERS)}*`);
};

handler.help = ['magic8ball [pertanyaan]'];
handler.tags = ['fun'];
handler.command = ['magic8ball', '8ball'];
handler.limit = true;
handler.register = true;

export default handler;
