/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const SESSIONS = new Map();

const SCRAMBLE_DATA = [
    { word: 'KOMPUTER', hint: 'Alat elektronik untuk mengolah data' },
    { word: 'PETUALANGAN', hint: 'Perjalanan penuh tantangan dan eksplorasi' },
    { word: 'PERSAHABATAN', hint: 'Hubungan dekat dan tulus antar teman' },
    { word: 'KEBAHAGIAAN', hint: 'Perasaan senang, tenang, dan puas' },
    { word: 'TEKNOLOGI', hint: 'Ilmu terapan untuk memudahkan kehidupan manusia' },
    { word: 'IMAJINASI', hint: 'Daya khayal atau kreativitas dalam pikiran' },
    { word: 'PROGRAMMER', hint: 'Profesi pembuat dan pengembang perangkat lunak' },
    { word: 'KECERDASAN', hint: 'Kemampuan berpikir dan menyelesaikan masalah' },
    { word: 'ASTRONOT', hint: 'Orang yang dilatih untuk menjelajahi luar angkasa' },
    { word: 'NUSANTARA', hint: 'Sebutan kepulauan di wilayah Indonesia' },
    { word: 'MATEMATIKA', hint: 'Ilmu tentang bilangan, rumus, dan kalkulasi' },
    { word: 'SMARTPHONE', hint: 'Ponsel pintar dengan beragam fitur dan aplikasi' },
    { word: 'LABORATORIUM', hint: 'Ruangan khusus untuk riset dan eksperimen ilmiah' },
    { word: 'HEMISFER', hint: 'Belahan bola bumi atau otak' },
    { word: 'FOTOSINTESIS', hint: 'Proses tumbuhan hijau membuat makanannya sendiri' }
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

function scrambleWord(word) {
    const arr = word.split('');
    for (let i = arr.length - 1; i > 0; i--) {
        const j = randInt(0, i);
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.join('');
}

const handler = async (m, { text, args, usedPrefix, command }) => {
    const cmd = command.toLowerCase();
    const prefix = usedPrefix || '.';

    if (cmd === 'wordscramble' || cmd === 'scramble' || cmd === 'tebakkata') {
        const item = pick(SCRAMBLE_DATA);
        SESSIONS.set(m.chat, item.word.toLowerCase());
        return m.reply(`🔀 *TEBAK KATA ACAK*

Susunan huruf: *${scrambleWord(item.word)}*
💡 Hint: _${item.hint}_

Jawab dengan: *${prefix}jawabscramble [kata]*`);
    }

    if (cmd === 'jawabscramble') {
        const ans = (args.join(' ') || text || '').toLowerCase().trim();
        const correct = SESSIONS.get(m.chat);
        if (!correct) return m.reply(`❌ Belum ada game aktif. Ketik *${prefix}wordscramble* dulu!`);
        if (!ans) return m.reply(`📌 Ketik kata tebakanmu: *${prefix}jawabscramble <kata>*`);

        if (ans === correct) {
            SESSIONS.delete(m.chat);
            return m.reply(`🎉 *BENAR!* Kata yang tepat adalah: *${correct.toUpperCase()}*! Hebat!`);
        } else {
            return m.reply('❌ Belum tepat, ayo coba tebak lagi!');
        }
    }
};

handler.help = ['wordscramble', 'jawabscramble <kata>'];
handler.tags = ['fun'];
handler.command = ['wordscramble', 'scramble', 'tebakkata', 'jawabscramble'];
handler.limit = true;
handler.register = true;

export default handler;
