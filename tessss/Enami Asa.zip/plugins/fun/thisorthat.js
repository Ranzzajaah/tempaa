/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const PAIRS = [
    ['Kucing', 'Anjing'], ['Pagi Hari', 'Malam Hari'], ['Pantai', 'Gunung'],
    ['Teh Manis', 'Kopi Susu'], ['Nonton Film', 'Baca Buku'], ['Musim Panas', 'Musim Hujan'],
    ['Mie Goreng', 'Mie Kuah'], ['Game PC', 'Game Mobile'], ['Uang Banyak', 'Waktu Luang']
];

const handler = async (m) => {
    const [a, b] = pick(PAIRS);
    return m.reply(`⚖️ *THIS OR THAT*

*${a}* 🆚 *${b}*

Pilih salah satu dan tuliskan alasanmu!`);
};

handler.help = ['thisorthat'];
handler.tags = ['fun'];
handler.command = ['thisorthat', 'pilihmana'];
handler.limit = true;
handler.register = true;

export default handler;
