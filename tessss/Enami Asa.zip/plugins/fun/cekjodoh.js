/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createCanvas } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY } from '../../canvas/canvas-font.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

async function generateJodohCanvas({ name1, name2, percentage, statusText }) {
  await ensureCanvasFonts().catch(() => null);

  const W = 900, H = 500;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#fdfbf7');
  bgGrad.addColorStop(0.5, '#f7f0e6');
  bgGrad.addColorStop(1, '#f1e6d6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 800; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 14);
  ctx.strokeStyle = '#ec4899';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = `bold 24px ${FONT_FAMILY}`;
  ctx.fillStyle = '#831843';
  ctx.fillText('💘 CEK JODOH KECOCOKAN', p + 35, p + 45);

  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#db2777';
  ctx.fillText(`💖 ${percentage}% MATCH`, W - p - 170, p + 45);

  const cY = 140;
  rrp(ctx, p + 35, cY, W - p * 2 - 70, 110, 12);
  ctx.fillStyle = 'rgba(253, 242, 248, 0.9)';
  ctx.fill();
  ctx.strokeStyle = '#fbcfe8';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.font = `bold 24px ${FONT_FAMILY}`;
  ctx.fillStyle = '#9d174d';
  ctx.textAlign = 'center';
  ctx.fillText(`${name1}  ❤️  ${name2}`, W / 2, cY + 45);

  ctx.font = `15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#be185d';
  ctx.fillText(`Prediksi: ${statusText}`, W / 2, cY + 80);
  ctx.textAlign = 'left';

  const mY = cY + 140;
  const barW = W - p * 2 - 70;
  rrp(ctx, p + 35, mY, barW, 28, 8);
  ctx.fillStyle = '#fce7f3';
  ctx.fill();

  const fillW = Math.max(16, (barW * Math.min(100, percentage)) / 100);
  rrp(ctx, p + 35, mY, fillW, 28, 8);
  ctx.fillStyle = '#ec4899';
  ctx.fill();

  const bY = H - p - 80;
  rrp(ctx, p + 35, bY, W - p * 2 - 70, 58, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.85)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('💡 TIPS HUBUNGAN', p + 55, bY + 24);
  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText('Jaga komunikasi & saling percaya agar hubungan langgeng!', p + 55, bY + 44);

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { hirara, conn, sock, usedPrefix, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let target1 = m.sender;
	let target2 = null;

	const mentionedJid = m.mentionedJid || [];

	if (mentionedJid.length >= 2) {
		target1 = mentionedJid[0];
		target2 = mentionedJid[1];
	} else if (mentionedJid.length === 1) {
		target2 = mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		target2 = m.quoted.sender;
	} else if (text && text.includes('|')) {
		const parts = text.split('|');
		const name1 = parts[0].trim();
		const name2 = parts[1].trim();

		const percentage = Math.floor(Math.random() * 101);
		let statusText = 'Jodoh Tak Duga';
		if (percentage > 85) statusText = 'Pasangan Takdir Sejati (99% Nikah!) 💕';
		else if (percentage > 70) statusText = 'Sangat Cocok & Romantis 💖';
		else if (percentage > 50) statusText = 'Bisa Cocok Asal Saling Pengertian 💓';
		else if (percentage > 30) statusText = 'Sering Berantem Cekcok 💔';
		else statusText = 'Mending Berteman Aja Deh... 😅';

		const cardBuffer = await generateJodohCanvas({ name1, name2, percentage, statusText }).catch(() => null);

		const replyMsg = `💘 *CEK JODOH COMPATIBILITY* 💘\n\n` +
			`👩‍❤️‍👨 Pasangan: *${name1}* ❤️ *${name2}*\n` +
			`📊 Kecocokan: *${percentage}%*\n` +
			`💌 Prediksi: *${statusText}*`;

		if (cardBuffer) {
			return client.sendMessage(m.chat, { image: cardBuffer, caption: replyMsg }, { quoted: m });
		} else {
			return client.sendMessage(m.chat, { text: replyMsg }, { quoted: m });
		}
	} else {
		return client.sendMessage(m.chat, { text: `💘 *CEK JODOH KECOCOKAN*\n\nTag 1/2 orang atau tulis 2 nama!\nContoh:\n• *${usedPrefix}cekjodoh @user*\n• *${usedPrefix}cekjodoh @user1 @user2*\n• *${usedPrefix}cekjodoh Romeo | Juliet*` }, { quoted: m });
	}

	const percentage = Math.floor(Math.random() * 101);
	let statusText = 'Jodoh Tak Duga';
	if (percentage > 85) statusText = 'Pasangan Takdir Sejati (99% Nikah!) 💕';
	else if (percentage > 70) statusText = 'Sangat Cocok & Romantis 💖';
	else if (percentage > 50) statusText = 'Bisa Cocok Asal Saling Pengertian 💓';
	else if (percentage > 30) statusText = 'Sering Berantem Cekcok 💔';
	else statusText = 'Mending Berteman Aja Deh... 😅';

	const name1 = `@${getCleanTag(target1)}`;
	const name2 = `@${getCleanTag(target2)}`;

	const cardBuffer = await generateJodohCanvas({ name1, name2, percentage, statusText }).catch(() => null);

	const replyMsg = `💘 *CEK JODOH COMPATIBILITY* 💘\n\n` +
		`👩‍❤️‍👨 Pasangan: ${name1} ❤️ ${name2}\n` +
		`📊 Kecocokan: *${percentage}%*\n` +
		`💌 Prediksi: *${statusText}*`;

	await client?.sendMessage(m.chat, { react: { text: '💘', key: m.key } }).catch(() => null);

	const mentions = [target1, target2].filter(Boolean);
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyMsg,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyMsg,
			mentions
		}, { quoted: m });
	}
};

handler.help = ['cekjodoh <@tag/nama | nama>'];
handler.tags = ['fun'];
handler.command = ['cekjodoh', 'jodohcheck', 'jodoh'];
handler.limit = true;

export default handler;
