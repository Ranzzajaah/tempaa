const pickRandom = (list) => {
    return list[Math.floor(Math.random() * list.length)];
};

const userMention = (jid) => '@' + jid.split('@')[0];

const handler = async (m, { sock, groupMetadata, text, usedPrefix, command }) => {
    if (!m.isGroup) {
        return m.reply('❌ Perintah ini hanya dapat digunakan di dalam grup!');
    }

    if (!text) {
        return m.reply(`📌 *Contoh Penggunaan:*\n• \`${usedPrefix + command} Orang Paling Ganteng\`\n• \`${usedPrefix + command} Beban Grup\``);
    }

    // Ambil data metadata grup (Gunakan fallback sock.groupMetadata jika parameter kosong)
    let metadata = groupMetadata;
    if (!metadata || !metadata.participants || metadata.participants.length === 0) {
        try {
            metadata = await sock.groupMetadata(m.chat);
        } catch (err) {
            console.error('[TOP COMMAND ERROR]', err);
            return m.reply('❌ Gagal mengambil daftar anggota grup.');
        }
    }

    const participants = metadata?.participants || [];
    if (participants.length === 0) {
        return m.reply('❌ Daftar anggota grup tidak ditemukan.');
    }

    // Ambil 5 anggota secara acak dari partisipan grup
    const shuffled = [...participants].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 5).map(v => v.id || v.jid);

    const emojis = ['🤓', '😅', '😂', '😳', '😎', '🥵', '😱', '🤑', '🙄', '💩', '🍑', '🤨', '🥴', '🔥', '👇🏻', '😔', '👀', '🌚'];
    const randomEmoji = pickRandom(emojis);

    let caption = `*${randomEmoji} TOP 5 ${text.toUpperCase()} ${randomEmoji}*\n\n`;
    selected.forEach((jid, index) => {
        caption += `${index + 1}. ${userMention(jid)}\n`;
    });

    await sock.sendMessage(m.chat, {
        text: caption.trim(),
        mentions: selected
    }, { quoted: m });
};

handler.help = ['top <teks>'];
handler.tags = ['kerang', 'fun', 'group'];
handler.command = ['top'];
handler.group = true;

export default handler;