/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const GOMBAL_LIST = [
  "Rumah kamu dekat bandara ya? Soalnya pas liat senyummu, hatiku langsung take off tanpa izin! 🛫💖",
  "Kamu tahu bedanya kamu sama modem? Kalau modem penghubung internet, kalau kamu penghubung masa depanku! 📶💍",
  "Kamu punya peta nggak? Soalnya aku tersesat di dalam indahnya matamu dan nggak mau keluar lagi. 🗺️✨",
  "Kopi apa yang paling manis di dunia? Kopi-kirkan kamu setiap detik tanpa henti! ☕🥰",
  "Kamu capek nggak sih? Soalnya dari tadi muter-muter terus di pikiran dan mimpi indahku! 🏃‍♀️💕",
  "Bapak kamu tukang listrik ya? Kok tiap kali natap kamu, ada sengatan cinta bertegangan tinggi di dadaku! ⚡❤️",
  "Cita-citaku dulu mau jadi astronot, tapi sekarang berubah, pengen jadi imam yang selalu mendampingimu! 🌙👰",
  "Aku nggak butuh aplikasi kompas lagi, karena ke mana pun aku pergi, arah hatiku selalu tertuju ke kamu! 🧭💘",
  "Kalau disuruh milih antara bernafas atau mencintaimu, aku bakal hembusin nafas terakhir cuma buat bilang 'I love you'. 🌹❤️",
  "Tahu nggak kenapa gula di tehku nggak manis? Soalnya manisnya udah diborong semua sama wajahmu! 🍯😍"
];

const getCleanTag = (jid) => {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
};

const handler = async (m, { usedPrefix, command, args, hirara, conn, sock }) => {
  const client = hirara || conn || sock || global.mainSock || global.sock;
  let targetJid = m.mentionedJid?.[0];
  if (!targetJid && args[0] && args[0].includes('@')) {
    const cleanNum = args[0].replace(/[^0-9]/g, '');
    if (cleanNum) targetJid = cleanNum + '@s.whatsapp.net';
  }
  if (!targetJid && m.quoted?.sender) {
    targetJid = m.quoted.sender;
  }

  const gombalText = GOMBAL_LIST[Math.floor(Math.random() * GOMBAL_LIST.length)];

  if (targetJid) {
    const targetTag = getCleanTag(targetJid);
    const text = `🌹 *GOMBALAN ROMANTIS MAUT* 🌹\n\n` +
      `💌 *Ditujukan untuk:* @${targetTag}\n\n` +
      `✨ "${gombalText}"\n\n` +
      `_Pasti hatinya langsung meleleh kayak mentega panas tuh!_ 🧈😳`;
    return client.sendMessage(m.chat, { text, mentions: [targetJid] }, { quoted: m });
  }

  const text = `🌹 *GOMBALAN HARI INI* 🌹\n\n` +
    `✨ "${gombalText}"\n\n` +
    `💡 *Tips:* Tag gebetanmu pakai *${usedPrefix + command} @user* biar doi baper!`;

  return client.sendMessage(m.chat, { text }, { quoted: m });
};

handler.help = ['gombal [@user]'];
handler.tags = ['fun'];
handler.command = ['gombal', 'rayu', 'flirt'];
handler.limit = true;
handler.category = 'fun';

export default handler;
