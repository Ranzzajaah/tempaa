/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const handler = async (m, { args }) => {
    const count = Math.min(10, Math.max(1, parseInt(args[0]) || 2));
    const sides = Math.min(100, Math.max(2, parseInt(args[1]) || 6));
    const rolls = Array.from({ length: count }, () => randInt(1, sides));
    const total = rolls.reduce((a, b) => a + b, 0);
    return m.reply(`🎲 *ROLL ${count}x DADU (${sides} sisi)*

🎯 Hasil: ${rolls.join(', ')}
📊 Total: *${total}*`);
};

handler.help = ['rolldice [jumlah] [sisi]'];
handler.tags = ['fun'];
handler.command = ['rolldice', 'dadu'];
handler.limit = true;
handler.register = true;

export default handler;
