/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const MUSUH_TYPES = [
	'Lawan Bebuyutan Sejak TK ⚔️',
	'Musuh Bebuyutan Rebutan Makanan 🍕',
	'Rival Abadi Di Game Online 🎮',
	'Sahabat Tapi Sering Berantem Cekcok 🤼‍♂️',
	'Musuh Karena Mantan 💔'
];

const handler = async (m, { hirara, conn, sock, usedPrefix, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let target1 = m.sender;
	let target2 = null;

	const mentionedJid = m.mentionedJid || [];

	if (mentionedJid.length >= 2) {
		target1 = mentionedJid[0];
		target2 = mentionedJid[1];
	} else if (mentionedJid.length === 1) {
		target2 = mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		target2 = m.quoted.sender;
	} else if (text && text.includes('|')) {
		const parts = text.split('|');
		const name1 = parts[0].trim();
		const name2 = parts[1].trim();

		const rate = Math.floor(Math.random() * 80) + 20;
		const type = MUSUH_TYPES[Math.floor(Math.random() * MUSUH_TYPES.length)];

		const cardBuffer = await generateFunCard({
			title: '⚔️ CEK PERMUSUHAN & RIVAL',
			badgeText: `🔥 ${rate}% RIVAL`,
			titleBg: '#ea580c',
			badgeBg: '#ffea00',
			name: `${name1} vs ${name2}`,
			rate,
			categoryLabel: 'Kategori Rivalitas',
			categoryValue: type,
			descLabel: 'Solusi Pertikaian',
			descValue: 'Gunakan .duel @user untuk menyelesaikan permusuhan di Arena PvP Canvas!',
			footerText: 'Selesaikan percekcokan di Arena Duel Canvas!',
			barColor: '#f97316',
			showMeter: true
		}).catch(() => null);

		const replyMsg = `⚔️ *CEK PERMUSUHAN & RIVALITAS* ⚔️\n\n` +
			`🤼‍♂️ *Rival:* *${name1}* vs *${name2}*\n` +
			`🔥 *Tingkat Permusuhan:* *${rate}%*\n` +
			`🎭 *Kategori Rivalitas:* ${type}\n\n` +
			`👉 _Gunakan .duel @user untuk menyelesaikan permusuhan di Arena PvP Canvas!_ ⚔️`;

		if (cardBuffer) {
			return client.sendMessage(m.chat, { image: cardBuffer, caption: replyMsg }, { quoted: m });
		} else {
			return client.sendMessage(m.chat, { text: replyMsg }, { quoted: m });
		}
	} else {
		return client.sendMessage(m.chat, { text: `⚔️ *CEK PERMUSUHAN & RIVALITAS*\n\nTag 1/2 orang atau tulis 2 nama!\nContoh:\n• *${usedPrefix}cekmusuh @user*\n• *${usedPrefix}cekmusuh @user1 @user2*\n• *${usedPrefix}cekmusuh Tom | Jerry*` }, { quoted: m });
	}

	const rate = Math.floor(Math.random() * 80) + 20;
	const type = MUSUH_TYPES[Math.floor(Math.random() * MUSUH_TYPES.length)];

	const name1 = `@${getCleanTag(target1)}`;
	const name2 = `@${getCleanTag(target2)}`;

	let ppUrl = null;
	if (target1 && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(target1, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '⚔️ CEK PERMUSUHAN & RIVAL',
		badgeText: `🔥 ${rate}% RIVAL`,
		titleBg: '#ea580c',
		badgeBg: '#ffea00',
		name: `${name1} vs ${name2}`,
		rate,
		categoryLabel: 'Kategori Rivalitas',
		categoryValue: type,
		descLabel: 'Solusi Pertikaian',
		descValue: 'Gunakan .duel @user untuk menyelesaikan permusuhan di Arena PvP Canvas!',
		footerText: 'Selesaikan percekcokan di Arena Duel Canvas!',
		barColor: '#f97316',
		showMeter: true,
		ppUrl
	}).catch(() => null);

	const replyMsg = `⚔️ *CEK PERMUSUHAN & RIVALITAS* ⚔️\n\n` +
		`🤼‍♂️ *Rival:* ${name1} vs ${name2}\n` +
		`🔥 *Tingkat Permusuhan:* *${rate}%*\n` +
		`🎭 *Kategori Rivalitas:* ${type}\n\n` +
		`👉 _Gunakan .duel ${name2} untuk menyelesaikan permusuhan di Arena PvP Canvas!_ ⚔️`;

	await client?.sendMessage(m.chat, { react: { text: '⚔️', key: m.key } }).catch(() => null);

	const mentions = [target1, target2].filter(Boolean);
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyMsg,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, { text: replyMsg, mentions }, { quoted: m });
	}
};

handler.command = ['cekmusuh', 'rivalcheck', 'musuh'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek persentase percekcokan dan tingkat permusuhan antara 2 orang dengan Canvas';
handler.register = true;

export default handler;
