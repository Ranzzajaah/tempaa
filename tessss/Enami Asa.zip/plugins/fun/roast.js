/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const ROAST_TEMPLATES = [
  "Mukamu kayak wifi gratis di cafe, banyak yang mau nyambung tapi lemotnya minta ampun!",
  "Otakmu kayak tab browser yang dibuka 100 biji: muter-muter nggak ada yang jalan!",
  "Kamu itu kayak update Windows di jam kerja, datangnya nggak diundang dan bikin orang emosi!",
  "Level kepekaanmu kayak kalkulator rusak, dipencet apa aja tetep Error 404!",
  "Gayamu udah kayak miliarder di Wall Street, padahal saldo ATM kalo ditarik 50rb mesinnya langsung kasihan.",
  "Kamu kalo lari dari kenyataan pasti juara 1 internasional!",
  "Kepribadianmu kayak sinyal edge di tengah hutan, bikin orang nunggu lama dan akhirnya nyerah.",
  "Kamu itu bukti nyata kalau oksigen di bumi ini sangat murah hati.",
  "Kalo kebodohan bisa jadi energi listrik, kamu sendiri udah bisa nerangin seisi pulau Jawa!",
  "Jangan kebanyakan insecure ya, soalnya semua yang kamu takutin tentang dirimu itu beneran nyata kok! 🤣"
];

const getCleanTag = (jid) => {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
};

const handler = async (m, { usedPrefix, command, args, getUser, user, hirara, conn, sock }) => {
  const client = hirara || conn || sock || global.mainSock || global.sock;
  let targetJid = m.mentionedJid?.[0];
  if (!targetJid && args[0] && args[0].includes('@')) {
    const cleanNum = args[0].replace(/[^0-9]/g, '');
    if (cleanNum) targetJid = cleanNum + '@s.whatsapp.net';
  }
  if (!targetJid && m.quoted?.sender) {
    targetJid = m.quoted.sender;
  }
  if (!targetJid) {
    targetJid = m.sender;
  }

  const cleanTag = getCleanTag(targetJid);
  let targetName = '';
  if (targetJid === m.sender) {
    targetName = m.pushName || (user?.nama && user.nama !== 'User' ? user.nama : '');
  } else {
    let uData = null;
    if (typeof getUser === 'function') {
      try { uData = await getUser(targetJid); } catch (_) {}
    }
    const foundName = uData?.nama || uData?.name || (m.quoted?.sender === targetJid ? m.quoted?.pushName : '');
    if (foundName && foundName !== 'User' && !/^\d+$/.test(foundName)) {
      targetName = foundName;
    }
  }

  const roast = ROAST_TEMPLATES[Math.floor(Math.random() * ROAST_TEMPLATES.length)];

  const text = `🔥 *ROASTING MAUT* 🔥\n\n` +
    `🎯 *Korban:* @${cleanTag}${targetName ? ` (${targetName})` : ''}\n\n` +
    `💬 "${roast}"\n\n` +
    `_Bercanda ya bang, jangan dimasukin ke hati nanti sempit!_ 😂`;

  return client.sendMessage(m.chat, { text, mentions: [targetJid] }, { quoted: m });
};

handler.help = ['roast [@user]'];
handler.tags = ['fun'];
handler.command = ['roast', 'roasting', 'hujat'];
handler.limit = true;
handler.category = 'fun';

export default handler;
