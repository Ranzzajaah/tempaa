const pickRandom = (list) => {
    return list[Math.floor(Math.random() * list.length)];
};

const handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`📌 *Contoh Penggunaan:*\n• \`${usedPrefix + command} aku nikah?\``);
    }

    const units = ['detik', 'menit', 'jam', 'hari', 'minggu', 'bulan', 'tahun', 'abad'];
    const randomNum = Math.floor(Math.random() * 100) + 1;
    const randomUnit = pickRandom(units);

    const result = `Kayaknya ${randomNum} ${randomUnit} lagi...`;

    await m.reply(result);
};

handler.help = ['', 'kah'].map(v => 'kapan' + v + ' <text>?');
handler.tags = ['kerang', 'fun'];
handler.command = /^kapan(kah)?$/i;
handler.owner = false;

export default handler;