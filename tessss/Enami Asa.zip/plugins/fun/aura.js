/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const KECANTIKAN_TYPES = [
	'Bidadari Surga Turun Ke Bumi ✨👸',
	'Cewek Skena Estetik Korean Look 💄🌸',
	'Manis Alami Tanpa Filter 💕',
	'Imut Menggemaskan Kayak Anime Girl 👧',
	'Elegan & Anggun Mempesona 🌹'
];

const handler = async (m, { hirara, conn, sock, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		targetJid = m.sender;
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	const rate = Math.floor(Math.random() * 51) + 50;
	const type = KECANTIKAN_TYPES[Math.floor(Math.random() * KECANTIKAN_TYPES.length)];

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '👸 CEK AURA KECANTIKAN',
		badgeText: `✨ ${rate}% AURA`,
		titleBg: '#f43f5e',
		badgeBg: '#ffea00',
		name: cardName,
		rate,
		categoryLabel: 'Kategori Aura',
		categoryValue: type,
		descLabel: 'Efek Pesona Aura',
		descValue: 'Tetaplah tersenyum karena senyummu menyinari dunia!',
		footerText: 'Kecantikan sejati bersinar dari kebaikan hatimu!',
		barColor: '#f43f5e',
		ppUrl
	}).catch(() => null);

	const replyText = `👸 *CEK SKOR KECANTIKAN / AURA* 👸\n\n` +
		`👤 *Subjek:* ${captionTag}\n` +
		`✨ *Skor Aura Kecantikan:* *${rate}%*\n` +
		`👑 *Kategori Aura:* ${type}\n\n` +
		`_Pesan: Tetaplah tersenyum karena senyummu menyinari hariku!_ 💖`;

	await client?.sendMessage(m.chat, { react: { text: '✨', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['aura', 'cekaura', 'auracheck'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek tingkat pesona aura keindahan dan ketampanan seseorang dengan Canvas';
handler.register = true;

export default handler;
