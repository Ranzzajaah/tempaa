/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const answers = [
    "Bisa banget! Percaya diri aja!",
    "Hmm, kayaknya susah deh.",
    "Tentu bisa! Semangat!",
    "Nggak bisa, maaf.",
    "Mungkin bisa, kalau usaha keras.",
    "Pasti bisa! Jangan menyerah!",
    "Agak susah sih, tapi bisa dicoba.",
    "Bisa kok! Yakin deh!",
    "Kayaknya nggak deh.",
    "Bisa! Ayo buktikan!",
    "Hmm... aku ragu.",
    "Bisa banget! Gas terus!",
    "Nggak bisa, coba yang lain.",
    "Bisa! Percaya sama diri sendiri!",
    "Susah, tapi bukan berarti nggak mungkin.",
    "Absolutely! Kamu pasti bisa!",
    "Kayaknya perlu usaha ekstra nih.",
    "Bisa! Jangan ragukan dirimu!",
    "Hmm, coba lagi nanti deh.",
    "Bisa! Aku percaya kamu!"
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} aku lulus ujian?*`);

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const caption = `💪 *PERTANYAAN*\n> ${text}\n\n🎱 *JAWABAN*\n> ${answer}`;

    if (doReply) return doReply(caption);
};

handler.help = ["bisakah <pertanyaan>"];
handler.tags = ["fun"];
handler.command = ["bisakah"];
handler.register = true;
handler.limit = true;

export default handler;
