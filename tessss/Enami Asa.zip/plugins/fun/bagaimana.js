/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const answers = [
    "Caranya gampang, ya tinggal dilakuin aja!",
    "Hmm, susah dijelasin sih. Coba aja dulu!",
    "Dengan usaha dan doa pastinya.",
    "Ya begitulah caranya.",
    "Aku kurang tau sih, coba cari referensi lain.",
    "Pelan-pelan aja, nanti juga bisa.",
    "Dengan kerja keras dan pantang menyerah!",
    "Pertama, percaya sama diri sendiri dulu.",
    "Hmm, tiap orang beda-beda sih caranya.",
    "Ikutin kata hatimu aja.",
    "Belajar dari yang sudah berpengalaman.",
    "Step by step, jangan terburu-buru.",
    "Dengan tekad yang kuat!",
    "Mulai dari yang kecil dulu.",
    "Konsisten aja, nanti juga bisa.",
    "Jangan overthinking, langsung action!",
    "Gampang! Tinggal mulai aja!",
    "Caranya? Ya dicoba dulu!",
    "Dengan strategi yang tepat.",
    "Hmm, aku juga masih belajar sih."
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} cara jadi sukses?*`);

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const caption = `📋 *PERTANYAAN*\n> ${text}\n\n🎱 *JAWABAN*\n> ${answer}`;

    if (doReply) return doReply(caption);
};

handler.help = ["bagaimana <pertanyaan>"];
handler.tags = ["fun"];
handler.command = ["bagaimana"];
handler.register = true;
handler.limit = true;

export default handler;
