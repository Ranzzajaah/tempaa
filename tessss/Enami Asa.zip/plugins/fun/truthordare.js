/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const TRUTHS = [
  "Siapa orang terakhir yang kamu stalk di Instagram/WhatsApp?",
  "Apa rahasia memalukan yang belum pernah kamu ceritain ke siapa pun di grup ini?",
  "Kapan terakhir kali kamu bohong ke orang tua dan tentang apa?",
  "Pernah nggak suka sama pacar atau gebetan temen sendiri?",
  "Hal paling cringe apa yang pernah kamu lakuin demi menarik perhatian gebetan?",
  "Kalau bisa tukar hidup sama salah satu member di grup ini selama 24 jam, mau tukar sama siapa dan kenapa?",
  "Pernah ngupil terus diusap ke bawah meja nggak? Jujur!",
  "Sebutkan 1 hal yang paling kamu benci dari diri kamu sendiri tapi orang lain nggak tahu!"
];

const DARES = [
  "Kirim pesan 'Aku sayang banget sama kamu' ke kontak ke-3 di riwayat chat WhatsApp-mu!",
  "Voice note nyanyi lagu balonku ada 5 versi nada seriosa ke grup ini sekarang!",
  "Ganti nama profil WhatsApp kamu jadi 'Penggemar Rahasia Bot' selama 1 jam!",
  "Kirim foto selfie muka paling jelek / aib kamu ke grup ini tanpa diedit!",
  "Puji salah satu member di grup ini yang paling jarang kamu ajak ngobrol secara lebay!",
  "Tulis di status WhatsApp: 'Aku lagi galau berat, tolong temenin makan es krim 😭' selama 15 menit!",
  "Kirim stiker paling absurd yang kamu punya 5 kali berturut-turut!"
];

const handler = async (m, { args, usedPrefix, command }) => {
  const type = args[0] ? args[0].toLowerCase() : (command.toLowerCase() === 'truth' ? 't' : command.toLowerCase() === 'dare' ? 'd' : '');

  if (type === 't' || type === 'truth') {
    const truth = TRUTHS[Math.floor(Math.random() * TRUTHS.length)];
    return m.reply(`🗣️ *TRUTH CHALLENGE* 🗣️\n\n"${truth}"\n\n_Jawab dengan jujur ya, jangan ada dusta di antara kita!_ 🤫`);
  }

  if (type === 'd' || type === 'dare') {
    const dare = DARES[Math.floor(Math.random() * DARES.length)];
    return m.reply(`🔥 *DARE CHALLENGE* 🔥\n\n"${dare}"\n\n_Lakukan tantangannya dan kirim buktinya sekarang!_ 😈`);
  }

  const randomType = Math.random() < 0.5 ? 'Truth' : 'Dare';
  const challenge = randomType === 'Truth' 
    ? TRUTHS[Math.floor(Math.random() * TRUTHS.length)]
    : DARES[Math.floor(Math.random() * DARES.length)];

  return m.reply(`🎲 *TRUTH OR DARE* 🎲\n\n🎯 *Kategori Terpilih:* *${randomType}*\n\n📜 *Tantangan:*\n"${challenge}"\n\n💡 *Pilihan lain:* *${usedPrefix}truth* atau *${usedPrefix}dare*`);
};

handler.help = ['tod', 'truth', 'dare'];
handler.tags = ['fun'];
handler.command = ['tod', 'truth', 'dare', 'tord'];
handler.limit = true;
handler.category = 'fun';

export default handler;
