/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const WATAK_LIST = [
	{ tipe: 'Sanguinis (Periang & Ceria) ✨', desc: 'Suka bersosialisasi, ceria, & selalu jadi pusat perhatian.' },
	{ tipe: 'Koleris (Pemimpin & Tegas) 👑', desc: 'Berjiwa pemimpin, mandiri, ambisius, & berani mengambil risiko.' },
	{ tipe: 'Melankolis (Perasa & Detail) 🎨', desc: 'Pemikir mendalam, perfeksionis, sangat setia, & perasa halus.' },
	{ tipe: 'Plegmatis (Damai & Santai) 🌿', desc: 'Penyabar, tidak suka konflik, pendengar yang baik, & tenang.' }
];

const handler = async (m, { hirara, conn, sock, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		targetJid = m.sender;
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	const watak = WATAK_LIST[Math.floor(Math.random() * WATAK_LIST.length)];
	const empati = Math.floor(Math.random() * 50) + 50;

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🧠 ANALISIS WATAK ASLI',
		badgeText: `💖 ${empati}% EMPATI`,
		titleBg: '#0284c7',
		badgeBg: '#ffea00',
		name: cardName,
		rate: empati,
		categoryLabel: 'Tipe Kepribadian',
		categoryValue: watak.tipe,
		descLabel: 'Karakteristik Utama',
		descValue: watak.desc,
		footerText: 'Kenali dirimu & hargai karakter kepribadian sesamamu!',
		barColor: '#38bdf8',
		ppUrl
	}).catch(() => null);

	const replyText = `🧠 *ANALISIS SIFAT & WATAK ASLI* 🧠\n\n` +
		`👤 *Subjek:* ${captionTag}\n` +
		`🎭 *Tipe Kepribadian:* ${watak.tipe}\n` +
		`💖 *Tingkat Empati:* ${empati}%\n\n` +
		`📝 *Karakteristik:* _"${watak.desc}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🧠', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['cekwatak', 'ceksifat', 'watak'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Analisis sifat dan kepribadian watak asli seseorang dengan Canvas';
handler.register = true;

export default handler;
