/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const WOULD_YOU_RATHER = [
    'Bisa terbang TANPA bisa berhenti, atau bisa berenang TANPA bisa naik ke darat?',
    'Selalu telat 10 menit, atau selalu terlalu cepat 1 jam?',
    'Kehilangan semua foto lama, atau kehilangan semua kontak HP?',
    'Hidup tanpa musik, atau hidup tanpa film?',
    'Punya uang tak terbatas tapi sendirian di pulau terpencil, atau hidup sederhana bersama orang tercinta?',
    'Bisa membaca pikiran orang lain, atau bisa melihat masa depan 5 menit ke depan?',
    'Gak pernah bisa makan makanan manis lagi, atau gak pernah bisa makan makanan asin/pedas lagi?',
    'Bisa menghentikan waktu, atau bisa memundurkan waktu 1 jam?',
    'Gak punya akses internet selamanya, atau gak pernah bepergian keluar kota selamanya?',
    'Tidur cuma 2 jam tanpa capek, atau makan apa aja tanpa takut naik berat badan?'
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m) => {
    return m.reply(`🤔 *WOULD YOU RATHER*

${pick(WOULD_YOU_RATHER)}`);
};

handler.help = ['wouldyourather'];
handler.tags = ['fun'];
handler.command = ['wouldyourather', 'wyr'];
handler.limit = true;
handler.register = true;

export default handler;
