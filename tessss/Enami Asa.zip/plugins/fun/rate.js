/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const ratings = [
    { score: "10/10", comment: "Sempurna! Nggak ada duanya!" },
    { score: "9/10", comment: "Hampir sempurna! Keren banget!" },
    { score: "8/10", comment: "Bagus banget! Mantap!" },
    { score: "7/10", comment: "Cukup bagus, di atas rata-rata!" },
    { score: "6/10", comment: "Lumayan, bisa lebih baik lagi." },
    { score: "5/10", comment: "Biasa aja sih, standar." },
    { score: "4/10", comment: "Hmm, kurang sedikit." },
    { score: "3/10", comment: "Perlu banyak perbaikan." },
    { score: "2/10", comment: "Aduh, masih jauh dari bagus." },
    { score: "1/10", comment: "Maaf, tapi ini parah." },
    { score: "100/10", comment: "LEGEND! Beyond perfect!" },
    { score: "11/10", comment: "Melebihi ekspektasi!" },
    { score: "69/100", comment: "Nice..." },
    { score: "420/10", comment: "BLAZING!" },
    { score: "∞/10", comment: "Unlimited power!" },
    { score: "7.5/10", comment: "Solid! Good job!" },
    { score: "8.5/10", comment: "Impressive!" },
    { score: "9.5/10", comment: "Near perfection!" },
    { score: "-1/10", comment: "Aku nggak tau harus ngomong apa..." },
    { score: "???/10", comment: "Error 404: Rating not found." }
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} wajahku*`);

    const rating = ratings[Math.floor(Math.random() * ratings.length)];
    const caption = `⭐ *RATING*\n\n> "${text}"\n\n🏆 *SKOR:* ${rating.score}\n> ${rating.comment}`;

    if (doReply) return doReply(caption);
};

handler.help = ["rate <hal/teks>"];
handler.tags = ["fun"];
handler.command = ["rate"];
handler.register = true;
handler.limit = true;

export default handler;
