/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const SESSIONS = new Map();

const TRIVIA = [
    { q: 'Apa ibu kota Jepang?', a: 'tokyo' },
    { q: 'Berapa jumlah benua di dunia?', a: '7' },
    { q: 'Planet apa yang dijuluki Planet Merah?', a: 'mars' },
    { q: 'Apa nama mata uang Jepang?', a: 'yen' },
    { q: 'Hewan apa yang dijuluki raja hutan?', a: 'singa' },
    { q: 'Berapa jumlah hari dalam tahun kabisat?', a: '366' },
    { q: 'Apa bahasa pemrograman yang dibuat oleh Brendan Eich?', a: 'javascript' },
    { q: 'Apa nama gas yang dihirup manusia untuk bernapas?', a: 'oksigen' },
    { q: 'Siapa presiden pertama Republik Indonesia?', a: 'soekarno' },
    { q: 'Apa mamalia terbesar di dunia?', a: 'paus biru' },
    { q: 'Unsur kimia dengan lambang Au adalah?', a: 'emas' },
    { q: 'Berapa jumlah warna pada pelangi?', a: '7' },
    { q: 'Gunung tertinggi di dunia adalah?', a: 'everest' },
    { q: 'Organ tubuh manusia yang berfungsi memompa darah adalah?', a: 'jantung' },
    { q: 'Apa ibu kota negara Australia?', a: 'canberra' },
    { q: 'Penemu lampu pijar adalah?', a: 'thomas alva edison' },
    { q: 'Apa nama candi Buddha terbesar di dunia yang ada di Indonesia?', a: 'borobudur' },
    { q: 'Pulau terbesar di Indonesia adalah pulau?', a: 'papua' },
    { q: 'Apa nama alat musik gesek berkulit kayu dengan 4 senar?', a: 'biola' },
    { q: 'Berapa sisi yang dimiliki bangun ruang kubus?', a: '6' },
    { q: 'Negara manakah yang terkenal dengan Menara Pisa?', a: 'italia' },
    { q: 'Siapakah penemu teori relativitas?', a: 'albert einstein' },
    { q: 'Burung yang tidak bisa terbang namun pandai berenang di kutub adalah?', a: 'penguin' },
    { q: 'Bumi berputar pada porosnya disebut?', a: 'rotasi' },
    { q: 'Apa mata uang negara Korea Selatan?', a: 'won' }
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m, { text, args, usedPrefix, command }) => {
    const cmd = command.toLowerCase();
    const prefix = usedPrefix || '.';

    if (cmd === 'trivia') {
        const item = pick(TRIVIA);
        SESSIONS.set(m.chat, item.a.toLowerCase());
        return m.reply(`🧠 *TRIVIA TIME!*

${item.q}

Jawab dengan: *${prefix}jawabtrivia [jawaban]*`);
    }

    if (cmd === 'jawabtrivia') {
        const ans = (args.join(' ') || text || '').toLowerCase().trim();
        const correct = SESSIONS.get(m.chat);
        if (!correct) return m.reply(`❌ Belum ada trivia aktif di chat ini. Ketik *${prefix}trivia* dulu!`);
        if (!ans) return m.reply(`📌 Ketik jawabanmu: *${prefix}jawabtrivia <jawaban>*`);

        if (ans === correct) {
            SESSIONS.delete(m.chat);
            return m.reply(`🎉 *BENAR!* Jawaban kamu tepat: *${correct.toUpperCase()}*! Kamu pintar banget!`);
        } else {
            return m.reply(`❌ Salah! Coba tebak lagi atau ketik *${prefix}trivia* untuk soal baru.`);
        }
    }
};

handler.help = ['trivia', 'jawabtrivia <jawaban>'];
handler.tags = ['fun'];
handler.command = ['trivia', 'jawabtrivia'];
handler.limit = true;
handler.register = true;

export default handler;
