const handler = async (m, { text, usedPrefix, command }) => {
    const category = command.replace(/cek$/i, '').toUpperCase();
    const randomPercent = Math.floor(Math.random() * 101);

    const resultText = `
────〔 *${command}* 〕────

${category} LEVEL *${randomPercent}*% 

Seberapapun *${category}* mu, tetap *SYUKURI* itu! ✨`.trim();

    await m.reply(resultText);
};

handler.help = ['gay', 'pintar', 'cantik', 'ganteng', 'gabut', 'gila', 'lesbi', 'stress', 'bucin', 'jones', 'sadboy'].map(v => v + 'cek');
handler.tags = ['kerang', 'fun'];
handler.command = /^(gay|pintar|cantik|ganteng|gabut|gila|lesbi|stress?|bucin|jones|sadboy)cek/i;
handler.owner = false;

export default handler;