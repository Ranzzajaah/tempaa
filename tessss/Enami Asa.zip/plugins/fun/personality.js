/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const PERSONALITY_TEST = [
    { trait: 'Pemimpin Alami 👑', desc: 'Kamu suka mengambil inisiatif, tegas, dan selalu diandalkan banyak orang saat genting.' },
    { trait: 'Si Kreatif 🎨', desc: 'Otakmu penuh ide unik, spontan, dan sering melihat hal dari sudut pandang yang gak kepikiran orang lain.' },
    { trait: 'Si Penenang 🍃', desc: 'Kehadiranmu membawa aura damai, bikin orang sekitar merasa tenang, nyaman, dan didengarkan.' },
    { trait: 'Si Petualang 🚀', desc: 'Kamu selalu haus hal baru, penasaran tinggi, dan benci rutinitas yang monoton membosankan.' },
    { trait: 'Si Analitis 🔍', desc: 'Kamu sangat teliti, logis, dan berpikir matang sebelum mengambil setiap keputusan.' },
    { trait: 'Sahabat Sejati 💖', desc: 'Kamu loyal, setia kawan, dan selalu ada buat mendengarkan curhatan teman-temanmu.' }
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m) => {
    const p = pick(PERSONALITY_TEST);
    return m.reply(`🧬 *KEPRIBADIANMU HARI INI*

*${p.trait}*
${p.desc}`);
};

handler.help = ['personality'];
handler.tags = ['fun'];
handler.command = ['personality', 'kepribadian'];
handler.limit = true;
handler.register = true;

export default handler;
