/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const answers = [
    "Karena memang sudah takdirnya begitu.",
    "Hmm, pertanyaan bagus! Aku juga bingung.",
    "Karena itulah cara kerjanya.",
    "Karena Tuhan berkehendak demikian.",
    "Aku nggak tau, cari di Google aja.",
    "Karena ya gitu aja.",
    "Mungkin karena kebetulan?",
    "Karena dunia memang penuh misteri.",
    "Hmm, sulit dijelaskan sih.",
    "Karena alam semesta bekerja dengan cara yang misterius.",
    "Aku juga penasaran, kenapa ya?",
    "Karena hal tersebut memang seharusnya terjadi.",
    "Pertanyaan yang bagus! Sayangnya aku nggak punya jawabannya.",
    "Karena itulah keunikan hidup.",
    "Karena setiap hal punya alasannya masing-masing.",
    "Hmm... aku butuh waktu untuk memikirkannya.",
    "Karena begitulah logikanya.",
    "Aku rasa karena memang harus begitu.",
    "Karena segala sesuatu saling berhubungan.",
    "Nah itu aku juga mikir!"
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} langit biru?*`);

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const caption = `🤔 *PERTANYAAN*\n> ${text}\n\n🎱 *JAWABAN*\n> ${answer}`;

    if (doReply) return doReply(caption);
};

handler.help = ["mengapa <pertanyaan>"];
handler.tags = ["fun"];
handler.command = ["mengapa"];
handler.register = true;
handler.limit = true;

export default handler;
