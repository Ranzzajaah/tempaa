/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const GAYA_STALKER = [
	{ tipe: 'Stalker Profesional 😎', desc: 'Sering kepoin story sampai ke postingan 3 tahun lalu!' },
	{ tipe: 'Pengagum Rahasia 🤫', desc: 'Cuma berani ngeliatin foto profil tanpa berani nge-chat.' },
	{ tipe: 'Detektif Media Sosial 🕵️‍♂️', desc: 'Tahu semua seluk beluk teman & aktivitas harianmu.' },
	{ tipe: 'Stalker Gagal 😅', desc: 'Niatnya kepoin story tapi kepencet love postingan lama!' }
];

const handler = async (m, { hirara, conn, sock, text }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	let targetJid = null;
	let name = text?.trim();

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (!name) {
		targetJid = m.sender;
	}

	let captionTag = name;
	let cardName = name;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;
		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	const rate = Math.floor(Math.random() * 60) + 40;
	const stalker = GAYA_STALKER[Math.floor(Math.random() * GAYA_STALKER.length)];

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🕵️‍♂️ CEK TINGKAT STALKER',
		badgeText: `🔍 ${rate}% STALKER`,
		titleBg: '#0f766e',
		badgeBg: '#ffea00',
		name: cardName,
		rate,
		categoryLabel: 'Tipe Stalker',
		categoryValue: stalker.tipe,
		descLabel: 'Perilaku Terdeteksi',
		descValue: stalker.desc,
		footerText: 'Hati-hati dalam menjelajahi linimasa sosial media!',
		barColor: '#14b8a6',
		ppUrl
	}).catch(() => null);

	const replyText = `🕵️‍♂️ *CEK TINGKAT STALKER* 🕵️‍♂️\n\n` +
		`👤 *Subjek:* ${captionTag}\n` +
		`🔍 *Level Stalker:* *${rate}%*\n` +
		`🎭 *Tipe Stalker:* ${stalker.tipe}\n\n` +
		`📝 *Keterangan:* _"${stalker.desc}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🕵️‍♂️', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: replyText,
			mentions
		}, { quoted: m });
	}
};

handler.command = ['cekstalker', 'stalkerrate'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek seberapa sering seseorang kepoin orang lain dengan Canvas';
handler.register = true;

export default handler;
