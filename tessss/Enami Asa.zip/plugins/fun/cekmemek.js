/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const getTarget = async (m, text) => {
	let targetJid = null;
	let targetName = '';

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (text && text.trim().length > 0) {
		const cleanNum = text.replace(/[^0-9]/g, '');
		if (cleanNum.length >= 7 && cleanNum.length <= 15) {
			targetJid = cleanNum + '@s.whatsapp.net';
		} else {
			targetName = text.trim();
		}
	} else {
		targetJid = m.sender;
	}

	let cardName = targetName;
	let captionTag = targetName;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;

		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	return { targetJid, targetName: cardName, captionTag: captionTag || cardName };
};

const handler = async (m, { text, reply, hirara, conn, sock }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	const { targetJid, targetName, captionTag } = await getTarget(m, text);

	const bentuk = ['tembem kenyal', 'mulus glowing', 'belah tengah estetik', 'tebal menggoda', 'pink merona', 'mungil imut'][Math.floor(Math.random() * 6)];
	const warna = ['pink natural', 'putih mulus', 'coklat manis', 'cerah glowing', 'pink muda'][Math.floor(Math.random() * 5)];
	const aroma = ['harum vanilla', 'wangi strawberry', 'segar semerbak', 'wangi melati', 'harum sabun mandi'][Math.floor(Math.random() * 5)];
	const kerapatan = Math.floor(Math.random() * 51) + 50;

	let catatan = '';
	if (kerapatan > 85) catatan = 'Rapat banget bak gerbang istana, idaman sejuta umat! 🏰✨';
	else if (kerapatan > 70) catatan = 'Pas mantap dan menggoda, bikin betah berlama-lama! 🌸';
	else catatan = 'Natural alami, penuh pesona kehangatan! 🍓';

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🌸 CEK MEMEK CHECK',
		badgeText: `🔒 ${kerapatan}% RAPAT`,
		titleBg: '#f43f5e',
		badgeBg: '#ffea00',
		name: targetName,
		rate: kerapatan,
		categoryLabel: 'Bentuk & Warna',
		categoryValue: `${bentuk} • ${warna}`,
		descLabel: 'Aroma & Kesan',
		descValue: catatan,
		footerText: 'Analisis kecantikan & estetika alami 🌸',
		barColor: '#fb7185',
		ppUrl
	}).catch(() => null);

	const caption = `🌸 *ʜᴀsɪʟ ᴄᴇᴋ ᴍᴇᴍᴇᴋ* 🌸\n\n• 👤 *ᴛᴀʀɢᴇᴛ:* ${captionTag}\n• ✨ *ʙᴇɴᴛᴜᴋ:* ${bentuk}\n• 🎨 *ᴡᴀʀɴᴀ:* ${warna}\n• 🍓 *ᴀʀᴏᴍᴀ:* ${aroma}\n• 🔒 *ᴛɪɴɢᴋᴀᴛ ᴋᴇʀᴀᴘᴀᴛᴀɴ:* ${kerapatan}%\n• 💬 *ᴄᴀᴛᴀᴛᴀɴ:* _"${catatan}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🌸', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: caption,
			mentions
		}, { quoted: m });
	}
};

handler.help = ['cekmemek <@tag/nama>'];
handler.tags = ['fun'];
handler.command = ['cekmemek'];
handler.limit = true;

export default handler;
