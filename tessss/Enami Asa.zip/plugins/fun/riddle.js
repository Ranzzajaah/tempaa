/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const SESSIONS = new Map();

const RIDDLE = [
    { q: 'Makin dikeringkan, makin basah. Apa itu?', a: 'handuk' },
    { q: 'Punya kunci tapi tidak bisa membuka pintu. Apa itu?', a: 'piano' },
    { q: 'Semakin diambil, semakin besar. Apa itu?', a: 'lubang' },
    { q: 'Berjalan tanpa kaki, menangis tanpa mata. Apa itu?', a: 'awan' },
    { q: 'Selalu datang tapi tidak pernah sampai. Apa itu?', a: 'besok' },
    { q: 'Punya leher tapi tidak punya kepala. Apa itu?', a: 'baju' },
    { q: 'Benda apa yang kalau dibalik berkurang nilainya 3?', a: 'angka 9' },
    { q: 'Benda apa yang selalu di depan mata tapi tidak bisa dilihat?', a: 'masa depan' },
    { q: 'Punya banyak gigi tapi tidak bisa menggigit. Apa itu?', a: 'sisir' },
    { q: 'Punya satu mata tapi tidak bisa melihat. Apa itu?', a: 'jarum' },
    { q: 'Jika kamu memilikiku, kamu ingin membagikanku. Jika kamu membagikanku, kamu tidak memilikiku lagi. Apa itu?', a: 'rahasia' }
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m, { text, args, usedPrefix, command }) => {
    const cmd = command.toLowerCase();
    const prefix = usedPrefix || '.';

    if (cmd === 'riddle' || cmd === 'tekateki') {
        const item = pick(RIDDLE);
        SESSIONS.set(m.chat, item.a.toLowerCase());
        return m.reply(`🧩 *TEKA-TEKI*

${item.q}

Jawab dengan: *${prefix}jawabriddle [jawaban]*`);
    }

    if (cmd === 'jawabriddle' || cmd === 'jawabriddle2') {
        const ans = (args.join(' ') || text || '').toLowerCase().trim();
        const correct = SESSIONS.get(m.chat);
        if (!correct) return m.reply(`❌ Belum ada teka-teki aktif. Ketik *${prefix}riddle* dulu!`);
        if (!ans) return m.reply(`📌 Ketik jawabanmu: *${prefix}jawabriddle <jawaban>*`);

        if (ans === correct) {
            SESSIONS.delete(m.chat);
            return m.reply(`🎉 *BENAR!* Jawabannya adalah: *${correct.toUpperCase()}*!`);
        } else {
            return m.reply('❌ Salah, coba tebak lagi!');
        }
    }
};

handler.help = ['riddle', 'jawabriddle <jawaban>'];
handler.tags = ['fun'];
handler.command = ['riddle', 'tekateki', 'jawabriddle', 'jawabriddle2'];
handler.limit = true;
handler.register = true;

export default handler;
