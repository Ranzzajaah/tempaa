/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const TAROT_CARDS = [
  { name: 'The Fool (0)', meaning: 'Awal baru, petualangan tak terduga, keberanian mengambil resiko!', icon: '🃏', type: 'Positif' },
  { name: 'The Magician (I)', meaning: 'Kekuatan tekad, potensi besar yang siap diwujudkan menjadi kenyataan.', icon: '🪄', type: 'Positif' },
  { name: 'The High Priestess (II)', meaning: 'Intuisi yang sangat kuat, rahasia tersembunyi akan segera terungkap.', icon: '🌙', type: 'Netral' },
  { name: 'The Empress (III)', meaning: 'Kelimpahan rezeki, kenyamanan hidup, dan cinta kasih bersemi.', icon: '👑', type: 'Sangat Positif' },
  { name: 'The Emperor (IV)', meaning: 'Kestabilan, disiplin, dan kekuasaan untuk mengontrol situasi rumit.', icon: '🏛️', type: 'Positif' },
  { name: 'The Lovers (VI)', meaning: 'Keputusan penting dalam hubungan, harmoni dua jiwa dan komitmen.', icon: '💑', type: 'Positif' },
  { name: 'The Chariot (VII)', meaning: 'Kemenangan besar melalui perjuangan gigih dan fokus yang tinggi.', icon: '🛡️', type: 'Positif' },
  { name: 'The Wheel of Fortune (X)', meaning: 'Roda takdir berputar! Nasib mujur dan perubahan besar segera tiba.', icon: '🎡', type: 'Sangat Positif' },
  { name: 'The Tower (XVI)', meaning: 'Kehancuran ilusi, perubahan mendadak yang membawa pelajaran berharga.', icon: '⚡', type: 'Tantangan' },
  { name: 'The Star (XVII)', meaning: 'Harapan baru, inspirasi tak terbatas, dan kedamaian jiwa.', icon: '⭐', type: 'Sangat Positif' },
  { name: 'The Sun (XIX)', meaning: 'Kebahagiaan puncak, kesuksesan mutlak, dan energi yang meluap-luap!', icon: '☀️', type: 'Sangat Positif' },
  { name: 'The World (XXI)', meaning: 'Pencapaian sempurna, siklus hidup tuntas dengan hasil memuaskan.', icon: '🌍', type: 'Sangat Positif' }
];

const getCleanTag = (jid) => {
  if (!jid) return '';
  return String(jid).split('@')[0].split(':')[0];
};

const handler = async (m, { hirara, conn, sock }) => {
  const client = hirara || conn || sock || global.mainSock || global.sock;
  const card = TAROT_CARDS[Math.floor(Math.random() * TAROT_CARDS.length)];
  const senderTag = getCleanTag(m.sender);

  const text = `🎴 *BACAAN KARTU MYSTIC TAROT* 🎴\n\n` +
    `👤 *Pembacaan Untuk:* @${senderTag}\n\n` +
    `🔮 *Kartu Terpilih:* ${card.icon} *${card.name}*\n` +
    `🏷️ *Aura Energi:* _${card.type}_\n\n` +
    `📜 *Arti & Petunjuk:*\n"${card.meaning}"\n\n` +
    `✨ _Biarkan takdir menuntun langkahmu hari ini!_`;

  return client.sendMessage(m.chat, { text, mentions: [m.sender] }, { quoted: m });
};

handler.help = ['tarot'];
handler.tags = ['fun'];
handler.command = ['tarot', 'bacatarot', 'kartutarot'];
handler.limit = true;
handler.category = 'fun';

export default handler;
