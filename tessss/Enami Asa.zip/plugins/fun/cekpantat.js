/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const getTarget = async (m, text) => {
	let targetJid = null;
	let targetName = '';

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (text && text.trim().length > 0) {
		const cleanNum = text.replace(/[^0-9]/g, '');
		if (cleanNum.length >= 7 && cleanNum.length <= 15) {
			targetJid = cleanNum + '@s.whatsapp.net';
		} else {
			targetName = text.trim();
		}
	} else {
		targetJid = m.sender;
	}

	let cardName = targetName;
	let captionTag = targetName;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;

		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	return { targetJid, targetName: cardName, captionTag: captionTag || cardName };
};

const handler = async (m, { text, reply, hirara, conn, sock }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	const { targetJid, targetName, captionTag } = await getTarget(m, text);

	const bentuk = ['semok bulat', 'padat berisi', 'tebal menggoda', 'mulus semok', 'ramping estetik', 'padat mantap'][Math.floor(Math.random() * 6)];
	const kekenyalan = Math.floor(Math.random() * 41) + 60;
	const ketahanan = ['kebal tepukan', 'goyangannya maut', 'bikin candu', 'lembut gemoy', 'mantul-mantul'][Math.floor(Math.random() * 5)];

	let catatan = '';
	if (kekenyalan > 85) catatan = 'Semok mantap tak tertandingi, bikin mata terpana! 🍑✨';
	else if (kekenyalan > 70) catatan = 'Bentuk proporsional pas di tangan dan gemoy! 💖';
	else catatan = 'Ramping estetik dan lincah bergoyang! 💫';

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🍑 CEK PANTAT CHECK',
		badgeText: `💫 ${kekenyalan}% KENYAL`,
		titleBg: '#f97316',
		badgeBg: '#ffea00',
		name: targetName,
		rate: kekenyalan,
		categoryLabel: 'Bentuk & Keistimewaan',
		categoryValue: `${bentuk} • ${ketahanan}`,
		descLabel: 'Catatan Kesemokan',
		descValue: catatan,
		footerText: 'Analisis kesemokan & estetika alami 🍑',
		barColor: '#fb923c',
		ppUrl
	}).catch(() => null);

	const caption = `🍑 *ʜᴀsɪʟ ᴄᴇᴋ ᴘᴀɴᴛᴀᴛ* 🍑\n\n• 👤 *ᴛᴀʀɢᴇᴛ:* ${captionTag}\n• ✨ *ʙᴇɴᴛᴜᴋ:* ${bentuk}\n• 💫 *ᴛɪɴɢᴋᴀᴛ ᴋᴇᴋᴇɴʏᴀʟᴀɴ:* ${kekenyalan}%\n• ⚡ *ᴋᴇɪsᴛɪᴍᴇᴡᴀᴀɴ:* ${ketahanan}\n• 💬 *ᴄᴀᴛᴀᴛᴀɴ:* _"${catatan}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🍑', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: caption,
			mentions
		}, { quoted: m });
	}
};

handler.help = ['cekpantat <@tag/nama>'];
handler.tags = ['fun'];
handler.command = ['cekpantat'];
handler.limit = true;

export default handler;
