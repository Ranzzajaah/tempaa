/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const answers = [
    "Hmm, aku coba ya... Kamu lagi mikirin makanan!",
    "Aku tebak... Kamu lagi gabut!",
    "Coba ya... Kayaknya kamu lagi seneng!",
    "Hmm, aku rasa kamu lagi bingung.",
    "Aku coba nebak... Kamu lagi kangen seseorang?",
    "Kayaknya kamu lagi santai deh.",
    "Aku tebak kamu lagi scroll HP terus.",
    "Hmm, pasti lagi bosan ya?",
    "Coba ditebak... Kamu lagi pengen jalan-jalan!",
    "Aku rasa kamu lagi butuh hiburan.",
    "Hmm, kayaknya kamu lagi happy!",
    "Aku coba... Kamu pasti lagi penasaran!",
    "Tebakan aku: kamu lagi rebahan.",
    "Hmm, kamu mungkin lagi mikirin seseorang spesial.",
    "Aku coba: kamu lagi mau curhat?",
    "Kayaknya kamu lagi pengen main game!",
    "Hmm, aku tebak kamu lagi dengerin musik.",
    "Coba aku tebak... Kamu lagi di kamar!",
    "Aku rasa kamu lagi waiting for something.",
    "Hmm, tebakan aku: kamu butuh temen ngobrol!"
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} tebak apa yang aku pikirkan*`);

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const caption = `🎯 *PERMINTAAN*\n> ${text}\n\n🎱 *RESPON*\n> ${answer}`;

    if (doReply) return doReply(caption);
};

handler.help = ["coba <pertanyaan>"];
handler.tags = ["fun"];
handler.command = ["coba"];
handler.register = true;
handler.limit = true;

export default handler;
