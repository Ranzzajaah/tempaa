/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const AFFIRMATIONS = [
    'Kamu jauh lebih kuat dan hebat dari yang kamu kira.',
    'Setiap langkah kecil yang kamu ambil hari ini tetaplah sebuah kemajuan.',
    'Kamu pantas mendapatkan hal-hal baik dan kebahagiaan hari ini.',
    'Kesalahan hari ini adalah guru berharga untuk keberhasilanmu besok.',
    'Percaya pada dirimu sendiri, kamu mampu melewati semua tantangan.'
];

const handler = async (m) => {
    return m.reply(`🌻 *AFIRMASI HARI INI*

"${pick(AFFIRMATIONS)}"`);
};

handler.help = ['affirmation'];
handler.tags = ['fun'];
handler.command = ['affirmation', 'afirmasi'];
handler.limit = true;
handler.register = true;

export default handler;
