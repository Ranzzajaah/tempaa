/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const RAMALAN_HARI_INI = [
	{ nasib: 'Sangat Beruntung! 🌟', desc: 'Hari ini kamu akan mendapat kabar gembira dan rezeki tak terduga.' },
	{ nasib: 'Asmara Membara 💕', desc: 'Ada seseorang yang diam-diam memperhatikan dan mengagumi senyumanmu.' },
	{ nasib: 'Keuangan Lancar 💰', desc: 'Usaha dan pekerjaanmu berjalan mulus, bonus uang menanti.' },
	{ nasib: 'Waspada Dompet Tipis 💸', desc: 'Jangan kebanyakan jajan kopi dan barang yang tidak perlu ya!' },
	{ nasib: 'Kesehatan Prima 🏋️‍♂️', desc: 'Tubuhmu sedang dalam kondisi sangat segar dan siap beraktivitas.' }
];

const handler = async (m, { hirara, conn, sock }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	const targetJid = m.sender;
	const cleanTag = getCleanTag(targetJid);
	const name = m.pushName || `@${cleanTag}`;
	const ramalan = RAMALAN_HARI_INI[Math.floor(Math.random() * RAMALAN_HARI_INI.length)];
	const angkaHoki = Math.floor(Math.random() * 90) + 10;

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🔮 RAMALAN NASIB HARI INI',
		badgeText: `🎲 HOKI #${angkaHoki}`,
		titleBg: '#8b5cf6',
		badgeBg: '#ffea00',
		name,
		rate: angkaHoki,
		categoryLabel: 'Prediksi Nasib',
		categoryValue: ramalan.nasib,
		descLabel: 'Wejangan Hari Ini',
		descValue: ramalan.desc,
		footerText: 'Jalani hari dengan senyuman & optimisme tinggi!',
		barColor: '#8b5cf6',
		ppUrl
	}).catch(() => null);

	const replyText = `🔮 *RAMALAN NASIB HARI INI* 🔮\n\n` +
		`👤 *Nama:* @${cleanTag}\n` +
		`🔮 *Prediksi Nasib:* ${ramalan.nasib}\n` +
		`🎲 *Angka Hoki Hari Ini:* *${angkaHoki}*\n\n` +
		`📜 *Wejangan:* _"${ramalan.desc}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🔮', key: m.key } }).catch(() => null);

	const mentions = [targetJid];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: replyText,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, { text: replyText, mentions }, { quoted: m });
	}
};

handler.command = ['ramalan', 'ramal'];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Ramalan nasib dan angka hoki hari ini dengan Canvas';
handler.register = true;

export default handler;
