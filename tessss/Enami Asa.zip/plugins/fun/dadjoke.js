/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const DAD_JOKES = [
    'Kenapa programmer suka alam? Karena banyak tree (pohon data)!',
    'Apa minuman favorit hantu? Es kunti(lanak)... eh, es teh maksudnya.',
    'Kenapa komputer gak pernah lapar? Karena udah punya byte!',
    'Kenapa laut gak pernah pinjam uang? Karena udah banyak "bank" (pantai)!',
    'Kenapa bebek goreng enak rasanya? Karena ada huruf B nya, coba kalau gak ada... jadi ekek goreng!',
    'Pocong apa yang paling disenangi ibu-ibu? Pocongan harga!',
    'Kenapa matahari tenggelam? Karena gak bisa berenang!',
    'Hewan apa yang bersaudara? Katak-beradik!',
    'Jus apa yang paling gak enak? Just friend...',
    'Kenapa superman bajunya ketat? Karena kalau longgar namanya super jumbo!'
];

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const handler = async (m) => {
    return m.reply(`😂 *DAD JOKE*

${pick(DAD_JOKES)}`);
};

handler.help = ['dadjoke'];
handler.tags = ['fun'];
handler.command = ['dadjoke', 'jokes'];
handler.limit = true;
handler.register = true;

export default handler;
