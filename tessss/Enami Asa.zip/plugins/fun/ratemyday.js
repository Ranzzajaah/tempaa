/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const handler = async (m) => {
    const score = randInt(1, 10);
    const comments = {
        low: 'Hari yang cukup berat dan melelahkan, tapi besok pasti jauh lebih baik! Tetap semangat ya!',
        mid: 'Hari yang cukup stabil dan oke, pertahankan energi positifmu!',
        high: 'Hari yang sangat luar biasa indah, bersyukur dan nikmati harimu!'
    };
    const tier = score <= 3 ? 'low' : score <= 7 ? 'mid' : 'high';
    return m.reply(`📅 *RATING HARI INI*

📊 Skor Harimu: *${score}/10*
💬 _"${comments[tier]}"_`);
};

handler.help = ['ratemyday'];
handler.tags = ['fun'];
handler.command = ['ratemyday'];
handler.limit = true;
handler.register = true;

export default handler;
