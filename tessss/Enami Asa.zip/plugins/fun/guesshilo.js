/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const SESSIONS = new Map();
const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const handler = async (m, { args, usedPrefix, command }) => {
    const cmd = command.toLowerCase();
    const prefix = usedPrefix || '.';

    if (cmd === 'guesshilo' || cmd === 'hilo') {
        const target = randInt(1, 100);
        SESSIONS.set(m.chat, target);
        return m.reply(`🔢 *HIGHER OR LOWER*

Aku punya angka rahasia antara 1 sampai 100.
Jawab dengan: *${prefix}tebakhilo [angka]*, bot akan memberitahu lebih tinggi atau rendah.`);
    }

    if (cmd === 'tebakhilo') {
        const guess = parseInt(args[0]);
        const target = SESSIONS.get(m.chat);
        if (target === undefined) return m.reply(`❌ Belum ada game aktif. Ketik *${prefix}guesshilo* dulu!`);
        if (isNaN(guess)) return m.reply(`📌 Cara pakai: *${prefix}tebakhilo [angka]*`);

        if (guess === target) {
            SESSIONS.delete(m.chat);
            return m.reply(`🎉 *TEPAT SEKALI!* Angka rahasianya memang *${target}*!`);
        } else if (guess < target) {
            return m.reply(`📈 *Lebih TINGGI* dari ${guess}! Coba lagi.`);
        } else {
            return m.reply(`📉 *Lebih RENDAH* dari ${guess}! Coba lagi.`);
        }
    }
};

handler.help = ['guesshilo', 'tebakhilo [angka]'];
handler.tags = ['fun'];
handler.command = ['guesshilo', 'hilo', 'tebakhilo'];
handler.limit = true;
handler.register = true;

export default handler;
