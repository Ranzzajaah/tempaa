/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const answers = [
    "Orang yang kamu pikirkan sekarang!",
    "Hmm, seseorang yang dekat denganmu.",
    "Orang yang tidak kamu duga!",
    "Aku nggak tau, coba pikir lagi.",
    "Seseorang yang sudah ada di hidupmu.",
    "Orang yang selalu mendukungmu.",
    "Mungkin orang yang baru kamu kenal?",
    "Orang yang selalu bikin kamu senyum.",
    "Hmm, misteri nih.",
    "Seseorang dengan inisial huruf A-Z.",
    "Orang yang paling nggak kamu sangka!",
    "Kamu sendiri!",
    "Orang yang ada di sekitarmu sekarang.",
    "Seseorang yang spesial.",
    "Hmm, aku rasa kamu sudah tau jawabannya.",
    "Orang yang setia padamu.",
    "Seseorang yang sedang memikirkanmu juga.",
    "Coba lihat ke samping kirimu!",
    "Orang yang sering chat sama kamu.",
    "Itu rahasia!"
];

const handler = async (m, { text, usedPrefix, command, reply }) => {
    const doReply = typeof reply === "function" ? reply : typeof m.reply === "function" ? m.reply.bind(m) : null;
    if (!text) return doReply(`Format Salah!\nContoh: *${usedPrefix + command} jodohku?*`);

    const answer = answers[Math.floor(Math.random() * answers.length)];
    const caption = `👤 *PERTANYAAN*\n> ${text}\n\n🎱 *JAWABAN*\n> ${answer}`;

    if (doReply) return doReply(caption);
};

handler.help = ["siapa <pertanyaan>"];
handler.tags = ["fun"];
handler.command = ["siapa"];
handler.register = true;
handler.limit = true;

export default handler;
