/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const getTarget = async (m, text, user, getUser) => {
	let targetJid = null;
	let targetName = '';

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (text && text.trim().length > 0) {
		const cleanNum = text.replace(/[^0-9]/g, '');
		if (cleanNum.length >= 7 && cleanNum.length <= 15) {
			targetJid = cleanNum + '@s.whatsapp.net';
		} else {
			targetName = text.trim();
		}
	} else {
		targetJid = m.sender;
	}

	let cardName = targetName;
	let captionTag = targetName;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;

		if (!cardName) {
			let uData = null;
			if (targetJid === m.sender && user) {
				uData = user;
			} else if (typeof getUser === 'function') {
				try { uData = await getUser(targetJid); } catch (_) {}
			}
			
			const foundName = uData?.name || uData?.nama || (m.quoted?.sender === targetJid ? m.quoted?.pushName : null);
			if (foundName && foundName !== 'User' && !/^\d+$/.test(foundName)) {
				cardName = foundName;
			} else if (targetJid === m.sender && m.pushName) {
				cardName = m.pushName;
			} else {
				cardName = `@${cleanTag}`;
			}
		}
	}

	return { targetJid, targetName: cardName, captionTag: captionTag || cardName };
};

const getPercentage = () => Math.floor(Math.random() * 101);

const getAnalysis = (pct) => {
	let comment = '', categoryVal = '';
	if (pct > 85) { comment = 'Ketampanan bak oppa Korea, bikin cewek antri!'; categoryVal = 'Pangeran Tampan 👑'; }
	else if (pct > 60) { comment = 'Kharismatik dan manis dipandang.'; categoryVal = 'Manis Menawan 😎'; }
	else if (pct > 30) { comment = 'Tampan kalau lagi rapi dan wangi.'; categoryVal = 'Standar Keren 👍'; }
	else { comment = 'Tampan di mata ibu dan keluarga!'; categoryVal = 'Kharisma Dalam 🌟'; }
	return { comment, categoryVal };
};

const handler = async (m, { hirara, conn, sock, reply, text, command, user, getUser }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	const { targetJid, targetName, captionTag } = await getTarget(m, text, user, getUser);
	const percentage = getPercentage();
	const { comment, categoryVal } = getAnalysis(percentage);

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const cardBuffer = await generateFunCard({
		title: '🕺 CEK KETAMPANAN / GANTENG',
		badgeText: `👑 ${percentage}% HANDSOME`,
		titleBg: '#0284c7',
		badgeBg: '#ffea00',
		name: targetName,
		rate: percentage,
		categoryLabel: 'Level Ketampanan',
		categoryValue: categoryVal,
		descLabel: 'Catatan Analisis',
		descValue: comment,
		footerText: 'Tampan luar biasa, utamakan akhlak & kebaikan hati!',
		barColor: '#38bdf8',
		ppUrl
	}).catch(() => null);

	const caption = `🎯 *ʜᴀsɪʟ ᴄʜᴇᴄᴋ* 🎯\n\n• 👤 *ᴛᴀʀɢᴇᴛ:* ${captionTag}\n• 📊 *ᴘᴇʀsᴇɴᴛᴀsᴇ:* *${percentage}%*\n• 🏷️ *sᴛᴀᴛᴜs:* ${categoryVal}\n• 💬 *ᴄᴀᴛᴀᴛᴀɴ:* _"${comment}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🕺', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: caption,
			mentions
		}, { quoted: m });
	}
};

handler.command = ["cekganteng","gantengcheck"];
handler.limit = true;
handler.category = 'fun';
handler.description = 'Cek skor ketampanan seseorang dengan Canvas';
handler.register = true;

export default handler;
