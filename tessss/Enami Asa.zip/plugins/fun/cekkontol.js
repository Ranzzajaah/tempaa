/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { generateFunCard } from '../../canvas/canvas-fun.js';

const getCleanTag = (jid) => {
	if (!jid) return '';
	return String(jid).split('@')[0].split(':')[0];
};

const getTarget = async (m, text) => {
	let targetJid = null;
	let targetName = '';

	if (m.mentionedJid && m.mentionedJid.length > 0) {
		targetJid = m.mentionedJid[0];
	} else if (m.quoted && m.quoted.sender) {
		targetJid = m.quoted.sender;
	} else if (text && text.trim().length > 0) {
		const cleanNum = text.replace(/[^0-9]/g, '');
		if (cleanNum.length >= 7 && cleanNum.length <= 15) {
			targetJid = cleanNum + '@s.whatsapp.net';
		} else {
			targetName = text.trim();
		}
	} else {
		targetJid = m.sender;
	}

	let cardName = targetName;
	let captionTag = targetName;

	if (targetJid) {
		const cleanTag = getCleanTag(targetJid);
		captionTag = `@${cleanTag}`;

		if (!cardName) {
			cardName = (targetJid === m.sender && m.pushName) ? m.pushName : (m.quoted?.sender === targetJid && m.quoted?.pushName ? m.quoted.pushName : `@${cleanTag}`);
		}
	}

	return { targetJid, targetName: cardName, captionTag: captionTag || cardName };
};

const handler = async (m, { text, reply, hirara, conn, sock }) => {
	const client = hirara || conn || sock || global.mainSock || global.sock;
	const { targetJid, targetName, captionTag } = await getTarget(m, text);

	const panjang = Math.floor(Math.random() * 16) + 8;
	const bentuk = ['lurus kokoh', 'agak belok estetik', 'urat berotot', 'mungil lucu', 'panjang gagah', 'tebal berkarisma'][Math.floor(Math.random() * 6)];
	const durasi = Math.floor(Math.random() * 55) + 5;
	const status = ['tahan banting', 'gampang lemes', 'berotot perkasa', 'siap tempur 24 jam', 'mode santai'][Math.floor(Math.random() * 5)];

	let catatan = '';
	if (panjang >= 18) catatan = 'Perkasa bak monster naga, siap guncang ranjang! 🐉⚡';
	else if (panjang >= 13) catatan = 'Ukuran pas proporsional, stamina tahan banting! 💪✨';
	else catatan = 'Mungil gesit dan lincah, kecil-kecil cabe rawit! 🌶️';

	let ppUrl = null;
	if (targetJid && client?.profilePictureUrl) {
		try { ppUrl = await client.profilePictureUrl(targetJid, 'image').catch(() => null); } catch (_) {}
	}

	const ratePanjang = Math.min(100, Math.floor((panjang / 24) * 100));

	const cardBuffer = await generateFunCard({
		title: '🍌 CEK KONTOL CHECK',
		badgeText: `📏 ${panjang} CM`,
		titleBg: '#eab308',
		badgeBg: '#ffea00',
		name: targetName,
		rate: ratePanjang,
		categoryLabel: 'Panjang & Bentuk',
		categoryValue: `${panjang} cm • ${bentuk}`,
		descLabel: 'Catatan Stamina',
		descValue: catatan,
		footerText: 'Analisis kejantanan & stamina alami 🍌',
		barColor: '#facc15',
		ppUrl
	}).catch(() => null);

	const caption = `🍌 *ʜᴀsɪʟ ᴄᴇᴋ ᴋᴏɴᴛᴏʟ* 🍌\n\n• 👤 *ᴛᴀʀɢᴇᴛ:* ${captionTag}\n• 📏 *ᴘᴀɴᴊᴀɴɢ:* ${panjang} cm\n• ✨ *ʙᴇɴᴛᴜᴋ:* ${bentuk}\n• ⏳ *ᴅᴜʀᴀsɪ ᴛᴇᴍᴘᴜʀ:* ${durasi} menit\n• ⚡ *ᴋᴏɴᴅɪsɪ:* ${status}\n• 💬 *ᴄᴀᴛᴀᴛᴀɴ:* _"${catatan}"_`;

	await client?.sendMessage(m.chat, { react: { text: '🍌', key: m.key } }).catch(() => null);

	const mentions = targetJid ? [targetJid] : [];
	if (cardBuffer) {
		return client.sendMessage(m.chat, {
			image: cardBuffer,
			caption,
			mentions
		}, { quoted: m });
	} else {
		return client.sendMessage(m.chat, {
			text: caption,
			mentions
		}, { quoted: m });
	}
};

handler.help = ['cekkontol <@tag/nama>'];
handler.tags = ['fun'];
handler.command = ['cekkontol'];
handler.limit = true;

export default handler;
