/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { deleteUser, listUsers } from '../../lib/cpanel.js';

const handler = async (m, { sock, args, command, usedPrefix }) => {
	const cmd = command.toLowerCase();

	if (cmd === 'delusr') {
		const userId = args[0] ? args[0].trim() : '';
		if (!userId) {
			return m.reply(`❌ *Mohon masukkan ID user yang ingin dihapus!*\n\nContoh: *${usedPrefix}delusr 1*`);
		}

		await global.react(sock, m, 'loading');

		try {
			const res = await deleteUser(userId);
			if (res.success) {
				await global.react(sock, m, 'success');
				return m.reply(`✅ *SUCCESSFULLY DELETE THE USER (ID: ${userId})*`);
			} else {
				await global.react(sock, m, 'error');
				return m.reply(`❌ USER NOT FOUND ATAU GAGAL DIHAPUS`);
			}
		} catch (err) {
			console.error('[DELUSR ERROR]', err);
			await global.react(sock, m, 'error');
			return m.reply(`❌ Terjadi kesalahan saat menghapus user: ${err?.message || 'Error'}`);
		}
	}

	if (cmd === 'listusr') {
		await global.react(sock, m, 'loading');

		try {
			const res = await listUsers();
			if (!res || !res.data || res.data.length === 0) {
				await global.react(sock, m, 'success');
				return m.reply(`📌 *DAFTAR USER PANEL*\n\nTidak ada user aktif.`);
			}

			let messageText = `👥 *DAFTAR USER AKTIF PTERODACTYL*\n\n`;
			for (const userItem of res.data) {
				const u = userItem.attributes;
				messageText += `• *ID User:* ${u.id}\n`;
				messageText += `  *Username:* ${u.username}\n`;
				messageText += `  *Email:* ${u.email}\n\n`;
			}

			if (res.meta?.pagination) {
				messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages} | Total User: ${res.meta.pagination.count}`;
			}

			await m.reply(messageText);
			await global.react(sock, m, 'success');
		} catch (err) {
			console.error('[LISTUSR ERROR]', err);
			await global.react(sock, m, 'error');
			return m.reply(`❌ Terjadi kesalahan saat mengambil daftar user: ${err?.message || 'Error'}`);
		}
	}
};

handler.command = ['delusr', 'listusr'];
handler.category = 'panel';
handler.description = 'Kelola dan hapus user Pterodactyl Panel';
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
