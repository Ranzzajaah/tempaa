/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';

const handler = async (m, { sock, prefix, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password\` atau \`${usedPrefix + command} ipvps|password\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const vii = input.split(separator).map(s => s.trim());
  if (vii.length < 2) return m.reply('❌ IP VPS atau Password VPS tidak lengkap!');

  const ipvps = vii[0];
  const passwd = vii[1];

  m.reply(
    `📦 *MEMPROSES INSTALL TEMA BILLING PTERODACTYL...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `⏳ Mohon tunggu 1-10 menit hingga proses instalasi selesai...`
  );

  const connSettings = {
    host: ipvps,
    port: 22,
    username: 'root',
    password: passwd
  };

  const commandSh = `bash <(curl -s https://raw.githubusercontent.com/veryLinh/Theme-Autoinstaller/main/install.sh)`;
  const ress = new Client();

  ress.on('ready', () => {
    ress.exec(commandSh, (err, stream) => {
      if (err) {
        ress.end();
        return m.reply(`❌ *EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', async () => {
        await m.reply('✅ *Berhasil install tema billing pterodactyl!*');
        ress.end();
      }).on('data', async (data) => {
        console.log(data.toString());
        try {
          stream.write(`skyzodev\n`);
          stream.write(`1\n`);
          stream.write(`2\n`);
          stream.write(`yes\n`);
          stream.write(`x\n`);
        } catch {}
      }).stderr.on('data', (data) => {
        console.log('STDERR: ' + data);
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error: ' + err);
    m.reply('❌ Katasandi atau IP tidak valid!');
  }).connect(connSettings);
};

handler.help = ['installtemabilling'];
handler.tags = ['panel'];
handler.command = ['installtemabilling'];
handler.owner = true;

handler.noJadiBot = true;

export default handler;
