/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';

const handler = async (m, { sock, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password,domainnode\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,node.domain.com\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const t = input.split(separator).map(s => s.trim());
  if (t.length < 3) {
    return m.reply(`❌ Format kurang lengkap! Gunakan: \`${usedPrefix + command} ipvps,password,domainnode\``);
  }

  const [ipvps, passwd, domainnode] = t;
  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };

  m.reply(
    `🟢 *PROSES AUTO-INSTALL & CONFIG WINGS (ANTI MERAH) DIMULAI...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🌐 *Domain Node:* \`${domainnode}\`\n\n` +
    `⏳ Mohon tunggu 1-2 menit...`
  );

  const wingsScript = `
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
ufw disable || true
iptables -F || true

cd /var/www/pterodactyl || exit

if ! command -v docker &> /dev/null; then
  curl -sSL https:
fi

systemctl enable --now docker || true
systemctl restart docker || true

mkdir -p /etc/pterodactyl /var/log/pterodactyl
curl -L -o /usr/local/bin/wings "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64" || true
chmod u+x /usr/local/bin/wings || true

certbot certonly --standalone -d ${domainnode} --non-interactive --agree-tos -m admin@gmail.com || certbot certonly --nginx -d ${domainnode} --non-interactive --agree-tos -m admin@gmail.com || true

php artisan p:node:configuration 1 > /etc/pterodactyl/config.yml || true

cat << 'EOF_WINGS_SVC' > /etc/systemd/system/wings.service
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF_WINGS_SVC

systemctl daemon-reload || true
systemctl enable --now wings || true
systemctl restart wings || true
exit 0
`;

  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendWingsReport(domainnode);
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(wingsScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendWingsReport(domNode) {
    const reportText =
      `🎉 *INSTALL & AUTO PAIRING WINGS SELESAI!* 🎉\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🌐 *Domain Node:* \`${domNode}\`\n` +
      `🔒 *SSL Node:* Certbot Secured (HTTPS)\n` +
      `🔑 *Token Configuration:* Auto Fetched & Paired from Panel\n` +
      `🟢 *Status Daemon:* 100% HIJAU & Active Daemon\n\n` +
      `✨ *Node di Web Panel sekarang sudah 100% HIJAU & Siap digunakan!*`;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['autowings'];
handler.category = 'panel';
handler.description = 'Otomatisasi Instalasi Docker, Wings, SSL Node, dan Auto-Fetch Configuration Token via SSH (100% Guaranteed Green 🟢)';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
