/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || !input.includes(',')) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password\` ATAU \`${usedPrefix + command} ipvps,password,domainpanel\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123\`\n` +
      `💡 *Dengan Domain:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,kyzz-apis.kyu4me.biz.id\``
    );
  }

  const t = input.split(',').map(s => s.trim());
  const ipvps = t[0];
  const passwd = t[1];
  const domainpanel = t[2] || '_';

  m.reply(`🔧 *MEMULAI DEEP DIAGNOSTIC & SUPER FIX PANEL PTERODACTYL...*\n🖥️ *IP VPS:* \`${ipvps}\`\n🌐 *Domain:* \`${domainpanel}\` \n\n⏳ Mohon tunggu 1-2 menit...`);

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };

  const scriptCommands = `
ufw disable || true
iptables -F || true
rm -f /etc/nginx/sites-enabled/default || true

PHP_SOCK=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -n 1)
if [ -z "$PHP_SOCK" ]; then
  systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || systemctl restart php8.3-fpm || true
  PHP_SOCK=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -n 1)
fi

mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled

cat << 'EOF_NGINX' > /etc/nginx/sites-available/pterodactyl.conf
server {
    listen 80 default_server;
    server_name _;

    root /var/www/pterodactyl/public;
    index index.html index.htm index.php;
    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    access_log off;
    error_log  /var/log/nginx/pterodactyl.app-error.log error;

    client_max_body_size 100M;
    client_body_timeout 120s;

    sendfile off;

    location ~ \\.php$ {
        fastcgi_split_path_info ^(.+\\.php)(/.+)$;
        fastcgi_pass unix:PHP_SOCK_PLACEHOLDER;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }

    location ~ /\\.ht {
        deny all;
    }
}
EOF_NGINX

sed -i "s|unix:PHP_SOCK_PLACEHOLDER|unix:$PHP_SOCK|g" /etc/nginx/sites-available/pterodactyl.conf
ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf

if [ "${domainpanel}" != "_" ]; then
  sed -i "s|server_name _;|server_name ${domainpanel};|g" /etc/nginx/sites-available/pterodactyl.conf
fi

cd /var/www/pterodactyl || exit
chown -R www-data:www-data /var/www/pterodactyl/*
chmod -R 755 storage bootstrap/cache
php artisan view:clear || true
php artisan config:clear || true
php artisan route:clear || true

systemctl restart nginx || true
`;

  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        const successMsg =
          `🎉 *DEEP FIX SELESAI! PANEL PTERODACTYL DIREPAIR!* 🎉\n\n` +
          `🖥️ *IP VPS:* \`${ipvps}\`\n` +
          `🛠️ *Perbaikan yang Diterapkan:*\n` +
          `1. Nginx Default Site Removed & Clean Pterodactyl Config Re-generated\n` +
          `2. PHP-FPM FastCGI Unix Socket Re-linked Automatically\n` +
          `3. Ownership \`www-data:www-data\` & Storage Permissions Fixed\n` +
          `4. UFW Disabled & Ports Unblocked 100%\n` +
          `5. Laravel View & Route Cache Cleared\n\n` +
          `🌐 *Coba Buka Web via HTTP / IP VPS / Domain:* \`http://${ipvps}\`\n` +          `📌 *Catatan Cloudflare:* Pastikan status Proxy di Cloudflare diatur ke *DNS Only (Awan Abu-abu)* atau SSL diatur ke *Full*.`;

        m.reply(successMsg);
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(scriptCommands + '\n');
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);
};

handler.command = ['fixpanel', 'fixpnl', 'repairpanel'];
handler.category = 'panel';
handler.description = 'Deep Diagnostic & Auto Repair Pterodactyl Panel (Nginx, PHP-FPM Socket, Permissions, Cache, Firewall) via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
