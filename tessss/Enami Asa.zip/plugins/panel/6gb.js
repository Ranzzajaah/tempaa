/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createPanel } from '../../lib/cpanel.js';

const handler = async (m, { sock, text, command, usedPrefix, isOwner, isPremium, isReseller }) => {
	if (!isOwner && !isPremium && !isReseller) {
		return m.reply('❌ *Akses Ditolak!*\n\nFitur ini khusus untuk *Reseller Panel / Premium / Owner*.\nHubungi admin untuk upgrade role reseller.');
	}

	if (!text) {
		return m.reply('❌ *Format Salah!*\n\nPenggunaan:\n*' + usedPrefix + command + ' namapanel,nowa*\natau\n*' + usedPrefix + command + ' 628xxxx,namapanel*');
	}

	await global.react(sock, m, 'loading');

	try {
		const result = await createPanel({ command: '6gb', text, sock });
		const { user, server, sendRes, username, email } = result;

		let replyText = '✅ *BERIKUT DATA PANEL ANDA*\n\n' +
			'• *NAMA:* ' + username + '\n' +
			'• *EMAIL:* ' + email + '\n' +
			'• *ID USER:* ' + user.id + '\n' +
			'• *MEMORY:* ' + (server.limits.memory === 0 ? 'Unlimited' : server.limits.memory) + ' MB\n' +
			'• *DISK:* ' + (server.limits.disk === 0 ? 'Unlimited' : server.limits.disk) + ' MB\n' +
			'• *CPU:* ' + server.limits.cpu + '%\n\n';

		if (sendRes.wa) {
			replyText += '📲 Data panel telah berhasil dikirimkan ke PM WhatsApp tujuan!';
		} else {
			replyText += '⚠️ Gagal mengirim data ke PM WhatsApp (pastikan nomor valid & terdaftar).';
		}

		if (sendRes.tg) {
			replyText += '\n✈️ Notifikasi panel juga berhasil dikirimkan ke Telegram!';
		}

		await m.reply(replyText);
		await global.react(sock, m, 'success');
	} catch (err) {
		console.error('[CREATE PANEL ERROR]', err);
		await global.react(sock, m, 'error');
		return m.reply('❌ ' + (err?.message || 'Gagal membuat akun panel'));
	}
};

handler.command = ['6gb'];
handler.category = 'panel';
handler.description = 'Buat server panel Pterodactyl 6GB';

handler.register = true;

handler.premium = true;

handler.noJadiBot = true;

export default handler;
