/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { deleteServer, listServers } from '../../lib/cpanel.js';

const handler = async (m, { sock, args, command, usedPrefix }) => {
	const cmd = command.toLowerCase();

	if (cmd === 'delsrv') {
		const serverId = args[0] ? args[0].trim() : '';
		if (!serverId) {
			return m.reply(`❌ *Mohon masukkan ID server yang ingin dihapus!*\n\nContoh: *${usedPrefix}delsrv 1234*`);
		}

		await global.react(sock, m, 'loading');

		try {
			const res = await deleteServer(serverId);
			if (res.success) {
				await global.react(sock, m, 'success');
				return m.reply(`✅ *SUCCESFULLY DELETE SERVER (ID: ${serverId})*`);
			} else {
				await global.react(sock, m, 'error');
				return m.reply(`❌ SERVER TIDAK ADA ATAU GAGAL DIHAPUS`);
			}
		} catch (err) {
			console.error('[DELSRV ERROR]', err);
			await global.react(sock, m, 'error');
			return m.reply(`❌ Terjadi kesalahan saat menghapus server: ${err?.message || 'Error'}`);
		}
	}

	if (cmd === 'listsrv') {
		await global.react(sock, m, 'loading');

		try {
			const { servers, meta } = await listServers();
			if (!servers || servers.length === 0) {
				await global.react(sock, m, 'success');
				return m.reply(`📌 *DAFTAR SERVER PANEL*\n\nTidak ada server aktif.`);
			}

			let messageText = `🖥️ *DAFTAR SERVER AKTIF PTERODACTYL*\n\n`;
			servers.forEach((s) => {
				messageText += `• *ID Server:* ${s.id}\n`;
				messageText += `  *Nama Server:* ${s.name}\n`;
				messageText += `  *Status:* ${s.status}\n\n`;
			});

			if (meta?.pagination) {
				messageText += `Page: ${meta.pagination.current_page}/${meta.pagination.total_pages} | Total: ${meta.pagination.total} server`;
			}

			await m.reply(messageText);
			await global.react(sock, m, 'success');
		} catch (err) {
			console.error('[LISTSRV ERROR]', err);
			await global.react(sock, m, 'error');
			return m.reply(`❌ Terjadi kesalahan saat mengambil daftar server: ${err?.message || 'Error'}`);
		}
	}
};

handler.command = ['delsrv', 'listsrv'];
handler.category = 'panel';
handler.description = 'Kelola dan hapus server Pterodactyl Panel';
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
