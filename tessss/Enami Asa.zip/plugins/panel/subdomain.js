/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

function getCFSettings() {
  const token = global.cftoken || global.tokencf || global.tokenCF || '';
  const zone = global.cfzone || global.zonecf || global.zoneCF || '';
  const domain = global.cfdomain || global.domaincf || global.domainCF || global.domain || '';
  return { token, zone, domain };
}

const handler = async (m, {text, usedPrefix, command, isOwner, reply}) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const { token, zone, domain } = getCFSettings();
  const args = (text || '').trim().split(/\s+/);
  const cmd = command.toLowerCase();

  if (!token || !zone) {
    return m.reply('❌ Konfigurasi Cloudflare belum diisi pada `settings.js`!');
  }

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  switch (cmd) {
    case 'createsubdo':
    case 'addsubdo':
    case 'createsubdomain': {
      if (!args[0]) {
        return m.reply(
          `❌ *FORMAT SALAH!*\n\n` +
          `📌 *Penggunaan:* \`${usedPrefix + command} <nama_subdomain> <ip_vps>\` ATAU \`${usedPrefix + command} <ip_vps>\`\n` +
          `💡 *Contoh 1 (Otomatis kyzz-apis & node):* \`${usedPrefix + command} 103.187.xxx.xxx\`\n` +
          `💡 *Contoh 2 (Custom):* \`${usedPrefix + command} panel 103.187.xxx.xxx\``
        );
      }

      let subName, ipVps;

      if (args.length === 1 && /^(\d{1,3}\.){3}\d{1,3}$/.test(args[0])) {
        ipVps = args[0].trim();
        const randNum = Math.floor(Math.random() * 3) + 1;
        subName = randNum === 1 ? 'kyzz-apis' : `kyzz-apis${randNum}`;
      } else if (args.length >= 2) {
        subName = args[0].trim().toLowerCase();
        ipVps = args[1].trim();
      } else {
        return m.reply(`❌ Format IP tidak valid! Gunakan: \`${usedPrefix + command} 103.187.xxx.xxx\` atau \`${usedPrefix + command} nama 103.187.xxx.xxx\``);
      }

      const cleanDomain = domain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
      const nodeSubName = subName.includes('.') ? `node-${subName}` : `node-${subName}.${cleanDomain}`;

      m.reply(`⏳ *MEMBUAT DUAL SUBDOMAIN CLOUDFLARE (PROXIED ORANGE CLOUD)...*\n🌐 *Main:* \`${mainDomain}\` (Proxied: true)\n📡 *Node:* \`${nodeSubName}\` (Proxied: false)\n🖥️ *IP Target:* \`${ipVps}\``);

      try {
        const createMainRes = await axios.post(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
          {
            type: 'A',
            name: mainDomain,
            content: ipVps,
            ttl: 1,
            proxied: true
          },
          { headers }
        );

        const createNodeRes = await axios.post(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
          {
            type: 'A',
            name: nodeSubName,
            content: ipVps,
            ttl: 1,
            proxied: false
          },
          { headers }
        );

        if (createMainRes.data.success && createNodeRes.data.success) {
          return m.reply(
            `🎉 *BERHASIL MEMBUAT DUAL SUBDOMAIN CLOUDFLARE!* 🎉\n\n` +
            `🌐 *Domain Panel:* \`${mainDomain}\` (🟠 Proxied - Cloudflare Protection & Challenge Active)\n` +
            `📡 *Domain Node:* \`${nodeSubName}\` (⚪ DNS Only - Wings WebSocket Compatible)\n` +
            `🖥️ *IP VPS:* \`${ipVps}\`\n` +
            `☁️ *Zone Domain:* \`${domain}\``
          );
        } else {
          return m.reply(`❌ Gagal membuat subdomain: ${JSON.stringify(createMainRes.data.errors)}`);
        }
      } catch (err) {
        const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
        return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
      }
    }

    case 'cfproxy':
    case 'setproxy': {
      if (!args[0]) {
        return m.reply(`❌ *FORMAT SALAH!*\n\n📌 *Penggunaan:* \`${usedPrefix + command} <nama_subdomain> <on/off>\`\n💡 *Contoh:* \`${usedPrefix + command} kyzz-apis.kyu4me.biz.id on\``);
      }
      const target = args[0].trim().toLowerCase();
      const enableProxy = (args[1] || 'on').toLowerCase() === 'on';

      m.reply(`⏳ *MENGUBAH STATUS PROXY CLOUDFLARE FOR \`${target}\` TO \`${enableProxy ? 'ON (PROXIED)' : 'OFF (DNS ONLY)'}\`...*`);

      try {
        const listRes = await axios.get(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?type=A&per_page=100`,
          { headers }
        );

        if (listRes.data.success) {
          const found = listRes.data.result.find(r => r.name.toLowerCase().includes(target));
          if (!found) return m.reply(`❌ Subdomain \`${target}\` tidak ditemukan.`);

          const patchRes = await axios.patch(
            `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${found.id}`,
            { proxied: enableProxy },
            { headers }
          );

          if (patchRes.data.success) {
            return m.reply(
              `⚡ *STATUS PROXY CLOUDFLARE BERHASIL DIPERBARUI!* ⚡\n\n` +
              `🌐 *Subdomain:* \`${found.name}\`\n` +
              `🟠 *Proxied Status:* \`${enableProxy ? 'TRUE (Cloudflare Protected)' : 'FALSE (DNS Only)'}\``
            );
          }
        }
      } catch (err) {
        const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
        return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
      }
    }

    case 'listsubdo':
    case 'listsubdomain': {
      reply(global.mess.wait);

      try {
        const listRes = await axios.get(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?type=A&per_page=100`,
          { headers }
        );

        if (!listRes.data.success || listRes.data.result.length === 0) {
          return m.reply(`📭 Tidak ada DNS Record tipe A yang ditemukan.`);
        }

        const records = listRes.data.result;
        let textList = `📋 *DAFTAR SUBDOMAIN CLOUDFLARE (${records.length}):*\n\n`;

        records.forEach((rec, idx) => {
          const proxyStatus = rec.proxied ? '🟠 Proxied' : '⚪ DNS Only';
          textList += `${idx + 1}. *${rec.name}* ➔ \`${rec.content}\` (${proxyStatus})\n`;
        });

        return m.reply(textList);
      } catch (err) {
        const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
        return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
      }
    }

    case 'delsubdo':
    case 'delsubdomain': {
      if (!args[0]) {
        return m.reply(`❌ *FORMAT SALAH!*\n\n📌 *Penggunaan:* \`${usedPrefix + command} <nama_subdomain_atau_id>\``);
      }

      const target = args[0].trim().toLowerCase();
      m.reply(`⏳ *MENGHAPUS SUBDOMAIN CLOUDFLARE \`${target}\`...*`);

      try {
        let recordId = target;

        if (!target.match(/^[a-f0-9]{32}$/)) {
          const listRes = await axios.get(
            `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?type=A&per_page=100`,
            { headers }
          );

          if (listRes.data.success) {
            const found = listRes.data.result.find(r => r.name.toLowerCase().includes(target));
            if (found) {
              recordId = found.id;
            } else {
              return m.reply(`❌ Subdomain \`${target}\` tidak ditemukan pada Cloudflare Zone.`);
            }
          }
        }

        const delRes = await axios.delete(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${recordId}`,
          { headers }
        );

        if (delRes.data.success) {
          return m.reply(`🗑️ *SUBDOMAIN BERHASIL DIHAPUS DARI CLOUDFLARE!*\n🆔 *Record ID:* \`${recordId}\``);
        } else {
          return m.reply(`❌ Gagal menghapus subdomain: ${JSON.stringify(delRes.data.errors)}`);
        }
      } catch (err) {
        const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
        return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
      }
    }

    case 'delallsubdo':
    case 'clearsubdo':
    case 'delallsubdomain': {
      reply(global.mess.wait);

      try {
        const listRes = await axios.get(
          `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?type=A&per_page=100`,
          { headers }
        );

        if (!listRes.data.success || listRes.data.result.length === 0) {
          return m.reply(`📭 Tidak ada DNS Record tipe A yang ditemukan untuk dihapus.`);
        }

        const records = listRes.data.result;
        let successCount = 0;
        let failCount = 0;

        for (const rec of records) {
          try {
            await axios.delete(
              `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${rec.id}`,
              { headers }
            );
            successCount++;
          } catch (e) {
            failCount++;
          }
        }

        return m.reply(
          `🗑️ *PENGHAPUSAN MASAL SUBDOMAIN SELESAI!* 🗑️\n\n` +
          `✅ *Berhasil Dihapus:* ${successCount} Subdomain\n` +
          `❌ *Gagal Dihapus:* ${failCount} Subdomain\n` +
          `🌐 *Domain:* \`${domain}\``
        );
      } catch (err) {
        const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
        return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
      }
    }
  }
};

handler.command = ['subdomain','listsubdo','delsubdo'];
handler.category = 'panel';
handler.description = 'Manajemen Subdomain Cloudflare (Auto Proxy Orange Cloud, Subdomain Panel & Node, List, Delete)';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
