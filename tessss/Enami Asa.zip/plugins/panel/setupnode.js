/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password,domainpnl,domainnode,ramvps\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,panel.domain.com,node.domain.com,8000\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const t = input.split(separator).map(s => s.trim());
  if (t.length < 5) {
    return m.reply(`❌ Format kurang lengkap! Gunakan: \`${usedPrefix + command} ipvps,password,domainpnl,domainnode,ramvps\``);
  }

  const [ipvps, passwd, subdomain, domainnode, ramvps] = t;
  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };

  m.reply(
    `📍 *MEMULAI OTOMATISASI CREATION LOCATION & NODE PTERODACTYL...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🌐 *Domain Panel:* \`${subdomain}\`\n` +
    `📡 *Domain Node:* \`${domainnode}\`\n` +
    `💾 *RAM Node:* \`${ramvps} MB\`\n\n` +
    `⏳ Mohon tunggu sekitar 1-2 menit...`
  );

  const setupNodeScript = `
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
ufw disable || true
iptables -F || true

cd /var/www/pterodactyl

sed -i "s/'locale' => '.*/'locale' => 'id',/g" config/app.php || true
sed -i "s/APP_LOCALE=.*/APP_LOCALE=id/g" .env || true
if ! grep -q "APP_LOCALE" .env; then
  echo "APP_LOCALE=id" >> .env
fi

php artisan p:location:make --short="kyzz-apis" --long="kyzz-apis Location" --no-interaction || true

php artisan p:node:make --name="kyzz-apis" --description="Autocreated Kyzz APIs Node" --locationId=1 --fqdn="${domainnode}" --public=1 --scheme="https" --proxy=0 --maintenance=0 --maxMemory=${ramvps} --overallocateMemory=0 --maxDisk=100000 --overallocateDisk=0 --uploadSize=100 --daemonListeningPort=8080 --daemonSFTPPort=2022 --daemonBase="/var/lib/pterodactyl/volumes" --no-interaction || true

for p in $(seq 25565 25585); do
  mariadb -u pterodactyl -pSecretPass123! panel -e "INSERT IGNORE INTO allocations (node_id, ip, ip_alias, port, created_at, updated_at) VALUES (1, '${ipvps}', 'api.kyzzz.xyz', $p, NOW(), NOW());" || true
done

php artisan view:clear || true
php artisan config:clear || true
exit 0
`;

  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendSetupNodeReport(subdomain, domainnode, ramvps);
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(setupNodeScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendSetupNodeReport(subDom, domNode, ram) {
    const reportText =
      `🎉 *PEMBUATAN LOCATION & NODE SELESAI!* 🎉\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🌐 *Domain Panel:* \`https://${subDom}\`\n` +      `📡 *Domain Node:* \`${domNode}\`\n\n` +
      `📍 *Lokasi:* \`SGP\` (Singapore Location)\n` +
      `📡 *Nama Node:* \`Node-Singapore\`\n` +
      `💾 *RAM Node:* \`${ram} MB\`\n` +
      `🔌 *Allocations:* \`${ipvps}:25565 - 25585\` (21 Port Created)\n\n` +
      `👉 *Langkah Selanjutnya (Install & Configure Wings):*\n` +
      `Ketik: \`${usedPrefix}autowings ${ipvps},${passwd},${domNode}\``;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['setupnode', 'createnode', 'addnode'];
handler.category = 'panel';
handler.description = 'Otomatisasi Pembuatan Location, Node, dan Allocations di Panel Pterodactyl via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
