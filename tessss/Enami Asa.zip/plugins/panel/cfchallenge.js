/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';

function getCFSettings() {
  const token = global.cftoken || global.tokencf || global.tokenCF || '';
  const zone = global.cfzone || global.zonecf || global.zoneCF || '';
  const domain = global.cfdomain || global.domaincf || global.domainCF || global.domain || '';
  return { token, zone, domain };
}

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const { token, zone, domain } = getCFSettings();
  const args = (text || '').trim().split(/\s+/);

  if (!token || !zone) {
    return m.reply('❌ Konfigurasi Cloudflare belum diisi pada `settings.js`!');
  }

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  if (!args[0]) {
    return m.reply(
      `🛡️ *MANAJEMEN CLOUDFLARE SECURITY CHALLENGE*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} <mode>\`\n\n` +
      `💡 *Mode Pilihan:*\n` +
      `• \`on\` / \`under_attack\` ➔ Mengaktifkan Under Attack Mode (Cloudflare Captcha Challenge untuk semua pengujung)\n` +
      `• \`off\` / \`medium\` ➔ Mematikan Under Attack Mode (Kembali ke Security Normal)\n` +
      `• \`high\` ➔ Mode Keamanan Tinggi\n` +
      `• \`status\` ➔ Cek Status Keamanan Cloudflare Saat Ini`
    );
  }

  const modeInput = args[0].toLowerCase();
  let securityLevel = '';

  if (modeInput === 'on' || modeInput === 'under_attack' || modeInput === 'challenge') {
    securityLevel = 'under_attack';
  } else if (modeInput === 'off' || modeInput === 'medium' || modeInput === 'normal') {
    securityLevel = 'medium';
  } else if (modeInput === 'high') {
    securityLevel = 'high';
  } else if (modeInput === 'low') {
    securityLevel = 'low';
  } else if (modeInput === 'status') {
    try {
      const statusRes = await axios.get(
        `https://api.cloudflare.com/client/v4/zones/${zone}/settings/security_level`,
        { headers }
      );
      if (statusRes.data.success) {
        const currentVal = statusRes.data.result.value;
        return m.reply(`🛡️ *STATUS KEAMANAN CLOUDFLARE:* \`${currentVal.toUpperCase()}\`\n🌐 *Domain:* \`${domain}\``);
      }
    } catch (e) {
      return m.reply(`❌ Gagal mengambil status Cloudflare: ${e.message}`);
    }
  } else {
    return m.reply(`❌ Mode tidak valid! Gunakan: \`on\`, \`off\`, \`high\`, atau \`status\``);
  }

  m.reply(`⏳ *MENGUBAH CLOUDFLARE SECURITY CHALLENGE MODE KE \`${securityLevel.toUpperCase()}\`...*`);

  try {
    const updateRes = await axios.patch(
      `https://api.cloudflare.com/client/v4/zones/${zone}/settings/security_level`,
      { value: securityLevel },
      { headers }
    );

    if (updateRes.data.success) {
      const statusText = securityLevel === 'under_attack'
        ? '🔥 *UNDER ATTACK MODE AKTIF!* Seluruh pengunjung akan melewati Cloudflare Captcha Challenge.'
        : `✅ *MODE KEAMANAN BERHASIL DISET KE:* \`${securityLevel.toUpperCase()}\``;

      return m.reply(
        `🛡️ *CLOUDFLARE SECURITY LEVEL UPDATED!* 🛡️\n\n` +
        `${statusText}\n` +
        `🌐 *Domain:* \`${domain}\``
      );
    } else {
      return m.reply(`❌ Gagal mengubah Security Challenge Mode: ${JSON.stringify(updateRes.data.errors)}`);
    }
  } catch (err) {
    const errMsg = err.response?.data?.errors?.[0]?.message || err.message;
    return m.reply(`❌ *CLOUDFLARE API ERROR:*\n${errMsg}`);
  }
};

handler.command = ['cfchallenge'];
handler.category = 'panel';
handler.description = 'Manajemen Cloudflare Security Challenge Level (Under Attack Mode, High, Medium, Status)';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
