/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const [ipvps, passwd] = input.split(separator).map(s => s.trim());

  m.reply(
    `🎨 *PROSES MEMASANG TEMA HALAMAN LOGIN KYZZ APIS...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🖼️ *Branding Logo:* Kyzz APIs Neon Cyber Logo\n` +
    `✨ *Aestetik:* Cyber Glassmorphism & Gradient Submit Button\n\n` +
    `⏳ Mohon tunggu sekitar 1 menit...`
  );

  const localShPath = path.join(process.cwd(), 'data/sh/login-theme.sh');
  const themeScript = fs.existsSync(localShPath)
    ? fs.readFileSync(localShPath, 'utf8')
    : 'echo "Login theme script not found"';

  const logoPath = path.join(process.cwd(), 'data/img/login_logo.jpg');
  let logoBase64 = '';
  if (fs.existsSync(logoPath)) {
    logoBase64 = fs.readFileSync(logoPath).toString('base64');
  }

  const fullScript = `
mkdir -p /var/www/pterodactyl/public/branding
cat << 'EOF_B64' > /var/www/pterodactyl/public/branding/kyzz_logo.b64
${logoBase64}
EOF_B64
base64 -d /var/www/pterodactyl/public/branding/kyzz_logo.b64 > /var/www/pterodactyl/public/branding/kyzz_logo.jpg || true

${themeScript}
exit 0
`;

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendThemeReport();
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(fullScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendThemeReport() {
    const reportText =
      `🎨 *PEMASANGAN TEMA HALAMAN LOGIN KYZZ APIS SELESAI!* 🎉\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🖼️ *Logo Login:* Logo Cybernetic Neon Kyzz APIs\n` +
      `✨ *Desain:* Dark Glassmorphism + Gradient Glow Button\n\n` +
      `🌐 *Silakan buka web panel Anda untuk melihat tampilan baru Halaman Login!*`;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['logintheme'];
handler.category = 'panel';
handler.description = 'Memasang Tema Khusus Halaman Login Branding Kyzz APIs (Logo Neon Cybernetic + Dark Glassmorphism) via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
