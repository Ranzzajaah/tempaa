/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const [ipvps, passwd] = input.split(separator).map(s => s.trim());

  m.reply(
    `🖤 *MEMULAI PEMASANGAN TEMA RESMI ELYSIUM (OFFICIAL OPEN SOURCE)...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🎨 *Visual Style:* Official Monospaced Dark Theme\n` +
    `📦 *Source:* \`instax-dutta/elysium\`\n\n` +
    `⏳ Mohon tunggu sekitar 1-2 menit...`
  );

  const localShPath = path.join(process.cwd(), 'data/sh/elysium-install.sh');
  const elysiumScript = fs.existsSync(localShPath)
    ? fs.readFileSync(localShPath, 'utf8')
    : 'curl -sL https://raw.githubusercontent.com/instax-dutta/elysium/main/install.sh | bash';

  const fullScript = `
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

cat << 'EOF_ELYSIUM' > /tmp/elysium-install.sh
${elysiumScript}
EOF_ELYSIUM

chmod +x /tmp/elysium-install.sh
bash /tmp/elysium-install.sh || true

cd /var/www/pterodactyl || exit
php artisan view:clear || true
systemctl restart nginx || true
systemctl restart php8.3-fpm || systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || true
rm -f /tmp/elysium-install.sh || true

exit 0
`;

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendElysiumReport();
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(fullScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendElysiumReport() {
    const reportText =
      `🖤 *PEMASANGAN TEMA RESMI ELYSIUM SELESAI!* 🖤\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🎨 *Style:* Official Monospaced Dark Theme\n` +
      `⚡ *Status:* Active & 100% Installed\n\n` +
      `🌐 *Silakan buka & hard refresh browser (Ctrl + F5) untuk melihat tampilan Tema Elysium!*`;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['elysium', 'instalelysium', 'elysiumtheme'];
handler.category = 'panel';
handler.description = 'Memasang Tema Resmi Elysium (Monospaced Dark Theme) via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
