/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || !input.includes(',')) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password,token_wings\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,eyJhbGciOi...!\``
    );
  }

  const t = input.split(',').map(s => s.trim());
  if (t.length < 3) return m.reply(`❌ Format salah! Gunakan: \`${usedPrefix + command} ipvps,password,token\``);

  const [ipvps, passwd, token] = t;
  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };

  const scriptPath = path.join(process.cwd(), 'data/sh/autonode.sh');
  const scriptContent = fs.existsSync(scriptPath)
    ? fs.readFileSync(scriptPath, 'utf8')
    : 'bash <(curl -s https://raw.githubusercontent.com/wndrzzka/installer-pterodactlty/main/install.sh)';

  m.reply(`⚙️ *PROSES CONFIGURE & START WINGS DIMULAI...*\n🖥️ *IP VPS:* \`${ipvps}\``);

  const conn = new Client();
  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        m.reply(`✅ *SUKSES START WINGS!* Silakan cek status Node di web panel Anda (Harus berstatus Hijau 🟢).`);
      }).on('data', (data) => {
        stream.write('iniwannbroku\n');
        stream.write('3\n');
        stream.write(`${token}\n`);
      });

      stream.write(scriptContent + '\n');
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI GAGAL:* ${err.message}`);
  }).connect(connSettings);
};

handler.command = ['wingsstart'];
handler.category = 'panel';
handler.description = 'Configure dan start Wings Pterodactyl via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
