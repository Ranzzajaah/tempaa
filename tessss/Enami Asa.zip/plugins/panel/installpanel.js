/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

const handler = async (m, { sock, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password,domainpnl,domainnode,ramvps\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,panel.domain.com,node.domain.com,8000\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const t = input.split(separator).map(s => s.trim());
  if (t.length < 5) {
    return m.reply(`❌ Format kurang lengkap! Gunakan: \`${usedPrefix + command} ipvps,password,domainpnl,domainnode,ramvps\``);
  }

  const [ipvps, passwd, subdomain, domainnode, ramvps] = t;
  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const generatedPass = generateRandomPassword();

  m.reply(
    `🚀 *PROSES INSTALL PTERODACTYL PANEL DIMULAI!*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🌐 *Domain Panel:* \`${subdomain}\`\n` +
    `🌐 *Domain Node:* \`${domainnode}\`\n` +
    `💾 *RAM Node:* \`${ramvps} MB\`\n\n` +
    `⏳ Mohon tunggu 5-10 menit...`
  );

  const pteroScriptPath = path.join(process.cwd(), 'data/sh/ptero-installer.sh');
  const nodeScriptPath = path.join(process.cwd(), 'data/sh/autonode.sh');

  const pteroScript = fs.existsSync(pteroScriptPath)
    ? fs.readFileSync(pteroScriptPath, 'utf8')
    : 'bash <(curl -s https://pterodactyl-installer.se)';

  const nodeScript = fs.existsSync(nodeScriptPath)
    ? fs.readFileSync(nodeScriptPath, 'utf8')
    : 'bash <(curl -s https://raw.githubusercontent.com/wndrzzka/installer-pterodactlty/main/install.sh)';

  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      let answered = false;
      stream.on('close', () => {
        installWings(conn, domainnode, subdomain, generatedPass, ramvps);
      }).on('data', (data) => {
        const str = data.toString();
        if (str.includes('Input') && !answered) {
          answered = true;
          stream.write('0\n\n\n1248\nAsia/Jakarta\nadmin@gmail.com\nadmin@gmail.com\nadmin\nadmin\nadmin\n');
          stream.write(`${generatedPass}\n`);
          stream.write(`${subdomain}\n`);
          stream.write('y\ny\ny\ny\ny\n\n1\n');
        }
        if (str.includes('Please read the Terms of Service')) {
          stream.write('Y\n');
        }
      }).stderr.on('data', () => {});

      stream.write(pteroScript + '\n');
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  async function installWings(connInst, domainNode, subDom, pass, ram) {
    await sock.sendMessage(m.chat, { text: `⚙️ *PROSES INSTALL WINGS SEDANG BERLANGSUNG...*\n\n⏳ Mohon tunggu 3-5 menit.` }, { quoted: m });

    connInst.exec('bash -s', (err, stream) => {
      if (err) {
        connInst.end();
        return m.reply(`❌ *WINGS EXEC ERROR:* ${err.message}`);
      }

      let answeredWings = false;
      stream.on('close', () => {
        createNode(connInst, domainNode, ram, subDom, pass);
      }).on('data', (data) => {
        const str = data.toString();
        if (str.includes('Input') && !answeredWings) {
          answeredWings = true;
          stream.write('1\ny\ny\ny\n');
          stream.write(`${subDom}\n`);
          stream.write('y\nuser\n1248\ny\n');
          stream.write(`${domainNode}\n`);
          stream.write('y\nadmin@gmail.com\ny\n');
        }
      }).stderr.on('data', () => {});

      stream.write(pteroScript + '\n');
    });
  }

  async function createNode(connInst, domainNode, ram, subDom, pass) {
    await sock.sendMessage(m.chat, { text: `📍 *MEMULAI AUTONODE & LOCATION CREATION...*` }, { quoted: m });

    connInst.exec('bash -s', (err, stream) => {
      if (err) {
        connInst.end();
        return m.reply(`❌ *NODE EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        connInst.end();
        sendPanelData(subDom, pass);
      }).on('data', (data) => {
        stream.write('iniwannbroku\n');
        stream.write('4\n');
        stream.write('SGP\n');
        stream.write('Autonode WannFyy\n');
        stream.write(`${domainNode}\n`);
        stream.write('NODES\n');
        stream.write(`${ram}\n`);
        stream.write(`${ram}\n`);
        stream.write('1\n');
      }).stderr.on('data', () => {});

      stream.write(nodeScript + '\n');
    });
  }

  function sendPanelData(subDom, pass) {
    const infoText =
      `🎉 *INSTALLASI PTERODACTYL PANEL SELESAI!* 🎉\n\n` +
      `🌐 *LOGIN:* https://${subDom}\n` +
      `👤 *USERNAME:* \`admin\`\n` +
      `🔑 *PASSWORD:* \`${pass}\`\n\n` +
      `📌 *Catatan:* Silakan buka web panel Anda, buat Allocation pada Node, ambil Token Configuration, lalu jalankan:\n` +
      `👉 \`${usedPrefix}wingsstart ${ipvps},${passwd},TOKEN_WINGS\`\n\n` +
      `⏳ *Harap tunggu 1-3 menit agar SSL & Domain aktif sepenuhnya.*`;

    sock.sendMessage(m.chat, { text: infoText }, { quoted: m });
  }
};

handler.command = ['installpanel'];
handler.category = 'panel';
handler.description = 'Otomatisasi Instalasi Pterodactyl Panel, Wings, dan Node via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
