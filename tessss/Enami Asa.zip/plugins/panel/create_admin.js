/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { createAdmin } from '../../lib/cpanel.js';

const handler = async (m, { sock, text, usedPrefix }) => {
	if (!text) {
		return m.reply(`❌ *Format Salah!*\n\nPenggunaan:\n*${usedPrefix}createadmin namapanel,nowa*\natau\n*${usedPrefix}createadmin 628xxxx,namapanel*`);
	}

	await global.react(sock, m, 'loading');

	try {
		const result = await createAdmin({ text, sock });
		const { user, sendRes } = result;

		let replyText = `👑 *AKUN ADMIN PANEL BERHASIL DIBUAT*\n\n` +
			`• *TYPE:* Root Admin User\n` +
			`• *ID:* ${user.id}\n` +
			`• *USERNAME:* ${user.username}\n` +
			`• *EMAIL:* ${user.email}\n` +
			`• *NAME:* ${user.first_name} ${user.last_name}\n` +
			`• *ADMIN:* ${user.root_admin}\n` +
			`• *CREATED AT:* ${user.created_at}\n\n`;

		if (sendRes.wa) {
			replyText += `📲 Detail login admin telah berhasil dikirimkan ke PM WhatsApp tujuan!`;
		} else {
			replyText += `⚠️ Gagal mengirim ke PM WhatsApp tujuan (pastikan nomor valid & terdaftar).`;
		}

		if (sendRes.tg) {
			replyText += `\n✈️ Detail admin juga berhasil dikirimkan ke Telegram!`;
		}

		await m.reply(replyText);
		await global.react(sock, m, 'success');
	} catch (err) {
		console.error('[CREATE ADMIN ERROR]', err);
		await global.react(sock, m, 'error');
		return m.reply(`❌ ${err?.message || 'Gagal membuat akun admin panel'}`);
	}
};

handler.command = ['createadmin', 'addadminpanel'];
handler.category = 'panel';
handler.description = 'Buat akun Admin (Root Admin) Pterodactyl Panel';
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
