/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password\`\n` +
      `💡 *Contoh:* \`${usedPrefix + command} 103.187.xxx.xxx,Password123\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const [ipvps, passwd] = input.split(separator).map(s => s.trim());

  m.reply(
    `🌸 *MEMULAI PEMASANGAN TEMA KYZZ THEMES (WHITE PINK ANIME PIXEL ART)...*\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🎨 *Visual Style:* Soft Pastel White & Sakura Pink Anime Pixel Art Bedroom\n` +
    `🐱 *Mascot:* Cute White Pixel Cat & Sakura Sparkles\n` +
    `✨ *Branding:* Kyzz Themes × Dynamic User Greeting\n\n` +
    `⏳ Mohon tunggu sekitar 1-2 menit...`
  );

  const localShPath = path.join(process.cwd(), 'data/sh/kyzz-pink-theme.sh');
  const themeScript = fs.existsSync(localShPath)
    ? fs.readFileSync(localShPath, 'utf8')
    : 'echo "Kyzz Pink script not found"';

  const bgLocalPath = path.join(process.cwd(), 'data/img/kyzz_pink_bg.jpg');
  const mascotLocalPath = path.join(process.cwd(), 'data/img/kyzz_pink_mascot.jpg');

  let bgBase64 = '';
  let mascotBase64 = '';

  if (fs.existsSync(bgLocalPath)) bgBase64 = fs.readFileSync(bgLocalPath).toString('base64');
  if (fs.existsSync(mascotLocalPath)) mascotBase64 = fs.readFileSync(mascotLocalPath).toString('base64');

  const fullScript = `
mkdir -p /var/www/pterodactyl/public/branding

cat << 'EOF_BG' > /var/www/pterodactyl/public/branding/kyzz_pink_bg.b64
${bgBase64}
EOF_BG
base64 -d /var/www/pterodactyl/public/branding/kyzz_pink_bg.b64 > /var/www/pterodactyl/public/branding/kyzz_pink_bg.jpg || true

cat << 'EOF_MASCOT' > /var/www/pterodactyl/public/branding/kyzz_pink_mascot.b64
${mascotBase64}
EOF_MASCOT
base64 -d /var/www/pterodactyl/public/branding/kyzz_pink_mascot.b64 > /var/www/pterodactyl/public/branding/kyzz_pink_mascot.jpg || true

${themeScript}
exit 0
`;

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendThemeReport();
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(fullScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendThemeReport() {
    const reportText =
      `🌸 *PEMASANGAN TEMA KYZZ THEMES (WHITE PINK ANIME PIXEL ART) SELESAI!* 🌸\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🎨 *Style:* Soft Pastel White & Sakura Pink Anime Pixel Art\n` +
      `✨ *Dynamic Greeting:* Active ("Welcome Back!" & "Welcome, {username}!")\n` +
      `🐱 *Mascot:* Cute Sleeping White Pixel Cat\n\n` +
      `🌐 *Silakan buka web panel Anda sekarang untuk melihat tampilan White Pink Kyzz Themes!*`;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['kyzzpink'];
handler.category = 'panel';
handler.description = 'Memasang Tema Kyzz Themes (Soft Pastel White & Sakura Pink Anime Pixel Art) via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
