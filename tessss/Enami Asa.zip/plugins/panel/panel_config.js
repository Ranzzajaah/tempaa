/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const handler = async (m, { args, command, usedPrefix }) => {
	const cmd = command.toLowerCase();

	if (cmd === 'domain') {
		return m.reply(`📍 *Domain Panel:* \n${global.domain || 'Belum diatur'}`);
	}

	if (cmd === 'plta') {
		return m.reply(`📍 *PLTA Token:* \n${global.plta || 'Belum diatur'}`);
	}

	if (cmd === 'pltc') {
		return m.reply(`📍 *PLTC Token:* \n${global.pltc || 'Belum diatur'}`);
	}

	if (cmd === 'setpanel') {
		const type = args[0] ? args[0].toLowerCase() : '';
		const value = args[1] ? args[1].trim() : '';

		if (!['domain', 'plta', 'pltc', 'loc', 'eggs'].includes(type) || !value) {
			return m.reply(
				`❌ *Format Salah!*\n\n` +
				`Penggunaan:\n` +
				`• *${usedPrefix}setpanel domain https://panel.domain.com*\n` +
				`• *${usedPrefix}setpanel plta ptla_xxxx*\n` +
				`• *${usedPrefix}setpanel pltc ptlc_xxxx*\n` +
				`• *${usedPrefix}setpanel loc 1*\n` +
				`• *${usedPrefix}setpanel eggs 15*`
			);
		}

		global[type] = value;

		try {
			const settingsPath = path.join(process.cwd(), 'settings.js');
			let content = fs.readFileSync(settingsPath, 'utf-8');

			const regex = new RegExp(`global\\.${type}\\s*=\\s*['"][^'"]*['"];?`);
			if (content.match(regex)) {
				content = content.replace(regex, `global.${type} = '${value}';`);
			} else {
				content += `\nglobal.${type} = '${value}';\n`;
			}

			fs.writeFileSync(settingsPath, content);
			return m.reply(`✅ Sukses memperbarui *global.${type}* menjadi: \`${value}\` (Tersimpan di settings.js)`);
		} catch (e) {
			console.error('[SETPANEL ERROR]', e);
			return m.reply(`✅ Sukses memperbarui *global.${type}* di memory runtime.`);
		}
	}
};

handler.command = ['setpanel'];
handler.category = 'panel';
handler.description = 'Cek dan atur konfigurasi domain/plta/pltc Pterodactyl Panel';
handler.owner = true;
handler.noJadiBot = true;

handler.register = true;

export default handler;
