/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import axios from 'axios';
import { Client } from 'ssh2';

function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function getCFSettings() {
  const token = global.cftoken || global.tokencf || global.tokenCF || '';
  const zone = global.cfzone || global.zonecf || global.zoneCF || '';
  const domain = global.cfdomain || global.domaincf || global.domainCF || global.domain || '';
  return { token, zone, domain };
}

const handler = async (m, { sock, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || (!input.includes(',') && !input.includes('|'))) {
    return m.reply(
      `❌ *FORMAT SALAH!*\n\n` +
      `📌 *Penggunaan:* \`${usedPrefix + command} ipvps,password,ramvps\` ATAU \`${usedPrefix + command} ipvps,password,namasubdo,ramvps\`\n` +
      `💡 *Contoh 1 (Otomatis Subdomain kyzz-apis):* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,8000\`\n` +
      `💡 *Contoh 2 (Custom Subdomain):* \`${usedPrefix + command} 103.187.xxx.xxx,Password123,panel1,8000\``
    );
  }

  const separator = input.includes('|') ? '|' : ',';
  const t = input.split(separator).map(s => s.trim());
  let ipvps, passwd, subName, ramvps;
  if (t.length === 3) {
    [ipvps, passwd, ramvps] = t;
    const randNum = Math.floor(Math.random() * 3) + 1;
    subName = randNum === 1 ? 'kyzz-apis' : `kyzz-apis${randNum}`;
  } else if (t.length >= 4) {
    [ipvps, passwd, subName, ramvps] = t;
  } else {
    return m.reply(`❌ Format kurang lengkap! Gunakan: \`${usedPrefix + command} ipvps,password,ramvps\` atau \`${usedPrefix + command} ipvps,password,namasubdo,ramvps\``);
  }

  const { token: cfToken, zone: cfZone, domain: cfDomain } = getCFSettings();
  if (!cfToken || !cfZone) {
    return m.reply('❌ Konfigurasi Cloudflare belum diisi pada `settings.js`!');
  }

  const cleanDomain = cfDomain.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  const nodeSubName = subName.includes('.') ? `node-${subName}` : `node-${subName}.${cleanDomain}`;

  m.reply(
    `🌐 *MEMBUAT SUBDOMAIN CLOUDFLARE...*\n` +
    `🌐 *Main:* \`${mainDomain}\`\n` +
    `📡 *Node:* \`${nodeSubName}\`\n` +
    `🖥️ *IP:* \`${ipvps}\``
  );

  const headers = {
    'Authorization': `Bearer ${cfToken}`,
    'Content-Type': 'application/json'
  };

  try {
    await axios.post(`https://api.cloudflare.com/client/v4/zones/${cfZone}/dns_records`, {
      type: 'A', name: mainDomain, content: ipvps, ttl: 1, proxied: false
    }, { headers });

    await axios.post(`https://api.cloudflare.com/client/v4/zones/${cfZone}/dns_records`, {
      type: 'A', name: nodeSubName, content: ipvps, ttl: 1, proxied: false
    }, { headers });
  } catch (err) {
    return m.reply(`❌ *CLOUDFLARE DNS CREATION ERROR:* ${err.response?.data?.errors?.[0]?.message || err.message}`);
  }

  const generatedPass = generateRandomPassword();

  m.reply(
    `🚀 *ULTIMATE FULL SETUP (SUBDOMAIN + PANEL + LOCATION + NODE + WINGS) DIMULAI!* 🚀\n\n` +
    `🖥️ *IP VPS:* \`${ipvps}\`\n` +
    `🌐 *Domain Panel:* \`${mainDomain}\`\n` +
    `📡 *Domain Node:* \`${nodeSubName}\`\n` +
    `💾 *RAM Node:* \`${ramvps} MB\`\n\n` +
    `⏳ Bot sedang menginstal seluruh komponen dari Subdomain hingga Wings secara otomatis...\n` +
    `⏱️ *Estimasi Waktu:* 3-5 Menit.`
  );

  const fullSetupScript = `
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
ufw disable || true
iptables -F || true

rm -f /etc/nginx/sites-enabled/default || true

apt-get update -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"
apt-get install -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" software-properties-common curl apt-transport-https ca-certificates gnupg tar unzip git jq nginx mariadb-server certbot python3-certbot-nginx

LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php || true
apt-get update -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold"
apt-get install -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" php8.3 php8.3-fpm php8.3-cli php8.3-common php8.3-mysql php8.3-pdo php8.3-mbstring php8.3-tokenizer php8.3-xml php8.3-curl php8.3-zip php8.3-bcmath php8.3-gd php8.3-intl

curl -sS https:

mariadb -e "CREATE DATABASE IF NOT EXISTS panel;" || true
mariadb -e "CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY 'SecretPass123!';" || true
mariadb -e "GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1' WITH GRANT OPTION;" || true
mariadb -e "FLUSH PRIVILEGES;" || true

mkdir -p /var/www/pterodactyl
cd /var/www/pterodactyl

curl -sL https:

chmod -R 755 storageAPP_NAME="Kyzz APIs"/g' .env
sed -i 's|APP_URL=.*|APP_URL="https://${mainDomain}"|g' .env
sed -i 's/DB_PASSWORD=.*/DB_PASSWORD="SecretPass123!"/g' .env

php artisan migrate --seed --force || true

php artisan p:user:make --email="admin@gmail.com" --username="admin" --name-first="Admin" --name-last="Kyzz" --password="${generatedPass}" --admin=1 --no-interaction || php artisan tinker --execute="\\$u = Pterodactyl\\\\Models\\\\User::where('username', 'admin')->first(); if(\\$u) { \\$u->password = Hash::make('${generatedPass}'); \\$u->save(); }" || true

chown -R www-data:www-data /var/www/pterodactyl
chmod -R 775 /var/www/pterodactyl/storage /var/www/pterodactyl/bootstrap/cache

PHP_SOCK=$(ls /run/php/php*-fpm.sock 2>/dev/null | head -n 1)
if [ -z "$PHP_SOCK" ]; then
  PHP_SOCK="/run/php/php8.3-fpm.sock"
fi

certbot certonly --nginx -d ${mainDomain} --non-interactive --agree-tos -m admin@gmail.com || certbot certonly --standalone -d ${mainDomain} --non-interactive --agree-tos -m admin@gmail.com || true

cat << 'EOF_NGINX' > /etc/nginx/sites-available/pterodactyl.conf
server {
    listen 80;
    server_name ${mainDomain};
    return 301 https:
}

server {
    listen 443 ssl http2;
    server_name ${mainDomain};

    root /var/www/pterodactyl/public;
    index index.html index.htm index.php;
    charset utf-8;

    ssl_certificate /etc/letsencrypt/live/${mainDomain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${mainDomain}/privkey.pem;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    access_log off;
    error_log  /var/log/nginx/pterodactyl.app-error.log error;

    client_max_body_size 100M;
    client_body_timeout 120s;

    sendfile off;

    location ~ \\.php$ {
        fastcgi_split_path_info ^(.+\\.php)(/.+)$;
        fastcgi_pass unix:PHP_SOCK_VAL;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }

    location ~ /\\.ht {
        deny all;
    }
}
EOF_NGINX

sed -i "s|unix:PHP_SOCK_VAL|unix:$PHP_SOCK|g" /etc/nginx/sites-available/pterodactyl.conf
ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf

nginx -t && systemctl restart nginx
systemctl restart php8.3-fpm || systemctl restart php8.1-fpm || systemctl restart php8.2-fpm || true

sed -i "s/'locale' => '.*/'locale' => 'id',/g" config/app.php || true
sed -i "s/APP_LOCALE=.*/APP_LOCALE=id/g" .env || true
if ! grep -q "APP_LOCALE" .env; then
  echo "APP_LOCALE=id" >> .env
fi

php artisan p:location:make --short="kyzz-apis" --long="kyzz-apis Location" --no-interaction || true

php artisan p:node:make --name="kyzz-apis" --description="Autocreated Kyzz APIs Node" --locationId=1 --fqdn="${nodeSubName}" --public=1 --scheme="https" --proxy=0 --maintenance=0 --maxMemory=${ramvps} --overallocateMemory=0 --maxDisk=100000 --overallocateDisk=0 --uploadSize=100 --daemonListeningPort=8080 --daemonSFTPPort=2022 --daemonBase="/var/lib/pterodactyl/volumes" --no-interaction || true

for p in $(seq 25565 25585); do
  mariadb -u pterodactyl -pSecretPass123! panel -e "INSERT IGNORE INTO allocations (node_id, ip, ip_alias, port, created_at, updated_at) VALUES (1, '${ipvps}', 'api.kyzzz.xyz', $p, NOW(), NOW());" || true
done

# Auto Create Nest & Egg kyuuj
mariadb -u pterodactyl -pSecretPass123! panel -e "INSERT IGNORE INTO nests (id, uuid, author, name, description, created_at, updated_at) VALUES (5, UUID(), 'admin@gmail.com', 'kyzz bot wasap', 'Nest khusus bot WhatsApp', NOW(), NOW());" || true

cat << 'EOF_EGG_KYUUJ' > /root/egg-kyuuj.json
{
    "_comment": "DO NOT EDIT: FILE GENERATED AUTOMATICALLY BY PTERODACTYL PANEL - PTERODACTYL.IO",
    "meta": {
        "version": "PTDL_v2",
        "update_url": null
    },
    "exported_at": "2025-06-28T12:41:20+07:00",
    "name": "kyuuj",
    "author": "kyzz@gmail.com",
    "description": "Lu Mau Buat Bot Wa??\\r\\nPake Egg Ini Jangan Salah Pake Ya\\r\\nSalah Dikit Gak Ngaruh, Tapi Kalo Salah Eggg Yaa Buat Server Baru",
    "features": null,
    "docker_images": {
        "ghcr.io/parkervcp/yolks:nodejs_24": "ghcr.io/parkervcp/yolks:nodejs_24",
        "ghcr.io/parkervcp/yolks:nodejs_23": "ghcr.io/parkervcp/yolks:nodejs_23",
        "ghcr.io/parkervcp/yolks:nodejs_22": "ghcr.io/parkervcp/yolks:nodejs_22",
        "ghcr.io/parkervcp/yolks:nodejs_21": "ghcr.io/parkervcp/yolks:nodejs_21",
        "ghcr.io/parkervcp/yolks:nodejs_20": "ghcr.io/parkervcp/yolks:nodejs_20",
        "ghcr.io/parkervcp/yolks:nodejs_19": "ghcr.io/parkervcp/yolks:nodejs_19",
        "ghcr.io/parkervcp/yolks:nodejs_18": "ghcr.io/parkervcp/yolks:nodejs_18",
        "ghcr.io/parkervcp/yolks:nodejs_17": "ghcr.io/parkervcp/yolks:nodejs_17",
        "ghcr.io/parkervcp/yolks:nodejs_16": "ghcr.io/parkervcp/yolks:nodejs_16",
        "ghcr.io/parkervcp/yolks:nodejs_15": "ghcr.io/parkervcp/yolks:nodejs_15",
        "ghcr.io/parkervcp/yolks:nodejs_14": "ghcr.io/parkervcp/yolks:nodejs_14",
        "ghcr.io/parkervcp/yolks:nodejs_13": "ghcr.io/parkervcp/yolks:nodejs_13",
        "ghcr.io/parkervcp/yolks:nodejs_12": "ghcr.io/parkervcp/yolks:nodejs_12",
        "ghcr.io/parkervcp/yolks:nodejs_11": "ghcr.io/parkervcp/yolks:nodejs_11",
        "ghcr.io/parkervcp/yolks:nodejs_10": "ghcr.io/parkervcp/yolks:nodejs_10",
        "ghcr.io/parkervcp/yolks:nodejs_9": "ghcr.io/parkervcp/yolks:nodejs_9",
        "ghcr.io/parkervcp/yolks:nodejs_8": "ghcr.io/parkervcp/yolks:nodejs_8",
        "ghcr.io/parkervcp/yolks:nodejs_7": "ghcr.io/parkervcp/yolks:nodejs_7",
        "ghcr.io/parkervcp/yolks:nodejs_6": "ghcr.io/parkervcp/yolks:nodejs_6",
        "ghcr.io/parkervcp/yolks:nodejs_5": "ghcr.io/parkervcp/yolks:nodejs_5",
        "ghcr.io/parkervcp/yolks:nodejs_4": "ghcr.io/parkervcp/yolks:nodejs_4",
        "ghcr.io/parkervcp/yolks:nodejs_3": "ghcr.io/parkervcp/yolks:nodejs_3",
        "ghcr.io/parkervcp/yolks:nodejs_2": "ghcr.io/parkervcp/yolks:nodejs_2",
        "ghcr.io/parkervcp/yolks:nodejs_1": "ghcr.io/parkervcp/yolks:nodejs_1"
    },
    "file_denylist": [],
    "startup": "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \\"1\\" ]]; then git pull; fi; if [[ ! -z \${NODE_PACKAGES} ]]; then /usr/local/bin/npm install \${NODE_PACKAGES}; fi; if [[ ! -z \${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall \${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi;  if [[ ! -z \${CUSTOM_ENVIRONMENT_VARIABLES} ]]; then      vars=\$(echo \${CUSTOM_ENVIRONMENT_VARIABLES} | tr \\";\\" \\"\\\\n\\");      for line in \$vars;     do export \$line;     done fi;  /usr/local/bin/\${CMD_RUN};",
    "config": {
        "files": "{}",
        "startup": "{\\r\\n    \\"done\\": \\"running\\"\\r\\n}",
        "logs": "{}",
        "stop": "^^C"
    },
    "scripts": {
        "installation": {
            "script": "#!/bin/bash\\r\\n# NodeJS App Installation Script\\r\\n#\\r\\n# Server Files: /mnt/server\\r\\napt update\\r\\napt install -y git curl jq file unzip make gcc g++ python python-dev libtool\\r\\n\\r\\nmkdir -p /mnt/server\\r\\ncd /mnt/server\\r\\n\\r\\nif [ \\"\${USER_UPLOAD}\\" == \\"true\\" ] || [ \\"\${USER_UPLOAD}\\" == \\"1\\" ]; then\\r\\n    echo -e \\"assuming user knows what they are doing have a good day.\\"\\r\\n    exit 0\\r\\nfi\\r\\n\\r\\n## add git ending if it's not on the address\\r\\nif [[ \${GIT_ADDRESS} != *.git ]]; then\\r\\n    GIT_ADDRESS=\${GIT_ADDRESS}.git\\r\\nfi\\r\\n\\r\\nif [ -z \\"\${USERNAME}\\" ] && [ -z \\"\${ACCESS_TOKEN}\\" ]; then\\r\\n    echo -e \\"using anon api call\\"\\r\\nelse\\r\\n    GIT_ADDRESS=\\"https://\${USERNAME}:\${ACCESS_TOKEN}@\$(echo -e \${GIT_ADDRESS} | cut -d/ -f3-)\\"\\r\\nfi\\r\\n\\r\\n## pull git js repo\\r\\nif [ \\"\$(ls -A /mnt/server)\\" ]; then\\r\\n    echo -e \\"/mnt/server directory is not empty.\\"\\r\\n    if [ -d .git ]; then\\r\\n        echo -e \\".git directory exists\\"\\r\\n        if [ -f .git/config ]; then\\r\\n            echo -e \\"loading info from git config\\"\\r\\n            ORIGIN=\$(git config --get remote.origin.url)\\r\\n        else\\r\\n            echo -e \\"files found with no git config\\"\\r\\n            echo -e \\"closing out without touching things to not break anything\\"\\r\\n            exit 10\\r\\n        fi\\r\\n    fi\\r\\n\\r\\n    if [ \\"\${ORIGIN}\\" == \\"\${GIT_ADDRESS}\\" ]; then\\r\\n        echo \\"pulling latest from github\\"\\r\\n        git pull\\r\\n    fi\\r\\nelse\\r\\n    echo -e \\"/mnt/server is empty.\\\\ncloning files into repo\\"\\r\\n    if [ -z \${BRANCH} ]; then\\r\\n        echo -e \\"cloning default branch\\"\\r\\n        git clone \${GIT_ADDRESS} .\\r\\n    else\\r\\n        echo -e \\"cloning \${BRANCH}'\\"\\r\\n        git clone --single-branch --branch \${BRANCH} \${GIT_ADDRESS} .\\r\\n    fi\\r\\n\\r\\nfi\\r\\n\\r\\necho \\"Installing nodejs packages\\"\\r\\nif [[ ! -z \${NODE_PACKAGES} ]]; then\\r\\n    /usr/local/bin/npm install \${NODE_PACKAGES}\\r\\nfi\\r\\n\\r\\nif [ -f /mnt/server/package.json ]; then\\r\\n    /usr/local/bin/npm install --production\\r\\nfi\\r\\n\\r\\necho -e \\"install complete\\"\\r\\nexit 0",
            "container": "node:14-buster-slim",
            "entrypoint": "bash"
        }
    },
    "variables": [
        {
            "name": "Git Repo Address",
            "description": "GitHub Repo to clone\\r\\n\\r\\nI.E. https://github.com/user_name/repo_name",
            "env_variable": "GIT_ADDRESS",
            "default_value": "",
            "user_viewable": true,
            "user_editable": true,
            "rules": "nullable|string",
            "field_type": "text"
        },
        {
            "name": "Install Branch",
            "description": "The branch to install.",
            "env_variable": "BRANCH",
            "default_value": "",
            "user_viewable": true,
            "user_editable": true,
            "rules": "nullable|string",
            "field_type": "text"
        },
        {
            "name": "Git Username",
            "description": "Username to auth with git.",
            "env_variable": "USERNAME",
            "default_value": "",
            "user_viewable": true,
            "user_editable": true,
            "rules": "nullable|string",
            "field_type": "text"
        },
        {
            "name": "Git Access Token",
            "description": "Password to use with git.\\r\\n\\r\\nIt's best practice to use a Personal Access Token.\\r\\nhttps://github.com/settings/tokens\\r\\nhttps://gitlab.com/-/profile/personal_access_tokens",
            "env_variable": "ACCESS_TOKEN",
            "default_value": "",
            "user_viewable": true,
            "user_editable": true,
            "rules": "nullable|string",
            "field_type": "text"
        },
        {
            "name": "Command Run",
            "description": "The command to start the bot",
            "env_variable": "CMD_RUN",
            "default_value": "npm start",
            "user_viewable": true,
            "user_editable": true,
            "rules": "required|string",
            "field_type": "text"
        }
    ]
}
EOF_EGG_KYUUJ

php artisan p:egg:import /root/egg-kyuuj.json 5 || true

if ! command -v docker &> /dev/null; then
  curl -sSL https:
fi

systemctl enable --now docker || true
systemctl restart docker || true

mkdir -p /etc/pterodactyl /var/log/pterodactyl
curl -L -o /usr/local/bin/wings "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64" || true
chmod u+x /usr/local/bin/wings || true

certbot certonly --standalone -d ${nodeSubName} --non-interactive --agree-tos -m admin@gmail.com || certbot certonly --nginx -d ${nodeSubName} --non-interactive --agree-tos -m admin@gmail.com || true

NEW_SECRET=$(openssl rand -hex 8)
NEW_TOKEN=$(openssl rand -hex 32)

mariadb -u root -e "UPDATE panel.nodes SET daemon_token_id = '$NEW_SECRET', daemon_token = '$NEW_TOKEN' WHERE id = 1;" || true

cat << EOF_WINGS_CONF > /etc/pterodactyl/config.yml
debug: false
token_id: "$NEW_SECRET"
token: "$NEW_TOKEN"
api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: true
    cert: /etc/letsencrypt/live/\${nodeSubName}/fullchain.pem
    key: /etc/letsencrypt/live/\${nodeSubName}/privkey.pem
  upload_limit: 100
system:
  data: /var/lib/pterodactyl/volumes
  sftp:
    bind_port: 2022
allowed_mounts: []
remote: "https://\${mainDomain}"
EOF_WINGS_CONF

cat << 'EOF_WINGS_SVC' > /etc/systemd/system/wings.service
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF_WINGS_SVC

systemctl daemon-reload || true
systemctl enable --now wings || true
systemctl restart wings || true
exit 0
`;

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) {
        conn.end();
        return m.reply(`❌ *SSH EXEC ERROR:* ${err.message}`);
      }

      stream.on('close', () => {
        conn.end();
        sendFullSetupReport(mainDomain, nodeSubName, generatedPass, ramvps);
      }).on('data', () => {}).stderr.on('data', () => {});

      stream.write(fullSetupScript + '\n');
      stream.end();
    });
  }).on('error', (err) => {
    m.reply(`❌ *KONEKSI SSH GAGAL:* ${err.message}`);
  }).connect(connSettings);

  function sendFullSetupReport(subDom, domNode, pass, ram) {
    const reportText =
      `🎉 *ULTIMATE FULL SETUP SELESAI (100% READY & ONLINE)!* 🎉\n\n` +
      `🖥️ *IP VPS:* \`${ipvps}\`\n` +
      `🌐 *WEB PANEL:* https://${subDom}\n` +
      `📡 *NODE DOMAIN:* https://${domNode}\n` +
      `👤 *USERNAME:* \`admin\` (atau \`admin@gmail.com\`)\n` +
      `🔑 *PASSWORD:* \`${pass}\`\n\n` +
      `📍 *LOCATION:* \`SGP\` (Singapore Location)\n` +
      `📡 *NODE:* \`Node-Singapore\` (\`${domNode}\`)\n` +
      `💾 *RAM NODE:* \`${ram} MB\`\n` +
      `🔌 *ALLOCATIONS:* \`${ipvps}:25565 - 25585\` (21 Port Auto Created)\n` +
      `🔒 *SSL HTTPS:* Panel & Node Both Secured via Certbot\n` +
      `🟢 *STATUS WINGS:* 100% Online & Active Daemon\n\n` +
      `✨ *Subdomain Cloudflare, Pterodactyl Panel, Admin, Location, Node, Port, SSL, dan Wings sudah 100% siap dipakai tanpa perlu langkah manual!*`;

    sock.sendMessage(m.chat, { text: reportText }, { quoted: m });
  }
};

handler.command = ['fullsetup', 'fullsetuppanel', 'installall'];
handler.category = 'panel';
handler.description = '1-Click Ultimate All-in-One Full Setup (Auto Create Cloudflare Subdomains, Panel, Admin, Location, Node, Allocations, Docker, SSL, Wings Auto-Pairing)';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
