/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { Client } from 'ssh2';
import fs from 'fs';
import path from 'path';

const handler = async (m, { text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Perintah ini khusus untuk *Owner Bot*!');

  const input = (text || '').trim();
  if (!input || !input.includes(',')) return m.reply(`❌ Format salah! Gunakan: \`${usedPrefix + command} ipvps,password\``);
  const [ipvps, passwd] = input.split(',').map(s => s.trim());

  m.reply(`🔄 *PROSES REINSTALL PANEL SEDANG BERLANGSUNG...*\n⏳ Mohon tunggu 1-2 menit.`);

  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };

  const scriptPath = path.join(process.cwd(), 'data/sh/ptero-installer.sh');
  const scriptContent = fs.existsSync(scriptPath)
    ? fs.readFileSync(scriptPath, 'utf8')
    : 'bash <(curl -s https://pterodactyl-installer.se)';

  const conn = new Client();

  conn.on('ready', () => {
    conn.exec('bash -s', (err, stream) => {
      if (err) { conn.end(); return m.reply(`❌ Exec Error: ${err.message}`); }

      stream.on('close', () => {
        conn.end();
        m.reply(`✅ *REINSTALL PANEL SELESAI DILAKUKAN!*`);
      }).on('data', (data) => {
        const str = data.toString();
        if (str.includes('Input')) stream.write('6\n');
        if (str.includes('Input')) stream.write('y\n');
      });

      stream.write(scriptContent + '\n');
    });
  }).on('error', (err) => {
    m.reply(`❌ Koneksi VPS gagal: ${err.message}`);
  }).connect(connSettings);
};

handler.command = ['reinstallpanel'];
handler.category = 'panel';
handler.description = 'Reinstall Pterodactyl Panel via SSH';
handler.owner = true;

handler.noJadiBot = true;

export default handler;
