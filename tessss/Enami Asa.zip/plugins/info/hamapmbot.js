/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { prepareWAMessageMedia } from "@whiskeysockets/baileys";
import { getActiveThumbBuffer } from "../../lib/thumb.js";

const handler = async (m, { conn, sock, Func, args, isOwner }) => {
    const client = conn || sock;

    if (args[0] === "add" && isOwner && args[1]) {
        const target = args[1].replace(/[^0-9]/g, "");
        if (typeof global.addHama === "function") global.addHama(target);
        return m.reply(`✅ Nomor @${target} berhasil ditambahkan ke database hama PM.`, { mentions: [`${target}@s.whatsapp.net`] });
    }

    if (args[0] === "del" && isOwner && args[1]) {
        const target = args[1].replace(/[^0-9]/g, "");
        if (typeof global.removeHama === "function") global.removeHama(target);
        return m.reply(`✅ Nomor @${target} berhasil dihapus dari database hama PM.`, { mentions: [`${target}@s.whatsapp.net`] });
    }

    const hamaList = typeof global.getHamaList === "function" ? global.getHamaList() : [];

    let caption = `> ╭─❁  ᴅᴀꜰᴛᴀʀ ʜᴀᴍᴀ ᴘᴍ ❁\n`;
    caption += `> ◦❒ ᴛᴏᴛᴀʟ ʜᴀᴍᴀ : ${hamaList.length}\n`;
    caption += `> ◦❒ sᴛᴀᴛᴜs      : Anj Tukang PM Bot\n`;
    caption += `> ╰──────────────────❁\n\n`;

    hamaList.forEach((v, i) => {
        caption += `> ◦❒ ${i + 1}. @${v}\n`;
    });

    caption += `\n> ⚠️ ɴᴏᴛᴇ : Hindari melakukan spam di private chat agar limit tidak hangus atau terkena ban otomatis.`;

    const thumb = await getActiveThumbBuffer(300);

    let prepared = null;
    try {
        prepared = await prepareWAMessageMedia({
            image: thumb
        }, {
            upload: client.waUploadToServer,
            mediaTypeOverride: "thumbnail-link"
        });
    } catch (e) {}

    const textStyle = Func && typeof Func.Styles === "function" ? Func.Styles(caption) : caption;

    await client.sendMessage(
        m.chat, {
            text: `${global.website || "https://google.com"}\n\n${textStyle}`,
            mentions: hamaList.map(v => `${v}@s.whatsapp.net`),
            linkPreview: {
                "matched-text": global.website || "https://google.com",
                title: "ʙʟᴀᴄᴋʟɪsᴛ ʜᴀᴍᴀ ᴘᴍ",
                description: "Daftar user pengganggu ketenangan bot",
                previewType: 0,
                ...(thumb && thumb.length ? { jpegThumbnail: thumb } : {}),
                ...(prepared?.imageMessage ? { highQualityThumbnail: prepared.imageMessage } : {}),
                linkMediaDuration: 0,
                socialMediaPostType: 4
            }
        }, {
            quoted: m
        }
    );
};

handler.command = ["hama", "hamapmbot", "hamapm", "listhama"];
handler.tags = ["info"];
handler.help = ["hama"];

export default handler;
