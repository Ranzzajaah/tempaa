/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { scrapeSearch, scrapeHomeArticles, scrapeArticleDetail } from '../../scrape/okezone.js'

const handler = async (m, { conn, sock, text, reply, usedPrefix, command }) => {
	const client = conn || sock
	const cmd = command.toLowerCase()

	if (text && (text.startsWith('http://') || text.startsWith('https://'))) {
		reply(global.mess.wait)
		try {
			const detail = await scrapeArticleDetail(text.trim())
			if (!detail || !detail.title) {
				return reply('❌ Gagal menguraikan artikel Okezone.')
			}

			const caption = `📰 *${detail.title}*\n\n` +
				(detail.publishedAt ? `🕒 *Waktu:* ${detail.publishedAt}\n` : '') +
				(detail.author ? `👤 *Penulis:* ${detail.author}\n\n` : '\n') +
				`💬 ${detail.description || detail.fullText.slice(0, 300)}\n\n` +
				`🔗 *Link:* ${detail.url}`

			if (detail.image) {
				return await sock.sendMessage(m.chat, { image: { url: detail.image }, caption }, { quoted: m })
			} else {
				return reply(caption)
			}
		} catch (e) {
			console.error('[OKEZONE DETAIL ERROR]', e)
			return reply('❌ Terjadi kesalahan saat membaca berita.')
		}
	}

	if (!text) {
		reply(global.mess.wait)
		try {
			const articles = await scrapeHomeArticles({ limit: 10 })
			if (!articles || articles.length === 0) {
				return reply('❌ Gagal mengambil berita terkini Okezone.')
			}

			const listRows = articles.map((item, index) => {
				return {
					header: `Berita ${index + 1}`,
					title: item.title.slice(0, 24),
					description: item.title,
					id: `${usedPrefix}${cmd} ${item.url}`
				}
			})

			const listMessage = {
				title: '📰 Berita Terkini Okezone',
				sections: [{
					title: 'Pilih Berita Untuk Dibaca',
					rows: listRows
				}]
			}

			const nativeButtons = [{
				name: "single_select",
				buttonParamsJson: JSON.stringify(listMessage)
			}]

			if (client.relayMessage) {
				return await client.relayMessage(
					m.chat,
					{
						viewOnceMessage: {
							message: {
								interactiveMessage: {
									body: { text: `📰 *OKEZONE LATEST NEWS*\n\nBerikut berita terbaru hari ini dari Okezone.` },
									footer: { text: `© Hirara AI • News Portal` },
									nativeFlowMessage: { buttons: nativeButtons }
								}
							}
						}
					},
					{ quoted: m }
				)
			} else {
				let caption = `📰 *OKEZONE LATEST NEWS*\n\n`
				articles.forEach((item, index) => {
					caption += `*${index + 1}. ${item.title}*\n🔗 ${item.url}\n\n`
				})
				return reply(caption)
			}
		} catch (e) {
			console.error('[OKEZONE HOME ERROR]', e)
			return reply('❌ Terjadi kesalahan saat mengambil berita.')
		}
	}

	reply(`⏳ Mencari berita Okezone dengan kata kunci *"${text}"*...`)
	try {
		const results = await scrapeSearch(text, { limit: 10 })
		if (!results || results.length === 0) {
			return reply(`❌ Berita dengan kata kunci *"${text}"* tidak ditemukan.`)
		}

		const listRows = results.map((item, index) => {
			return {
				header: `Hasil ${index + 1}`,
				title: item.title.slice(0, 24),
				description: item.title,
				id: `${usedPrefix}${cmd} ${item.url}`
			}
		})

		const listMessage = {
			title: '🔍 Hasil Pencarian Okezone',
			sections: [{
				title: `Kata Kunci: ${text}`,
				rows: listRows
			}]
		}

		const nativeButtons = [{
			name: "single_select",
			buttonParamsJson: JSON.stringify(listMessage)
		}]

		if (client.relayMessage) {
			return await client.relayMessage(
				m.chat,
				{
					viewOnceMessage: {
						message: {
							interactiveMessage: {
								body: { text: `🔍 *OKEZONE SEARCH RESULTS*\n\nDitemukan *${results.length}* berita untuk *"${text}"*.` },
								footer: { text: `© Hirara AI • News Portal` },
								nativeFlowMessage: { buttons: nativeButtons }
							}
						}
					}
				},
				{ quoted: m }
			)
		} else {
			let caption = `🔍 *OKEZONE SEARCH RESULTS*\n\n`
			results.forEach((item, index) => {
				caption += `*${index + 1}. ${item.title}*\n🔗 ${item.url}\n\n`
			})
			return reply(caption)
		}
	} catch (e) {
		console.error('[OKEZONE SEARCH ERROR]', e)
		return reply('❌ Terjadi kesalahan saat mencari berita.')
	}
}

handler.help = ['okezone [kata_kunci/link]']
handler.tags = ['info', 'search']
handler.command = ['okezone', 'berita', 'news']
handler.limit = true;
handler.register = true

export default handler
