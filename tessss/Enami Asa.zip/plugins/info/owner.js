/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';
import { AIRich } from '../../lib/helper-bails.js';
import { getActiveThumbPath } from '../../lib/thumb.js';
import { uploadMedia } from '../../lib/Uploader.js';

let cachedUploadedMediaUrl = null;
let lastUploadedTime = 0;

async function getOrUploadMediaUrl() {
  const now = Date.now();
  if (cachedUploadedMediaUrl && now - lastUploadedTime < 1000 * 60 * 60 * 6) {
    return cachedUploadedMediaUrl;
  }

  const mediaImgPath = getActiveThumbPath() || path.join(process.cwd(), 'media', 'menu.jpg');
  let imgBuffer = null;
  if (mediaImgPath && fs.existsSync(mediaImgPath)) {
    imgBuffer = fs.readFileSync(mediaImgPath);
  }

  if (imgBuffer) {
    try {
      const uploadedUrl = await uploadMedia(imgBuffer, 'banner.jpg');
      if (uploadedUrl && typeof uploadedUrl === 'string' && uploadedUrl.startsWith('http')) {
        cachedUploadedMediaUrl = uploadedUrl;
        lastUploadedTime = now;
        return cachedUploadedMediaUrl;
      }
    } catch (err) {
      console.error('[UPLOAD BANNER MEDIA ERROR]:', err.message);
    }
  }

  return cachedUploadedMediaUrl || global.banner || global.thumbnail || '';
}

const handler = async (m, { conn, sock, reply }) => {
  const client = conn || sock || global.conn || global.mainSock;

  const rawOwners = Array.isArray(global.owner) ? global.owner : [global.owner].filter(Boolean);
  const firstOwner = rawOwners[0];
  let ownerNum = '';

  if (Array.isArray(firstOwner)) {
    ownerNum = String(firstOwner[0] || '').replace(/[^0-9]/g, '');
  } else if (firstOwner) {
    ownerNum = String(firstOwner).replace(/[^0-9]/g, '');
  }
  if (!ownerNum && global.nomerOwner) {
    ownerNum = String(global.nomerOwner).replace(/[^0-9]/g, '');
  }

  const ownerName = global.namaOwner || 'Owner';
  const botName = (global.namaBot || 'Hirara AI').replace(/[꒰꒱©]/g, '').trim();

  try {
    const ownerJid = `${ownerNum}@s.whatsapp.net`;

    let ownerPpUrl = null;
    if (client && typeof client.profilePictureUrl === 'function' && ownerNum) {
      try {
        ownerPpUrl = await client.profilePictureUrl(ownerJid, 'image').catch(() => null);
      } catch (_) {}
    }

    const bannerUrl = await getOrUploadMediaUrl();
    const avatarUrl = ownerPpUrl || bannerUrl || '';

    const rich = new AIRich(client);

    if (bannerUrl) {
      rich.addImage(bannerUrl, {
        width: 1080,
        height: 369
      });
    }

    rich._addContent(
      AIRich.newLayout('Single', {
        __typename: 'GenAICompactEntityPrimitive',
        title: ownerName,
        subtitle: `Owner ${botName}`,
        secondary_subtitle: 'Developer & Creator',
        entity_id: Date.now(),
        entity_url: `https://wa.me/${ownerNum}`,
        entity_type: 'PAGE',
        action_type: 'FOLLOW',
        is_verified: true,
        image: {
          url: avatarUrl || bannerUrl,
          url_fallback: bannerUrl || avatarUrl
        }
      }),
      { messageType: 2, messageText: `Hii ${m.pushName || 'kak'}, ini kontak Owner ${botName}` }
    );

    await rich.send(m.chat, { quoted: m });
  } catch (e) {
    console.error('[OWNER AIRich Error]:', e);
    const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : null;
    const fallbackText = `👑 *OWNER ${botName.toUpperCase()}*\n\n` +
      `• *Nama:* ${ownerName}\n` +
      `• *Kontak:* https://wa.me/${ownerNum}\n\n` +
      `Silakan hubungi kontak di atas untuk keperluan sewa atau info bot.`;

    if (doReply) {
      return doReply(fallbackText);
    } else if (client && typeof client.sendMessage === 'function') {
      return client.sendMessage(m.chat, { text: fallbackText }, { quoted: m });
    }
  }
};

handler.help = ['owner', 'own', 'creator'];
handler.tags = ['info'];
handler.command = ['owner', 'own', 'creator'];

export default handler;
