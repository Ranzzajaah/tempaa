/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'node:fs';
import { Button } from '../../lib/helper-bails.js';

const handler = async (m, { sock, usedPrefix, text, getPluginStats, getMenuData }) => {
	const menuData = typeof getMenuData === 'function' ? getMenuData() : {};
	let totalCmds = 0;
	for (const cat in menuData) {
		if (Array.isArray(menuData[cat])) totalCmds += menuData[cat].length;
	}
	const info = typeof getPluginStats === 'function' ? getPluginStats() : { totalFiles: totalCmds };
	const displayTotal = totalCmds || info.totalFiles || 0;

	let teks = `*Source code Hirara Ai*
- Script name : *${global.namaBot}*
- Creator : *${global.namaOwner}*
- Version : *${global.versi}*
- Type : *plugins*
- Total plugins : *${displayTotal}*
- Modules : *ESM*
- Database storage : *Sqlite3*
- Library : *baileys (original bails)*

*Price List SC:*
- Rp 15.000 : No update
- Rp 20.000 : 2× update
- Rp 30.000 : 5× update
- Rp 50.000 : Permanen update (sampe kapan-kapan)

*Fetures!*
- Free *${displayTotal}* fitur bawaan
- Fast respon & simpel
- Auto reload plugin & auto add ke list menu
- Auto convert lid to jid
- Support buttons, catalog, event, poll, dll
- Free example kode
- 100% tanpa ENC
- 100% tanpa newsletter follow

*Benefit:*
- Free Role VIP web api.kyzz.xyz
- Free konsultasi & bantuan install
- Script ringan & hemat RAM
- Full fitur & terupdate
- Mudah dipahami & dimodifikasi
- Bebas rename & recode`;

	const cryptoModule = await import('node:crypto');
	const randomUUID = cryptoModule.randomUUID ? cryptoModule.randomUUID() : `sc_${Date.now()}`;

	const btn = new Button(sock)
		.setImage(fs.existsSync('./media/menu.jpg') ? fs.readFileSync('./media/menu.jpg') : './media/menu.jpg')
		.setBody(`Hii *${m.pushName}*\n\n${teks}`)
		.setFooter('© kyzz')
		.addReviewAndPay({
			currency: 'IDR',
			total_amount: { value: 15000, offset: 0 },
			reference_id: 'kyzz',
			order_request_id: randomUUID,
			type: 'digital-goods',
			order: {
				status: 'shipped',
				subtotal: { value: 1500000, offset: 100 },
				tax: { value: 0, offset: 100 },
				discount: { value: 0, offset: 100 },
				shipping: { value: 0, offset: 100 },
				order_type: 'ORDER',
				items: [
					{
						retailer_id: 'sc-15k',
						name: 'Source code Hirara Ai - 15k (No Update)',
						amount: { value: 1500000, offset: 100 },
						quantity: 1,
						description: 'Benefit: Free Role VIP web api.kyzz.xyz, Free konsultasi & install, 100% tanpa ENC'
					},
					{
						retailer_id: 'sc-20k',
						name: 'Source code Hirara Ai - 20k (2x Update)',
						amount: { value: 2000000, offset: 100 },
						quantity: 1,
						description: 'Benefit: Free Role VIP web api.kyzz.xyz, 2x Update, Free konsultasi & install, 100% tanpa ENC'
					},
					{
						retailer_id: 'sc-30k',
						name: 'Source code Hirara Ai - 30k (5x Update)',
						amount: { value: 3000000, offset: 100 },
						quantity: 1,
						description: 'Benefit: Free Role VIP web api.kyzz.xyz, 5x Update, Free konsultasi & install, 100% tanpa ENC'
					},
					{
						retailer_id: 'sc-50k',
						name: 'Source code Hirara Ai - 50k (Permanen Update)',
						amount: { value: 5000000, offset: 100 },
						quantity: 1,
						description: 'Benefit: Free Role VIP web api.kyzz.xyz, Permanen Update, Free konsultasi & install, 100% tanpa ENC'
					}
				]
			}
		});

	await btn.send(m.chat, { quoted: m });
};

handler.command = ['sc', 'script'];
export default handler;