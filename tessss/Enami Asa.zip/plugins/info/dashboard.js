/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getStatsData } from '../../lib/database.js';
import { createCanvas } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY } from '../../canvas/canvas-font.js';

function drawRoundedCard(ctx, x, y, w, h, r, fill, stroke = '#000000', strokeWidth = 2, shadowColor = '#000000', shadowDist = 3) {
  if (shadowColor && shadowDist > 0) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(x + shadowDist, y + shadowDist, w, h, r);
    ctx.fillStyle = shadowColor;
    ctx.fill();
    ctx.restore();
  }

  ctx.save();
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fillStyle = fill;
  ctx.fill();

  if (stroke && strokeWidth > 0) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = strokeWidth;
    ctx.stroke();
  }

  ctx.clip();
  const gloss = ctx.createLinearGradient(x, y, x, y + Math.min(h * 0.45, 26));
  gloss.addColorStop(0, 'rgba(255, 255, 255, 0.45)');
  gloss.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = gloss;
  ctx.fillRect(x, y, w, Math.min(h * 0.45, 26));
  ctx.restore();
}

async function generateDashboardCanvas({
  botName = 'Hirara AI',
  totalHits = 273000,
  totalFeatures = 1172,
  totalCategories = 24,
  topList = []
}) {
  await ensureCanvasFonts().catch(() => {});
  const W = 1000, H = 1050;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  // Background cream
  ctx.fillStyle = '#fffae5';
  ctx.fillRect(0, 0, W, H);

  // Polka dots
  ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
  for (let gx = 16; gx < W; gx += 26) {
    for (let gy = 16; gy < H; gy += 26) {
      ctx.beginPath();
      ctx.arc(gx, gy, 1.8, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const p = 16;
  // Main frame 3D
  drawRoundedCard(ctx, p, p, W - p * 2, H - p * 2, 24, '#ffffff', '#000000', 3.5, '#000000', 6);

  // Top header pill (Pink)
  drawRoundedCard(ctx, p + 20, p + 18, 540, 52, 16, '#ff4794', '#000000', 3, '#000000', 4);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText('📊 BOT DASHBOARD & TOP 20 🚀', p + 40, p + 45);

  // Top right badge (Yellow)
  drawRoundedCard(ctx, W - p - 340, p + 18, 320, 52, 16, '#ffd000', '#000000', 3, '#000000', 4);
  ctx.font = `bold 17px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.textAlign = 'center';
  ctx.fillText(`⚡ ${totalHits.toLocaleString('id-ID')}x TOTAL HITS`, W - p - 180, p + 45);

  // 3 Stat Summary Cards
  const summaryY = p + 86;
  const summaryW = (W - p * 2 - 60) / 3;
  const summaryH = 70;

  const sumCards = [
    { title: '🎯 TOTAL HIT BOT', val: `${totalHits.toLocaleString('id-ID')}x`, bg: '#4deeea' },
    { title: '📦 TOTAL FITUR', val: `${totalFeatures.toLocaleString('id-ID')} Fitur`, bg: '#74ee15' },
    { title: '📁 TOTAL KATEGORI', val: `${totalCategories} Kategori`, bg: '#ffd000' }
  ];

  sumCards.forEach((c, i) => {
    const cx = p + 20 + i * (summaryW + 10);
    drawRoundedCard(ctx, cx, summaryY, summaryW, summaryH, 14, c.bg, '#000000', 2.5, '#000000', 3);
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillText(c.title, cx + summaryW / 2, summaryY + 24);
    ctx.font = `bold 20px ${FONT_FAMILY}`;
    ctx.fillText(c.val, cx + summaryW / 2, summaryY + 48);
  });

  // Top 20 Cards (2 Columns: Left 1-10, Right 11-20)
  const gridY = summaryY + summaryH + 20;
  const colW = (W - p * 2 - 50) / 2;
  const itemH = 68;
  const maxHit = topList.length > 0 ? (topList[0].total || 1) : 1;

  const displayList = topList.slice(0, 20);

  displayList.forEach((item, idx) => {
    const isRightCol = idx >= 10;
    const rowIdx = idx % 10;
    const itemX = p + 20 + (isRightCol ? colW + 10 : 0);
    const itemY = gridY + rowIdx * (itemH + 8);

    drawRoundedCard(ctx, itemX, itemY, colW, itemH, 12, '#ffffff', '#000000', 2, '#000000', 3);

    const rank = idx + 1;
    let rankBg = '#f1f5f9';
    if (rank === 1) rankBg = '#ffd000';
    else if (rank === 2) rankBg = '#e2e8f0';
    else if (rank === 3) rankBg = '#fed7aa';
    else if (rank <= 10) rankBg = '#4deeea';

    // Rank Badge
    drawRoundedCard(ctx, itemX + 10, itemY + 12, 42, 42, 10, rankBg, '#000000', 1.8, null, 0);
    ctx.font = `bold 16px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(`#${rank}`, itemX + 31, itemY + 34);

    // Command Name
    ctx.textAlign = 'left';
    ctx.font = `bold 16px ${FONT_FAMILY}`;
    ctx.fillStyle = '#0f172a';
    ctx.fillText(`.${item.name}`, itemX + 62, itemY + 24);

    // Hit Count
    ctx.textAlign = 'right';
    ctx.font = `bold 15px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ff4794';
    ctx.fillText(`${item.total.toLocaleString('id-ID')}x`, itemX + colW - 14, itemY + 24);

    // Progress Bar Track
    const barX = itemX + 62;
    const barY = itemY + 40;
    const barMaxW = colW - 76;
    const barH = 10;
    const progress = Math.max(0.05, Math.min(1, item.total / maxHit));
    const fillW = barMaxW * progress;

    drawRoundedCard(ctx, barX, barY, barMaxW, barH, 5, '#f1f5f9', '#000000', 1.2, null, 0);
    const barFillCol = rank <= 3 ? '#ff4794' : rank <= 10 ? '#00e5ff' : '#74ee15';
    drawRoundedCard(ctx, barX, barY, fillW, barH, 5, barFillCol, '#000000', 1.2, null, 0);
  });

  // Footer bar (Cyan)
  const footY = H - p - 56;
  const footW = W - p * 2 - 40;
  drawRoundedCard(ctx, p + 20, footY, footW, 46, 12, '#00e5ff', '#000000', 2.5, '#000000', 3);
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`✨ ${botName} • WhatsApp Bot Real-Time Analytics`, p + 38, footY + 24);

  ctx.textAlign = 'right';
  ctx.fillText(`${totalHits.toLocaleString('id-ID')} Hits Verified ✓`, p + 20 + footW - 20, footY + 24);

  return canvas.toBuffer('image/jpeg');
}

const getTime = (ms) => {
	const now = Date.now();
	const diff = Math.max(0, now - ms);
	const seconds = Math.floor(diff / 1000);
	const minutes = Math.floor(seconds / 60);
	const hours = Math.floor(minutes / 60);
	const days = Math.floor(hours / 24);

	if (days > 0) return `${days} hari yang lalu`;
	if (hours > 0) return `${hours} jam yang lalu`;
	if (minutes > 0) return `${minutes} menit yang lalu`;
	return `${seconds || 1} detik yang lalu`;
};

const handler = async (m, { conn, sock, reply, getMenuData, getPluginStats }) => {
	const client = conn || sock || global.mainSock;
	const statsData = (typeof getStatsData === 'function' ? getStatsData() : null) || global.db?.data?.stats || {};

	const stats = Object.entries(statsData)
		.map(([key, val]) => {
			if (!val || typeof val !== 'object') return null;
			return {
				name: key,
				total: val.total || 0,
				success: val.success || 0,
				last: val.last || 0
			};
		})
		.filter(Boolean)
		.sort((a, b) => (b.total || 0) - (a.total || 0));

	if (!stats.length) {
		return reply(`📊 *Dashboard ${global.namaBot || 'Hirara AI'}*\n\nBelum ada data riwayat command yang dieksekusi.`);
	}

	const menuData = typeof getMenuData === 'function' ? getMenuData() : {};
	const categories = Object.keys(menuData).filter(cat => cat !== '-' && !cat.startsWith('-'));
	let totalFeaturesCount = 0;
	for (const cat of categories) {
		totalFeaturesCount += Array.isArray(menuData[cat]) ? menuData[cat].length : 0;
	}
	if (totalFeaturesCount === 0) totalFeaturesCount = stats.length;

	const top20 = stats.slice(0, 20);
	const totalHits = stats.reduce((acc, cur) => acc + (cur.total || 0), 0);

	let txt = `📊 *DASHBOARD & STATISTIK BOT*\n` +
		`• *Nama Bot:* ${global.namaBot || 'Hirara AI'}\n` +
		`• *Total Hit:* ${totalHits.toLocaleString('id-ID')}x\n` +
		`• *Total Fitur Terdaftar:* ${totalFeaturesCount.toLocaleString('id-ID')} Fitur\n` +
		`• *Total Kategori:* ${categories.length || 24} Kategori\n\n` +
		`🏆 *TOP 20 COMMAND PALING SERING DIGUNAKAN:*\n\n`;

	txt += top20.map(({ name, total, last }, idx) => {
		const medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : '🔹';
		return `${medal} *${idx + 1}. .${name}*\n` +
			`  ├ 🎯 *Hit:* ${total.toLocaleString('id-ID')}x\n` +
			`  ╰ 🕒 *Terakhir:* ${getTime(last || Date.now())}`;
	}).join('\n\n');

	try {
		const cardBuffer = await generateDashboardCanvas({
			botName: global.namaBot || 'Hirara AI',
			totalHits,
			totalFeatures: totalFeaturesCount,
			totalCategories: categories.length || 24,
			topList: top20
		});

		if (cardBuffer) {
			await client.sendMessage(m.chat, {
				image: cardBuffer,
				caption: txt.trim()
			}, { quoted: m });
			return;
		}
	} catch (e) {
		console.error('[DASHBOARD CANVAS ERROR]:', e);
	}

	await reply(txt.trim());
};

handler.help = ['dashboard'];
handler.tags = ['info'];
handler.command = ['dashboard'];
handler.register = true;

export default handler;
