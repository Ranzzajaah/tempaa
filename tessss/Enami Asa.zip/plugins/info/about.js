/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getActiveThumbBuffer } from '../../lib/thumb.js';
import { Button } from '../../lib/helper-bails.js';

const handler = async (m, { conn, sock, reply }) => {
	const client = conn || sock;
	const botName = global.namaBot || 'Hirara AI';
	const ownerName = global.namaOwner || 'mommy kyu';

	const caption = `🌸 *${botName}* adalah bot WhatsApp yang cerdas dan sangat berguna untuk membantu Anda dalam menjawab pertanyaan dan memberikan solusi dengan cepat.\n\n` +
		`Dikembangkan oleh *${ownerName}* dan menggunakan base *${botName}* yang terus diperbarui.\n\n` +
		`Dengan kemampuan luas seperti pencarian informasi, manajemen aktivitas, dan respon cepat, *${botName}* siap membantu kebutuhan Anda.\n\n` +
		`Gunakan *${botName}* sekarang dan nikmati pengalaman bot WhatsApp yang modern dan cerdas! ✨\n\n` +
		`© ${botName} • Created by ${ownerName}`;

	const thumbBuf = await getActiveThumbBuffer().catch(() => null);

	try {
		const btn = new Button(client);
		if (thumbBuf && thumbBuf.length) {
			btn.setImage(thumbBuf);
		}
		btn.setBody('');
		btn.setFooter(caption);

		return await btn.send(m.chat, { quoted: m });
	} catch (err) {
		console.error('[ABOUT BUTTON PHOTO FAIL]', err);
		return (reply || m.reply)(caption);
	}
};

handler.help = ['about', 'aboutbot', 'infobot'];
handler.tags = ['info', 'main'];
handler.command = /^(about|aboutbot|infobot|botinfo)$/i;

export default handler;
