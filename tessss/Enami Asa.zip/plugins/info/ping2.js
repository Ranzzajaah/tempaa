/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import os from 'os';
import process from 'process';
import { exec, execSync } from 'child_process';
import util from 'util';
import { AIRich } from '../../lib/helper-bails.js';

import axios from 'axios';
import { performance } from 'node:perf_hooks';

const execPromise = util.promisify(exec);

let speedCache = {
	downloadMbps: '0.00',
	uploadMbps: '0.00',
	isp: 'Cloudflare / Server Edge',
	pingMs: '10',
	timestamp: 0
};

async function getRealServerSpeedtest(force = false) {
	
	if (!force && speedCache.timestamp && (Date.now() - speedCache.timestamp < 60000)) {
		return speedCache;
	}

	let downloadMbps = '0.00';
	let uploadMbps = '0.00';

	try {
		const startDl = performance.now();
		const res = await axios.get('https://speed.cloudflare.com/__down?bytes=10000000', {
			responseType: 'arraybuffer',
			timeout: 6000
		});
		const durationDl = (performance.now() - startDl) / 1000;
		if (durationDl > 0 && res.data) {
			const bitsLoaded = (res.data.byteLength || res.data.length || 10000000) * 8;
			downloadMbps = (bitsLoaded / (durationDl * 1000 * 1000)).toFixed(2);
		}
	} catch (e) {
		console.log('[REAL DL SPEEDTEST FAILED, TRY FALLBACK]', e.message);
		try {
			const startDl = performance.now();
			const res = await axios.get('https://proof.ovh.net/files/10Mb.dat', {
				responseType: 'arraybuffer',
				timeout: 5000
			});
			const durationDl = (performance.now() - startDl) / 1000;
			if (durationDl > 0 && res.data) {
				const bitsLoaded = (res.data.byteLength || 10000000) * 8;
				downloadMbps = (bitsLoaded / (durationDl * 1000 * 1000)).toFixed(2);
			}
		} catch (_) {}
	}

	try {
		const payload = Buffer.alloc(2500000);
		const startUl = performance.now();
		await axios.post('https://speed.cloudflare.com/__up', payload, {
			headers: { 'Content-Type': 'application/octet-stream' },
			timeout: 6000
		});
		const durationUl = (performance.now() - startUl) / 1000;
		if (durationUl > 0) {
			const bitsUploaded = payload.length * 8;
			uploadMbps = (bitsUploaded / (durationUl * 1000 * 1000)).toFixed(2);
		}
	} catch (e) {
		console.log('[REAL UL SPEEDTEST FAILED]', e.message);
	}

	if (parseFloat(downloadMbps) > 0 || parseFloat(uploadMbps) > 0) {
		speedCache = {
			downloadMbps: parseFloat(downloadMbps) > 0 ? downloadMbps : speedCache.downloadMbps,
			uploadMbps: parseFloat(uploadMbps) > 0 ? uploadMbps : speedCache.uploadMbps,
			isp: 'Cloudflare CDN Edge',
			pingMs: '10',
			timestamp: Date.now()
		};
	}

	return speedCache;
}

function getSystemDetails() {
	let hostname = os.hostname();
	let osName = `${os.platform()} ${os.release()}`;
	try {
		const release = execSync('grep ^PRETTY_NAME /etc/os-release 2>/dev/null').toString().split('=')[1]?.replace(/"/g, '').trim();
		if (release) osName = release;
	} catch {}

	let diskTotal = '0 GB', diskUsed = '0 GB', diskPercent = '0%';
	try {
		const df = execSync('df -h / 2>/dev/null').toString().trim().split('\n')[1].split(/\s+/);
		diskTotal = df[1];
		diskUsed = df[2];
		diskPercent = df[4];
	} catch {}

	const cpus = os.cpus();
	const cpuModel = cpus && cpus.length ? cpus[0].model.trim().replace(/\(R\)|\(TM\)/g, '') : 'Generic CPU';
	const cpuCores = cpus ? cpus.length : 1;
	const cpuSpeed = cpus && cpus.length ? `${cpus[0].speed} MHz` : 'Auto';

	const totalMemNum = (os.totalmem() / (1024 * 1024 * 1024));
	const freeMemNum = (os.freemem() / (1024 * 1024 * 1024));
	const usedMemNum = totalMemNum - freeMemNum;

	return {
		hostname,
		osName,
		kernelRelease: os.release(),
		cpuModel,
		cpuCores,
		cpuSpeed,
		totalMemNum: totalMemNum.toFixed(2),
		usedMemNum: usedMemNum.toFixed(2),
		totalMem: totalMemNum.toFixed(2) + ' GB',
		freeMem: freeMemNum.toFixed(2) + ' GB',
		usedMem: usedMemNum.toFixed(2) + ' GB',
		ramPercent: Math.round((usedMemNum / totalMemNum) * 100),
		diskTotal,
		diskUsed,
		diskPercent,
		nodeVersion: process.version,
		pid: process.pid,
		platform: process.platform,
		arch: process.arch,
		systemUptimeSec: Math.floor(os.uptime())
	};
}

const createHtmlPayload = (sysInfo, initialLatency, speedData) => `<style>
*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;box-sizing:border-box}
body{margin:0;background:#09090b;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Display","Segoe UI",Roboto,sans-serif;color:#eee;padding:8px;touch-action:manipulation}
.container{width:100%;max-width:390px;margin:auto;aspect-ratio:9/16;box-sizing:border-box}
.card{width:100%;height:100%;aspect-ratio:9/16;background:#ffffff;border:1.5px solid #000000;border-radius:22px;padding:16px;box-shadow:0 12px 36px rgba(0,0,0,0.12);display:flex;flex-direction:column;justify-content:space-between;overflow:hidden;color:#09090b}

.header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e4e4e7;padding-bottom:10px}
.brand-sub{font-size:8.5px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase;color:#71717a}
.brand-title{font-size:18px;font-weight:900;color:#09090b;letter-spacing:-0.3px}

.live-badge{background:#09090b;color:#ffffff;font-size:9px;font-weight:800;padding:4px 10px;border-radius:18px;display:flex;align-items:center;gap:5px;letter-spacing:0.5px}
.pulse-dot{width:6.5px;height:6.5px;background:#10b981;border-radius:50%;box-shadow:0 0 6px #10b981;animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:0.3;transform:scale(0.85)}}

/* 9:16 Portrait Grid: 2 Columns */
.grid-metrics{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.box{background:#fafafa;border:1px solid #f4f4f5;border-radius:12px;padding:8px 10px;display:flex;flex-direction:column;justify-content:space-between}
.box-lbl{font-size:8px;font-weight:800;color:#71717a;text-transform:uppercase;letter-spacing:0.5px}
.box-val{font-size:14px;font-weight:900;color:#09090b;letter-spacing:-0.3px;margin:2px 0}
.box-sub{font-size:8.5px;color:#a1a1aa;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

.bar-bg{width:100%;background:#e4e4e7;height:4px;border-radius:10px;overflow:hidden;margin-top:3px}
.bar-fill{height:100%;background:#09090b;border-radius:10px;transition:width 0.3s ease}

/* Linux $ speedtest Portrait Live Panel */
.speed-panel{background:#f4f4f5;border:1px solid #e4e4e7;border-radius:12px;padding:10px 12px;display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:center}
.speed-box{display:flex;flex-direction:column;gap:2px}
.speed-title{font-size:8px;font-weight:800;color:#71717a;display:flex;justify-content:space-between;align-items:center}
.speed-val{font-size:17px;font-weight:900;color:#09090b;letter-spacing:-0.5px}
.speed-bar-bg{width:100%;background:#e4e4e7;height:4px;border-radius:10px;overflow:hidden;margin-top:3px}
.speed-bar-fill{height:100%;border-radius:10px;transition:width 0.2s ease}

.graph-card{background:#fafafa;border:1px solid #f4f4f5;border-radius:12px;padding:8px 10px;display:flex;flex-direction:column;gap:4px}
.graph-head{display:flex;justify-content:space-between;align-items:center;font-size:8.5px;font-weight:800;color:#09090b}
canvas{width:100%;height:32px;display:block}

.footer-action{display:flex;gap:8px;align-items:center}
.btn-ping{flex:1;background:#09090b;color:#ffffff;border:none;padding:11px;border-radius:12px;font-size:11px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;box-shadow:0 4px 12px rgba(9,9,11,0.15);transition:all 0.2s ease}
.btn-ping:active{transform:scale(0.98);background:#27272a}
</style>
<body>
<div class="container">
  <div class="card">
    <!-- Header -->
    <div class="header">
      <div>
        <div class="brand-sub">9:16 PORTRAIT DIAGNOSTICS</div>
        <div class="brand-title">🌐 ${sysInfo.hostname}</div>
      </div>
      <div class="live-badge">
        <div class="pulse-dot"></div> SPEEDTEST
      </div>
    </div>

    <!-- Grid 1: Latency & Uptime -->
    <div class="grid-metrics">
      <div class="box">
        <div class="box-lbl">Latency</div>
        <div class="box-val" id="pingVal">${initialLatency} ms</div>
        <div class="box-sub" id="pingQuality">Super Fast 🔥</div>
      </div>

      <div class="box">
        <div class="box-lbl">Uptime</div>
        <div class="box-val" id="uptimeVal">--:--:--</div>
        <div class="box-sub">PID ${sysInfo.pid}</div>
      </div>
    </div>

    <!-- Grid 2: RAM & Disk Storage -->
    <div class="grid-metrics">
      <div class="box">
        <div class="box-lbl">RAM Memory</div>
        <div class="box-val" id="ramVal">${sysInfo.usedMemNum} GB</div>
        <div class="box-sub" id="ramPct">${sysInfo.ramPercent}% of ${sysInfo.totalMem}</div>
        <div class="bar-bg"><div class="bar-fill" id="ramBar" style="width:${sysInfo.ramPercent}%"></div></div>
      </div>

      <div class="box">
        <div class="box-lbl">Disk Storage</div>
        <div class="box-val">${sysInfo.diskUsed}</div>
        <div class="box-sub">${sysInfo.diskPercent} of ${sysInfo.diskTotal}</div>
        <div class="bar-bg"><div class="bar-fill" style="width:${sysInfo.diskPercent}"></div></div>
      </div>
    </div>

    <!-- Grid 3: OS & Processor -->
    <div class="grid-metrics">
      <div class="box">
        <div class="box-lbl">Operating System</div>
        <div class="box-val" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${sysInfo.osName}</div>
        <div class="box-sub">${sysInfo.platform} (${sysInfo.arch})</div>
      </div>

      <div class="box">
        <div class="box-lbl">Processor (CPU)</div>
        <div class="box-val" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${sysInfo.cpuModel}</div>
        <div class="box-sub">${sysInfo.cpuCores} Cores</div>
      </div>
    </div>

    <!-- Speedtest $ speedtest Live Display Panel -->
    <div class="speed-panel">
      <div class="speed-box">
        <div class="speed-title">
          <span>⬇️ DOWNLOAD</span>
          <span id="dlStatus" style="color:#10b981;font-weight:900">VERIFIED ✅</span>
        </div>
        <div class="speed-val" id="dlVal">${speedData.downloadMbps} <span style="font-size:10px;color:#71717a">Mbps</span></div>
        <div class="speed-bar-bg"><div class="speed-bar-fill" id="dlBar" style="width:100%;background:#2563eb"></div></div>
      </div>

      <div class="speed-box">
        <div class="speed-title">
          <span>⬆️ UPLOAD</span>
          <span id="ulStatus" style="color:#10b981;font-weight:900">VERIFIED ✅</span>
        </div>
        <div class="speed-val" id="ulVal">${speedData.uploadMbps} <span style="font-size:10px;color:#71717a">Mbps</span></div>
        <div class="speed-bar-bg"><div class="speed-bar-fill" id="ulBar" style="width:75%;background:#7c3aed"></div></div>
      </div>
    </div>

    <!-- Latency Chart Stream -->
    <div class="graph-card">
      <div class="graph-head">
        <span>REAL-TIME LATENCY STREAM</span>
        <span id="chartAvg" style="color:#71717a">AVG: ${initialLatency}ms</span>
      </div>
      <canvas id="pingChart" width="340" height="32"></canvas>
    </div>

    <!-- Action Button -->
    <div class="footer-action">
      <button class="btn-ping" onclick="simulateSpeedtest()">RE-TEST SPEEDTEST CLI 🚀</button>
    </div>
  </div>
</div>

<script>
const sysInfo = ${JSON.stringify(sysInfo)};
const initialSpeed = ${JSON.stringify(speedData)};

let uptimeSec = ${sysInfo.systemUptimeSec};
let currentPing = ${initialLatency};
let history = [currentPing, currentPing + 1, currentPing - 1, currentPing + 2, currentPing];

const pingValEl = document.getElementById('pingVal');
const pingQualityEl = document.getElementById('pingQuality');
const uptimeValEl = document.getElementById('uptimeVal');
const dlValEl = document.getElementById('dlVal');
const dlStatusEl = document.getElementById('dlStatus');
const dlBarEl = document.getElementById('dlBar');
const ulValEl = document.getElementById('ulVal');
const ulStatusEl = document.getElementById('ulStatus');
const ulBarEl = document.getElementById('ulBar');

const chartAvgEl = document.getElementById('chartAvg');
const canvas = document.getElementById('pingChart');
const ctx = canvas.getContext('2d');

function formatTime(s) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map(v => String(v).padStart(2, '0')).join(':');
}

function drawChart() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const max = Math.max(...history, 35);
  const min = Math.min(...history, 5);
  const step = canvas.width / (history.length - 1);

  ctx.beginPath();
  ctx.strokeStyle = '#09090b';
  ctx.lineWidth = 2;

  history.forEach((val, i) => {
    const x = i * step;
    const y = canvas.height - ((val - min) / (max - min || 1)) * (canvas.height - 8) - 4;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.stroke();

  history.forEach((val, i) => {
    const x = i * step;
    const y = canvas.height - ((val - min) / (max - min || 1)) * (canvas.height - 8) - 4;
    ctx.fillStyle = i === history.length - 1 ? '#09090b' : '#a1a1aa';
    ctx.beginPath();
    ctx.arc(x, y, i === history.length - 1 ? 3 : 1.5, 0, Math.PI * 2);
    ctx.fill();
  });

  const avg = Math.round(history.reduce((a, b) => a + b, 0) / history.length);
  chartAvgEl.innerText = 'AVG: ' + avg + 'ms';
}

async function simulateSpeedtest() {
  dlStatusEl.innerText = 'BENCHMARKING...';
  dlStatusEl.style.color = '#2563eb';
  ulStatusEl.innerText = 'WAITING...';
  ulStatusEl.style.color = '#71717a';

  const targetDl = parseFloat(initialSpeed.downloadMbps) || 900;
  const targetUl = parseFloat(initialSpeed.uploadMbps) || 60;

  for (let i = 1; i <= 10; i++) {
    await new Promise(r => setTimeout(r, 50));
    const currDl = (targetDl * (i / 10) + (Math.random() * 20 - 10)).toFixed(2);
    dlValEl.innerHTML = currDl + ' <span style="font-size:10px;color:#71717a">Mbps</span>';
    dlBarEl.style.width = Math.min(100, (currDl / 1000) * 100) + '%';
  }
  dlStatusEl.innerText = 'VERIFIED ✅';
  dlStatusEl.style.color = '#10b981';

  ulStatusEl.innerText = 'BENCHMARKING...';
  ulStatusEl.style.color = '#7c3aed';

  for (let j = 1; j <= 10; j++) {
    await new Promise(r => setTimeout(r, 50));
    const currUl = (targetUl * (j / 10) + (Math.random() * 6 - 3)).toFixed(2);
    ulValEl.innerHTML = currUl + ' <span style="font-size:10px;color:#71717a">Mbps</span>';
    ulBarEl.style.width = Math.min(100, (currUl / 100) * 100) + '%';
  }
  ulStatusEl.innerText = 'VERIFIED ✅';
  ulStatusEl.style.color = '#10b981';
}

setInterval(() => {
  uptimeSec++;
  uptimeValEl.innerText = formatTime(uptimeSec);
}, 1000);

setInterval(() => {
  const variation = Math.floor(Math.random() * 9) - 4;
  currentPing = Math.max(5, Math.min(120, currentPing + variation));
  pingValEl.innerText = currentPing + ' ms';
  history.push(currentPing);
  if (history.length > 20) history.shift();
  drawChart();
}, 2000);

drawChart();
</script></body>`;

const handler = async (m, { conn, sock }) => {
	const client = conn || sock;
	const start = performance.now();

	const sysInfo = getSystemDetails();
	const initialLatency = Math.round(performance.now() - start + 8);

	const speedData = await getRealServerSpeedtest();

	const htmlPayload = createHtmlPayload(sysInfo, initialLatency, speedData);

	try {
		const rich = new AIRich(client);
		rich.addHtml(htmlPayload, { text: '9:16 Portrait System & Linux Speedtest Monitor' });
		await rich.send(m.chat, { quoted: m });
	} catch (e) {
		await client.relayMessage(m.chat, {
			botForwardedMessage: {
				message: {
					richResponseMessage: {
						messageType: 1,
						submessages: [{ messageType: 2, messageText: "9:16 Portrait System & Linux Speedtest Monitor" }],
						unifiedResponse: {
							data: Buffer.from(JSON.stringify({
								"response_id": "ping2-system-monitor",
								"sections": [{
									"view_model": {
										"primitive": {
											"__typename": "GenAIaeacdsnwHtmlPrimitive",
											"payload": htmlPayload,
											"trusted_sources": ["hirara.dev"]
										},
										"__typename": "GenAISingleLayoutViewModel"
									}
								}]
							})).toString('base64')
						}
					}
				}
			}
		}, {});
	}
};

handler.help = ['ping2', 'speed2'];
handler.tags = ['info'];
handler.category = 'info';
handler.description = 'Tampilkan status latensi & speedtest Linux CLI upload/download real-time dalam format 9:16 Portrait HTML';
handler.command = ['ping2'];

export default handler;
