/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { getActiveThumbBuffer } from '../../lib/thumb.js';
import { Button } from '../../lib/helper-bails.js';

const toSmallCaps = (str) => {
	const smallCapsMap = {
		a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
		j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
		s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
	};
	return String(str).toLowerCase().split('').map(c => smallCapsMap[c] || c).join('');
};

const handler = async (m, { conn, sock, reply }) => {
	const client = conn || sock;

	const text = `╭─❁ *${toSmallCaps('THANK YOU TO')}* ❁\n` +
		`│\n` +
		`│ ✦ *Allah SWT.* (The Creator of Everything)\n` +
		`│ ✦ *Mother & Father* (My Greatest Support)\n` +
		`│ ✦ *wa.me/kyuucwesejati* (Developer Hirara)\n` +
		`│ ✦ *Hilman* (Dev Ryo Yamada MD)\n` +
		`│ ✦ *Kano* (femboy jing)\n` +
		`│ ✦ *Rennz* (penyopng ourin jir 😹)\n` +
		`│ ✦ *Raynold* (penyopng ourin jir 😹)\n` +
		`│ ✦ *Fahri* (Dev jssslyn MD)\n` +
		`│\n` +
		`│ ✦ *All Buyer*\n` +
		`│ ✦ *All User & Contributor*\n` +
		`╰─❁\n\n` +
		`_tq all my friend and ya gitulah_ ✨`;

	const thumbBuf = await getActiveThumbBuffer().catch(() => null);

	try {
		const btn = new Button(client);
		if (thumbBuf && thumbBuf.length) {
			btn.setImage(thumbBuf);
		}
		btn.setBody('');
		btn.setFooter(text);

		return await btn.send(m.chat, { quoted: m });
	} catch (err) {
		console.error('[TQTO ERROR]', err);
		return (reply || m.reply)(text);
	}
};

handler.help = ['tqto', 'thanksto'];
handler.tags = ['info', 'main'];
handler.command = /^(tqto|thanksto|thanks)$/i;

export default handler;
