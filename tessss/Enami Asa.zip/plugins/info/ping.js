/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import os from 'os';
import { execSync } from 'child_process';
import { performance } from 'node:perf_hooks';
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, 'fonts_ping');

const FONT_SOURCES = [
  {
    url: 'https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf',
    file: 'Inter.ttf',
    family: 'Inter',
  },
  {
    url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
    file: 'NotoColorEmoji.ttf',
    family: 'NotoEmoji',
  },
];

let fontsReady = false;

async function ensureFonts() {
  if (fontsReady) return;
  if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
  const { default: axios } = await import('axios');
  for (const f of FONT_SOURCES) {
    const p = join(FONT_DIR, f.file);
    if (!existsSync(p)) {
      const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
      writeFileSync(p, Buffer.from(data));
    }
    try { GlobalFonts.registerFromPath(p, f.family); } catch {}
  }
  fontsReady = true;
}

const F = (size, bold = false) => `${bold ? 'bold ' : ''}${size}px Inter, NotoEmoji, sans-serif`;

const formatSize = (bytes) => {
  if (!bytes || bytes === 0) return '0 B';
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
};

const formatTime = (seconds) => {
  seconds = Number(seconds);
  if (isNaN(seconds)) return '0m';
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  return `${m}m ${s}s`;
};

function getDisk() {
  try {
    const df = execSync('df -k --output=size,used / 2>/dev/null').toString();
    const lines = df.trim().split('\n');
    if (lines.length > 1) {
      const [total, used] = lines[1].trim().split(/\s+/).map(Number);
      return { total: total * 1024, used: used * 1024 };
    }
  } catch {}
  return { total: 0, used: 0 };
}

function getNetwork() {
  let totalRx = 0, totalTx = 0;
  try {
    const net = execSync('cat /proc/net/dev 2>/dev/null').toString();
    for (const line of net.split('\n')) {
      if (line.includes(':') && !line.includes('lo:')) {
        const parts = line.trim().split(/\s+/);
        totalRx += parseInt(parts[1]) || 0;
        totalTx += parseInt(parts[9]) || 0;
      }
    }
  } catch {}
  return { totalRx, totalTx };
}

function getOsName() {
  try {
    const id = execSync('grep ^PRETTY_NAME /etc/os-release 2>/dev/null').toString().split('=')[1]?.replace(/"/g, '').trim();
    if (id) return id;
  } catch {}
  return `${os.platform()} ${os.release()}`;
}

function getCpuUsage() {
  try {
    const s1 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
    execSync('sleep 0.15');
    const s2 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
    const idle1 = s1[4], total1 = s1.slice(1).reduce((a, b) => a + b, 0);
    const idle2 = s2[4], total2 = s2.slice(1).reduce((a, b) => a + b, 0);
    return Math.min(100, Math.max(0, (1 - (idle2 - idle1) / (total2 - total1)) * 100));
  } catch {
    const load = os.loadavg()[0];
    return Math.min(100, (load * 100) / os.cpus().length);
  }
}

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawProgressBar(ctx, x, y, w, h, val, max, color1, color2) {
  rrp(ctx, x, y, w, h, h / 2);
  ctx.fillStyle = 'rgba(201, 149, 110, 0.15)';
  ctx.fill();
  const fillW = Math.max(h, w * Math.min(1, Math.max(0, val / max)));
  const g = ctx.createLinearGradient(x, 0, x + fillW, 0);
  g.addColorStop(0, color1);
  g.addColorStop(1, color2);
  rrp(ctx, x, y, fillW, h, h / 2);
  ctx.fillStyle = g;
  ctx.fill();
}

async function generatePingCanvas(data) {
  const W = 900, H = 520;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#fdfbf7');
  bgGrad.addColorStop(0.5, '#f7f0e6');
  bgGrad.addColorStop(1, '#f1e6d6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 800; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const vign = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.75);
  vign.addColorStop(0, 'transparent');
  vign.addColorStop(1, 'rgba(140, 90, 50, 0.08)');
  ctx.fillStyle = vign;
  ctx.fillRect(0, 0, W, H);

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 14);
  ctx.strokeStyle = '#c9956e';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  rrp(ctx, p + 5, p + 5, W - p * 2 - 10, H - p * 2 - 10, 10);
  ctx.strokeStyle = 'rgba(201, 149, 110, 0.35)';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = 'bold 24px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText('SYSTEM & BOT STATUS', p + 35, p + 45);

  const latVal = typeof data.latency === 'number' ? data.latency : parseFloat(data.latency) || 0;
  const latColor = latVal < 150 ? '#15803d' : latVal < 350 ? '#d97706' : '#b91c1c';
  ctx.font = 'bold 14px sans-serif';
  const latText = `LATENCY: ${latVal.toFixed(2)} ms`;
  ctx.fillStyle = latColor;
  ctx.textAlign = 'right';
  ctx.fillText(latText, W - p - 35, p + 45);
  ctx.textAlign = 'left';

  const divY = p + 65;
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(p + 35, divY);
  ctx.lineTo(W - p - 35, divY);
  ctx.stroke();

  const startY = divY + 25;
  const leftX = p + 35;
  const rightX = p + 450;
  const colW = 385;

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText('RESOURCE USAGE', leftX, startY);

  ctx.font = 'bold 12px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(`CPU USAGE`, leftX, startY + 30);
  ctx.fillStyle = '#8c502b';
  ctx.textAlign = 'right';
  ctx.fillText(`${data.cpuPercent.toFixed(1)}%`, leftX + colW, startY + 30);
  ctx.textAlign = 'left';
  drawProgressBar(ctx, leftX, startY + 38, colW, 12, data.cpuPercent, 100, '#eab308', '#ca8a04');

  ctx.font = 'bold 12px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(`RAM USAGE`, leftX, startY + 75);
  ctx.fillStyle = '#8c502b';
  ctx.textAlign = 'right';
  ctx.fillText(`${data.ramPercent.toFixed(1)}%`, leftX + colW, startY + 75);
  ctx.textAlign = 'left';
  drawProgressBar(ctx, leftX, startY + 83, colW, 12, data.ramPercent, 100, '#3b82f6', '#1d4ed8');

  ctx.font = 'bold 12px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(`STORAGE DISK`, leftX, startY + 120);
  ctx.fillStyle = '#8c502b';
  ctx.textAlign = 'right';
  ctx.fillText(`${data.diskPercent.toFixed(1)}%`, leftX + colW, startY + 120);
  ctx.textAlign = 'left';
  drawProgressBar(ctx, leftX, startY + 128, colW, 12, data.diskPercent, 100, '#10b981', '#047857');

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText('NETWORK TRAFFIC', leftX, startY + 175);

  rrp(ctx, leftX, startY + 190, colW, 58, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.85)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = '12px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText('DOWNLOAD (RX)', leftX + 15, startY + 214);
  ctx.font = 'bold 15px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(formatSize(data.totalRx), leftX + 15, startY + 236);

  ctx.font = '12px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText('UPLOAD (TX)', leftX + 210, startY + 214);
  ctx.font = 'bold 15px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(formatSize(data.totalTx), leftX + 210, startY + 236);

  ctx.font = 'bold 14px sans-serif';
  ctx.fillStyle = '#7a3e20';
  ctx.fillText('HARDWARE & OS', rightX, startY);

  const infoBoxY = startY + 15;
  const infoBoxH = 233;
  rrp(ctx, rightX, infoBoxY, colW, infoBoxH, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.85)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  const rows = [
    { label: 'CPU Model', val: data.cpuModel.length > 25 ? data.cpuModel.substring(0, 23) + '…' : data.cpuModel },
    { label: 'CPU Cores / Clock', val: `${data.cpuCores} Cores @ ${data.cpuSpeed.toFixed(2)} GHz` },
    { label: 'Operating System', val: data.osName },
    { label: 'Platform & Arch', val: `${os.platform()} (${data.arch})` },
    { label: 'Kernel Version', val: data.kernel.length > 25 ? data.kernel.substring(0, 23) + '…' : data.kernel },
    { label: 'Node.js Version', val: data.nodeVersion },
    { label: 'System Hostname', val: data.hostname },
  ];

  let rowY = infoBoxY + 24;
  rows.forEach((r) => {
    ctx.font = '12px sans-serif';
    ctx.fillStyle = '#8c502b';
    ctx.fillText(r.label, rightX + 15, rowY);

    ctx.font = 'bold 12px sans-serif';
    ctx.fillStyle = '#3b1c0c';
    ctx.textAlign = 'right';
    ctx.fillText(r.val, rightX + colW - 15, rowY);
    ctx.textAlign = 'left';

    rowY += 29;
  });

  const footerY = H - p - 70;
  const footerW = W - p * 2 - 70;
  rrp(ctx, leftX, footerY, footerW, 50, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.95)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = '12px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText('BOT UPTIME', leftX + 20, footerY + 20);
  ctx.font = 'bold 15px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(formatTime(data.botUptime), leftX + 20, footerY + 39);

  ctx.font = '12px sans-serif';
  ctx.fillStyle = '#8c502b';
  ctx.fillText('SERVER UPTIME', leftX + 240, footerY + 20);
  ctx.font = 'bold 15px sans-serif';
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(formatTime(data.vpsUptime), leftX + 240, footerY + 39);

  ctx.font = 'bold 13px sans-serif';
  ctx.fillStyle = '#15803d';
  ctx.textAlign = 'right';
  ctx.fillText('SYSTEM ONLINE', leftX + footerW - 20, footerY + 30);
  ctx.textAlign = 'left';

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock }) => {
  try {
    await ensureFonts();

    const start = performance.now();
    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    const latency = performance.now() - start;

    const cpus = os.cpus();
    const totalMem = os.totalmem();
    const ramUsed = totalMem - os.freemem();
    const disk = getDisk();
    const net = getNetwork();

    const data = {
      latency,
      cpuPercent: parseFloat(getCpuUsage()),
      ramPercent: parseFloat(((ramUsed / totalMem) * 100).toFixed(1)),
      diskPercent: disk.total ? parseFloat(((disk.used / disk.total) * 100).toFixed(1)) : 0,
      totalRx: net.totalRx,
      totalTx: net.totalTx,
      cpuModel: cpus[0]?.model?.trim() || 'Unknown',
      cpuCores: cpus.length,
      cpuSpeed: (cpus[0]?.speed || 0) / 1000,
      loadAvg: os.loadavg(),
      hostname: os.hostname(),
      osName: getOsName(),
      kernel: os.release(),
      arch: os.arch(),
      nodeVersion: process.version,
      botUptime: process.uptime(),
      vpsUptime: os.uptime(),
    };

    const imgBuffer = await generatePingCanvas(data);

    await sock.sendMessage(m.chat, {
      image: imgBuffer,
      mimetype: 'image/jpeg',
    }, { quoted: m });

    await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (e) {
    console.error('[ping-canvas]', e);
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.command = ['ping', 'os', 'system'];
export default handler;