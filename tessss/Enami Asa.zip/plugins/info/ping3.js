/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import os from 'os';
import { execSync } from 'child_process';
import { performance } from 'node:perf_hooks';

const formatSize = (bytes) => {
	if (!bytes || bytes === 0) return '0 B';
	const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
	const i = Math.floor(Math.log(bytes) / Math.log(1024));
	return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
};

const formatTime = (seconds) => {
	seconds = Number(seconds);
	if (isNaN(seconds) || seconds <= 0) return '0d 0h 0m 0s';
	const d = Math.floor(seconds / 86400);
	const h = Math.floor((seconds % 86400) / 3600);
	const m = Math.floor((seconds % 3600) / 60);
	const s = Math.floor(seconds % 60);
	return `${d}d ${h}h ${m}m ${s}s`;
};

function getDisk() {
	try {
		const df = execSync('df -k --output=size,used,avail / 2>/dev/null').toString();
		const lines = df.trim().split('\n');
		if (lines.length > 1) {
			const [total, used, avail] = lines[1].trim().split(/\s+/).map(Number);
			return {
				total: total * 1024,
				used: used * 1024,
				avail: avail * 1024,
				percent: parseFloat(((used / total) * 100).toFixed(2))
			};
		}
	} catch {}
	return { total: 0, used: 0, avail: 0, percent: 0 };
}

function getNetwork() {
	let totalRx = 0, totalTx = 0;
	try {
		const net = execSync('cat /proc/net/dev 2>/dev/null').toString();
		for (const line of net.split('\n')) {
			if (line.includes(':') && !line.includes('lo:')) {
				const parts = line.trim().split(/\s+/);
				totalRx += parseInt(parts[1]) || 0;
				totalTx += parseInt(parts[9]) || 0;
			}
		}
	} catch {}
	return { totalRx, totalTx };
}

function getOsPrettyName() {
	try {
		const id = execSync('grep ^PRETTY_NAME /etc/os-release 2>/dev/null').toString().split('=')[1]?.replace(/"/g, '').trim();
		if (id) return id;
	} catch {}
	return `${os.type()} ${os.release()}`;
}

function getCpuUsage() {
	try {
		const s1 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
		execSync('sleep 0.15');
		const s2 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
		const idle1 = s1[4], total1 = s1.slice(1).reduce((a, b) => a + b, 0);
		const idle2 = s2[4], total2 = s2.slice(1).reduce((a, b) => a + b, 0);
		return Math.min(100, Math.max(0, (1 - (idle2 - idle1) / (total2 - total1)) * 100));
	} catch {
		const load = os.loadavg()[0];
		return Math.min(100, (load * 100) / (os.cpus().length || 1));
	}
}

function getBattery() {
	try {
		const cap = execSync('cat /sys/class/power_supply/BAT*/capacity 2>/dev/null').toString().trim();
		const status = execSync('cat /sys/class/power_supply/BAT*/status 2>/dev/null').toString().trim();
		if (cap) return `${cap}% (${status || 'Discharging'})`;
	} catch {}
	return 'AC Power / VPS';
}

const handler = async (m, { sock, reply }) => {
	const start = performance.now();
	await sock.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });
	const latency = (performance.now() - start).toFixed(2);

	const cpus = os.cpus();
	const cpuModel = cpus[0]?.model?.trim() || 'Unknown CPU';
	const cpuCores = cpus.length;
	const cpuSpeed = ((cpus[0]?.speed || 0) / 1000).toFixed(2);
	const cpuUsage = getCpuUsage().toFixed(2);

	const totalMem = os.totalmem();
	const freeMem = os.freemem();
	const usedMem = totalMem - freeMem;
	const ramPercent = ((usedMem / totalMem) * 100).toFixed(2);
	const memUsage = process.memoryUsage();

	const disk = getDisk();
	const net = getNetwork();
	const loadAvg = os.loadavg().map(v => v.toFixed(2)).join(', ');

	const infoText = `╭───「 *SYSTEM & BOT METRICS* 」───
│ ⚡ *Latency:* ${latency} ms
│ ⏱️ *Bot Uptime:* ${formatTime(process.uptime())}
│ 🖥️ *Host Uptime:* ${formatTime(os.uptime())}
╰─────────────────────────

╭───「 *HARDWARE & CPU* 」───
│ ⚙️ *Model:* ${cpuModel}
│ 🧮 *Cores / Clock:* ${cpuCores} Core(s) @ ${cpuSpeed} GHz
│ 📊 *CPU Usage:* ${cpuUsage}%
│ 📈 *Load Avg (1/5/15m):* [ ${loadAvg} ]
│ 🔋 *Power / Battery:* ${getBattery()}
╰─────────────────────────

╭───「 *MEMORY (RAM & HEAP)* 」───
│ 💾 *System RAM:* ${formatSize(usedMem)} / ${formatSize(totalMem)} (${ramPercent}%)
│ 🟢 *Free RAM:* ${formatSize(freeMem)}
│ 📦 *Node RSS:* ${formatSize(memUsage.rss)}
│ 📦 *Node Heap Used:* ${formatSize(memUsage.heapUsed)} / ${formatSize(memUsage.heapTotal)}
│ 📦 *Node External:* ${formatSize(memUsage.external)}
╰─────────────────────────

╭───「 *STORAGE & NETWORK* 」───
│ 💽 *Disk Usage:* ${formatSize(disk.used)} / ${formatSize(disk.total)} (${disk.percent}%)
│ 💽 *Disk Free:* ${formatSize(disk.avail)}
│ 📥 *Download (RX):* ${formatSize(net.totalRx)}
│ 📤 *Upload (TX):* ${formatSize(net.totalTx)}
╰─────────────────────────

╭───「 *ENVIRONMENT & OS* 」───
│ 🐧 *OS Name:* ${getOsPrettyName()}
│ 🏗️ *Platform / Arch:* ${os.platform()} (${os.arch()})
│ 🧬 *Kernel:* ${os.release()}
│ 🏷️ *Hostname:* ${os.hostname()}
│ 🟢 *Node.js:* ${process.version}
│ 🚀 *V8 Engine:* ${process.versions.v8}
╰─────────────────────────`.trim();

	await reply(infoText);
	await sock.sendMessage(m.chat, { react: { text: '🚀', key: m.key } });
};

handler.help = ['ping3'];
handler.tags = ['info'];
handler.command = ['ping3', 'p3', 'status3'];

export default handler;
