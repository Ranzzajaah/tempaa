/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import path from 'path';

const handler = async (m, { reply }) => {
	const dir = process.cwd();
	const kecuali = ['node_modules', 'sessions', '.npm', '.cache', '.git', '.pm2', 'tmp'];

	let tree = '';
	let totalFile = 0;
	let totalFolder = 0;
	const folderFilesCount = new Map();

	const traverse = (currentDir, prefix = '') => {
		let files = [];
		try {
			files = fs.readdirSync(currentDir);
		} catch {
			return 0;
		}

		let fileCountCurrentFolder = 0;

		files.forEach((file, index) => {
			const full = path.join(currentDir, file);
			if (kecuali.some(k => full.includes(k))) return;

			const last = index === files.length - 1;
			tree += prefix + (last ? '└── ' : '├── ') + file;

			try {
				if (fs.statSync(full).isDirectory()) {
					totalFolder++;
					tree += '\n';
					const countBefore = totalFile;
					traverse(full, prefix + (last ? '    ' : '│   '));
					const filesInThisFolder = totalFile - countBefore;
					folderFilesCount.set(full, filesInThisFolder);
				} else {
					totalFile++;
					fileCountCurrentFolder++;
					tree += '\n';
				}
			} catch {}
		});

		return fileCountCurrentFolder;
	};

	traverse(dir);

	tree += `\n📁 *Total folder:* ${totalFolder}\n📄 *Total file:* ${totalFile}\n\n`;
	tree += '📊 *Persentase file per folder:*\n';

	folderFilesCount.forEach((count, folder) => {
		const perc = totalFile ? ((count / totalFile) * 100).toFixed(2) : 0;
		tree += `- ${path.relative(process.cwd(), folder) || '.'}: ${count} file (${perc}%)\n`;
	});

	await reply(tree.trim());
};

handler.help = ['tree'];
handler.tags = ['info'];
handler.command = ['tree'];
handler.owner = true;
handler.register = true;

export default handler;
