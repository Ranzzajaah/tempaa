/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const SALAM_DATA = [
	{
		religion: 'Islam',
		keywords: [
			'assalamualaikum',
			'assalamu\'alaikum',
			'as-salamu alaykum',
			'assalamualaikum wr wb',
			'assalamu\'alaikum wr wb',
			'assalamualaikum warahmatullahi wabarakatuh',
			'assalamu\'alaikum warahmatullahi wabarakatuh',
			'samlikum',
			'mikum',
			'ass'
		],
		response: 'Wa\'alaikumsalam Warahmatullahi Wabarakatuh 🌙✨\nSemoga keberkahan, rahmat, dan keselamatan selalu menyertaimu.'
	},
	{
		religion: 'Kristen / Katolik',
		keywords: [
			'syalom',
			'shalom',
			'shalom aleichem',
			'salam damai kristus',
			'damai kristus'
		],
		response: 'Shalom! Damai Sejahtera Kristus Menyertai Kita Semua ✝️🕊️✨'
	},
	{
		religion: 'Hindu',
		keywords: [
			'om swastiastu',
			'swastiastu',
			'om shanti shanti shanti om',
			'om santi santi santi om'
		],
		response: 'Om Swastiastu 🕉️🪷✨\nSemoga damai dan kebaikan datang dari segala penjuru.'
	},
	{
		religion: 'Buddha',
		keywords: [
			'namo buddhaya',
			'namo buddhaya',
			'namo buddhaya',
			'sotthi hotu'
		],
		response: 'Namo Buddhaya ☸️🌸✨\nSemoga semua makhluk hidup berbahagia dan terbebas dari penderitaan.'
	},
	{
		religion: 'Konghucu',
		keywords: [
			'wei de dong tian',
			'xian you yi de',
			'salam kebajikan'
		],
		response: 'Wei De Dong Tian (Hanya Kebajikan Yang Berkenan Pada Tian) ☯️🎋✨\nSalam Kebajikan!'
	},
	{
		religion: 'Universal / Nusantara',
		keywords: [
			'rahayu',
			'sampurasun',
			'salam nusantara',
			'salam sejahtera'
		],
		response: 'Rahayu Sagung Dumadi / Sampurasun 🌿🇮🇩✨\nSalam sejahtera dan damai untuk kita semua!'
	}
];

const handler = async (m, { reply }) => {
	const rawText = (m.text || m.body || '').trim().toLowerCase();

	for (const item of SALAM_DATA) {
		const isMatched = item.keywords.some(kw => {
			const cleanKw = kw.toLowerCase().replace(/['\-\s]/g, '');
			const cleanMsg = rawText.replace(/['\-\s]/g, '');
			return cleanMsg.includes(cleanKw) || rawText === kw.toLowerCase();
		});

		if (isMatched) {
			return reply(item.response);
		}
	}

	return reply('Wa\'alaikumsalam / Salam Sejahtera / Rahayu untuk kita semua! 🌸✨');
};

handler.help = ['assalamualaikum', 'shalom', 'om swastiastu', 'namo buddhaya', 'wei de dong tian', 'rahayu'];
handler.tags = ['-'];
handler.command = [
	'assalamualaikum',
	'assalamu\'alaikum',
	'samlikum',
	'mikum',
	'shalom',
	'syalom',
	'swastiastu',
	'om swastiastu',
	'namobuddhaya',
	'namo buddhaya',
	'weidedongtian',
	'wei de dong tian',
	'rahayu',
	'sampurasun'
];
handler.noPrefix = true;
handler.register = false;

export default handler;
