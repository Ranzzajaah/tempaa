/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { isBotMessage } from '../../lib/detectbot.js';

const toSmallCaps = (str) => {
	const smallCapsMap = {
		a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
		j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
		s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
	};
	return str.toLowerCase().split('').map(c => smallCapsMap[c] || c).join('');
};

const handler = async (m) => m;

handler.before = async function (m, { sock, conn, isOwner, isAdmin, isBotAdmin, getGroup, isTrustedBot }) {
	conn = sock || conn || global.mainSock;

	if (!m.isGroup || m.fromMe || m.key.fromMe) return;

	const groupDb = typeof getGroup === 'function' ? await getGroup(m.chat) : null;
	if (groupDb?.antibot !== 1) return;

	if (!isBotAdmin) return;

	const senderJid = m.sender || m.key?.participant || '';
	const senderNumber = senderJid.replace(/[^0-9]/g, '');

	if (isOwner || isAdmin) return;

	if (typeof isTrustedBot === 'function' && isTrustedBot(senderJid)) return;

	const analysis = isBotMessage(m, conn);
	if (!analysis.isBot) return;

	const action = (groupDb?.antibot_action || 'kick').toLowerCase();

	try {
		await conn.sendMessage(m.chat, {
			delete: {
				remoteJid: m.chat,
				id: m.key.id,
				participant: m.key.participant || m.sender,
				fromMe: false
			}
		}).catch(() => {});

		if (action === 'del') {
			await conn.sendMessage(m.chat, {
				text: `🚫 *${toSmallCaps('Pesan dari bot')}* @${senderNumber} *${toSmallCaps('telah dihapus')}* (${analysis.confidence}% *${toSmallCaps('bot detect')}*).`,
				mentions: [senderJid]
			}, { quoted: m });
			return;
		}

		let caption = `🚫 *${toSmallCaps('Anti-Bot Terdeteksi')}* ✨\n\n` +
			`• 👤 *${toSmallCaps('Target:')}* @${senderNumber}\n` +
			`• 🤖 *${toSmallCaps('Status:')}* Terdeteksi Bot (${analysis.confidence}% probability)\n` +
			`• 🛡️ *${toSmallCaps('Tindakan:')}* Dikeluarkan dari grup demi keamanan.\n\n` +
			`꒰ © Hirara AI ꒱`;

		await conn.sendMessage(m.chat, {
			text: caption.trim(),
			mentions: [senderJid]
		}, { quoted: null });

		await conn.groupParticipantsUpdate(m.chat, [senderJid], 'remove').catch(() => {});
	} catch (e) {
		console.error('[ANTIBOT ACTION ERROR]', e);
	}
};

handler.command = [];
export default handler;
