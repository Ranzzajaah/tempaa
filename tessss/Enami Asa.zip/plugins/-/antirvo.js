/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { downloadContentFromMessage, downloadMediaMessage } from '@whiskeysockets/baileys';
import fs from 'fs';

const getMediaInfoAndBuffer = async (sock, m) => {
	const q = m;
	if (!q) return null;

	const qObj = q.message || q.msg || q;
	const viewOnceContainer = qObj?.viewOnceMessage || qObj?.viewOnceMessageV2 || qObj?.viewOnceMessageV2Extension || q?.viewOnceMessage || q?.viewOnceMessageV2 || q?.viewOnceMessageV2Extension;
	const innerMsg = viewOnceContainer?.message || qObj;

	const img = innerMsg?.imageMessage || qObj?.imageMessage || q?.imageMessage || (q.mtype === 'imageMessage' || /image/.test(q.mimetype || '') ? q : null);
	const vid = innerMsg?.videoMessage || qObj?.videoMessage || q?.videoMessage || (q.mtype === 'videoMessage' || /video/.test(q.mimetype || '') ? q : null);
	const aud = innerMsg?.audioMessage || qObj?.audioMessage || q?.audioMessage || (q.mtype === 'audioMessage' || /audio/.test(q.mimetype || '') ? q : null);

	const mediaMsg = img || vid || aud;
	const mediaType = img ? 'image' : vid ? 'video' : aud ? 'audio' : null;

	const isViewOnce = !!viewOnceContainer || !!mediaMsg?.viewOnce || q.mtype?.toLowerCase().includes('viewonce');
	if (!isViewOnce || !mediaMsg || !mediaType) return null;

	let buffer = null;

	try {
		const stream = await downloadContentFromMessage(mediaMsg, mediaType);
		let buf = Buffer.from([]);
		for await (const chunk of stream) {
			buf = Buffer.concat([buf, chunk]);
		}
		if (buf && buf.length > 0) buffer = buf;
	} catch (e) {
		console.log('[ANTIRVO METHOD 1 FAILED]', e.message);
	}

	if (!buffer || buffer.length === 0) {
		try {
			const realMsg = q.fakeObj ? q.fakeObj : (q.message ? q : { message: q.msg || q, key: q.key || {} });
			buffer = await downloadMediaMessage(realMsg, 'buffer', {}, { reuploadRequest: sock.updateMediaMessage });
		} catch (e) {
			console.log('[ANTIRVO METHOD 2 FAILED]', e.message);
		}
	}

	if (!buffer || buffer.length === 0) {
		try {
			if (typeof sock.downloadMediaMessage === 'function') {
				buffer = await sock.downloadMediaMessage(q);
			} else if (typeof sock.downloadAndSaveMediaMessage === 'function') {
				const tmpPath = await sock.downloadAndSaveMediaMessage(q);
				if (tmpPath && fs.existsSync(tmpPath)) {
					buffer = fs.readFileSync(tmpPath);
					fs.unlinkSync(tmpPath);
				}
			}
		} catch (e) {
			console.log('[ANTIRVO METHOD 3 FAILED]', e.message);
		}
	}

	if (!buffer || buffer.length === 0) return null;

	return {
		buffer,
		mediaType,
		caption: mediaMsg.caption || q.caption || q.text || '',
		mimetype: mediaMsg.mimetype || q.mimetype || '',
		ptt: !!mediaMsg.ptt || !!q.ptt
	};
};

const handler = async (m) => m;

handler.before = async (m, { sock, getGroup }) => {
	if (!m.isGroup || m.fromMe) return;

	const chatDb = await getGroup(m.chat);
	if (chatDb?.antiviewonce !== 1) return;

	try {
		const res = await getMediaInfoAndBuffer(sock, m);
		if (!res || !res.buffer) return;

		const { buffer, mediaType, caption: origCaptionStr, mimetype, ptt } = res;
		const sender = m.sender || m.key?.participant || m.key?.remoteJid;
		const userMention = sender ? `@${sender.split('@')[0]}` : 'Unknown';
		const timeStr = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
		const origCaption = origCaptionStr ? `\n💬 *Caption:* ${origCaptionStr}` : '';
		const caption = `『 ANTI RVO 』\n\n👤 *Pengirim:* ${userMention}\n🕒 *Waktu:* ${timeStr}\n📑 *Tipe:* ${mediaType.toUpperCase()}${origCaption}`;

		const mentions = sender ? [sender] : [];

		if (mediaType === 'image') {
			await sock.sendMessage(m.chat, { image: buffer, caption, mentions }, { quoted: m });
		} else if (mediaType === 'video') {
			await sock.sendMessage(m.chat, { video: buffer, caption, mentions }, { quoted: m });
		} else if (mediaType === 'audio') {
			await sock.sendMessage(m.chat, { text: caption, mentions }, { quoted: m });
			await sock.sendMessage(
				m.chat,
				{
					audio: buffer,
					mimetype: mimetype || 'audio/ogg; codecs=opus',
					ptt: ptt
				},
				{ quoted: m }
			);
		}
	} catch (e) {
		console.error('[ANTIRVO] Gagal memproses media view once:', e.message);
	}
};

handler.command = [];
handler.limit = true;

export default handler;
