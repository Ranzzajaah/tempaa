/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import moment from 'moment-timezone';
import { prepareWAMessageMedia } from '@whiskeysockets/baileys';
import fs from 'fs';
import axios from 'axios';
import '../../settings.js';

const handler = async (m) => m;

handler.onGroupUpdate = async (update, { sock, getGroup }) => {
	const { id, author, participants, action } = update;
	if (!id || !participants) return;

	const groupData = await getGroup(id);
	if (!groupData) return;

	const now = moment().tz('Asia/Jakarta');
	const defaultImage = 'https://athars.space/uploads/c528fdc2.jpeg';
	const pageUrl = global.linkGC || 'https://chat.whatsapp.com/LlePewannNRKTuduT4u57M?s=cl&p=a&mlu=4&ilr=4';

	let groupName = 'Group WhatsApp', groupDesc = '', totalMembers = 0, totalAdmins = 0;

	try {
		const metadata = await sock.groupMetadata(id);
		groupName = metadata.subject || 'Group WhatsApp';
		groupDesc = metadata.desc || '';
		totalMembers = metadata.participants.length;
		totalAdmins = metadata.participants.filter(v => v.admin !== null).length;
	} catch {
		console.log('Gagal ambil metadata grup');
	}

	const formatMessage = (template, userJid, actorJid) => {
		const userTag = `@${userJid.split('@')[0]}`;
		const actorTag = actorJid ? `@${actorJid.split('@')[0]}` : 'Admin';
		return template
			.replace(/@user/gi, userTag)
			.replace(/@tag/gi, userTag)
			.replace(/@grup/gi, groupName)
			.replace(/@group/gi, groupName)
			.replace(/@desk/gi, groupDesc)
			.replace(/@desc/gi, groupDesc)
			.replace(/@member/gi, totalMembers)
			.replace(/@admin/gi, totalAdmins)
			.replace(/@date/gi, now.format('DD MMMM YYYY'))
			.replace(/@time/gi, `${now.format('HH:mm:ss')} WIB`)
			.replace(/@actor/gi, actorTag);
	};

	const fetchBuffer = async (userJid) => {
		let imgUrl = null;
		if (userJid) {
			try {
				imgUrl = await sock.profilePictureUrl(userJid, 'image');
			} catch (_) {}
		}
		if (imgUrl) {
			try {
				const res = await axios.get(imgUrl, { responseType: 'arraybuffer' });
				return Buffer.from(res.data);
			} catch (_) {}
		}
		if (fs.existsSync('./src/avatar_contact.png')) {
			try { return fs.readFileSync('./src/avatar_contact.png'); } catch (_) {}
		}
		if (fs.existsSync('./src/wel-good.jpg')) {
			try { return fs.readFileSync('./src/wel-good.jpg'); } catch (_) {}
		}
		try {
			const res = await axios.get(defaultImage, { responseType: 'arraybuffer' });
			return Buffer.from(res.data);
		} catch (_) {
			return null;
		}
	};

	const sendWelcomeMessage = async (titleText, descText, captionText, mentions, userJid) => {
		const targetUrl = global.linkGC || pageUrl;
		const thumbBuf = await fetchBuffer(userJid);

		if (sock && typeof sock.sendButtons === 'function') {
			try {
				await sock.sendButtons(id, {
					type: 'location_buttons',
					thumbnail: thumbBuf,
					location: {
						degreesLatitude: 0,
						degreesLongitude: 0,
						name: titleText,
						address: descText,
						jpegThumbnail: thumbBuf
					},
					text: '',
					footer: captionText,
					contextInfo: {
						mentionedJid: mentions
					},
					buttons: [
						{
							displayText: '🌐 Link Group WhatsApp',
							url: targetUrl
						}
					]
				});
				return;
			} catch (e) {
				console.error('[WELCOME SEND_BUTTONS FAIL]', e.message);
			}
		}

		let image = null;
		if (thumbBuf && sock?.waUploadToServer) {
			try {
				const { imageMessage } = await prepareWAMessageMedia({
					image: thumbBuf
				}, {
					upload: sock.waUploadToServer,
					mediaTypeOverride: 'thumbnail-link'
				});
				image = imageMessage;
				if (image) {
					image.width = 1280;
					image.height = 720;
				}
			} catch (_) {}
		}

		try {
			await sock.sendMessage(id, {
				text: `${targetUrl}\n\n${captionText}`,
				mentions,
				linkPreview: {
					'matched-text': targetUrl,
					title: titleText,
					description: descText,
					previewType: 0,
					...(thumbBuf ? { jpegThumbnail: thumbBuf } : {}),
					...(image ? { highQualityThumbnail: image } : {}),
					linkPreviewMetadata: {
						linkMediaDuration: 0,
						socialMediaPostType: 4
					}
				}
			});
		} catch (e) {
			if (thumbBuf) {
				await sock.sendMessage(id, {
					image: thumbBuf,
					caption: captionText,
					mentions
				}).catch(() => sock.sendMessage(id, { text: captionText, mentions }));
			} else {
				await sock.sendMessage(id, { text: captionText, mentions }).catch(() => {});
			}
		}
	};

	for (const n of participants) {
		const user = typeof n === 'string' ? n : n?.id || n?.jid || '';
		if (!user) continue;

		const tag = user.split('@')[0];
		const actor = author ? author.split('@')[0] : 'Admin';

		if (action === 'add' && groupData.welcome === 1) {
			const text = groupData.sWelcome
				? formatMessage(groupData.sWelcome, user, author)
				: formatMessage(global.defaultGroupMessages?.welcome || 'ʜᴀʟᴏ @user, sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ ɢʀᴜᴘ *@grup* 🎀✨\nᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴘᴀᴛᴜʜɪ ʀᴜʟᴇs ɢʀᴜᴘ & ɪᴋᴜᴛᴀɴ ɴɪᴍʙʀᴜɴɢ ʏᴀᴀ 🌸\n\n👥 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ: @member', user, author);
			await sendWelcomeMessage(
				`👋 WELCOME TO ${groupName.toUpperCase()}`,
				`Member baru mampir! Kenalan yuk sama @${tag} 🥳`,
				text,
				[user],
				user
			);
		} else if (action === 'remove' && groupData.goodbye === 1) {
			const text = groupData.sGoodbye
				? formatMessage(groupData.sGoodbye, user, author)
				: formatMessage(global.defaultGroupMessages?.goodbye || 'ᴅᴀᴅᴀʜ @user, sᴇʟᴀᴍᴀᴛ ᴛɪɴɢɢᴀʟ ᴅᴀʀɪ *@grup* 🥺👋\nsᴇᴍᴏɢᴀ ʜᴀʀɪ-ʜᴀʀɪᴍᴜ sᴇʟᴀʟᴜ ᴍᴇɴʏᴇɴᴀɴɢᴋᴀɴ ʏᴀᴀ 🌸\n\n👥 sɪsᴀ ᴍᴇᴍʙᴇʀ: @member', user, author);
			await sendWelcomeMessage(
				`👋 GOODBYE FROM ${groupName.toUpperCase()}`,
				`Selamat tinggal @${tag}, semoga sukses selalu!`,
				text,
				[user],
				user
			);
		} else if (action === 'promote' && groupData.welcome === 1) {
			const text = formatMessage(global.defaultGroupMessages?.promote || 'ᴄɪᴇᴇ @user sᴇʟᴀᴍᴀᴛ ʏᴀᴀ, ᴋᴀᴍᴜ ʀᴇsᴍɪ ᴅɪᴀɴɢᴋᴀᴛ ᴊᴀᴅɪ ᴀᴅᴍɪɴ ɢʀᴜᴘ *@grup* 👑✨\nᴅɪᴀɴɢᴋᴀᴛ ᴏʟᴇʜ: @actor\n\n👑 ᴛᴏᴛᴀʟ ᴀᴅᴍɪɴ: @admin', user, author);
			await sendWelcomeMessage(
				`🎉 PROMOTED - ${groupName.toUpperCase()}`,
				`Wihh ada Admin Baru nih! Selamatt @${tag} 👑`,
				text,
				[user, author],
				user
			);
		} else if (action === 'demote' && groupData.welcome === 1) {
			const text = formatMessage(global.defaultGroupMessages?.demote || 'ʏᴀʜʜ @user, ᴊᴀʙᴀᴛᴀɴ ᴀᴅᴍɪɴ ᴋᴀᴍᴜ ᴅɪ ɢʀᴜᴘ *@grup* ᴛᴇʟᴀʜ ᴅɪᴄᴀʙᴜᴛ ᴅᴜʟᴜ ʏᴀᴀ 😿\nᴅɪᴄᴏᴘᴏᴛ ᴏʟᴇʜ: @actor\n\n👑 sɪsᴀ ᴀᴅᴍɪɴ: @admin', user, author);
			await sendWelcomeMessage(
				`📉 DEMOTED - ${groupName.toUpperCase()}`,
				`Status admin @${tag} telah dicabut 😅`,
				text,
				[user, author],
				user
			);
		}
	}
};

handler.command = [];
export default handler;
