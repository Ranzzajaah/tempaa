/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const spamMap = new Map();

const handler = async (m) => m;

handler.before = async (m, { sock, isOwner, isAdmin, isBotAdmin, getGroup }) => {
	if (!m.isGroup || m.fromMe) return;

	const chatDb = await getGroup(m.chat);
	if (chatDb?.antispam !== 1) return;
	if (isOwner || isAdmin) return;

	const now = Date.now();
	const key = `${m.chat}_${m.sender}`;
	const userHistory = spamMap.get(key) || [];
	const filtered = userHistory.filter(ts => now - ts < 4000);

	filtered.push(now);
	spamMap.set(key, filtered);

	if (filtered.length >= 6) {
		spamMap.delete(key);
		const action = (chatDb?.antispam_action || 'warn').toLowerCase();

		if (isBotAdmin) {
			try {
				await sock.sendMessage(m.chat, {
					delete: {
						remoteJid: m.chat,
						id: m.key.id,
						participant: m.key.participant || m.sender,
						fromMe: false
					}
				});
			} catch (_) {}
		}

		if (action === 'kick') {
			await sock.sendMessage(m.chat, {
				text: `🚫 @${m.sender.split('@')[0]} terdeteksi spam chat cepat (6 pesan / 4 dtk) dan langsung dikeluarkan!`,
				mentions: [m.sender]
			}, { quoted: null });
			if (isBotAdmin) {
				await sock.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => {});
			}
			return;
		}

		await sock.sendMessage(m.chat, {
			text: `⚠️ @${m.sender.split('@')[0]}, jangan spam chat di grup ini! Harap jeda pesan Anda.`,
			mentions: [m.sender]
		}, { quoted: m });
	}
};

handler.command = [];
export default handler;
