/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const warnMap = new Map();

const badWords = [
	'anjing', 'babi', 'kunyuk', 'bajingan', 'asu', 'bangsat', 'kontol', 'memek',
	'pantek', 'goblok', 'tolol', 'jancok', 'pukimak', 'kampang', 'itil'
];

const handler = async (m) => m;

handler.before = async (m, { sock, isOwner, isAdmin, isBotAdmin, getGroup }) => {
	if (!m.isGroup || m.fromMe || !m.text) return;

	const chatDb = await getGroup(m.chat);
	if (chatDb?.antitoxic !== 1) return;
	if (isOwner || isAdmin) return;

	const body = m.text.toLowerCase();
	const isToxic = badWords.some(word => new RegExp(`\\b${word}\\b`, 'i').test(body));
	if (!isToxic) return;

	const action = (chatDb?.antitoxic_action || 'warn').toLowerCase();
	const key = `${m.chat}_${m.sender}`;

	if (isBotAdmin) {
		await sock.sendMessage(m.chat, {
			delete: {
				remoteJid: m.chat,
				id: m.key.id,
				participant: m.key.participant || m.sender,
				fromMe: false
			}
		}).catch(() => {});
	}

	if (action === 'del') {
		await sock.sendMessage(m.chat, {
			text: `🚫 @${m.sender.split('@')[0]}, dilarang berkata kasar di sini! (Pesan Dihapus)`,
			mentions: [m.sender]
		}, { quoted: m });
		return;
	}

	if (action === 'kick') {
		await sock.sendMessage(m.chat, {
			text: `🚫 @${m.sender.split('@')[0]} terdeteksi berkata kasar dan langsung dikeluarkan dari grup!`,
			mentions: [m.sender]
		}, { quoted: null });

		if (isBotAdmin) {
			await sock.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => {});
		}
		return;
	}

	const currentWarn = (warnMap.get(key) || 0) + 1;
	warnMap.set(key, currentWarn);

	if (currentWarn >= 3) {
		warnMap.delete(key);
		await sock.sendMessage(m.chat, {
			text: `🚫 @${m.sender.split('@')[0]} terdeteksi berkata kasar (*3/3 Warn*) dan dikeluarkan dari grup!`,
			mentions: [m.sender]
		}, { quoted: null });

		if (isBotAdmin) {
			await sock.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch(() => {});
		}
	} else {
		await sock.sendMessage(m.chat, {
			text: `⚠️ @${m.sender.split('@')[0]}, dilarang berkata kasar di sini!\nPesan dihapus & Total Peringatan: *${currentWarn}/3*`,
			mentions: [m.sender]
		}, { quoted: m });
	}
};

handler.command = [];
export default handler;
