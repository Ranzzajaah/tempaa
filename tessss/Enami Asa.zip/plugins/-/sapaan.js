/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const RESPONSES = {
	gay: 'lu gay 🗿🏳️‍🌈',
	pemboy: 'hy pemboy 🎀💅✨',
	asik: 'wah kamu asik 🎉😎🔥',
	atheis: 'pa PE pa PE atheis lu 🗿👊',
	kangen: 'oyy napa manggil-manggil? kangen ya? 🤪',
	santai: 'woyy santai dong gausah ngegas 🗿',
	tes: 'tes tes 1 2 3 mic check, bot aktif kok! 🎙️⚡'
};

const MAP = {
	hi: RESPONSES.gay,
	hii: RESPONSES.gay,
	hiii: RESPONSES.gay,
	hai: RESPONSES.pemboy,
	haii: RESPONSES.pemboy,
	haiii: RESPONSES.pemboy,
	hallow: RESPONSES.asik,
	halo: RESPONSES.asik,
	haloo: RESPONSES.asik,
	hallo: RESPONSES.asik,
	hello: RESPONSES.asik,
	p: RESPONSES.atheis,
	pp: RESPONSES.atheis,
	ppp: RESPONSES.atheis,
	oy: RESPONSES.kangen,
	woy: RESPONSES.santai,
	tes: RESPONSES.tes,
	test: RESPONSES.tes
};

const handler = async (m, { command, reply }) => {
	const cmd = (command || '').toLowerCase();
	return reply(MAP[cmd] || RESPONSES.asik);
};

handler.help = ['hi', 'hai', 'halo', 'hallow', 'p', 'oy', 'woy', 'tes'];
handler.tags = ['-'];
handler.command = Object.keys(MAP);
handler.noPrefix = true;
handler.register = false;

export default handler;
