/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from 'fs';
import { getActiveThumbBuffer } from '../../lib/thumb.js';

const handler = async (m) => m;

handler.before = async (m, { sock, conn }) => {
	const restartFile = './tmp/restart.json';
	if (!fs.existsSync(restartFile)) return;

	try {
		const raw = fs.readFileSync(restartFile, 'utf-8');
		const data = JSON.parse(raw);
		fs.unlinkSync(restartFile);

		const client = sock || conn || global.mainSock;
		if (!client) return;

		const timeTaken = ((Date.now() - (data.time || Date.now())) / 1000).toFixed(2);
		const pageUrl = global.website || 'https://api.kyzzz.xyz';
		const botName = global.namaBot || 'Hirara AI';
		const ownerName = global.namaOwner || 'Mommy kyu';

		const feedbackText = `${pageUrl}\n\n` +
			`🌸 *ʙᴏᴛ sᴜᴅᴀʜ ᴏɴʟɪɴᴇ ʟᴀɢɪ!* 🌸\n\n` +
			`✨ *sᴛᴀᴛᴜs:* sɪᴀᴘ ᴅɪɢᴜɴᴀᴋᴀɴ ᴋᴇᴍʙᴀʟɪ 🎀\n` +
			`⚡ *ᴡᴀᴋᴛᴜ ʀᴇsᴛᴀʀᴛ:* ${timeTaken} ᴅᴇᴛɪᴋ\n` +
			`💖 *sᴇʟᴀᴍᴀᴛ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ ᴀᴋᴛɪᴠɪᴛᴀs ʏᴀᴀ!*`;

		const thumbBuf = await getActiveThumbBuffer().catch(() => null);

		await client.sendMessage(data.chat, {
			text: feedbackText,
			mentions: data.sender ? [data.sender] : [],
			linkPreview: {
				'matched-text': pageUrl,
				title: `🌸 ${botName} • System Online!`,
				description: `© ${ownerName} • Restart Berhasil (${timeTaken}s)`,
				previewType: 0,
				...(thumbBuf ? { jpegThumbnail: thumbBuf } : {}),
				linkPreviewMetadata: {
					linkMediaDuration: 0,
					socialMediaPostType: 4
				}
			}
		}).catch(() => {});
	} catch (e) {
		console.error('[RESTART NOTIFICATION FAIL]', e);
	}
};

export default handler;
