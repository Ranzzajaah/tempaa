/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const handler = async (m) => m;

handler.before = async (m, { sock, conn, isOwner, isPremium }) => {
    try {
        const client = sock || conn;
        if (!client) return;

        if (m.isGroup || m.fromMe || m.key.fromMe || !m.chat || m.chat.endsWith("@g.us") || m.chat.endsWith("@newsletter") || m.chat.includes("broadcast")) {
            return;
        }

        if (isOwner || isPremium) return;

        const senderJid = m.sender || m.chat;
        const senderNumber = senderJid.replace(/[^0-9]/g, "");
        if (!senderNumber) return;

        let isAntipmActive = true;
        if (typeof global.getSettings === "function") {
            const settings = await global.getSettings();
            if (settings && typeof settings.antipm !== "undefined") {
                isAntipmActive = settings.antipm === 1;
            }
        }

        if (!isAntipmActive) return;

        if (typeof global.addHama === "function") {
            global.addHama(senderNumber);
        }

        try {
            if (typeof client.updateBlockStatus === "function") {
                await client.updateBlockStatus(senderJid, "block");
            }
        } catch (errBlock) {}

    } catch (err) {}
};

export default handler;
