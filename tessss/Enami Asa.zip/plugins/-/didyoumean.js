/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import similarity from 'similarity';

const findBestMatch = (cmd, cmds) => {
	let bestCmd = null;
	let maxScore = -1;
	const target = cmd.toLowerCase();

	for (const c of cmds) {
		const candidate = c.toLowerCase();
		if (candidate === target) continue;

		const sim = similarity(target, candidate);
		if (sim < 0.35) continue;

		let score = sim;
		if (candidate[0] === target[0]) {
			score += 0.25;
		}
		if (candidate.length === target.length) {
			score += 0.05;
		}

		if (score > maxScore) {
			maxScore = score;
			bestCmd = c;
		}
	}

	if (!bestCmd) return null;
	const rawSim = similarity(target, bestCmd.toLowerCase());
	const pct = Math.floor(rawSim * 100);
	return { match: bestCmd, pct };
};

const handler = async (m) => m;

handler.before = async (m, { sock, conn, reply, usedPrefix, command, isCmd, isCommandRegistered, getAllCommands, text }) => {
	try {
		if (!isCmd || !command) return;

		const cleanCmd = String(command).trim().toLowerCase();
		if (!cleanCmd || cleanCmd.length < 2) return;

		if (cleanCmd.startsWith('stop') || cleanCmd.includes('stop')) return;

		if (typeof isCommandRegistered === 'function' && isCommandRegistered(cleanCmd)) return;

		const client = sock || conn;
		const allCmds = typeof getAllCommands === 'function' ? getAllCommands() : [];
		if (!allCmds || !allCmds.length) return;

		const res = findBestMatch(cleanCmd, allCmds);
		if (!res || !res.match || res.pct < 50) return;

		const prefix = usedPrefix || '.';
		const suggestedCmd = `${prefix}${res.match}${text ? ' ' + text : ''}`;
		const botName = global.namaBot || 'Hirara AI';
		const bodyText = `⚠️ Command *${prefix}${cleanCmd}* tidak ditemukan.\n\n💡 Maksud Anda: *${suggestedCmd}* (${res.pct}% kemiripan)`;

		console.log(`[DIDYOUMEAN MATCH] Typo '${prefix}${cleanCmd}' -> Suggested '${suggestedCmd}' (${res.pct}%)`);

		if (client && typeof client.sendButtons === 'function') {
			return await client.sendButtons(m.chat, {
				type: 'location_buttons',
				text: bodyText,
				footer: `${botName} • Auto Suggestion`,
				buttons: [
					{ displayText: suggestedCmd, id: suggestedCmd }
				]
			}, { quoted: m });
		}

		const doReply = typeof reply === 'function' ? reply : typeof m.reply === 'function' ? m.reply.bind(m) : null;
		if (doReply) {
			await doReply(bodyText);
		} else if (client && typeof client.sendMessage === 'function') {
			await client.sendMessage(m.chat, { text: bodyText }, { quoted: m });
		}
	} catch (err) {
		console.error('[DIDYOUMEAN ERROR]', err);
	}
};

handler.command = [];
handler.limit = true;

export default handler;
