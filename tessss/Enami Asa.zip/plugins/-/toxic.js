import axios from 'axios';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { exec } from 'child_process';

const TOXIC_WORDS = [
	'miskin',
	'miskinn',
	'miskinan',
	'asu',
	'asuu',
	'anjing',
	'anjg',
	'ajg',
	'babi',
	'kontol',
	'kntl',
	'memek',
	'mmk',
	'jembut',
	'pantek',
	'bangsat',
	'bgst',
	'tolol',
	'goblok',
	'gblk',
	'bego',
	'idiot',
	'yatim',
	'piatu',
	'pepek',
	'itil',
	'bajingan',
	'ngentot',
	'ngentod',
	'peler',
	'pler'
];

const TOXIC_OGG_PATH = path.join(process.cwd(), 'media', 'toxic.ogg');
let cachedOggBuffer = null;

const getToxicOggBuffer = async () => {
	if (cachedOggBuffer && cachedOggBuffer.length > 0) return cachedOggBuffer;

	if (fs.existsSync(TOXIC_OGG_PATH)) {
		cachedOggBuffer = fs.readFileSync(TOXIC_OGG_PATH);
		return cachedOggBuffer;
	}

	return null;
};

const handler = async (m, { sock, conn, reply }) => {
	const client = sock || conn || global.mainSock || global.conn;

	try {
		const oggBuf = await getToxicOggBuffer();
		if (oggBuf && oggBuf.length > 0) {
			return await client.sendMessage(
				m.chat,
				{
					audio: oggBuf,
					mimetype: 'audio/ogg; codecs=opus',
					ptt: true
				},
				{ quoted: m }
			);
		}
	} catch (e) {
		console.error('[TOXIC SOUND ERROR]:', e.message);
	}

	return reply('jangan toxic om 🥺🙏');
};

handler.help = ['toxic'];
handler.tags = ['-'];
handler.command = TOXIC_WORDS;
handler.noPrefix = true;
handler.register = false;

export default handler;
