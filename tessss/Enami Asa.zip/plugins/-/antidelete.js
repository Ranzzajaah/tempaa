/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import * as baileys from '@whiskeysockets/baileys';
const { downloadContentFromMessage, extractMessageContent, getContentType } = baileys;

const MEDIA_TYPE = {
	imageMessage: 'image',
	videoMessage: 'video',
	audioMessage: 'audio',
	stickerMessage: 'sticker',
	documentMessage: 'document'
};

const handler = async (m) => m;

handler.before = async (m, { sock, getGroup }) => {
	if (!m.isGroup || m.mtype !== 'protocolMessage') return;

	const protocolMessage = m.msg;
	if (!protocolMessage || protocolMessage.type !== 0) return;

	if (m.fromMe) return;

	const chatDb = await getGroup(m.chat);
	if (chatDb?.antidelete !== 1) return;

	const key = protocolMessage.key;
	if (!key?.id) return;

	const stored = global.store?.loadMessage(m.chat, key.id);
	if (!stored) return;

	const sender = key.participant || key.remoteJid || m.sender;
	const content = extractMessageContent(stored.message) || stored.message;
	if (!content) return;

	const type = getContentType(content) || Object.keys(content)[0];
	if (!type) return;

	const msgContent = content[type];

	const caption = `『 ANTI DELETE 』\n\n👤 *Pengirim:* @${sender.split('@')[0]}\n🕒 *Dikirim:* ${stored.messageTimestamp ? new Date(stored.messageTimestamp * 1000).toLocaleString('id-ID') : '-'}\n🚫 *Dihapus:* ${new Date().toLocaleString('id-ID')}\n📑 *Tipe:* ${type.replace('Message', '')}`;

	try {
		await sock.sendMessage(m.chat, { text: caption, mentions: [sender] });

		if (MEDIA_TYPE[type]) {
			const stream = await downloadContentFromMessage(msgContent, MEDIA_TYPE[type]);
			let buffer = Buffer.from([]);
			for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

			const sendObj = { [MEDIA_TYPE[type]]: buffer };
			if (msgContent.caption) sendObj.caption = msgContent.caption;
			if (MEDIA_TYPE[type] === 'audio') {
				sendObj.mimetype = 'audio/ogg; codecs=opus';
				sendObj.ptt = !!msgContent.ptt;
			}
			await sock.sendMessage(m.chat, sendObj);
		} else {
			const teks = msgContent?.text || msgContent?.conversation || content?.conversation || msgContent?.caption || '';
			if (teks) await sock.sendMessage(m.chat, { text: teks });
		}
	} catch (e) {
		console.error('[ANTIDELETE] Gagal kirim ulang pesan:', e.message);
	}
};

handler.command = [];
handler.limit = true;

export default handler;
