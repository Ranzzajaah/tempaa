let handler = async (m, { conn, command, reply }) => {
    const num = parseInt(command.replace(/mengkane/i, ''));

    if (isNaN(num) || num < 1 || num > 52) {
        return (reply || m.reply)(
            `🎵 *MENGKANE MUSIC*\n\n` +
            `> Tersedia: mengkane1 - mengkane52\n` +
            `> Contoh: .mengkane1`
        );
    }

    try {
        const fixcmd = command.replace(/mengkane/i, 'mangkane');
        const sound = num < 25 ?
            `https://raw.githubusercontent.com/hyuura/Rest-Sound/main/HyuuraKane/${fixcmd}.mp3` :
            `https://raw.githubusercontent.com/aisyah-rest/mangkane/main/Mangkanenya/${fixcmd}.mp3`;

        await conn.sendMessage(m.chat, {
            audio: {
                url: sound
            },
            mimetype: 'audio/mpeg',
            ptt: false
        }, {
            quoted: m
        });
    } catch (err) {
        (reply || m.reply)(`❌ *ERROR*\n\n> Musik tidak ditemukan.`);
    }
};

handler.help = ['mengkane1 - mengkane52'];
handler.tags = ['audio'];
handler.command = /^mengkane([1-9]|[1-4][0-9]|5[0-2])$/i;

export default handler;
