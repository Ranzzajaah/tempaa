let handler = async (m, { conn, command, reply }) => {
    const num = parseInt(command.replace(/music/i, ''));

    if (isNaN(num) || num < 1 || num > 65) {
        return (reply || m.reply)(`🎵 *MUSIK KOLEKSI*\n\n> Tersedia: .music1 - .music65`);
    }

    try {
        await conn.sendMessage(m.chat, {
            audio: {
                url: `https://raw.githubusercontent.com/Rez4-3yz/Music-rd/master/music/music${num}.mp3`
            },
            mimetype: 'audio/mpeg',
            ptt: false
        }, {
            quoted: m
        });
    } catch (err) {
        (reply || m.reply)(`❌ *ERROR*\n\n> Musik tidak ditemukan atau gagal diambil.`);
    }
};

handler.help = ['music1 - music65'];
handler.tags = ['audio'];
handler.command = /^music([1-9]|[1-5][0-9]|6[0-5])$/i;

export default handler;
