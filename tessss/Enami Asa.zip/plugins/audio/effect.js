/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { unlinkSync, readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs'
import { join } from 'path'
import { exec } from 'child_process'

let handler = async (m, { conn, sock, usedPrefix, command, reply }) => {
    const client = conn || sock
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || (q.msg || q).mtype || q.mtype || ''
        if (q.mtype === 'audioMessage' || q.msg?.audioMessage || q.message?.audioMessage) {
            mime = mime || 'audio/mp4'
        }

        let effects = {
            bass: '-af equalizer=f=94:width_type=o:width=2:g=18',
            blown: '-af acrusher=.1:1:64:0:log',
            deep: '-af atempo=4/4,asetrate=44500*2/3',
            earrape: '-af volume=12',
            fast: '-filter:a "atempo=1.63,asetrate=44100"',
            fat: '-filter:a "atempo=1.6,asetrate=22100"',
            nightcore: '-filter:a atempo=1.06,asetrate=44100*1.25',
            reverse: '-filter_complex "areverse"',
            robot: '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"',
            slow: '-filter:a "atempo=0.8,asetrate=44100"',
            smooth: '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"',
            tupai: '-filter:a "atempo=0.5,asetrate=65100"',
            audio8d: '-af apulsator=hz=0.125:amount=1',
            echo: '-af aecho=0.8:0.9:1000:0.3',
            distortion: '-af "acompressor=threshold=0.1:ratio=20:attack=1:release=10,acrusher=level_in=8:level_out=18:bits=8:mode=log:aa=1"',
            pitch: '-af "reverb=80:100:100:100:0:0"',
            reverb: '-af "aecho=0.8:0.9:1000:0.3, aecho=0.8:0.9:500:0.5, aecho=0.8:0.9:250:0.7"',
            flanger: '-af "asetrate=48000*1.5,atempo=1.5,asetrate=48000,equalizer=f=8000:width_type=h:width=50:g=6,apulsator=hz=0.125:amount=1"',
            apulsator: '-af apulsator=hz=0.125',
            tremolo: '-af tremolo=f=6.0:d=0.8',
            chorus: '-af chorus=0.7:0.9:55:0.4:0.25:2'
        }

        let set = effects[command.toLowerCase()]
        if (!set) return (reply || m.reply)(`*[INFO] reply audio/vn dengan command ${usedPrefix + command}*`)
        if (!/audio/.test(mime)) return (reply || m.reply)(`*[INFO] reply audio / vn dulu ya*`)

        let tmpDir = join(process.cwd(), 'tmp')
        if (!existsSync(tmpDir)) mkdirSync(tmpDir, { recursive: true })

        let getRandom = (ext) => `${Math.floor(Math.random() * 10000)}${ext}`
        let inputPath = join(tmpDir, getRandom('.mp3'))
        let outputPath = join(tmpDir, getRandom('.mp3'))

        let media = null
        if (typeof q.download === 'function') {
            media = await q.download().catch(() => null)
        }
        if (!media && typeof m.quoted?.download === 'function') {
            media = await m.quoted.download().catch(() => null)
        }
        if (!media && client?.downloadAndSaveMediaMessage) {
            media = await client.downloadAndSaveMediaMessage(q).catch(() => null)
        }
        if (!media && client?.downloadMediaMessage) {
            media = await client.downloadMediaMessage(q).catch(() => null)
        }

        if (typeof media === 'string') {
            inputPath = media
        } else if (Buffer.isBuffer(media)) {
            writeFileSync(inputPath, media)
        } else {
            return (reply || m.reply)('❌ Gagal mengunduh audio. Pastikan kamu membalas (reply) pesan audio atau VN!')
        }

        exec(`ffmpeg -y -i "${inputPath}" ${set} "${outputPath}"`, async (err) => {
            try {
                try { unlinkSync(inputPath) } catch {}
                if (err) return (reply || m.reply)(`_*Error saat proses audio!*_`)

                let buff = readFileSync(outputPath)
                await client.sendMessage(m.chat, {
                    audio: buff,
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, { quoted: m })

                try { unlinkSync(outputPath) } catch {}
            } catch {
                (reply || m.reply)('Error processing file')
            }
        })

    } catch (e) {
        console.error(e)
        (reply || m.reply)('❌ Terjadi kesalahan pada fitur audio effect.')
    }
}

const audioEffects = ['bass', 'blown', 'deep', 'earrape', 'fast', 'fat', 'nightcore', 'reverse', 'robot', 'slow', 'smooth', 'tupai', 'audio8d', 'echo', 'distortion', 'pitch', 'reverb', 'flanger', 'apulsator', 'tremolo', 'chorus'];
handler.help = audioEffects;
handler.tags = ['audio'];
handler.command = audioEffects;
handler.limit = true;

export default handler;
