/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { setAfk, getAfk, deleteAfk, getAllAfk } from '../../lib/database.js';

if (!global.afkUsers) global.afkUsers = new Map();

// Sinkronisasi data AFK yang tersimpan di SQLite ke memori
const syncAfkFromDb = async () => {
	try {
		const list = await getAllAfk();
		if (Array.isArray(list)) {
			for (const item of list) {
				if (item.jid && item.since > 0) {
					global.afkUsers.set(item.jid, {
						reason: item.reason || 'Tidak ada alasan',
						since: item.since
					});
				}
			}
		}
	} catch (e) {
		console.error('[AFK SYNC ERROR]:', e);
	}
};
syncAfkFromDb();

const normalizeJid = (jid) => {
	if (!jid) return '';
	return jid.replace(/:\d+@/, '@').split('@')[0] + '@s.whatsapp.net';
};

const formatDuration = (ms) => {
	const s = Math.floor(Math.max(0, ms) / 1000);
	const m = Math.floor(s / 60);
	const h = Math.floor(m / 60);
	const d = Math.floor(h / 24);

	if (d > 0) return `${d} hari ${h % 24} jam`;
	if (h > 0) return `${h} jam ${m % 60} menit`;
	if (m > 0) return `${m} menit ${s % 60} detik`;
	return `${s} detik`;
};

const handler = async (m, { text, reply }) => {
	const senderJid = normalizeJid(m.sender);

	let existing = global.afkUsers.get(senderJid);
	if (!existing) {
		const dbAfk = await getAfk(senderJid);
		if (dbAfk) existing = dbAfk;
	}

	if (existing) {
		const durasi = formatDuration(Date.now() - existing.since);
		global.afkUsers.delete(senderJid);
		await deleteAfk(senderJid);

		return reply(
			`👋 Kamu sudah kembali!\n` +
			`⏱️ AFK selama: *${durasi}*`
		);
	}

	const reason = text?.trim() || 'Tidak ada alasan';
	const now = Date.now();

	global.afkUsers.set(senderJid, {
		reason,
		since: now,
	});
	await setAfk(senderJid, reason, now);

	return reply(
		`😴 Kamu sekarang *AFK*\n` +
		`📝 Alasan: *${reason}*\n\n` +
		`Bot akan otomatis menjawab jika kamu di-mention.\n` +
		`Ketik *.afk* lagi atau kirim pesan untuk menonaktifkan.`
	);
};

handler.before = async (m, { sock, conn }) => {
	const client = sock || conn;
	if (m.fromMe) return true;

	const senderJid = normalizeJid(m.sender);

	// Cek apakah pengirim pesan sedang AFK
	let senderAfk = global.afkUsers.get(senderJid);
	if (!senderAfk) {
		const dbAfk = await getAfk(senderJid);
		if (dbAfk) {
			senderAfk = dbAfk;
			global.afkUsers.set(senderJid, dbAfk);
		}
	}

	if (senderAfk && m.text && !m.text.startsWith('.') && !m.text.startsWith('#') && !m.text.startsWith('!')) {
		const durasi = formatDuration(Date.now() - senderAfk.since);

		global.afkUsers.delete(senderJid);
		await deleteAfk(senderJid);

		await client.sendMessage(
			m.chat, {
				text: `👋 @${senderJid.split('@')[0]} sudah kembali dari AFK!\n⏱️ Durasi AFK: *${durasi}*`,
				mentions: [senderJid],
			}, {
				quoted: m
			}
		).catch(() => {});

		return true;
	}

	const rawMentions = [
		...(m.mentions || []),
		...(m.quoted?.sender ? [m.quoted.sender] : [])
	];

	const mentioned = [...new Set(rawMentions)].filter(Boolean);

	for (let jid of mentioned) {
		const v = normalizeJid(jid);
		if (v === senderJid) continue;

		let targetAfk = global.afkUsers.get(v);
		if (!targetAfk) {
			const dbAfk = await getAfk(v);
			if (dbAfk) {
				targetAfk = dbAfk;
				global.afkUsers.set(v, dbAfk);
			}
		}

		if (!targetAfk) continue;

		const durasi = formatDuration(Date.now() - targetAfk.since);

		await client.sendMessage(
			m.chat, {
				text: `😴 @${v.split('@')[0]} sedang *AFK*\n📝 Alasan: *${targetAfk.reason}*\n⏱️ Durasi: *${durasi}*`,
				mentions: [v],
			}, {
				quoted: m
			}
		).catch(() => {});
	}

	return true;
};

handler.help = ['afk [alasan]'];
handler.tags = ['main'];
handler.command = ['afk'];
handler.register = true;

export default handler;
