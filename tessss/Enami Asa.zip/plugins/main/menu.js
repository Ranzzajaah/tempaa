/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from "fs"
import os from "os"
import moment from "moment-timezone"
import { prepareWAMessageMedia } from "@whiskeysockets/baileys"
import { BloksWidget } from "../../lib/helper-bails.js"
import { getActiveThumbBuffer } from "../../lib/thumb.js"
import { getSettings, getRegisteredCount, getGroup } from "../../lib/database.js";
const toSmallCaps = (str) => {
  const smallCapsMap = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
    j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
    s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
  }
  return str.toLowerCase().split('').map(c => smallCapsMap[c] || c).join('')
}

const toItalicMath = (str) => {
  const italicMap = {
    a: '𝘢', b: '𝘣', c: '𝘤', d: '𝘥', e: '𝘦', f: '𝘧', g: '𝘨', h: '𝘩', i: '𝘪',
    j: '𝘫', k: '𝘬', l: '𝘭', m: '𝘮', n: '𝘯', o: '𝘰', p: '𝘱', q: '𝘲', r: '𝘳',
    s: '𝘴', t: '𝘵', u: '𝘶', v: '𝘷', w: '𝘸', x: '𝘹', y: '𝘺', z: '𝘻',
    A: '𝘈', B: '𝘉', C: '𝘊', D: '𝘋', E: '𝘌', F: '𝘍', G: '𝘎', H: '𝘏', I: '𝘐',
    J: '𝘑', K: '𝘒', L: '𝘓', M: '𝘔', N: '𝘕', O: '𝘖', P: '𝘗', Q: '𝘘', R: '𝘙',
    S: '𝘚', T: '𝘛', U: '𝘜', V: '𝘝', W: '𝘞', X: '𝘟', Y: '𝘠', Z: '𝘡'
  }
  return str.split('').map(c => italicMap[c] || c).join('')
}

const getCategoryEmoji = (cat) => {
  const c = cat.toLowerCase()
  if (c === 'ai') return '🤖'
  if (c === 'anime') return '🌸'
  if (c === 'asupan') return '💃'
  if (c === 'audio') return '🎧'
  if (c === 'bypass') return '🔓'
  if (c === 'cewerandom') return '✨'
  if (c === 'convert') return '🔄'
  if (c === 'download') return '📥'
  if (c === 'ephoto') return '🎨'
  if (c === 'fun') return '🎲'
  if (c === 'game') return '🎮'
  if (c === 'github') return '🐙'
  if (c === 'grup' || c === 'group') return '👥'
  if (c === 'image' || c === 'img') return '🖼️'
  if (c === 'info') return 'ℹ️'
  if (c === 'islamic' || c === 'islami' || c === 'religi') return '🕌'
  if (c === 'main') return '🏠'
  if (c === 'maker') return '🛠️'
  if (c === 'nsfw') return '🔞'
  if (c === 'other') return '📦'
  if (c === 'owner') return '👑'
  if (c === 'panel') return '🖥️'
  if (c === 'premium' || c === 'vip') return '💎'
  if (c === 'rpg') return '⚔️'
  if (c === 'search') return '🔍'
  if (c === 'stalker') return '🕵️'
  if (c === 'tools') return '🧰'
  if (c === 'xp') return '✨'
  return '📁'
}

const sortCategoriesAZ = (categories) => {
  return [...categories].sort((a, b) => a.localeCompare(b))
}

const getBadge = (cmd) => {
  if (typeof cmd === 'object' && cmd !== null) {
    if (cmd.isOwner) return ' Ⓞ'
    if (cmd.isPremium) return ' Ⓟ'
    if (cmd.isAdmin || cmd.admin) return ' Ⓐ'
    return ' Ⓕ'
  }
  return ''
}

const getCmdName = (cmd) => {
  return typeof cmd === 'object' && cmd !== null ? cmd.name : cmd
}

const sortCommandsAZ = (commands) => {
  return [...commands].sort((a, b) => {
    const nameA = getCmdName(a)
    const nameB = getCmdName(b)
    return nameA.localeCompare(nameB)
  })
}

const listCategories = (categories) => {
  return categories.map(cat => `  ◦ ${toSmallCaps(cat)}`).join('\n')
}

const getMenuThumb = async () => {
  return await getActiveThumbBuffer()
}

const playMenuAudio = async (conn, chat, m) => {
  const opusPath = 'media/menu.opus'
  const mp3Path = 'media/menu.mp3'
  let audioPath = null

  if (fs.existsSync(opusPath)) {
    audioPath = opusPath
  } else if (fs.existsSync(mp3Path)) {
    audioPath = mp3Path
  }

  if (audioPath) {
    const audio = fs.readFileSync(audioPath)
    const waveform = new Uint8Array([
      10, 25, 45, 70, 90, 65, 40, 20, 35, 60, 85, 100, 75, 50, 30, 15,
      25, 55, 80, 95, 70, 45, 30, 50, 75, 90, 60, 35, 20, 40, 65, 85,
      60, 30, 15, 35, 65, 90, 75, 40, 25, 45, 70, 85, 60, 35, 15, 30
    ])
    await conn.sendMessage(chat, {
      audio,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true,
      waveform
    }, { quoted: m, messageId: global.customId ? global.customId() : undefined })
    return
  }
}

const formatUptime = (seconds) => {
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  const parts = []
  if (d > 0) parts.push(`${d}d`)
  if (h > 0) parts.push(`${h}h`)
  if (m > 0) parts.push(`${m}m`)
  parts.push(`${s}s`)
  return parts.join(' ')
}

const handler = async (m, { conn, sock, getMenuData, usedPrefix, isOwner, isPremium, user, text, args, reply }) => {
  const client = conn || sock
  const prefix = usedPrefix || '.'
  const prfx = prefix
  const menu = getMenuData()

  for (const cat in menu) {
    menu[cat] = sortCommandsAZ(menu[cat])
  }

  const categories = sortCategoriesAZ(Object.keys(menu))
  const sub = (text || '').trim().toLowerCase()
  const rawSender = m.sender || ''
  const senderNumber = user?.nomor || (rawSender.endsWith('@lid') ? (user?.nomor || rawSender.split('@')[0]) : rawSender.split('@')[0].split(':')[0]) || 'User'
  const sender = rawSender
  const no = senderNumber
  const botName = global.namaBot || 'Hirara AI'
  const ownerName = global.namaOwner || 'Mommy kyu'
  const web = global.website || 'https://api.kyzzz.xyz'

  if (sub && sub !== 'all' && sub !== '1' && sub !== '2' && sub !== '3' && !categories.includes(sub)) {
    const inputCat = (args && args[0]) ? args[0] : (text || '').trim()
    const bodyText = `Kategori "${inputCat}" tidak ditemukan di daftar kategori yang tersedia.`
    const footerText = `${bodyText}\n\n© ${botName}`
    const thumb = await getMenuThumb().catch(() => null)

    if (client && typeof client.sendButtons === 'function') {
      try {
        await client.sendButtons(m.chat, {
          location: {
            degreesLatitude: 0,
            degreesLongitude: 0,
            name: botName,
            address: web,
            jpegThumbnail: thumb
          },
          text: '',
          footer: footerText,
          messageParams: {
            bottom_sheet: {
              in_thread_buttons_limit: 1,
              list_title: 'menu_error',
              button_title: botName
            }
          },
          contextInfo: {
            mentionedJid: [sender]
          }
        }, { quoted: m })
        return
      } catch (err) {
        console.error('[MENU ERROR RESPONSE FAIL]', err.message)
      }
    }
    const sendReply = typeof reply === 'function' ? reply : (t => m.reply(t))
    return sendReply(footerText)
  }

  const botUptime = process.uptime()
  const serverUptime = os.uptime()
  const uptimeStr = formatUptime(botUptime)
  const serverUptimeStr = formatUptime(serverUptime)
  const status = isOwner ? 'Owner' : isPremium ? 'Premium' : 'Free User'
  const mode = global.public ? 'Public' : 'Self'

  const limit = (isOwner || isPremium) ? 'Unlimited' : (user?.limit ?? 25)
  const money = (user?.money || 0).toLocaleString('id-ID')
  const regStatus = user?.registered ? 'Terverifikasi (Sudah Daftar)' : 'Belum Terdaftar'
  const regCount = await getRegisteredCount()
  const totalUser = regCount.toLocaleString('id-ID')

  const legendText = `*Keterangan Symbol:*\n• Ⓕ = Free\n• Ⓟ = Premium\n• Ⓐ = Admin\n• Ⓞ = Owner\n\n`

  const totalFitur = Object.values(menu).reduce((sum, list) => sum + (Array.isArray(list) ? list.length : 0), 0)

  const formatSectionStyle1 = (category, cmds) => {
    if (!cmds?.length) return ''
    const emoji = getCategoryEmoji(category)
    const catTitle = toSmallCaps(category).toUpperCase()

    const lines = cmds.map((cmdObj) => {
      const cName = toSmallCaps(getCmdName(cmdObj))
      const badge = getBadge(cmdObj)
      return `┃ 𝜗𝜚 ${prefix}${cName}${badge}`
    })

    return `┏━━〔 ${emoji} *${catTitle}* 〕\n${lines.join('\n')}\n┗━━━━━━━━━━━━━━━┈༓`
  }

  const getMenuHeader = () => {
    return `🌸 *${cuteGreeting}* 🌸\n` +
      `ʜᴀʟᴏ ᴋᴀᴋ @${no} 🎀\n\n` +
      `╭━━━〔 ✨ *ɪɴғᴏʀᴍᴀsɪ ᴘᴇɴɢɢᴜɴᴀ* 〕━━━╮\n` +
      `┃ ✦ 👤 *ᴜsᴇʀ       :* @${no}\n` +
      `┃ ✦ 📊 *sᴛᴀᴛᴜs     :* ${status}\n` +
      `┃ ✦ 📝 *ʀᴇɢɪsᴛᴇʀ   :* ${regStatus}\n` +
      `┃ ✦ 👥 *ᴛᴏᴛᴀʟ ᴜsᴇʀ :* ${totalUser}\n` +
      `┃ ✦ 🛠️ *ᴛᴏᴛᴀʟ ғɪᴛᴜʀ :* ${totalFitur}\n` +
      `┃ ✦ 🎫 *ʟɪᴍɪᴛ      :* ${limit}\n` +
      `┃ ✦ 💰 *ᴜᴀɴɢ       :* Rp ${money}\n` +
      `┃ ✦ ⏱️ *ᴜᴘᴛɪᴍᴇ     :* ${uptimeStr}\n` +
      `┃ ✦ ⚙️ *ᴍᴏᴅᴇ       :* ${mode}\n` +
      `┃ ✦ 🔑 *ᴘʀᴇғɪx     :* ${prfx}\n` +
      `╰━━━━━━━━━━━━━━━━━━━╯\n\n`
  }

  const getCuteGreeting = () => {
    const hour = parseInt(moment().tz('Asia/Jakarta').format('H'), 10)
    const greetingsPagi = [
      'sᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ, sᴇᴍᴀɴɢᴀᴛ ʏᴀᴀ ʜᴀʀɪ ɪɴɪ! ☀️🌸',
      'ᴏʜᴀʏᴏᴜ! sᴇᴍᴏɢᴀ ʜᴀʀɪᴍᴜ ᴍᴇɴʏᴇɴᴀɴɢᴋᴀɴ 🎀✨',
      'ᴘᴀɢɪ-ᴘᴀɢɪ sᴇɴʏᴜᴍ ᴅᴜʟᴜ ʙɪᴀʀ ᴍᴀɴɪs! 🌷🐣'
    ]
    const greetingsSiang = [
      'sᴇʟᴀᴍᴀᴛ sɪᴀɴɢ! ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ᴍᴀᴋᴀɴ sɪᴀɴɢ ʏᴀᴀ 🍱✨',
      'ᴋᴏɴɴɪᴄʜɪᴡᴀ! ᴛᴇᴛᴀᴘ sᴇᴍᴀɴɢᴀᴛ ʏᴀᴀ 🌸🍹',
      'sɪᴀɴɢ-sɪᴀɴɢ ᴊᴀɴɢᴀɴ ʟᴜᴘᴀ ɪsᴛɪʀᴀʜᴀᴛ sᴇʙᴇɴᴛᴀʀ 🍰🧸'
    ]
    const greetingsSore = [
      'sᴇʟᴀᴍᴀᴛ sᴏʀᴇ! sᴀɴᴛᴀɪ sᴇʙᴇɴᴛᴀʀ ʏᴜᴋ ☕🌇',
      'sᴏʀᴇ ʏᴀɴɢ ɪɴᴅᴀʜ! ᴄᴀᴘᴇᴋ ɢᴀᴋ ʜᴀʀɪ ɪɴɪ? 🌸🍃',
      'sᴏʀᴇ-sᴏʀᴇ ᴇɴᴀᴋɴʏᴀ ɴɢᴇᴛᴇʜ ʙᴀʀᴇɴɢ 🍮🧋'
    ]
    const greetingsMalam = [
      'sᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ! ᴊᴀɴɢᴀɴ ʙᴇɢᴀᴅᴀɴɢ ʏᴀᴀ 🌙💤',
      'ᴋᴏɴʙᴀɴᴡᴀ! sᴇᴍᴏɢᴀ ᴍɪᴍᴘɪ ɪɴᴅᴀʜ ɴᴀɴᴛɪ ✨🧸',
      'ᴍᴀʟᴀᴍ-ᴍᴀʟᴀᴍ ʀᴇʙᴀʜᴀɴ sᴀᴍʙɪʟ ᴄʜᴀᴛᴛɪɴɢ-ᴀɴ ʏᴜᴋ 🍓🎀'
    ]

    if (hour >= 4 && hour < 11) return greetingsPagi[Math.floor(Math.random() * greetingsPagi.length)]
    if (hour >= 11 && hour < 15) return greetingsSiang[Math.floor(Math.random() * greetingsSiang.length)]
    if (hour >= 15 && hour < 18) return greetingsSore[Math.floor(Math.random() * greetingsSore.length)]
    return greetingsMalam[Math.floor(Math.random() * greetingsMalam.length)]
  }

  const cuteGreeting = getCuteGreeting()

  const botSettings = await getSettings()
  const groupData = m.isGroup ? await getGroup(m.chat) : null
  let menuType = (groupData && groupData.menuType > 0) ? groupData.menuType : (botSettings?.menuType || global.menuType || 1)
  if (sub === '3' || args[0] === '3') menuType = 3
  if (sub === '2' || args[0] === '2' || m.command === 'allmenu') menuType = 2
  if (sub === '1' || args[0] === '1') menuType = 1

  if (menuType === 3) {
    const targetSub = (sub === '3' || !sub) ? 'all' : sub
    const greeting = cuteGreeting

    const uptimeH = Math.floor(botUptime / 3600)
    const uptimeM = Math.floor((botUptime % 3600) / 60)
    const shortUptime = `${uptimeH} jam ${uptimeM} menit`

    let bodyDesc = ''
    if (targetSub === 'all') {
      bodyDesc = `${greeting}\n` +
        `Aku ${botName}, siap membantu kamu.\n\n` +
        `╭ Uptime  : ${shortUptime}\n` +
        `├ Name    : ${botName}\n` +
        `├ Total   : ${totalFitur} Fitur\n` +
        `├ Version : 2.7.3\n` +
        `├ Library : @whiskeysockets/baileys\n` +
        `├ Mode    : ${m.isGroup ? 'onlygc' : 'public'}\n` +
        `├ User    : ${m.pushName || no}\n` +
        `├ Role    : ${user?.role || 'Rosenvale'}\n` +
        `├ Level   : ${user?.level || 1}\n` +
        `╰ XP      : ${user?.exp || 0}/${(user?.level ? user.level * 2400 : 1000)}\n\n` +
        categories.map(c => `   ⌯ menu ${c}`).join('\n') + '\n'
    } else if (categories.includes(targetSub)) {
      bodyDesc = `${greeting}\n` +
        `Aku ${botName}, siap membantu kamu.\n\n` +
        `╭ Kategori : ${toSmallCaps(targetSub).toUpperCase()}\n` +
        `╰ Total    : ${menu[targetSub]?.length || 0} Perintah\n\n` +
        `${formatSectionStyle1(targetSub, menu[targetSub])}\n\n` +
        `© ${botName} • Created by ${ownerName}`
    } else {
      bodyDesc = `${greeting}\n` +
        `Aku ${botName}, siap membantu kamu.\n\n` +
        `╭ Uptime  : ${shortUptime}\n` +
        `├ Name    : ${botName}\n` +
        `├ Total   : ${totalFitur} Fitur\n` +
        `├ Version : 2.7.3\n` +
        `├ Library : @whiskeysockets/baileys\n` +
        `├ Mode    : ${m.isGroup ? 'onlygc' : 'public'}\n` +
        `├ User    : ${m.pushName || no}\n` +
        `├ Role    : ${user?.role || 'Rosenvale'}\n` +
        `├ Level   : ${user?.level || 1}\n` +
        `╰ XP      : ${user?.exp || 0}/${(user?.level ? user.level * 2400 : 1000)}\n\n` +
        categories.map(c => `   ⌯ menu ${c}`).join('\n') + '\n'
    }

    const rowsKategori = categories.map(cat => ({
      header: '',
      title: `${toItalicMath(`menu ${cat}`)}`,
      description: `ʟɪʜᴀᴛ ᴍᴇɴᴜ ${toSmallCaps(cat)}`,
      id: `${prefix}menu ${cat}`
    }))
    rowsKategori.push({
      header: '',
      title: 'Allmenu',
      description: 'ʟɪʜᴀᴛ sᴇᴍᴜᴀ ꜰɪᴛᴜʀ',
      id: `${prefix}allmenu`
    })

    const bannerUrl = 'https://c.termai.cc/i129/Nz5.png'

    try {
      const widget = new BloksWidget(client)
        .setHeaderImage(bannerUrl, { fit: 'cover', variant: 'header' })
        .setBody(bodyDesc)
        .setContextInfo({
          mentionedJid: [sender]
        })

      widget.addButton('', {})
      widget.addSelection('List Menu', [
        {
          title: 'Pilih Kategori',
          highlight_label: '',
          rows: rowsKategori
        }
      ])
      widget.addReply('owner', `${prefix}owner`, { icon: 'PROMOTION' })

      await widget.send(m.chat, { quoted: m })
    } catch (err) {
      console.error('[MENU 3 BLOKSWIDGET FAIL]', err)
      const thumbBuf = await getMenuThumb().catch(() => null)
      if (thumbBuf) {
        await client.sendMessage(m.chat, {
          image: thumbBuf,
          caption: bodyDesc,
          mentions: [sender]
        }, { quoted: m, messageId: global.customId ? global.customId() : undefined }).catch(() => {})
      } else {
        await client.sendMessage(m.chat, {
          text: bodyDesc,
          mentions: [sender]
        }, { quoted: m, messageId: global.customId ? global.customId() : undefined }).catch(() => {})
      }
    }

    try {
      await playMenuAudio(client, m.chat, m)
    } catch (e) {
      console.error('[MENU AUDIO ERROR]', e)
    }
    return
  }

  if (menuType === 2) {
    let menuText = ''
    const targetSub = (sub === '2' || !sub || m.command === 'allmenu') ? 'all' : sub
    const pushname = m.pushName || user?.nama || user?.name || no
    const botname = botName
    const ownername = ownerName
    const isPrem = isPremium || isOwner
    const nameCreator = ownerName

    const headerMenu2 = `*ʜᴀʟᴏ ᴋᴀᴋ ${pushname} 🌸✨* ɴᴀᴍᴀ ᴀᴋᴜ *${botname}*, ᴀsɪsᴛᴇɴ ɪᴍᴜᴛ ʏᴀɴɢ sɪᴀᴘ ᴍᴇɴᴇᴍᴀɴɪ & ᴍᴇᴍʙᴀɴᴛᴜ ʜᴀʀɪ-ʜᴀʀɪ ᴋᴀᴍᴜ 🌷🎀\n\n` +
      `ᴀᴋᴜ ʙɪsᴀ ʙᴀɴᴛᴜ ʙᴀɴʏᴀᴋ ʜᴀʟ ʟʜᴏ! ᴍᴜʟᴀɪ ᴅᴀʀɪ ᴊᴀɢᴀ ɢʀᴜᴘ, ᴅᴏᴡɴʟᴏᴀᴅ ᴍᴇᴅɪᴀ, ᴍᴀɪɴ ɢᴀᴍᴇ sᴇʀᴜ, ʙᴇʟᴀᴊᴀʀ, sᴀᴍᴘᴀɪ ᴛᴏᴏʟs ᴋᴇʀᴇɴ ʟᴀɪɴɴʏᴀ ʏᴀɴɢ ʙɪᴋɪɴ ʜᴀʀɪᴍᴜ ᴍᴀᴋɪɴ ᴍᴜᴅᴀʜ & ᴍᴇɴʏᴇɴᴀɴɢᴋᴀɴ 🧸🍰🍓\n\n` +
      `✘ ᴄʀᴇᴀᴛᴏʀ: ${nameCreator}\n\n` +
      `ᴋᴀʟᴀᴜ ᴀᴅᴀ ᴋᴇɴᴅᴀʟᴀ ᴀᴛᴀᴜ ᴍᴀᴜ ᴛᴀɴʏᴀ-ᴛᴀɴʏᴀ, sɪʟᴀᴋᴀɴ ʜᴜʙᴜɴɢɪ ᴄʀᴇᴀᴛᴏʀ ᴛᴇʀsᴀʏᴀɴɢ ᴋᴇᴛɪᴋ *${prefix}ᴏᴡɴᴇʀ* ʏᴀᴀ 💌✨\n\n` +
      `┏═━ \`/ɪɴғᴏʀᴍᴀsɪ ᴜsᴇʀ\\\` ━━\n` +
      `║❃ ɴᴀᴍᴀ: *${pushname}* \n` +
      `║❃ sᴛᴀᴛᴜs: *${isPrem ? 'ᴘʀᴇᴍɪᴜᴍ ᴜsᴇʀ  ✓⃝' : 'ғʀᴇᴇ ᴜseʀ  𝕏'}*  \n` +
      `║❃ ɴᴏᴍᴏʀ : ${no}\n` +
      `┗━━━━━━━━━━━━\n\n` +
      `\`/[ 𝗢 𝗪 𝗡 𝗘 𝗥 - 𝗜 𝗡 𝗙 𝗢 ]\\\`\n` +
      `> ☃︎ ︳ᴄʀᴇᴀᴛᴏʀ : ${ownername}\n` +
      `> ☃︎ ︳ɴᴀᴍᴀ ʙᴏᴛ : ${botname}\n` +
      `> ☃︎ ︳ᴠᴇʀsɪ : 999999999\n` +
      `> ☃︎ ︳ᴛʏᴘᴇ : ᴘʟᴜɢɪɴ ᴇsᴍ\n` +
      `> ☃︎ ︳ᴛᴇʟᴇɢʀᴀᴍ : t.me/kyunotdev\n` +
      `> ☃︎ ︳ᴡʜᴀᴛsᴀᴘᴘ ᴏᴡɴᴇʀ : wa.me/kyuucwesejati\n\n` +
      `\`/[ 𝗜 𝗡 𝗙 𝗢 - 𝗕 𝗢 𝗧 ]\\\`\n` +
      `> ║❃ ɴᴀᴍᴀ ʙᴏᴛ: *${botname}*  \n` +
      `> ║❃ ʀᴜɴᴛɪᴍᴇ: *${uptimeStr}*\n` +
      `> ║❃ ᴘᴇɴɢᴇᴍʙᴀɴɢ: *${ownername}*  \n` +
      `> ║❃ ᴍᴏᴅᴇ: *${global.public ? 'ᴘᴜʙʟɪᴄ' : 'sᴇʟғ'}*  \n` +
      `> ║❃ ᴛᴏᴛᴀʟ ᴘᴇɴɢɢᴜɴᴀ: *${totalUser}*\n\n`

    const formatCategoryMenu2 = (category, cmds) => {
      if (!cmds?.length) return ''
      const catTitle = toSmallCaps(category).toUpperCase()
      const lines = cmds.map((cmdObj) => {
        const cName = toSmallCaps(getCmdName(cmdObj))
        const badge = getBadge(cmdObj)
        return `┊• ${prefix}${cName}${badge}`
      })
      return `❏═┅═━–❏ \`/ᴍᴇɴᴜ ${catTitle}\\\` ❏═┅═━–❏  \n${lines.join('\n')}\n╰❏═┅═━–〈`
    }

    if (targetSub === 'all') {
      menuText = headerMenu2
      for (const cat of categories) {
        menuText += formatCategoryMenu2(cat, menu[cat]) + '\n\n'
      }
      menuText = menuText.trim()
    } else if (categories.includes(targetSub)) {
      menuText = headerMenu2 + formatCategoryMenu2(targetSub, menu[targetSub])
    } else {
      menuText = headerMenu2
      for (const cat of categories) {
        menuText += formatCategoryMenu2(cat, menu[cat]) + '\n\n'
      }
      menuText = menuText.trim()
    }

    const pageUrl = web || 'https://api.kyzzz.xyz'
    const thumbBuf = await getMenuThumb().catch(() => null)

    let hqImage = null
    if (thumbBuf && client?.waUploadToServer) {
      try {
        const { imageMessage } = await prepareWAMessageMedia({
          image: thumbBuf
        }, {
          upload: client.waUploadToServer,
          mediaTypeOverride: 'thumbnail-link'
        })
        hqImage = imageMessage
        if (hqImage) {
          hqImage.width = 1280
          hqImage.height = 720
        }
      } catch (_) {}
    }

    const hiddenUrlText = `\u200B${pageUrl}\u200B`

    try {
      await client.sendMessage(m.chat, {
        text: `${hiddenUrlText}\n${menuText}`,
        linkPreview: {
          'matched-text': pageUrl,
          title: `${botName} - All Menu`,
          description: `© ${ownerName}`,
          previewType: 0,
          ...(thumbBuf ? { jpegThumbnail: thumbBuf } : {}),
          ...(hqImage ? { highQualityThumbnail: hqImage } : {}),
          linkPreviewMetadata: {
            linkMediaDuration: 0,
            socialMediaPostType: 4
          }
        },
        mentions: [sender]
      }, { quoted: m, messageId: global.customId ? global.customId() : undefined })
    } catch (err) {
      console.error('[MENU 2 LINKPREVIEW FAIL]', err)
      if (thumbBuf) {
        await client.sendMessage(m.chat, {
          image: thumbBuf,
          caption: menuText,
          mentions: [sender]
        }, { quoted: m, messageId: global.customId ? global.customId() : undefined }).catch(() => {})
      } else {
        await client.sendMessage(m.chat, {
          text: menuText,
          mentions: [sender]
        }, { quoted: m, messageId: global.customId ? global.customId() : undefined }).catch(() => {})
      }
    }

    try {
      await playMenuAudio(client, m.chat, m)
    } catch (e) {
      console.error('[MENU AUDIO ERROR]', e)
    }
    return
  }

  let teks = ''
  if (sub === 'all') {
    teks = `🌸 *${cuteGreeting}* 🌸\n` +
           `ʜᴀʟᴏ @${no}, ɪɴɪ sᴇᴍᴜᴀ ᴅᴀғᴛᴀʀ ғɪᴛᴜʀ *${botName}* ʏᴀᴀ ✨\n\n` +
           `◦ sᴛᴀᴛᴜs       : *${status}*\n` +
           `◦ ʀᴇɢɪsᴛᴇʀ     : ${regStatus}\n` +
           `◦ ᴛᴏᴛᴀʟ ᴜsᴇʀ   : ${totalUser}\n` +
           `◦ ᴛᴏᴛᴀʟ ғɪᴛᴜʀ   : *${totalFitur}*\n` +
           `◦ ʟɪᴍɪᴛ        : ${limit}\n` +
           `◦ ᴜᴀɴɢ         : Rp ${money}\n` +
           `◦ ᴜᴘᴛɪᴍᴇ       : ${uptimeStr}\n` +
           `◦ sᴇʀᴠᴇʀ ᴜᴘᴛɪᴍᴇ : ${serverUptimeStr}\n` +
           `◦ ᴍᴏᴅᴇ         : ${mode}\n` +
           `◦ ᴘʀᴇғɪx       : ${prfx}\n\n` +
           legendText

    for (const cat of categories) {
      teks += formatSectionStyle1(cat, menu[cat]) + '\n\n'
    }
    teks += `© ${botName} • Created by ${ownerName}`

  } else if (categories.includes(sub)) {
    teks = `🌸 *${cuteGreeting}* 🌸\n` +
           `ʜᴀʟᴏ @${no}, ɪɴɪ ᴅᴀғᴛᴀʀ ᴍᴇɴᴜ *${toSmallCaps(sub).toUpperCase()}* ʏᴀᴀ 🎀\n\n` +
           `◦ sᴛᴀᴛᴜs       : *${status}*\n` +
           `◦ ʀᴇɢɪsᴛᴇʀ     : ${regStatus}\n` +
           `◦ ᴛᴏᴛᴀʟ ᴜsᴇʀ   : ${totalUser}\n` +
           `◦ ᴛᴏᴛᴀʟ ғɪᴛᴜʀ   : *${totalFitur}*\n` +
           `◦ ʟɪᴍɪᴛ        : ${limit}\n` +
           `◦ ᴜᴀɴɢ         : Rp ${money}\n` +
           `◦ ᴜᴘᴛɪᴍᴇ       : ${uptimeStr}\n` +
           `◦ sᴇʀᴠᴇʀ ᴜᴘᴛɪᴍᴇ : ${serverUptimeStr}\n` +
           `◦ ᴍᴏᴅᴇ         : ${mode}\n` +
           `◦ ᴘʀᴇғɪx       : ${prfx}\n\n` +
           legendText +
           `${formatSectionStyle1(sub, menu[sub])}\n\n` +
           `© ${botName} • Created by ${ownerName}`

  } else {
    const errorNotice = sub ? `⚠️ Kategori *"${sub}"* tidak ditemukan!\nBerikut daftar kategori yang tersedia:\n\n` : ''
    teks = `🌸 *${cuteGreeting}* 🌸\n` +
           `ʜᴀʟᴏ @${no}, sᴇʟᴀᴍᴀᴛ ᴅᴀᴛᴀɴɢ ᴅɪ *${botName}* ʏᴀᴀ 🎀✨\n\n` +
           errorNotice +
           `◦ sᴛᴀᴛᴜs       : *${status}*\n` +
           `◦ ʀᴇɢɪsᴛᴇʀ     : ${regStatus}\n` +
           `◦ ᴛᴏᴛᴀʟ ᴜsᴇʀ   : ${totalUser}\n` +
           `◦ ᴛᴏᴛᴀʟ ғɪᴛᴜʀ   : *${totalFitur}*\n` +
           `◦ ʟɪᴍɪᴛ        : ${limit}\n` +
           `◦ ᴜᴀɴɢ         : Rp ${money}\n` +
           `◦ ᴜᴘᴛɪᴍᴇ       : ${uptimeStr}\n` +
           `◦ sᴇʀᴠᴇʀ ᴜᴘᴛɪᴍᴇ : ${serverUptimeStr}\n` +
           `◦ ᴍᴏᴅᴇ         : ${mode}\n` +
           `◦ ᴘʀᴇғɪx       : ${prfx}\n\n` +
           legendText +
           `*DAFTAR KATEGORI*\n${listCategories(categories)}\n\n` +
           `ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ᴅɪ ᴛᴏᴍʙᴏʟ ʙᴀᴡᴀʜ, ᴀᴛᴀᴜ ᴋᴇᴛɪᴋ:\n${prefix}menu <kategori>\n${prefix}menu all\n\n` +
           `© ${botName} • Created by ${ownerName}`
  }

  const thumb = await getMenuThumb()
  await client.sendButtons(m.chat, {
    location: {
      degreesLatitude: 0,
      degreesLongitude: 0,
      name: botName,
      address: web,
      jpegThumbnail: thumb,
    },
    text: '',
    footer: teks,
    messageParams: {
      bottom_sheet: {
        in_thread_buttons_limit: 1,
        list_title: 'menu',
        button_title: 'Hirara AI'
      }
    },
    contextInfo: {
      mentionedJid: [sender]
    },
    buttons: [
      {
        title: 'info',
        sections: [
          {
            title: '',
            highlight_label: botName,
            rows: [
              {
                title: "📜 sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ",
                description: `${botName} - ɪɴғᴏʀᴍᴀsɪ sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ`,
                id: `${prefix}script`
              },
              {
                title: "👑 ᴏᴡɴᴇʀ ʙᴏᴛ",
                description: `${botName} - ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʙᴏᴛ`,
                id: `${prefix}owner`
              }
            ]
          }
        ],
        icon: "REVIEW"
      },
      {
        title: 'cmd',
        sections: [
          {
            title: '',
            highlight_label: botName,
            rows: categories.map(cat => {
              const emoji = getCategoryEmoji(cat)
              return {
                title: `${emoji} ${toSmallCaps(cat)} ᴍᴇɴᴜ`,
                description: `${botName} - ғɪᴛᴜʀ ᴋᴀᴛᴇɢᴏʀɪ ${toSmallCaps(cat)}`,
                id: `${prefix}menu ${cat}`
              }
            })
          }
        ],
        icon: "DEFAULT"
      },
      {
        displayText: `👑 ${ownerName}`,
        url: web
      }
    ]
  }, { quoted: m, messageId: global.customId ? global.customId() : undefined })

  try {
    await playMenuAudio(client, m.chat, m)
  } catch (e) {
    console.error('[MENU AUDIO ERROR]', e)
  }
}

handler.command = ['menu','help']
export default handler