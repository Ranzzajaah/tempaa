import crypto from 'crypto';
import { getUser, registerUser } from '../../lib/database.js';

const handler = async (m, { conn, sock, text, usedPrefix, command, reply }) => {
	const client = sock || conn;
	const user = await getUser(m.sender);

	if (user && user.registered === 1) {
		return reply(`⚠️ Kamu sudah terdaftar di database!\n\nKetik *${usedPrefix}profile* untuk melihat profil kamu.`);
	}

	let nama, umur;
	let isFastReg = false;

	const isFastRegCmd = /^(daftarcepat|dcepat|fastreg)$/i.test(command);

	if (!text || isFastRegCmd) {
		const pushName = m.pushName || m.name || 'User';
		nama = pushName.trim() || 'HiraraUser';
		umur = Math.floor(Math.random() * (30 - 17 + 1)) + 17;
		isFastReg = true;
	} else {
		const regRegex = /^(.*?)[. ,|]+([0-9]{1,3})$/i;
		const match = text.trim().match(regRegex);

		if (!match) {
			const errText = `⚠️ *FORMAT REGISTRASI SALAH*\n\n` +
				`📌 *Cara Daftar Manual:*\n` +
				`\`${usedPrefix}daftar Nama.Umur\`\n\n` +
				`💡 *Contoh:*\n` +
				`\`${usedPrefix}daftar Budi.20\`\n\n` +
				`⚡ Atau klik tombol *Daftar Cepat* di bawah untuk registrasi otomatis!`;

			if (client && typeof client.sendButtons === 'function') {
				return client.sendButtons(m.chat, {
					type: 'location_buttons',
					text: errText,
					footer: `${global.namaBot || 'Hirara AI'} • Registration System`,
					buttons: [
						{ displayText: '⚡ Daftar Cepat', id: `${usedPrefix}daftarcepat` }
					]
				}, { quoted: m });
			}
			return reply(errText);
		}

		nama = match[1].trim();
		umur = parseInt(match[2].trim());

		if (nama.length < 3 || nama.length > 25) {
			return reply('⚠️ Nama minimal 3 karakter dan maksimal 25 karakter!');
		}

		if (isNaN(umur) || umur < 10 || umur > 80) {
			return reply('⚠️ Umur minimal 10 tahun dan maksimal 80 tahun!');
		}
	}

	const serialNumber = crypto.randomBytes(8).toString('hex');
	const nomor = m.sender.split('@')[0];

	await registerUser(m.sender, {
		nama,
		umur,
		nomor,
		serialNumber
	});

	const initLimit = global.initialLimit || 50;

	let cardBuffer = null;
	try {
		const { createRegisterCard } = await import('../../lib/card.js');
		cardBuffer = await createRegisterCard({
			name: nama,
			age: umur,
			number: nomor,
			serialNumber: serialNumber,
			senderJid: m.sender,
			sock: client
		});
	} catch (err) {
		console.error('[DAFTAR CARD ERROR]', err);
	}

	const teks = `⚡ *REGISTRASI BERHASIL (${isFastReg ? 'DAFTAR CEPAT' : 'MANUAL'})*\n\n` +
		`👤 *Nama:* ${nama}\n` +
		`🎂 *Umur:* ${umur} Tahun\n` +
		`📱 *Nomor:* @${nomor}\n` +
		`🎟️ *Bonus Limit:* +${initLimit} Limit\n` +
		`🔑 *Serial Number:* \`${serialNumber}\`\n\n` +
		`🎉 Selamat! Akun kamu berhasil terdaftar dan mendapatkan *${initLimit} Limit* gratis! Gunakan *${usedPrefix}profile* untuk melihat profil kamu atau *${usedPrefix}menu* untuk melihat fitur.`;

	const buttons = [
		{ displayText: '👤 Profil', id: `${usedPrefix}profile` },
		{ displayText: '🔑 Serial Number', id: `${usedPrefix}ceksn` }
	];

	if (client && typeof client.sendButtons === 'function') {
		await client.sendButtons(m.chat, {
			type: 'location_buttons',
			thumbnail: cardBuffer || (global.getThumbBuffer ? global.getThumbBuffer() : ''),
			text: teks,
			footer: `${global.namaBot || 'Hirara AI'} • Registration Card System`,
			lat: 0,
			lng: 0,
			contextInfo: { mentionedJid: [m.sender] },
			buttons
		}, { quoted: m });
	} else if (cardBuffer) {
		await client.sendMessage(m.chat, {
			image: cardBuffer,
			caption: teks,
			mentions: [m.sender]
		}, { quoted: m });
	} else {
		await client.sendMessage(m.chat, {
			text: teks,
			mentions: [m.sender]
		}, { quoted: m });
	}
};

handler.help = ['daftar <nama.umur>', 'daftarcepat'];
handler.tags = ['main'];
handler.command = /^(daftar|register|reg|daftarcepat|dcepat|fastreg)$/i;
handler.register = false;

export default handler;
