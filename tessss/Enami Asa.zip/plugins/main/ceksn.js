import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, '../info/fonts_ping');

const FONT_SOURCES = [
	{
		url: 'https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf',
		file: 'Inter.ttf',
		family: 'Inter',
	},
	{
		url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
		file: 'NotoColorEmoji.ttf',
		family: 'NotoEmoji',
	},
];

let fontsReady = false;

async function ensureFonts() {
	if (fontsReady) return;
	if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
	const { default: axios } = await import('axios');
	for (const f of FONT_SOURCES) {
		const p = join(FONT_DIR, f.file);
		if (!existsSync(p)) {
			try {
				const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
				writeFileSync(p, Buffer.from(data));
			} catch (e) {
				console.error('[font-fetch-error]', e);
			}
		}
		if (existsSync(p)) {
			try { GlobalFonts.registerFromPath(p, f.family); } catch {}
		}
	}
	fontsReady = true;
}

const FONT_FAMILY = 'Inter, NotoEmoji, sans-serif';

function rrp(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

async function generateCekSNCanvas({ name, serialNumber, ppUrl }) {
  await ensureFonts();
  const W = 900, H = 500;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#fdfbf7');
  bgGrad.addColorStop(0.5, '#f7f0e6');
  bgGrad.addColorStop(1, '#f1e6d6');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  for (let i = 0; i < 800; i++) {
    const nx = Math.random() * W, ny = Math.random() * H;
    ctx.fillStyle = `rgba(140, 100, 70, ${Math.random() * 0.03 + 0.01})`;
    ctx.beginPath();
    ctx.arc(nx, ny, Math.random() * 0.7, 0, Math.PI * 2);
    ctx.fill();
  }

  const vign = ctx.createRadialGradient(W / 2, H / 2, H * 0.3, W / 2, H / 2, W * 0.75);
  vign.addColorStop(0, 'transparent');
  vign.addColorStop(1, 'rgba(140, 90, 50, 0.08)');
  ctx.fillStyle = vign;
  ctx.fillRect(0, 0, W, H);

  const p = 20;
  rrp(ctx, p, p, W - p * 2, H - p * 2, 14);
  ctx.strokeStyle = '#c9956e';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  rrp(ctx, p + 5, p + 5, W - p * 2 - 10, H - p * 2 - 10, 10);
  ctx.strokeStyle = 'rgba(201, 149, 110, 0.35)';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `bold 24px ${FONT_FAMILY}`;
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText('ACCOUNT SERIAL NUMBER', p + 35, p + 45);

  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('🔑 SECURITY PASS', W - p - 170, p + 45);

  const avX = p + 35, avY = p + 75, avSize = 140;

  ctx.save();
  ctx.strokeStyle = '#c9956e';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(avX + avSize / 2, avY + avSize / 2, avSize / 2 + 5, 0, Math.PI * 2);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(avX + avSize / 2, avY + avSize / 2, avSize / 2, 0, Math.PI * 2);
  ctx.clip();

  let avatarLoaded = false;
  if (ppUrl) {
    try {
      const img = await loadImage(ppUrl);
      ctx.drawImage(img, avX, avY, avSize, avSize);
      avatarLoaded = true;
    } catch (_) {}
  }
  if (!avatarLoaded) {
    ctx.fillStyle = '#c9956e';
    ctx.fillRect(avX, avY, avSize, avSize);
    ctx.font = `bold 50px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((name[0] || 'U').toUpperCase(), avX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  const dX = avX + avSize + 35;
  ctx.font = `bold 28px ${FONT_FAMILY}`;
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(name || 'User', dX, avY + 40);

  ctx.font = `16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('SYSTEM ACCESS HASH', dX, avY + 70);

  ctx.font = `14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#15803d';
  ctx.fillText('VERIFIED ACCOUNT ✓', dX, avY + 95);

  const gridY = avY + avSize + 25;
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(avX, gridY - 10);
  ctx.lineTo(W - p - 35, gridY - 10);
  ctx.stroke();

  ctx.font = `13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('STATUS VERIFIKASI', avX, gridY + 20);
  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#15803d';
  ctx.fillText('VERIFIED ✓', avX, gridY + 45);

  ctx.font = `13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('SECURITY STATUS', avX + 260, gridY + 20);
  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText('PROTECTED', avX + 260, gridY + 45);

  const bY = H - p - 80;
  rrp(ctx, avX, bY, W - p * 2 - 70, 58, 10);
  ctx.fillStyle = 'rgba(250, 243, 232, 0.85)';
  ctx.fill();
  ctx.strokeStyle = '#e0b596';
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = `12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#8c502b';
  ctx.fillText('🔑 SERIAL NUMBER', avX + 20, bY + 24);

  ctx.font = `bold 18px ${FONT_FAMILY}`;
  ctx.fillStyle = '#3b1c0c';
  ctx.fillText(serialNumber || 'UNKNOWN', avX + 20, bY + 46);

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock, user, usedPrefix }) => {
	if (!user || !user.registered) {
		return m.reply('❌ Kamu belum terdaftar.\nSilakan daftar dengan mengetik: .daftar');
	}

	const sn = user.serialNumber || user.sn || '';
	const name = user.nama || user.name || 'User';

	let ppUrl = null;
	try {
		ppUrl = await sock.profilePictureUrl(m.sender, 'image').catch(() => null);
	} catch (_) {}

	const cardBuffer = await generateCekSNCanvas({
		name,
		serialNumber: sn,
		ppUrl
	}).catch(() => null);

	const text = `🔐 *Serial Number*\n\n• Nama : ${name}\n• SN : \`${sn}\`\n\n_${sn}_`;
	const footer = `꒰ © ${new Date().getFullYear()} ${global.namaBot || 'Bot'} ꒱`;

	if (cardBuffer && sock?.sendButtons) {
		try {
			await sock.sendButtons(m.chat, {
				type: 'location_buttons',
				thumbnail: cardBuffer,
				text,
				footer,
				lat: 0,
				lng: 0,
				buttons: [
					{ copyCode: sn, text: '📋 Salin SN' }
				]
			}, { quoted: m });
		} catch (_) {
			await sock.sendMessage(m.chat, {
				image: cardBuffer,
				caption: text
			}, { quoted: m });
		}
	} else {
		m.reply(text);
	}
};

handler.help = ['ceksn <serial>'];
handler.command = ['ceksn', 'sn'];
handler.register = true;
handler.tags = ['xp'];

export default handler;
