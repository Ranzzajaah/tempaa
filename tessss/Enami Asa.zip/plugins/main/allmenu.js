import fs from "fs"
import os from "os"
import { getActiveThumbBuffer } from "../../lib/thumb.js"

const toSmallCaps = (str) => {
  const smallCapsMap = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
    j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
    s: 's', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
  }
  return str.toLowerCase().split('').map(c => smallCapsMap[c] || c).join('')
}

const getCategoryEmoji = (cat) => {
  const c = cat.toLowerCase()
  if (c === 'ai') return '🤖'
  if (c === 'anime') return '🌸'
  if (c === 'asupan') return '💃'
  if (c === 'audio') return '🎧'
  if (c === 'cewerandom') return '✨'
  if (c === 'convert') return '🔄'
  if (c === 'download') return '📥'
  if (c === 'ephoto') return '🎨'
  if (c === 'fun') return '🎲'
  if (c === 'github') return '🐙'
  if (c === 'grup') return '👥'
  if (c === 'info') return 'ℹ️'
  if (c === 'main') return '🏠'
  if (c === 'maker') return '🛠️'
  if (c === 'nsfw') return '🔞'
  if (c === 'other') return '📦'
  if (c === 'owner') return '👑'
  if (c === 'panel') return '🖥️'
  if (c === 'rpg') return '⚔️'
  if (c === 'search') return '🔍'
  if (c === 'tools') return '🧰'
  if (c === 'webapi') return '🌐'
  return '📁'
}

const sortCategoriesAZ = (categories) => {
  return [...categories].sort((a, b) => a.localeCompare(b))
}

const getBadge = (cmd) => {
  if (typeof cmd === 'object' && cmd !== null) {
    if (cmd.isOwner) return ' Ⓞ'
    if (cmd.isPremium) return ' Ⓟ'
    return ' Ⓕ'
  }
  return ''
}

const getCmdName = (cmd) => {
  return typeof cmd === 'object' && cmd !== null ? cmd.name : cmd
}

const sortCommandsAZ = (commands) => {
  return [...commands].sort((a, b) => {
    const nameA = getCmdName(a)
    const nameB = getCmdName(b)
    return nameA.localeCompare(nameB)
  })
}

const formatUptime = (seconds) => {
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  const parts = []
  if (d > 0) parts.push(`${d}d`)
  if (h > 0) parts.push(`${h}h`)
  if (m > 0) parts.push(`${m}m`)
  parts.push(`${s}s`)
  return parts.join(' ')
}

const handler = async (m, { conn, sock, getMenuData, usedPrefix, isOwner, isPremium, user }) => {
  const client = conn || sock
  const prefix = usedPrefix || '.'
  const prfx = prefix
  const menu = getMenuData()

  for (const cat in menu) {
    menu[cat] = sortCommandsAZ(menu[cat])
  }

  const categories = sortCategoriesAZ(Object.keys(menu))
  const sender = m.sender || ''
  const no = sender.split('@')[0] || 'User'
  const botName = global.namaBot || 'Hirara AI'
  const ownerName = global.namaOwner || 'Mommy kyu'

  const botUptime = process.uptime()
  const serverUptime = os.uptime()
  const uptimeStr = formatUptime(botUptime)
  const serverUptimeStr = formatUptime(serverUptime)
  const web = global.website || 'https://api.kyzzz.xyz'
  const status = isOwner ? 'Owner' : isPremium ? 'Premium' : 'Free User'
  const mode = global.public ? 'Public' : 'Self'

  const limit = (isOwner || isPremium) ? 'Unlimited' : (user?.limit ?? 25)
  const money = (user?.money || 0).toLocaleString('id-ID')
  const regStatus = user?.registered ? 'Terverifikasi (Sudah Daftar)' : 'Belum Terdaftar'

  const legendText = `*Keterangan Symbol:*\n• Ⓕ = Free\n• Ⓟ = Premium\n• Ⓞ = Owner\n\n`

  const formatSectionStyle1 = (category, cmds) => {
    if (!cmds?.length) return ''
    const lines = cmds.map((cmdObj, i) => {
      const cName = toSmallCaps(getCmdName(cmdObj))
      const badge = getBadge(cmdObj)
      if (cmds.length === 1) return `  ╰─ ${prefix}${cName}${badge}`
      if (i === 0) return `  ╭─ ${prefix}${cName}${badge}`
      if (i === cmds.length - 1) return `  ╰─ ${prefix}${cName}${badge}`
      return `  ├─ ${prefix}${cName}${badge}`
    })

    return `┌─「 *${toSmallCaps(category)}* 」\n${lines.join('\n')}\n└──────────────⊹`
  }

  const thumb = await getActiveThumbBuffer()

  let teks = `ʜᴀɪ @${no}, ɪɴɪ sᴇᴍᴜᴀ ғɪᴛᴜʀ *${botName}*\n\n` +
         `◦ sᴛᴀᴛᴜs       : *${status}*\n` +
         `◦ ʀᴇɢɪsᴛᴇʀ     : ${regStatus}\n` +
         `◦ ʟɪᴍɪᴛ        : ${limit}\n` +
         `◦ ᴜᴀɴɢ         : Rp ${money}\n` +
         `◦ ᴜᴘᴛɪᴍᴇ       : ${uptimeStr}\n` +
         `◦ sᴇʀᴠᴇʀ ᴜᴘᴛɪᴍᴇ : ${serverUptimeStr}\n` +
         `◦ ᴍᴏᴅᴇ         : ${mode}\n` +
         `◦ ᴘʀᴇғɪx       : ${prfx}\n\n` +
         legendText

  for (const cat of categories) {
    teks += formatSectionStyle1(cat, menu[cat]) + '\n\n'
  }

  teks += `───────────────\n` +
    `© ${botName} • Created by ${ownerName}`

  await client.sendButtons(m.chat, {
    location: {
      degreesLatitude: -6.2088,
      degreesLongitude: 106.8456,
      address: `${botName} — ${web}`,
      jpegThumbnail: thumb,
    },
    text: '',
    footer: teks,
    messageParams: {
      bottom_sheet: {
        in_thread_buttons_limit: 1,
        list_title: 'bottom_sheet',
        button_title: botName
      }
    },
    contextInfo: {
      mentionedJid: [sender]
    },
    buttons: [
      {
        title: 'info',
        sections: [
          {
            title: "ɪɴғᴏʀᴍᴀsɪ ʙᴏᴛ",
            rows: [
              {
                title: "📜 sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ",
                description: "ʜɪʀᴀʀᴀ - ɪɴғᴏʀᴍᴀsɪ sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ",
                id: `${prefix}script`
              },
              {
                title: "👑 ᴏᴡɴᴇʀ ʙᴏᴛ",
                description: "ʜɪʀᴀʀᴀ - ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ʙᴏᴛ",
                id: `${prefix}owner`
              }
            ]
          }
        ],
        icon: "REVIEW"
      },
      {
        title: 'cmd',
        sections: [
          {
            title: botName,
            highlight_label: botName,
            rows: categories.map(cat => {
              const emoji = getCategoryEmoji(cat)
              return {
                title: `${emoji} ${toSmallCaps(cat)} ᴍᴇɴᴜ`,
                description: `ʜɪʀᴀʀᴀ - ғɪᴛᴜʀ ᴋᴀᴛᴇɢᴏʀɪ ${toSmallCaps(cat)}`,
                id: `${prefix}menu ${cat}`
              }
            })
          }
        ],
        icon: "DEFAULT"
      },
      {
        displayText: `👑 ${ownerName}`,
        url: web
      }
    ]
  }, { quoted: m, messageId: global.customId ? global.customId() : undefined })
}

handler.help = ['allmenu']
handler.tags = ['main']
handler.command = ['allmenu', 'allhelp', 'menuall']

export default handler
