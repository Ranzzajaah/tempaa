import { unregisterUser } from '../../lib/database.js';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, '../info/fonts_ping');

const FONT_SOURCES = [
	{
		url: 'https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf',
		file: 'Inter.ttf',
		family: 'Inter',
	},
	{
		url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
		file: 'NotoColorEmoji.ttf',
		family: 'NotoEmoji',
	},
];

let fontsReady = false;

async function ensureFonts() {
	if (fontsReady) return;
	if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
	const { default: axios } = await import('axios');
	for (const f of FONT_SOURCES) {
		const p = join(FONT_DIR, f.file);
		if (!existsSync(p)) {
			try {
				const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
				writeFileSync(p, Buffer.from(data));
			} catch (e) {
				console.error('[font-fetch-error]', e);
			}
		}
		if (existsSync(p)) {
			try { GlobalFonts.registerFromPath(p, f.family); } catch {}
		}
	}
	fontsReady = true;
}

const FONT_FAMILY = 'Inter, NotoEmoji, sans-serif';

async function generateUnregCanvas({ name, serialNumber, ppUrl }) {
  await ensureFonts();
  const W = 800, H = 400;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  const bgGrad = ctx.createLinearGradient(0, 0, W, H);
  bgGrad.addColorStop(0, '#180808');
  bgGrad.addColorStop(0.5, '#0f0505');
  bgGrad.addColorStop(1, '#050202');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, W, H);

  const g1 = ctx.createRadialGradient(200, 100, 10, 200, 100, 350);
  g1.addColorStop(0, 'rgba(239, 68, 68, 0.25)');
  g1.addColorStop(1, 'transparent');
  ctx.fillStyle = g1;
  ctx.fillRect(0, 0, W, H);

  ctx.strokeStyle = 'rgba(239, 68, 68, 0.05)';
  ctx.lineWidth = 12;
  for (let i = -H; i < W + H; i += 40) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i + H, H);
    ctx.stroke();
  }

  const p = 24;
  ctx.save();
  ctx.fillStyle = 'rgba(24, 10, 10, 0.7)';
  ctx.strokeStyle = '#ef4444';
  ctx.lineWidth = 2;
  ctx.shadowColor = '#ef4444';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.roundRect(p, p, W - p * 2, H - p * 2, 16);
  ctx.fill();
  ctx.stroke();
  ctx.restore();

  ctx.font = `bold 24px ${FONT_FAMILY}`;
  ctx.fillStyle = '#fca5a5';
  ctx.fillText('ACCOUNT REVOCATION CARD', p + 35, p + 50);

  const avX = p + 40, avY = p + 80, avSize = 120;
  ctx.save();
  ctx.beginPath();
  ctx.arc(avX + avSize / 2, avY + avSize / 2, avSize / 2, 0, Math.PI * 2);
  ctx.clip();

  let avatarLoaded = false;
  if (ppUrl) {
    try {
      const img = await loadImage(ppUrl);
      ctx.drawImage(img, avX, avY, avSize, avSize);
      avatarLoaded = true;
    } catch (_) {}
  }
  if (!avatarLoaded) {
    ctx.fillStyle = '#991b1b';
    ctx.fillRect(avX, avY, avSize, avSize);
    ctx.font = `bold 45px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((name[0] || 'U').toUpperCase(), avX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.strokeStyle = '#f87171';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(avX + avSize / 2, avY + avSize / 2, avSize / 2 + 4, 0, Math.PI * 2);
  ctx.stroke();

  const dx = avX + avSize + 35;
  ctx.font = `bold 28px ${FONT_FAMILY}`;
  ctx.fillStyle = '#f8fafc';
  ctx.fillText(name || 'User', dx, avY + 40);

  ctx.font = `15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#fca5a5';
  ctx.fillText(`STATUS: UNREGISTERED / DELETED`, dx, avY + 70);

  const bY = H - p - 75;
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.4)';
  ctx.beginPath();
  ctx.roundRect(avX, bY, W - p * 2 - 80, 50, 10);
  ctx.fill();
  ctx.stroke();

  ctx.font = `12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#991b1b';
  ctx.fillText('REVOKED SERIAL NUMBER', avX + 20, bY + 20);

  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = '#f87171';
  ctx.fillText(serialNumber || 'UNKNOWN', avX + 20, bY + 40);

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock, text, usedPrefix, command, user }) => {
	if (!user || !user.registered) {
		return m.reply(`_Anda belum terdaftar._`);
	}

	const inputSN = text?.trim()?.toUpperCase();
	if (!inputSN) {
		return m.reply(`_Masukkan Serial Number (SN)._\nContoh:\n*${usedPrefix}${command} ${user.serialNumber}*`);
	}

	if (inputSN !== (user.serialNumber || '').toUpperCase()) {
		return m.reply('❌ *Serial Number tidak valid!*');
	}

	const oldName = user.nama || user.name || 'User';
	const oldSN = user.serialNumber || '';

	let ppUrl = null;
	try {
		ppUrl = await sock.profilePictureUrl(m.sender, 'image').catch(() => null);
	} catch (_) {}

	const cardBuffer = await generateUnregCanvas({
		name: oldName,
		serialNumber: oldSN,
		ppUrl
	}).catch((err) => {
		console.error('[unreg canvas error]', err);
		return null;
	});

	await unregisterUser(m.sender);

	const teks = `✅ *UNREGISTER BERHASIL*\n\nAkun kamu (${oldName}) dan seluruh data RPG telah berhasil dihapus dari database.`;

	if (cardBuffer && sock?.sendButtons) {
		await sock.sendButtons(m.chat, {
			type: 'location_buttons',
			thumbnail: cardBuffer,
			text: teks,
			footer: `${global.namaBot || 'Bot'} • Unregistration System`,
			lat: 0,
			lng: 0,
			buttons: [
				{ displayText: '📝 Daftar Kembali', id: `${usedPrefix}daftarcepat` }
			]
		}, { quoted: m });
	} else {
		m.reply(teks);
	}
};

handler.command = ['unreg', 'unregister'];
handler.register = true;
handler.category = 'main';
handler.description = 'Hapus pendaftaran akun dan reset data RPG';

export default handler;
