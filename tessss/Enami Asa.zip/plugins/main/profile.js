/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { parseInventory, ITEM_NAMES } from '../../lib/rpg.js';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY, loadAvatarImage } from '../../canvas/canvas-font.js';

function drawNeo3D(ctx, x, y, w, h, r, bg, depth = 6, borderColor = '#000000', borderWidth = 3) {
  function path(px, py) {
    ctx.beginPath();
    ctx.moveTo(px + r, py);
    ctx.lineTo(px + w - r, py);
    ctx.quadraticCurveTo(px + w, py, px + w, py + r);
    ctx.lineTo(px + w, py + h - r);
    ctx.quadraticCurveTo(px + w, py + h, px + w - r, py + h);
    ctx.lineTo(px + r, py + h);
    ctx.quadraticCurveTo(px, py + h, px, py + h - r);
    ctx.lineTo(px, py + r);
    ctx.quadraticCurveTo(px, py, px + r, py);
    ctx.closePath();
  }

  if (depth > 0) {
    path(x + depth, y + depth);
    ctx.fillStyle = '#000000';
    ctx.fill();
  }

  path(x, y);
  ctx.fillStyle = bg;
  ctx.fill();

  if (borderWidth > 0) {
    ctx.strokeStyle = borderColor;
    ctx.lineWidth = borderWidth;
    ctx.stroke();
  }

  ctx.save();
  path(x, y);
  ctx.clip();
  const gloss = ctx.createLinearGradient(x, y, x, y + h * 0.4);
  gloss.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
  gloss.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = gloss;
  ctx.fillRect(x, y, w, h * 0.4);
  ctx.restore();
}

function drawNeo3DBar(ctx, x, y, w, h, r, val, max, fillCol, depth = 4) {
  drawNeo3D(ctx, x, y, w, h, r, '#ffffff', depth, '#000000', 2);
  const percent = Math.max(0, Math.min(1, val / (max || 1)));
  if (percent > 0) {
    const fillW = Math.max(h, w * percent);
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + fillW - r, y);
    ctx.quadraticCurveTo(x + fillW, y, x + fillW, y + r);
    ctx.lineTo(x + fillW, y + h - r);
    ctx.quadraticCurveTo(x + fillW, y + h, x + fillW - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fillStyle = fillCol;
    ctx.fill();
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.stroke();

    const shine = ctx.createLinearGradient(x, y, x, y + h * 0.5);
    shine.addColorStop(0, 'rgba(255, 255, 255, 0.4)');
    shine.addColorStop(1, 'rgba(255, 255, 255, 0)');
    ctx.fillStyle = shine;
    ctx.fillRect(x, y, fillW, h * 0.5);
    ctx.restore();
  }
}

async function generateProfileCanvas({
  name,
  nomor,
  user,
  ppUrl,
  partnerName,
  roleText,
  regStatusText,
  totalItemsCount,
  topInventoryList
}) {
  await ensureCanvasFonts();
  const W = 1000, H = 640;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#fffae5';
  ctx.fillRect(0, 0, W, H);

  ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
  for (let gx = 15; gx < W; gx += 26) {
    for (let gy = 15; gy < H; gy += 26) {
      ctx.beginPath();
      ctx.arc(gx, gy, 1.8, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const p = 16;
  drawNeo3D(ctx, p, p, W - p * 2, H - p * 2, 24, '#ffffff', 8, '#000000', 4);

  drawNeo3D(ctx, p + 20, p + 18, 510, 48, 16, '#ff4794', 5, '#000000', 3.5);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ffffff';
  ctx.fillText('✨ HIRARA ADVENTURER ID 🎮', p + 38, p + 50);

  drawNeo3D(ctx, W - p - 340, p + 18, 320, 48, 16, '#ffd000', 5, '#000000', 3.5);
  ctx.font = `bold 15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`👑 ${roleText}`, W - p - 322, p + 48);

  const leftX = p + 20, leftY = p + 80, leftW = 295, leftH = 500;
  drawNeo3D(ctx, leftX, leftY, leftW, leftH, 20, '#ffffff', 6, '#000000', 3.5);

  const avSize = 130, avX = leftX + (leftW - avSize) / 2, avY = leftY + 20;
  drawNeo3D(ctx, avX, avY, avSize, avSize, 22, '#ffffff', 5, '#000000', 3);

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(avX + 22, avY);
  ctx.lineTo(avX + avSize - 22, avY);
  ctx.quadraticCurveTo(avX + avSize, avY, avX + avSize, avY + 22);
  ctx.lineTo(avX + avSize, avY + avSize - 22);
  ctx.quadraticCurveTo(avX + avSize, avY + avSize, avX + avSize - 22, avY + avSize);
  ctx.lineTo(avX + 22, avY + avSize);
  ctx.quadraticCurveTo(avX, avY + avSize, avX, avY + avSize - 22);
  ctx.lineTo(avX + 22, avY);
  ctx.quadraticCurveTo(avX, avY, avX + 22, avY);
  ctx.closePath();
  ctx.clip();

  const avatarImg = await loadAvatarImage(ppUrl);
  if (avatarImg) {
    ctx.drawImage(avatarImg, avX, avY, avSize, avSize);
  } else {
    ctx.fillStyle = '#60a5fa';
    ctx.fillRect(avX, avY, avSize, avSize);
    ctx.font = `bold 52px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((name[0] || 'U').toUpperCase(), avX + avSize / 2, avY + avSize / 2);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();

  ctx.textAlign = 'center';
  ctx.font = `bold 19px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  const displayName = name.length > 17 ? name.substring(0, 16) + '...' : name;
  ctx.fillText(displayName, leftX + leftW / 2, avY + avSize + 30);

  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#475569';
  ctx.fillText(`📱 +${nomor}`, leftX + leftW / 2, avY + avSize + 50);

  const isReg = user.registered === 1;
  const regY = avY + avSize + 62;
  drawNeo3D(ctx, leftX + 16, regY, leftW - 32, 54, 14, isReg ? '#bbf7d0' : '#fecaca', 4, '#000000', 2);
  ctx.textAlign = 'left';
  ctx.font = `bold 11px ${FONT_FAMILY}`;
  ctx.fillStyle = isReg ? '#15803d' : '#b91c1c';
  ctx.fillText(`${isReg ? '✅ VERIFIED' : '❌ UNREGISTERED'}`, leftX + 28, regY + 22);
  ctx.font = `bold 11px ${FONT_FAMILY}`;
  ctx.fillStyle = '#1e293b';
  ctx.fillText(`🔑 SN: ${user.serialNumber ? user.serialNumber.substring(0, 18) : '-'}`, leftX + 28, regY + 42);

  const partnerY = regY + 68;
  drawNeo3D(ctx, leftX + 16, partnerY, leftW - 32, 105, 16, user.partner ? '#fbcfe8' : '#e2e8f0', 4, '#000000', 2);
  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#db2777';
  ctx.fillText('👩‍❤️‍👨 PASANGAN (PARTNER):', leftX + 28, partnerY + 26);
  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  const displayPartner = partnerName.length > 18 ? partnerName.substring(0, 17) + '...' : partnerName;
  ctx.fillText(user.partner ? displayPartner : '💔 Jomblo Happy', leftX + 28, partnerY + 52);
  ctx.font = `bold 11px ${FONT_FAMILY}`;
  ctx.fillStyle = '#475569';
  ctx.fillText(user.partner ? `💕 Level ${user.datingLevel || 1}` : '👉 Ketik .tembak @user', leftX + 28, partnerY + 76);
  ctx.fillText(user.partner ? `💍 Pasangan Setia` : '🌸 Cari pasanganmu', leftX + 28, partnerY + 94);

  const rightX = leftX + leftW + 18, rightY = p + 80, rightW = W - p * 2 - leftW - 38, rightH = 500;
  drawNeo3D(ctx, rightX, rightY, rightW, rightH, 20, '#ffffff', 6, '#000000', 3.5);

  ctx.font = `bold 15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`⚔️ STATISTIK KARAKTER RPG  •  CLASS: ${user.role || 'Adventurer'}`, rightX + 20, rightY + 30);

  const halfBarW = (rightW - 54) / 2;
  const barH = 20;

  const maxExpForLvl = (user.level || 1) * 1000;
  drawNeo3DBar(ctx, rightX + 20, rightY + 44, halfBarW, barH, 10, user.exp || 0, maxExpForLvl, '#c084fc', 3);
  ctx.font = `bold 10px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`⭐ LVL ${user.level || 1}  •  EXP: ${(user.exp || 0).toLocaleString('id-ID')} / ${maxExpForLvl.toLocaleString('id-ID')}`, rightX + 28, rightY + 58);

  const userLimit = user.limit ?? user.limit_val ?? 20;
  drawNeo3DBar(ctx, rightX + 34 + halfBarW, rightY + 44, halfBarW, barH, 10, userLimit, 100, '#38bdf8', 3);
  ctx.fillText(`🎟️ LIMIT: ${userLimit.toLocaleString('id-ID')} TIKET`, rightX + 42 + halfBarW, rightY + 58);

  drawNeo3DBar(ctx, rightX + 20, rightY + 74, halfBarW, barH, 10, user.health || 100, user.maxHealth || 100, '#f87171', 3);
  ctx.fillText(`❤️ HP: ${user.health || 100} / ${user.maxHealth || 100}`, rightX + 28, rightY + 88);

  drawNeo3DBar(ctx, rightX + 34 + halfBarW, rightY + 74, halfBarW, barH, 10, user.energy || 100, user.maxEnergy || 100, '#34d399', 3);
  ctx.fillText(`⚡ ENERGY: ${user.energy || 100} / ${user.maxEnergy || 100}`, rightX + 42 + halfBarW, rightY + 88);

  const cardW = (rightW - 54) / 2;
  const cardH = 52;

  drawNeo3D(ctx, rightX + 20, rightY + 106, cardW, cardH, 14, '#fef08a', 4, '#000000', 2);
  ctx.font = `bold 10px ${FONT_FAMILY}`;
  ctx.fillStyle = '#854d0e';
  ctx.fillText('💰 DOMPET (WALLET)', rightX + 32, rightY + 124);
  ctx.font = `bold 15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`$${(user.money || 0).toLocaleString('id-ID')}`, rightX + 32, rightY + 146);

  drawNeo3D(ctx, rightX + 34 + cardW, rightY + 106, cardW, cardH, 14, '#bae6fd', 4, '#000000', 2);
  ctx.font = `bold 10px ${FONT_FAMILY}`;
  ctx.fillStyle = '#0369a1';
  ctx.fillText('🏦 TABUNGAN BANK', rightX + 46 + cardW, rightY + 124);
  ctx.font = `bold 15px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`$${(user.bank || 0).toLocaleString('id-ID')}`, rightX + 46 + cardW, rightY + 146);

  drawNeo3D(ctx, rightX + 20, rightY + 168, cardW, cardH, 14, '#bbf7d0', 4, '#000000', 2);
  ctx.font = `bold 10px ${FONT_FAMILY}`;
  ctx.fillStyle = '#15803d';
  ctx.fillText('🐾 HEWAN PELIHARAAN (PET)', rightX + 32, rightY + 186);
  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(user.pet && user.pet !== 'None' ? user.pet : 'Tidak Ada Pet', rightX + 32, rightY + 208);

  drawNeo3D(ctx, rightX + 34 + cardW, rightY + 168, cardW, cardH, 14, '#fed7aa', 4, '#000000', 2);
  ctx.font = `bold 10px ${FONT_FAMILY}`;
  ctx.fillStyle = '#c2410c';
  ctx.fillText('🛡️ EQUIPMENT BATTLE', rightX + 46 + cardW, rightY + 186);
  ctx.font = `bold 12px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`${user.weapon || 'Pedang Kayu'}  •  ${user.armor || 'Baju Kulit'}`, rightX + 46 + cardW, rightY + 208);

  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText('♻️ HASIL MULUNG & RECYCLE', rightX + 20, rightY + 242);

  const junkW = (rightW - 74) / 5;
  const junkH = 44;

  const junks = [
    { label: `${global.rpg?.emoticon('botol') || '🍾'} Botol`, val: user.botol || 0, bg: '#e0f2fe' },
    { label: `${global.rpg?.emoticon('kaleng') || '🥫'} Kaleng`, val: user.kaleng || 0, bg: '#ffedd5' },
    { label: `${global.rpg?.emoticon('kardus') || '📦'} Kardus`, val: user.kardus || 0, bg: '#fef3c7' },
    { label: `${global.rpg?.emoticon('gelas') || '🥤'} Gelas`, val: user.gelas || 0, bg: '#ede9fe' },
    { label: `${global.rpg?.emoticon('plastik') || '🛍️'} Plastik`, val: user.plastik || 0, bg: '#dcfce7' }
  ];

  junks.forEach((junk, idx) => {
    const jx = rightX + 20 + idx * (junkW + 8);
    drawNeo3D(ctx, jx, rightY + 252, junkW, junkH, 12, junk.bg, 3, '#000000', 2);
    ctx.font = `bold 10px ${FONT_FAMILY}`;
    ctx.fillStyle = '#475569';
    ctx.fillText(junk.label, jx + 6, rightY + 268);
    ctx.font = `bold 13px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.fillText(`${junk.val.toLocaleString('id-ID')}`, jx + 6, rightY + 286);
  });

  const invBoxH = 155;
  drawNeo3D(ctx, rightX + 20, rightY + 312, rightW - 40, invBoxH, 16, '#faf5ff', 4, '#000000', 2);
  ctx.font = `bold 13px ${FONT_FAMILY}`;
  ctx.fillStyle = '#7e22ce';
  ctx.fillText(`🎒 TAS INVENTORY (Total: ${totalItemsCount.toLocaleString('id-ID')} Item)`, rightX + 32, rightY + 334);

  if (topInventoryList.length > 0) {
    const colCount = 3;
    const itemGridW = (rightW - 70) / colCount;
    topInventoryList.slice(0, 9).forEach((item, idx) => {
      const col = idx % colCount;
      const row = Math.floor(idx / colCount);
      const ix = rightX + 32 + col * itemGridW;
      const iy = rightY + 346 + row * 34;

      drawNeo3D(ctx, ix, iy, itemGridW - 10, 26, 8, '#ffffff', 2, '#000000', 1.5);
      ctx.font = `bold 11px ${FONT_FAMILY}`;
      ctx.fillStyle = '#000000';
      const itemTxt = `${item.label}: ${item.qty.toLocaleString('id-ID')}`;
      ctx.fillText(itemTxt.length > 18 ? itemTxt.substring(0, 17) + '..' : itemTxt, ix + 8, iy + 17);
    });
  } else {
    ctx.font = `12px ${FONT_FAMILY}`;
    ctx.fillStyle = '#64748b';
    ctx.fillText('Tas kamu masih kosong. Dapatkan item lewat .mine, .hunt, .mulung, atau .fishing!', rightX + 32, rightY + 375);
  }

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, { sock, user, isOwner, isPremium, usedPrefix, prefix }) => {
  const targetJid = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.sender;
  const isSelf = targetJid === m.sender;

  const userData = isSelf ? user : await getUser(targetJid);
  const targetNum = targetJid.split('@')[0];

  let partnerName = 'Jomblo';
  if (userData.partner) {
    const pData = await getUser(userData.partner);
    partnerName = pData?.nama || pData?.name || `@${userData.partner.split('@')[0]}`;
  }

  let ppUrl = null;
  try {
    ppUrl = await sock.profilePictureUrl(targetJid, 'image').catch(() => null);
  } catch (_) {}

  const name = userData.nama || userData.name || (isSelf && m.pushName ? m.pushName : `@${targetNum}`);
  const nomor = userData.nomor || targetNum;
  const registered = userData.registered === 1;
  const regDate = registered ? (userData.registeredAt || '-') : 'Belum Terdaftar';
  const sn = registered ? (userData.serialNumber || '-') : '-';

  const roleText = isOwner ? 'Owner Bot' : isPremium ? 'Premium User' : 'Free User';
  const userLimit = userData.limit ?? userData.limit_val ?? 20;

  const inv = parseInventory(userData.inventory);
  let totalItemsCount = 0;
  const topInventoryList = [];

  for (const [k, qty] of Object.entries(inv)) {
    if (typeof qty === 'number' && qty > 0) {
      totalItemsCount += qty;
      const emot = global.rpg?.emoticon(k) || '';
      const rawName = ITEM_NAMES[k] ? ITEM_NAMES[k].replace(/^[^\w\s]+\s*/, '') : k;
      const label = emot ? `${emot} ${rawName}` : rawName;
      topInventoryList.push({ key: k, label, qty });
    }
  }
  topInventoryList.sort((a, b) => b.qty - a.qty);

  const cardBuffer = await generateProfileCanvas({
    name,
    nomor,
    user: userData,
    ppUrl,
    partnerName,
    roleText,
    regStatusText: registered ? 'Terverifikasi' : 'Belum Terdaftar',
    totalItemsCount,
    topInventoryList
  }).catch((err) => {
    console.error('[generateProfileCanvas Error]:', err);
    return null;
  });

  const nextExp = (userData.level || 1) * 1000;
  
  const topInvLines = topInventoryList.length > 0
    ? topInventoryList.slice(0, 5).map(i => `  • ${i.label}: ${i.qty.toLocaleString('id-ID')}`).join('\n')
    : '  • Tas Inventory Kosong';

  const eBotol = global.rpg?.emoticon('botol') || '🍾';
  const eKaleng = global.rpg?.emoticon('kaleng') || '🥫';
  const eKardus = global.rpg?.emoticon('kardus') || '📦';
  const eGelas = global.rpg?.emoticon('gelas') || '🥤';
  const ePlastik = global.rpg?.emoticon('plastik') || '🛍️';

  const profileText =
`👤 *USER PROFILE & STATUS* ✨

📋 *Informasi Akun:*
• 👤 Nama: ${name}
• 📱 Nomor: @${nomor}
• 👑 Hak Akses: ${roleText}
• 📌 Status: ${registered ? '✅ Terverifikasi' : '❌ Belum Terdaftar'}
• 📅 Tanggal Daftar: ${regDate}
• 🔑 Serial Number: \`${sn}\`

⚔️ *Statistik RPG & Vitals:*
• 🎮 Class / Role: ${userData.role || 'Adventurer'}
• ⭐ Level: Level ${userData.level || 1} (${(userData.exp || 0).toLocaleString('id-ID')} / ${nextExp.toLocaleString('id-ID')} EXP)
• ❤️ Health: ${userData.health || 100} / ${userData.maxHealth || 100} HP
• ⚡ Energy: ${userData.energy || 100} / ${userData.maxEnergy || 100} EP
• 🍖 Hunger: ${userData.hunger || 100} / 100
• 🎟️ Sisa Limit: ${userLimit.toLocaleString('id-ID')} Tiket

💰 *Keuangan & Sosial:*
• 💵 Saldo Dompet: $${(userData.money || 0).toLocaleString('id-ID')}
• 🏦 Saldo Bank: $${(userData.bank || 0).toLocaleString('id-ID')}
• 👩‍❤️‍👨 Pasangan: ${userData.partner ? `💕 ${partnerName} (Level ${userData.datingLevel || 1})` : '💔 Jomblo'}
• 🐾 Peliharaan: ${userData.pet && userData.pet !== 'None' ? `🐱 ${userData.pet}` : 'Tidak Ada'}

🛡️ *Perlengkapan & Tas Inventory:*
• 🗡️ Senjata Utama: ${userData.weapon || 'Pedang Kayu'}
• 🪖 Zirah Pelindung: ${userData.armor || 'Baju Kulit'}
• ♻️ Hasil Mulung: ${eBotol} ${userData.botol || 0} • ${eKaleng} ${userData.kaleng || 0} • ${eKardus} ${userData.kardus || 0} • ${eGelas} ${userData.gelas || 0} • ${ePlastik} ${userData.plastik || 0}
• 🎒 Total Barang: ${totalItemsCount.toLocaleString('id-ID')} Item
• 📦 Item Tas Terbanyak:
${topInvLines}`;

  await sock.sendMessage(m.chat, { react: { text: '👤', key: m.key } });

  if (cardBuffer) {
    return sock.sendMessage(m.chat, {
      image: cardBuffer,
      caption: profileText,
      mentions: [targetJid]
    }, { quoted: m });
  } else {
    return sock.sendMessage(m.chat, {
      text: profileText,
      mentions: [targetJid]
    }, { quoted: m });
  }
};

handler.command = ['me', 'profile', 'profil', 'status'];
handler.category = 'main';
handler.description = 'Tampilkan status profil lengkap pengguna';
handler.register = true;

export default handler;
