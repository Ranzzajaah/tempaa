/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { addExp } from '../../lib/rpg.js';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const FONT_DIR = join(__dirname, '../info/fonts_ping');

const FONT_SOURCES = [
	{
		url: 'https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf',
		file: 'Inter.ttf',
		family: 'Inter',
	},
	{
		url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf',
		file: 'NotoColorEmoji.ttf',
		family: 'NotoEmoji',
	},
];

let fontsReady = false;

async function ensureFonts() {
	if (fontsReady) return;
	if (!existsSync(FONT_DIR)) mkdirSync(FONT_DIR, { recursive: true });
	const { default: axios } = await import('axios');
	for (const f of FONT_SOURCES) {
		const p = join(FONT_DIR, f.file);
		if (!existsSync(p)) {
			try {
				const { data } = await axios.get(f.url, { responseType: 'arraybuffer', timeout: 30000 });
				writeFileSync(p, Buffer.from(data));
			} catch (e) {
				console.error('[font-fetch-error]', e);
			}
		}
		if (existsSync(p)) {
			try { GlobalFonts.registerFromPath(p, f.family); } catch {}
		}
	}
	fontsReady = true;
}

const FONT_FAMILY = 'Inter, NotoEmoji, sans-serif';
const COOLDOWN = 60 * 60 * 1000; 

const DROP_RATES = [
	{
		tier: 'LEGENDARY',
		rateText: '5%',
		chance: 0.05,
		color: '#FFD700',
		bgColor: 'rgba(255, 215, 0, 0.1)',
		borderColor: '#D4AF37',
		items: [
			{ name: 'Diamond', key: 'diamond', min: 2, max: 5, icon: '💎' },
			{ name: 'Limit', type: 'limit', min: 5, max: 15, icon: '🎟️' },
			{ name: 'Money', type: 'money', min: 50000, max: 150000, icon: '💰' },
			{ name: 'EXP', type: 'exp', min: 1000, max: 3000, icon: '✨' }
		]
	},
	{
		tier: 'EPIC',
		rateText: '20%',
		chance: 0.20,
		color: '#A855F7',
		bgColor: 'rgba(168, 85, 247, 0.1)',
		borderColor: '#9333EA',
		items: [
			{ name: 'Gold Ore', key: 'emas', min: 3, max: 8, icon: '🌟' },
			{ name: 'Limit', type: 'limit', min: 3, max: 8, icon: '🎟️' },
			{ name: 'Money', type: 'money', min: 20000, max: 50000, icon: '💵' },
			{ name: 'Potion', key: 'potion', min: 2, max: 5, icon: '🧪' }
		]
	},
	{
		tier: 'RARE',
		rateText: '35%',
		chance: 0.35,
		color: '#3B82F6',
		bgColor: 'rgba(59, 130, 246, 0.1)',
		borderColor: '#2563EB',
		items: [
			{ name: 'Iron Ore', key: 'besi', min: 5, max: 15, icon: '⛓️' },
			{ name: 'Limit', type: 'limit', min: 2, max: 5, icon: '🎟️' },
			{ name: 'Money', type: 'money', min: 8000, max: 20000, icon: '💵' },
			{ name: 'EXP', type: 'exp', min: 300, max: 800, icon: '✨' }
		]
	},
	{
		tier: 'COMMON',
		rateText: '40%',
		chance: 0.40,
		color: '#9CA3AF',
		bgColor: 'rgba(156, 163, 175, 0.1)',
		borderColor: '#6B7280',
		items: [
			{ name: 'Kayu', key: 'kayu', min: 10, max: 25, icon: '🪵' },
			{ name: 'Batu', key: 'batu', min: 10, max: 25, icon: '🪨' },
			{ name: 'Limit', type: 'limit', min: 1, max: 3, icon: '🎟️' },
			{ name: 'Money', type: 'money', min: 2000, max: 8000, icon: '💵' }
		]
	}
];

function rrp(ctx, x, y, w, h, r) {
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h - r);
	ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
	ctx.lineTo(x + r, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - r);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
}

async function generateAirdropCanvas({ playerName, lootTier, lootResults, newMoney, ppUrl }) {
	await ensureFonts();
	const W = 840, H = 520;
	const canvas = createCanvas(W, H);
	const ctx = canvas.getContext('2d');

	const bgGrad = ctx.createLinearGradient(0, 0, W, H);
	bgGrad.addColorStop(0, '#0D0E12');
	bgGrad.addColorStop(0.5, '#13151D');
	bgGrad.addColorStop(1, '#0A0B0E');
	ctx.fillStyle = bgGrad;
	ctx.fillRect(0, 0, W, H);

	for (let i = 0; i < 500; i++) {
		const nx = Math.random() * W, ny = Math.random() * H;
		ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.02 + 0.005})`;
		ctx.beginPath();
		ctx.arc(nx, ny, Math.random() * 0.8, 0, Math.PI * 2);
		ctx.fill();
	}

	rrp(ctx, 24, 24, W - 48, H - 48, 18);
	ctx.strokeStyle = lootTier.borderColor;
	ctx.lineWidth = 1.5;
	ctx.stroke();

	rrp(ctx, W / 2 - 180, 36, 360, 48, 12);
	ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
	ctx.fill();
	rrp(ctx, W / 2 - 180, 36, 360, 48, 12);
	ctx.strokeStyle = lootTier.borderColor;
	ctx.lineWidth = 1;
	ctx.stroke();

	ctx.font = `bold 20px ${FONT_FAMILY}`;
	ctx.fillStyle = '#E6C687';
	ctx.textAlign = 'center';
	ctx.textBaseline = 'middle';
	ctx.fillText('📦 HOURLY AIRDROP CRATE 📦', W / 2, 60);

	const avX = 55, avY = 96, avS = 56;
	ctx.save();
	rrp(ctx, avX, avY, avS, avS, 14);
	ctx.clip();
	try {
		if (ppUrl) {
			const avImg = await loadImage(ppUrl);
			ctx.drawImage(avImg, avX, avY, avS, avS);
		} else {
			throw new Error('No avatar');
		}
	} catch {
		ctx.fillStyle = '#1A1C24';
		ctx.fillRect(avX, avY, avS, avS);
		ctx.font = `bold 26px ${FONT_FAMILY}`;
		ctx.fillStyle = '#D4AF37';
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText((playerName || 'P').charAt(0).toUpperCase(), avX + avS / 2, avY + avS / 2);
	}
	ctx.restore();

	rrp(ctx, avX, avY, avS, avS, 14);
	ctx.strokeStyle = lootTier.borderColor;
	ctx.lineWidth = 1.5;
	ctx.stroke();

	ctx.textAlign = 'left';
	ctx.textBaseline = 'top';
	ctx.font = `bold 17px ${FONT_FAMILY}`;
	ctx.fillStyle = '#FFFFFF';
	const safeName = playerName.length > 16 ? playerName.substring(0, 15) + '...' : playerName;
	ctx.fillText(safeName, 128, 102);

	ctx.font = `13px ${FONT_FAMILY}`;
	ctx.fillStyle = '#9CA3AF';
	ctx.fillText('Status: Airdrop Unlocked (Cooldown 1 Jam)', 128, 126);

	const tierBoxX = 55, tierBoxY = 168;
	const tierBoxW = W - 110, tierBoxH = 44;
	rrp(ctx, tierBoxX, tierBoxY, tierBoxW, tierBoxH, 10);
	ctx.fillStyle = lootTier.bgColor;
	ctx.fill();
	rrp(ctx, tierBoxX, tierBoxY, tierBoxW, tierBoxH, 10);
	ctx.strokeStyle = lootTier.borderColor;
	ctx.lineWidth = 1;
	ctx.stroke();

	ctx.font = `bold 16px ${FONT_FAMILY}`;
	ctx.fillStyle = lootTier.color;
	ctx.textAlign = 'center';
	ctx.textBaseline = 'middle';
	ctx.fillText(`TIER CRATE: ${lootTier.tier} AIRDROP (${lootTier.rateText} DROP RATE)`, W / 2, tierBoxY + tierBoxH / 2);

	const lootGridY = 226;
	const itemBoxW = 220, itemBoxH = 110;
	const gapX = (tierBoxW - (3 * itemBoxW)) / 2;

	for (let i = 0; i < lootResults.length; i++) {
		const res = lootResults[i];
		const ix = tierBoxX + i * (itemBoxW + gapX);

		rrp(ctx, ix, lootGridY, itemBoxW, itemBoxH, 12);
		ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
		ctx.fill();
		rrp(ctx, ix, lootGridY, itemBoxW, itemBoxH, 12);
		ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
		ctx.lineWidth = 1;
		ctx.stroke();

		ctx.font = `bold 32px ${FONT_FAMILY}`;
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText(res.icon, ix + itemBoxW / 2, lootGridY + 36);

		ctx.font = `bold 14px ${FONT_FAMILY}`;
		ctx.fillStyle = '#E2E4EB';
		ctx.fillText(res.name, ix + itemBoxW / 2, lootGridY + 70);

		ctx.font = `bold 13px ${FONT_FAMILY}`;
		ctx.fillStyle = lootTier.color;
		ctx.fillText(`+${res.amount.toLocaleString('id-ID')}`, ix + itemBoxW / 2, lootGridY + 90);
	}

	const rateBoxY = 352;
	rrp(ctx, tierBoxX, rateBoxY, tierBoxW, 90, 10);
	ctx.fillStyle = 'rgba(255, 255, 255, 0.015)';
	ctx.fill();
	rrp(ctx, tierBoxX, rateBoxY, tierBoxW, 90, 10);
	ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
	ctx.lineWidth = 1;
	ctx.stroke();

	ctx.font = `bold 12px ${FONT_FAMILY}`;
	ctx.fillStyle = '#9CA3AF';
	ctx.textAlign = 'left';
	ctx.textBaseline = 'top';
	ctx.fillText('📊 CHANCE RATE DROPS:', tierBoxX + 16, rateBoxY + 12);

	ctx.font = `12px ${FONT_FAMILY}`;
	ctx.fillText('• 🟡 LEGENDARY (5%)  : Money (150K), Diamond, EXP (3K)', tierBoxX + 16, rateBoxY + 34);
	ctx.fillText('• 🟣 EPIC (20%)        : Money (50K), Emas, Potion', tierBoxX + 16, rateBoxY + 52);
	ctx.fillText('• 🔵 RARE (35%)      : Money (20K), Besi, EXP', tierBoxX + 380, rateBoxY + 34);
	ctx.fillText('• ⚪ COMMON (40%)  : Money (8K), Kayu, Batu', tierBoxX + 380, rateBoxY + 52);

	const footY = 460;
	ctx.font = `bold 13px ${FONT_FAMILY}`;
	ctx.fillStyle = '#D4AF37';
	ctx.textAlign = 'left';
	ctx.fillText(`💵 Total Money: $${newMoney.toLocaleString('id-ID')}`, 50, footY + 10);

	ctx.textAlign = 'right';
	ctx.fillText(`⏳ Next Airdrop: Ready per jam (1h)`, W - 50, footY + 10);

	return canvas.toBuffer('image/jpeg');
}

const handler = async (m, {sock, usedPrefix, user, reply}) => {
	const lastAirdrop = user.lastAirdrop ? new Date(user.lastAirdrop).getTime() : 0;
	const now = Date.now();

	if (now - lastAirdrop < COOLDOWN) {
		const remaining = Math.ceil((COOLDOWN - (now - lastAirdrop)) / 1000);
		const mins = Math.floor(remaining / 60);
		const secs = remaining % 60;
		return reply(global.mess.wait);
	}

	const rand = Math.random();
	let accumulated = 0;
	let selectedTier = DROP_RATES[DROP_RATES.length - 1];

	for (const tierObj of DROP_RATES) {
		accumulated += tierObj.chance;
		if (rand <= accumulated) {
			selectedTier = tierObj;
			break;
		}
	}

	const lootResults = [];
	let expGain = 0;
	let moneyGain = 0;
	let limitGain = 0;

	let inv = {};
	try {
		inv = typeof user.inventory === 'string' ? JSON.parse(user.inventory || '{}') : (user.inventory || {});
	} catch {
		inv = {};
	}

	for (const item of selectedTier.items) {
		const amount = Math.floor(Math.random() * (item.max - item.min + 1)) + item.min;
		lootResults.push({
			name: item.name,
			amount,
			icon: item.icon
		});

		if (item.type === 'money') {
			moneyGain += amount;
		} else if (item.type === 'exp') {
			expGain += amount;
		} else if (item.type === 'limit') {
			limitGain += amount;
		} else if (item.key) {
			inv[item.key] = (inv[item.key] || 0) + amount;
		}
	}

	user.inventory = inv;
	if (moneyGain > 0) user.money = (user.money || 0) + moneyGain;
	if (limitGain > 0) {
		user.limit = (user.limit || 0) + limitGain;
		user.limit_val = user.limit;
	}
	if (expGain > 0) addExp(user, expGain);

	await updateUser(m.sender, {
		money: user.money,
		exp: user.exp,
		limit: user.limit,
		inventory: JSON.stringify(inv),
		lastAirdrop: new Date().toISOString()
	});

	let ppUrl = '';
	try {
		ppUrl = await sock.profilePictureUrl(m.sender, 'image');
	} catch {
		ppUrl = '';
	}

	const playerName = m.pushName || m.name || user.name || 'Player';

	let canvasBuffer = null;
	try {
		canvasBuffer = await generateAirdropCanvas({
			playerName,
			lootTier: selectedTier,
			lootResults,
			newMoney: user.money,
			ppUrl
		});
	} catch (e) {
		console.error('[airdrop-canvas-error]', e);
	}

	let lootTextList = lootResults.map(r => `• ${r.icon} *${r.name}:* +${r.amount.toLocaleString('id-ID')}`).join('\n');

	let caption = `📦 *HOURLY AIRDROP UNLOCKED* 📦\n\n` +
		`• 👤 *Player:* ${playerName}\n` +
		`• 🗃️ *Crate Tier:* *${selectedTier.tier}* (${selectedTier.rateText})\n\n` +
		`🎁 *HADIAH AIRDROP:*\n${lootTextList}\n\n` +
		`💵 *Total Money Sekarang:* *$${user.money.toLocaleString('id-ID')}*\n` +
		`🎟️ *Total Limit Sekarang:* *${(user.limit || 0).toLocaleString('id-ID')}*\n` +
		`⏳ *Next Airdrop:* 1 Jam lagi`;

	if (canvasBuffer) {
		await sock.sendButtons(m.chat, {
			image: canvasBuffer,
			caption,
			footer: `Buka airdrop setiap jam untuk claim loot langka!`,
			buttons: [
				{ id: `${usedPrefix}airdrop`, text: '📦 Cek Airdrop' },
				{ id: `${usedPrefix}inv`, text: '🎒 Inventory' }
			]
		}, { quoted: m });
	} else {
		await sock.sendButtons(m.chat, {
			text: caption,
			footer: `Buka airdrop setiap jam untuk claim loot langka!`,
			buttons: [
				{ id: `${usedPrefix}airdrop`, text: '📦 Cek Airdrop' },
				{ id: `${usedPrefix}inv`, text: '🎒 Inventory' }
			]
		}, { quoted: m });
	}
};

handler.command = ['airdrop', 'claimairdrop'];
handler.limit = true;
handler.category = 'rpg';
handler.description = 'Buka airdrop per jam dengan rate hadiah & gambar Canvas';
handler.premium = true;
handler.register = true;

export default handler;
