/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { MONSTERS, addExp, parseInventory } from '../../lib/rpg.js';
import { checkAndSendLevelUp } from '../../lib/levelup.js';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { ensureCanvasFonts, FONT_FAMILY, loadAvatarImage } from '../../canvas/canvas-font.js';

const COOLDOWN = 3 * 60 * 1000;

function drawNeoBox(ctx, x, y, w, h, bg, stroke = '#000000', borderWidth = 4, shadowOffsetX = 6, shadowOffsetY = 6) {
  if (shadowOffsetX > 0 || shadowOffsetY > 0) {
    ctx.fillStyle = '#000000';
    ctx.fillRect(x + shadowOffsetX, y + shadowOffsetY, w, h);
  }
  ctx.fillStyle = bg;
  ctx.fillRect(x, y, w, h);
  if (borderWidth > 0) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = borderWidth;
    ctx.strokeRect(x, y, w, h);
  }
}

async function generateAdventureCanvas({ players, monsterName, playerWin, totalMoney, totalExp, damageDealt }) {
  await ensureCanvasFonts();
  const W = 880, H = 530;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, W, H);

  const p = 18;
  drawNeoBox(ctx, p, p, W - p * 2, H - p * 2, '#ffffff', '#000000', 5, 8, 8);

  drawNeoBox(ctx, p + 25, p + 25, 450, 48, '#ff5ebb', '#000000', 4, 5, 5);
  ctx.font = `bold 22px ${FONT_FAMILY}`;
  ctx.fillStyle = '#ffffff';
  ctx.fillText('⚔️ ADVENTURE BATTLE RAID', p + 45, p + 56);

  drawNeoBox(ctx, W - p - 240, p + 25, 215, 48, playerWin ? '#a0fe00' : '#ff4757', '#000000', 4, 5, 5);
  ctx.font = `bold 16px ${FONT_FAMILY}`;
  ctx.fillStyle = playerWin ? '#000000' : '#ffffff';
  ctx.fillText(playerWin ? '🏆 RAID VICTORY' : '💀 RAID DEFEATED', W - p - 225, p + 54);

  const startX = p + 25, startY = p + 95;
  drawNeoBox(ctx, startX, startY, W - p * 2 - 50, 60, '#ffea00', '#000000', 4, 5, 5);

  ctx.font = `bold 18px ${FONT_FAMILY}`;
  ctx.fillStyle = '#000000';
  ctx.fillText(`👹 PARTY (${players.length} HEROES) VS MONSTER ${monsterName.toUpperCase()}`, startX + 25, startY + 36);

  const gridY = startY + 80;
  const pCardW = 390, pCardH = 110;

  for (let idx = 0; idx < players.length; idx++) {
    const pl = players[idx];
    const col = idx % 2;
    const rowIdx = Math.floor(idx / 2);
    const ix = startX + col * (pCardW + 20);
    const iy = gridY + rowIdx * (pCardH + 18);

    drawNeoBox(ctx, ix, iy, pCardW, pCardH, playerWin ? '#ffffff' : '#fff0f0', '#000000', 4, 5, 5);

    const avSize = 70, avX = ix + 15, avY = iy + 20;
    drawNeoBox(ctx, avX, avY, avSize, avSize, '#ffffff', '#000000', 3, 3, 3);

    ctx.save();
    ctx.beginPath();
    ctx.rect(avX, avY, avSize, avSize);
    ctx.clip();
    const avatarImg = await loadAvatarImage(pl.ppUrl);
    if (avatarImg) {
      ctx.drawImage(avatarImg, avX, avY, avSize, avSize);
    } else {
      ctx.fillStyle = idx % 2 === 0 ? '#00f0ff' : '#ff79c6';
      ctx.fillRect(avX, avY, avSize, avSize);
      ctx.font = `bold 32px ${FONT_FAMILY}`;
      ctx.fillStyle = '#000000';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText((pl.name[0] || 'H').toUpperCase(), avX + avSize / 2, avY + avSize / 2);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
    }
    ctx.restore();

    ctx.font = `bold 16px ${FONT_FAMILY}`;
    ctx.fillStyle = '#000000';
    ctx.fillText(`${idx + 1}. ${pl.name}`, avX + avSize + 15, iy + 35);

    ctx.font = `bold 12px ${FONT_FAMILY}`;
    ctx.fillStyle = '#ff5ebb';
    ctx.fillText(`ROLE: ${pl.role.toUpperCase()}`, avX + avSize + 15, iy + 56);

    ctx.font = `bold 13px ${FONT_FAMILY}`;
    if (playerWin) {
      ctx.fillStyle = '#000000';
      const lootStr = pl.gearDropName ? `🎁 ${pl.gearDropName.substring(0, 16)}..` : `💰 +$${pl.shareMoney.toLocaleString('id-ID')}`;
      ctx.fillText(`${lootStr} | ✨ +${pl.shareExp} EXP`, avX + avSize + 15, iy + 82);
    } else {
      ctx.fillStyle = '#ff4757';
      ctx.fillText(`💔 Defeated (Health -${damageDealt + 20})`, avX + avSize + 15, iy + 82);
    }
  }

  const bY = H - p - 54;
  drawNeoBox(ctx, startX, bY, W - p * 2 - 50, 46, playerWin ? '#a0fe00' : '#ff4757', '#000000', 4, 5, 5);

  ctx.font = `bold 14px ${FONT_FAMILY}`;
  ctx.fillStyle = playerWin ? '#000000' : '#ffffff';
  ctx.fillText(
    playerWin 
      ? `🎉 TOTAL PARTY LOOT: $${totalMoney.toLocaleString('id-ID')}  |  ✨ +${totalExp} EXP  |  🩸 DAMAGE TAKEN: -${damageDealt}`
      : `💀 PARTY KALAH: Monster ${monsterName} terlalu kuat! Perbaiki senjata & zirah kamu.`, 
    startX + 20, 
    bY + 28
  );

  return canvas.toBuffer('image/jpeg');
}

const handler = async (m, {sock, user, usedPrefix, reply}) => {
	const senderJid = m.sender;

	const mentionedJids = m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
	const partyJids = Array.from(new Set([senderJid, ...mentionedJids])).slice(0, 4);

	const lastAdv = user.lastAdventure ? new Date(user.lastAdventure).getTime() : 0;
	const now = Date.now();

	if (now - lastAdv < COOLDOWN) {
		const remaining = Math.ceil((COOLDOWN - (now - lastAdv)) / 1000);
		const mins = Math.floor(remaining / 60);
		const secs = remaining % 60;
		return reply(global.mess.wait);
	}

	if ((user.health || 100) < 20) {
		return m.reply(`❤️ Health kamu terlalu rendah (${user.health || 0}/${user.maxHealth || 100})! Gunakan *${usedPrefix}heal* terlebih dahulu.`);
	}

	if ((user.energy || 100) < 15) {
		return m.reply(`⚡ Energy kamu tidak cukup! Energy tersisa: ${user.energy || 0}/${user.maxEnergy || 100}. Makan dulu dengan *${usedPrefix}eat*.`);
	}

	const partyUsers = [];
	for (const jid of partyJids) {
		if (jid === senderJid) {
			partyUsers.push({ jid, data: user });
		} else {
			const memberData = await getUser(jid);
			if (memberData && (memberData.health || 100) >= 20 && (memberData.energy || 100) >= 15) {
				partyUsers.push({ jid, data: memberData });
			}
		}
	}

	const maxPartyLvl = Math.max(...partyUsers.map(p => p.data.level || 1));
	const eligibleMonsters = MONSTERS.filter(mon => maxPartyLvl >= mon.minLevel);
	const monster = eligibleMonsters[Math.floor(Math.random() * eligibleMonsters.length)] || MONSTERS[0];

	let totalPartyAtk = 0;
	let totalPartyDef = 0;

	partyUsers.forEach(p => {
		const u = p.data;
		const inv = u.inventoryObj || {};
		const weaponBonus = (u.weapon === 'Sword' || inv.sword > 0) ? 25 : 0;
		const armorBonus = (u.armor === 'Armor' || inv.armor > 0) ? 20 : 0;
		totalPartyAtk += 20 + ((u.level || 1) * 5) + weaponBonus;
		totalPartyDef += 5 + armorBonus;
	});

	const monsterDamage = Math.max(5, Math.floor((monster.atk - (totalPartyDef / partyUsers.length))));
	const playerWin = totalPartyAtk >= (monster.hp / 3);

	let resultText = `⚔️ *PETUALANGAN ADVENTURE (MULTIPLAYER RAID)* ⚔️\n\n` +
		`Party (${partyUsers.length} Anggota) bertarung melawan *${monster.name}*!\n\n`;

	const totalMoneyGain = playerWin ? monster.money * partyUsers.length + Math.floor(Math.random() * 100) : 0;
	const totalExpGain = playerWin ? monster.exp * partyUsers.length + Math.floor(Math.random() * 50) : 0;

	const shareMoney = Math.floor(totalMoneyGain / partyUsers.length);
	const shareExp = Math.floor(totalExpGain / partyUsers.length);

	const playersCanvasData = [];

	for (const p of partyUsers) {
		const u = p.data;
		const name = u.nama || u.name || p.jid.split('@')[0];

		let ppUrl = null;
		try { ppUrl = await sock.profilePictureUrl(p.jid, 'image').catch(() => null); } catch (_) {}

		let gearDrop = null;
		const lootDrops = [];

		if (playerWin) {
			const uInv = parseInventory(u.inventory);

			if (Math.random() < 0.8) {
				const foodOptions = [
					{ key: 'food', name: '🍖 Makanan Olahan' },
					{ key: 'meat', name: '🥩 Daging Sapi' },
					{ key: 'drink', name: '🥤 Minuman Segar' },
					{ key: 'energy_drink', name: '⚡🧃 Energy Drink' }
				];
				const f = foodOptions[Math.floor(Math.random() * foodOptions.length)];
				uInv[f.key] = (uInv[f.key] || 0) + 1;
				lootDrops.push(f.name);
			}

			if (Math.random() < 0.25) {
				const petOptions = [
					{ key: 'pet_egg', name: '🥚 Pet Egg' },
					{ key: 'baby_fox', name: '🦊 Rubah Ekor Sembilan' },
					{ key: 'baby_griffin', name: '🦅 Bayi Griffin' }
				];
				const pItem = petOptions[Math.floor(Math.random() * petOptions.length)];
				uInv[pItem.key] = (uInv[pItem.key] || 0) + 1;
				lootDrops.push(pItem.name);
			}

			if (Math.random() < 0.35) {
				uInv.exp_booster = (uInv.exp_booster || 0) + 1;
				lootDrops.push('⚡ EXP Booster');
			}

			const randDrop = Math.random();
			if (randDrop < 0.05) {
				gearDrop = { key: 'excalibur', name: '⚡⚔️ Excalibur' };
			} else if (randDrop < 0.15) {
				gearDrop = { key: 'shadow_blade', name: '🗡️🖤 Shadow Blade' };
			} else if (randDrop < 0.30) {
				gearDrop = { key: 'katana', name: '🗡️ Katana Naga' };
			} else if (randDrop < 0.50) {
				gearDrop = { key: 'sword', name: '⚔️ Pedang Besi' };
			} else if (randDrop < 0.70) {
				gearDrop = { key: 'armor', name: '🪖 Zirah Perang' };
			}

			if (gearDrop) {
				uInv[gearDrop.key] = (uInv[gearDrop.key] || 0) + 1;
				lootDrops.push(gearDrop.name);
			}

			u.money = (u.money || 0) + shareMoney;
			u.health = Math.max(1, (u.health || 100) - monsterDamage);
			u.energy = Math.max(0, (u.energy || 100) - 15);
			u.hunger = Math.max(0, (u.hunger || 100) - 10);
			const lvlResult = addExp(u, shareExp);

			await updateUser(p.jid, {
				money: u.money,
				health: u.health,
				energy: u.energy,
				hunger: u.hunger,
				inventory: uInv,
				exp: u.exp,
				level: u.level,
				lastAdventure: new Date().toISOString()
			});

			if (lvlResult.leveledUp) {
				await checkAndSendLevelUp({ sock, m, user: u, lvlResult }).catch(() => null);
			}
		} else {
			u.health = Math.max(0, (u.health || 100) - (monsterDamage + 20));
			u.energy = Math.max(0, (u.energy || 100) - 15);

			await updateUser(p.jid, {
				health: u.health,
				energy: u.energy,
				lastAdventure: new Date().toISOString()
			});
		}

		playersCanvasData.push({
			name,
			ppUrl,
			shareMoney,
			shareExp,
			gearDropName: lootDrops.length > 0 ? lootDrops[0] : null,
			role: u.role || 'Adventurer'
		});

		resultText += `👤 *${name}* (${u.role || 'Adventurer'}):\n` +
			(playerWin ? `  • 💰 Money: +$${shareMoney.toLocaleString('id-ID')}\n  • ✨ EXP: +${shareExp}\n` : '') +
			(lootDrops.length > 0 ? `  • 🎁 Loot Drop: *${lootDrops.join(', ')}*!\n` : '') +
			`  • ❤️ Health: -${monsterDamage} (Sisa ${u.health}/${u.maxHealth || 100})\n\n`;
	}

	await sock.sendMessage(m.chat, { react: { text: playerWin ? '🏆' : '💀', key: m.key } }).catch(() => null);

	const cardBuffer = await generateAdventureCanvas({
		players: playersCanvasData,
		monsterName: monster.name,
		playerWin,
		totalMoney: totalMoneyGain,
		totalExp: totalExpGain,
		damageDealt: monsterDamage
	}).catch(() => null);

	if (cardBuffer) {
		await sock.sendMessage(m.chat, {
			image: cardBuffer,
			caption: resultText,
			mentions: partyUsers.map(p => p.jid)
		}, { quoted: m });
	} else {
		await sock.sendMessage(m.chat, {
			text: resultText,
			mentions: partyUsers.map(p => p.jid)
		}, { quoted: m });
	}
};

handler.command = ['adventure'];
handler.limit = true;
handler.category = 'rpg';
handler.description = 'Bertualang multiplayer/solo melawan monster dengan kartu visual Canvas';
handler.register = true;

export default handler;
