import axios from 'axios';
import { db } from '../../lib/database.js';

global.caklontong = global.caklontong || {};

const handler = async (m, { sock, usedPrefix, command, args }) => {
    const chatId = m.chat;

    if (global.caklontong[chatId]) {
        const session = global.caklontong[chatId];

        if (args[0] === 'nyerah') {
            clearTimeout(session.timer);
            await sock.sendMessage(m.chat, { 
                text: `🏳️ *KAMU MENYERAH!*\n\nJawaban yang benar adalah: *${session.jawabanAsli}*\n\n💡 *Penjelasan:* ${session.deskripsi}` 
            }, { quoted: m });
            delete global.caklontong[chatId];
            return;
        }

        if (args[0] === 'hint' || args[0] === 'bantuan') {
            let hintText = session.jawabanAsli.replace(/[a-zA-Z0-9]/g, (c, idx) => {
                return idx % 2 === 0 ? c.toUpperCase() + ' ' : '_ ';
            });

            return sock.sendMessage(m.chat, { 
                text: `*💡 HINT CAK LONTONG*\n\n${hintText.trim()}` 
            }, { quoted: m });
        }

        return sock.sendMessage(m.chat, { 
            text: `❌ Masih ada soal Cak Lontong yang belum terjawab di grup ini!\n\nKetik *${usedPrefix}${command} hint* untuk bantuan.\nKetik *${usedPrefix}${command} nyerah* untuk mengakhiri.` 
        }, { quoted: m });
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const { data } = await axios.get('https://api.siputzx.my.id/api/games/caklontong', { timeout: 10000 });
        
        if (!data || !data.status || !data.data) {
            throw new Error('Gagal mengambil data dari API');
        }

        const { soal, jawaban, deskripsi } = data.data;
        const jawabanKecil = jawaban.toLowerCase().trim();

        global.caklontong[chatId] = {
            soal: soal,
            jawaban: jawabanKecil,
            jawabanAsli: jawaban,
            deskripsi: deskripsi || '-',
            timer: setTimeout(() => {
                if (global.caklontong[chatId]) {
                    sock.sendMessage(m.chat, { 
                        text: `⏳ *WAKTU HABIS!*\n\nSayang sekali tidak ada yang berhasil menebak.\nJawaban yang benar adalah: *${jawaban}*\n\n💡 *Penjelasan:* ${deskripsi || '-'}` 
                    });
                    delete global.caklontong[chatId];
                }
            }, 120000)
        };

        let caption = `*👨‍🦲 CAK LONTONG 👨‍🦲*\n\n` +
            `"${soal}"\n\n` +
            `_⏰ Waktu: 2 Menit_\n` +
            `_💡 Ketik jawaban langsung di obrolan!_\n` +
            `_🔍 Ketik *${usedPrefix}${command} hint* jika kesulitan._\n` +
            `_🏳️ Ketik *${usedPrefix}${command} nyerah* untuk menyerah._`;

        await sock.sendMessage(m.chat, { text: caption }, { quoted: m });
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[CAK LONTONG ERROR]', e.message);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await sock.sendMessage(m.chat, { text: `❌ Gagal memuat game: ${e.message}` }, { quoted: m });
    }
};

handler.before = async (m, { sock }) => {
    if (m.isBot || m.fromMe) return;

    const chatId = m.chat;
    const session = global.caklontong[chatId];
    if (!session) return;

    const text = m.text?.toLowerCase().trim();
    if (!text) return;

    const userAns = text.replace(/\s+/g, '');
    const targetAns = session.jawaban.replace(/\s+/g, '');

    if (userAns === targetAns || text === session.jawaban) {
        const userId = m.sender;
        const playerName = m.pushName || 'Player';

        try {
            let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
            if (!user) {
                db.prepare('INSERT INTO users (id, name, level, exp, health, money, limit_val) VALUES (?, ?, 1, 0, 100, 50, 20)').run(userId, playerName);
            }
            db.prepare('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?').run(50, 20, userId);
        } catch (dbErr) {
            console.error('[DB ERROR]', dbErr.message);
        }

        clearTimeout(session.timer);

        let board = `🎉 *BENAR SEKALI!* 🎉\n\n` +
            `👤 *Penebak:* ${playerName}\n` +
            `📝 *Jawaban:* ${session.jawabanAsli}\n` +
            `💡 *Penjelasan:* ${session.deskripsi}\n` +
            `🎁 *Hadiah:* 💵 +$50 Money | ✨ +20 EXP\n`;

        await sock.sendMessage(m.chat, { text: board }, { quoted: m });
        delete global.caklontong[chatId];
    }
};

handler.help = ['caklontong'];
handler.tags = ['game'];
handler.command = ['caklontong', 'lontong'];

export default handler;