/**
 * =============================================================
 *  NAME       : TIC TAC TOE RICH MESSAGE (HTML5 INTERACTIVE)
 *  CATEGORY   : Game
 *  TYPE       : ESM Plugin
 * =============================================================
 */

import { AIRich } from '../../lib/helper-bails.js';

const htmlPayload = `<style>
* {
  -webkit-tap-highlight-color: transparent;
  -webkit-user-select: none;
  user-select: none;
  -webkit-touch-callout: none;
  box-sizing: border-box;
}
body {
  margin: 0;
  padding: 0;
  background: transparent;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
  color: #fff;
  touch-action: manipulation;
}
.ttt-wrapper {
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 10px;
}
.ttt-card {
  background: radial-gradient(circle at 50% 0%, rgba(26, 32, 60, 0.95), rgba(10, 13, 24, 0.98));
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border: 1px solid rgba(0, 240, 255, 0.28);
  border-radius: 22px;
  overflow: hidden;
  box-shadow: 0 16px 45px rgba(0, 0, 0, 0.75), 0 0 30px rgba(0, 240, 255, 0.12);
  position: relative;
}
.ttt-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, #00f0ff, #ff007f, transparent);
}
.ttt-header {
  padding: 14px 18px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(0, 0, 0, 0.25);
}
.ttt-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}
.ttt-logo {
  width: 38px;
  height: 38px;
  border-radius: 11px;
  background: linear-gradient(135deg, rgba(0, 240, 255, 0.2), rgba(255, 0, 127, 0.2));
  border: 1px solid rgba(0, 240, 255, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 0 15px rgba(0, 240, 255, 0.3);
}
.ttt-title-sub {
  font-size: 10px;
  letter-spacing: 2px;
  color: #00f0ff;
  font-weight: 800;
  text-transform: uppercase;
}
.ttt-title-main {
  font-size: 20px;
  font-weight: 900;
  color: #fff;
  letter-spacing: 0.5px;
  text-shadow: 0 0 12px rgba(255, 255, 255, 0.4);
}
.ttt-top-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.btn-icon {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  color: #00f0ff;
  width: 34px;
  height: 34px;
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}
.btn-icon:hover {
  background: rgba(0, 240, 255, 0.15);
  border-color: #00f0ff;
  transform: translateY(-1px);
}
.btn-icon:active {
  transform: scale(0.92);
}
.ttt-body {
  padding: 16px;
}
/* Mode Selector */
.mode-bar {
  display: flex;
  background: rgba(0, 0, 0, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 4px;
  gap: 4px;
  margin-bottom: 12px;
}
.mode-tab {
  flex: 1;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 700;
  text-align: center;
  color: rgba(255, 255, 255, 0.6);
  background: transparent;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
.mode-tab.active {
  background: linear-gradient(135deg, rgba(0, 240, 255, 0.25), rgba(0, 240, 255, 0.08));
  color: #00f0ff;
  border: 1px solid rgba(0, 240, 255, 0.4);
  box-shadow: 0 2px 10px rgba(0, 240, 255, 0.2);
}
/* Difficulty Bar (AI mode only) */
.diff-bar {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  margin-bottom: 14px;
}
.diff-badge {
  padding: 4px 10px;
  font-size: 11px;
  border-radius: 20px;
  cursor: pointer;
  font-weight: 600;
  border: 1px solid rgba(255, 255, 255, 0.12);
  background: rgba(255, 255, 255, 0.04);
  color: rgba(255, 255, 255, 0.6);
  transition: all 0.2s ease;
}
.diff-badge.active {
  border-color: #ffd700;
  color: #ffd700;
  background: rgba(255, 215, 0, 0.15);
  box-shadow: 0 0 10px rgba(255, 215, 0, 0.25);
}
/* Scoreboard */
.scoreboard {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 8px;
  margin-bottom: 14px;
}
.score-box {
  background: rgba(0, 0, 0, 0.35);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 8px 6px;
  text-align: center;
  transition: all 0.2s;
}
.score-box.x-box {
  border-color: rgba(0, 240, 255, 0.25);
}
.score-box.o-box {
  border-color: rgba(255, 0, 127, 0.25);
}
.score-label {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 2px;
}
.score-box.x-box .score-label { color: #00f0ff; }
.score-box.o-box .score-label { color: #ff007f; }
.score-box.tie-box .score-label { color: #ffd700; }
.score-num {
  font-size: 20px;
  font-weight: 900;
  color: #fff;
}
/* Status / Turn Banner */
.turn-banner {
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 12px;
  padding: 10px 14px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  font-weight: 700;
}
.turn-indicator {
  display: flex;
  align-items: center;
  gap: 8px;
}
.turn-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  animation: pulseDot 1.4s infinite;
}
.turn-dot.x-turn {
  background: #00f0ff;
  box-shadow: 0 0 10px #00f0ff;
}
.turn-dot.o-turn {
  background: #ff007f;
  box-shadow: 0 0 10px #ff007f;
}
@keyframes pulseDot {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.3); opacity: 0.6; }
}
/* 3x3 Grid */
.grid-container {
  position: relative;
  width: 100%;
  aspect-ratio: 1;
  max-width: 360px;
  margin: 0 auto 16px;
}
.grid {
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(3, 1fr);
  gap: 10px;
}
.cell {
  background: rgba(18, 24, 45, 0.85);
  border: 1.5px solid rgba(255, 255, 255, 0.1);
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  position: relative;
  overflow: hidden;
  box-shadow: inset 0 0 15px rgba(0, 0, 0, 0.4);
}
.cell:hover:not(.filled) {
  background: rgba(0, 240, 255, 0.08);
  border-color: rgba(0, 240, 255, 0.4);
  transform: scale(1.02);
}
.cell:active:not(.filled) {
  transform: scale(0.96);
}
.cell.win-cell {
  animation: winPulse 1s infinite alternate;
  border-color: #ffd700;
  border-width: 2px;
}
@keyframes winPulse {
  0% { transform: scale(1); box-shadow: 0 0 12px rgba(255, 215, 0, 0.4); }
  100% { transform: scale(1.05); box-shadow: 0 0 24px rgba(255, 215, 0, 0.85); }
}
/* SVG Marker Styling */
.cell svg {
  width: 62%;
  height: 62%;
  filter: drop-shadow(0 0 8px currentColor);
}
.mark-x {
  color: #00f0ff;
  stroke: #00f0ff;
}
.mark-o {
  color: #ff007f;
  stroke: #ff007f;
}
/* Canvas Overlay for Confetti */
#confettiCanvas {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 10;
}
/* Action Buttons */
.footer-actions {
  display: flex;
  gap: 10px;
}
.btn-action {
  flex: 1;
  padding: 12px 14px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  border: none;
}
.btn-primary {
  background: linear-gradient(135deg, #00f0ff, #0088ff);
  color: #030816;
  box-shadow: 0 4px 20px rgba(0, 240, 255, 0.35);
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 25px rgba(0, 240, 255, 0.5);
}
.btn-primary:active {
  transform: scale(0.97);
}
</style>

<div class="ttt-wrapper">
  <div class="ttt-card">
    <div class="ttt-header">
      <div class="ttt-brand">
        <div class="ttt-logo">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18" stroke="#00f0ff"></line>
            <circle cx="12" cy="12" r="5" stroke="#ff007f"></circle>
          </svg>
        </div>
        <div>
          <div class="ttt-title-sub">HIRARA GAME</div>
          <div class="ttt-title-main">TIC TAC TOE</div>
        </div>
      </div>
      <div class="ttt-top-actions">
        <button id="soundToggle" class="btn-icon" title="Suara"></button>
        <button id="resetScores" class="btn-icon" title="Reset Skor">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
            <path d="M3 3v5h5"></path>
          </svg>
        </button>
      </div>
    </div>

    <div class="ttt-body">
      <!-- Mode Tabs -->
      <div class="mode-bar">
        <button id="modeAi" class="mode-tab active">
          <span>🤖</span> vs Bot (AI)
        </button>
        <button id="modePvp" class="mode-tab">
          <span>👥</span> 2 Pemain (PvP)
        </button>
      </div>

      <!-- Difficulty Bar (only in AI mode) -->
      <div id="diffContainer" class="diff-bar">
        <span style="font-size: 11px; color: rgba(255,255,255,0.5); margin-right: 4px;">Tingkat:</span>
        <button class="diff-badge" data-diff="easy">Mudah</button>
        <button class="diff-badge" data-diff="medium">Sedang</button>
        <button class="diff-badge active" data-diff="master">Master (Unbeatable)</button>
      </div>

      <!-- Scoreboard -->
      <div class="scoreboard">
        <div class="score-box x-box">
          <div class="score-label" id="labelX">X (Kamu)</div>
          <div class="score-num" id="scoreX">0</div>
        </div>
        <div class="score-box tie-box">
          <div class="score-label">Seri</div>
          <div class="score-num" id="scoreTie">0</div>
        </div>
        <div class="score-box o-box">
          <div class="score-label" id="labelO">O (Bot)</div>
          <div class="score-num" id="scoreO">0</div>
        </div>
      </div>

      <!-- Turn & Status Banner -->
      <div class="turn-banner">
        <div class="turn-indicator">
          <div id="turnDot" class="turn-dot x-turn"></div>
          <span id="statusText">Giliran Kamu (X)</span>
        </div>
        <span id="streakBadge" style="font-size:11px; color:#ffd700; font-weight:700;">🔥 Streak: 0</span>
      </div>

      <!-- 3x3 Grid with Confetti overlay -->
      <div class="grid-container">
        <canvas id="confettiCanvas"></canvas>
        <div class="grid" id="board">
          <div class="cell" data-index="0"></div>
          <div class="cell" data-index="1"></div>
          <div class="cell" data-index="2"></div>
          <div class="cell" data-index="3"></div>
          <div class="cell" data-index="4"></div>
          <div class="cell" data-index="5"></div>
          <div class="cell" data-index="6"></div>
          <div class="cell" data-index="7"></div>
          <div class="cell" data-index="8"></div>
        </div>
      </div>

      <!-- Actions -->
      <div class="footer-actions">
        <button id="btnNewRound" class="btn-action btn-primary">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="1 4 1 10 7 10"></polyline>
            <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
          </svg>
          Ronde Baru
        </button>
      </div>
    </div>
  </div>
</div>

<script>
(function() {
  const SVG_X = '<svg class="mark-x" viewBox="0 0 50 50"><line x1="12" y1="12" x2="38" y2="38" stroke-width="6" stroke-linecap="round"/><line x1="38" y1="12" x2="12" y2="38" stroke-width="6" stroke-linecap="round"/></svg>';
  const SVG_O = '<svg class="mark-o" viewBox="0 0 50 50"><circle cx="25" cy="25" r="14" stroke-width="6" fill="none"/></svg>';
  const SVG_SOUND_ON = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>';
  const SVG_SOUND_OFF = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>';

  const WIN_LINES = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
  ];

  let board = ['', '', '', '', '', '', '', '', ''];
  let currentPlayer = 'X';
  let isGameActive = true;
  let gameMode = 'ai';
  let difficulty = 'master';
  let isSoundEnabled = true;
  let isAiThinking = false;
  let winStreak = 0;
  let scores = { x: 0, o: 0, tie: 0 };

  const cells = document.querySelectorAll('.cell');
  const statusText = document.getElementById('statusText');
  const turnDot = document.getElementById('turnDot');
  const scoreX = document.getElementById('scoreX');
  const scoreO = document.getElementById('scoreO');
  const scoreTie = document.getElementById('scoreTie');
  const labelX = document.getElementById('labelX');
  const labelO = document.getElementById('labelO');
  const streakBadge = document.getElementById('streakBadge');
  const soundToggle = document.getElementById('soundToggle');
  const resetScoresBtn = document.getElementById('resetScores');
  const modeAiBtn = document.getElementById('modeAi');
  const modePvpBtn = document.getElementById('modePvp');
  const diffContainer = document.getElementById('diffContainer');
  const diffButtons = document.querySelectorAll('.diff-badge');
  const btnNewRound = document.getElementById('btnNewRound');
  const confettiCanvas = document.getElementById('confettiCanvas');
  const cctx = confettiCanvas.getContext('2d');

  try {
    const savedScores = localStorage.getItem('ttt_scores');
    if (savedScores) scores = JSON.parse(savedScores);
    const savedSound = localStorage.getItem('ttt_sound');
    if (savedSound !== null) isSoundEnabled = savedSound === '1';
  } catch(e) {}

  function updateScoreDisplay() {
    scoreX.textContent = scores.x;
    scoreO.textContent = scores.o;
    scoreTie.textContent = scores.tie;
    streakBadge.textContent = '🔥 Streak: ' + winStreak;
    try {
      localStorage.setItem('ttt_scores', JSON.stringify(scores));
    } catch(e) {}
  }

  function updateSoundIcon() {
    soundToggle.innerHTML = isSoundEnabled ? SVG_SOUND_ON : SVG_SOUND_OFF;
    try {
      localStorage.setItem('ttt_sound', isSoundEnabled ? '1' : '0');
    } catch(e) {}
  }

  let audioCtx = null;
  function getAudioContext() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) audioCtx = new AudioContextClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playTone(freqStart, freqEnd, duration, type, gainVal) {
    if (!isSoundEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freqStart, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(Math.max(10, freqEnd), ctx.currentTime + duration);
      gain.gain.setValueAtTime(gainVal || 0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch(e) {}
  }

  function playMoveSound(player) {
    if (player === 'X') {
      playTone(540, 720, 0.08, 'sine', 0.2);
    } else {
      playTone(380, 260, 0.1, 'sine', 0.2);
    }
  }

  function playWinSound() {
    if (!isSoundEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const notes = [523.25, 659.25, 783.99, 1046.50];
      notes.forEach((freq, i) => {
        setTimeout(() => playTone(freq, freq * 1.02, 0.16, 'triangle', 0.25), i * 110);
      });
    } catch(e) {}
  }

  function playDrawSound() {
    playTone(260, 160, 0.25, 'sawtooth', 0.15);
  }

  function playClickSound() {
    playTone(600, 300, 0.04, 'sine', 0.1);
  }

  let particles = [];
  function resizeCanvas() {
    confettiCanvas.width = confettiCanvas.offsetWidth || 360;
    confettiCanvas.height = confettiCanvas.offsetHeight || 360;
  }
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  function spawnConfetti() {
    resizeCanvas();
    particles = [];
    const colors = ['#00f0ff', '#ff007f', '#ffd700', '#00ffaa', '#ffffff'];
    for (let i = 0; i < 70; i++) {
      particles.push({
        x: confettiCanvas.width / 2,
        y: confettiCanvas.height / 2,
        vx: (Math.random() - 0.5) * 12,
        vy: (Math.random() - 0.5) * 12 - 3,
        size: 3 + Math.random() * 5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        life: 0.95 + Math.random() * 0.04,
        rotation: Math.random() * 360,
        vr: (Math.random() - 0.5) * 10
      });
    }
    animateConfetti();
  }

  function animateConfetti() {
    if (particles.length === 0) {
      cctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
      return;
    }
    cctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    for (let i = particles.length - 1; i >= 0; i--) {
      const p = particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.25;
      p.alpha *= p.life;
      p.rotation += p.vr;

      if (p.alpha < 0.05 || p.y > confettiCanvas.height + 20) {
        particles.splice(i, 1);
        continue;
      }

      cctx.save();
      cctx.translate(p.x, p.y);
      cctx.rotate((p.rotation * Math.PI) / 180);
      cctx.globalAlpha = p.alpha;
      cctx.fillStyle = p.color;
      cctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
      cctx.restore();
    }
    if (particles.length > 0) {
      requestAnimationFrame(animateConfetti);
    }
  }

  function checkWinner(b) {
    for (const combo of WIN_LINES) {
      const [a, c, d] = combo;
      if (b[a] && b[a] === b[c] && b[a] === b[d]) {
        return { winner: b[a], line: combo };
      }
    }
    if (b.every(cell => cell !== '')) {
      return { winner: 'tie' };
    }
    return null;
  }

  function handleCellClick(index) {
    if (!isGameActive || board[index] !== '' || isAiThinking) return;

    makeMove(index, currentPlayer);

    const result = checkWinner(board);
    if (result) {
      endGame(result);
      return;
    }

    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateTurnUI();

    if (gameMode === 'ai' && currentPlayer === 'O') {
      triggerAiMove();
    }
  }

  function makeMove(index, player) {
    board[index] = player;
    const cellEl = cells[index];
    cellEl.innerHTML = player === 'X' ? SVG_X : SVG_O;
    cellEl.classList.add('filled');
    playMoveSound(player);
  }

  function updateTurnUI() {
    turnDot.className = 'turn-dot ' + (currentPlayer === 'X' ? 'x-turn' : 'o-turn');
    if (gameMode === 'ai') {
      statusText.textContent = currentPlayer === 'X' ? 'Giliran Kamu (X)' : 'Bot sedang berpikir...';
    } else {
      statusText.textContent = 'Giliran Pemain (' + currentPlayer + ')';
    }
  }

  function triggerAiMove() {
    isAiThinking = true;
    updateTurnUI();

    const delay = 320 + Math.random() * 250;
    setTimeout(() => {
      if (!isGameActive) {
        isAiThinking = false;
        return;
      }

      let bestIndex = getAiMove();
      if (bestIndex !== null && board[bestIndex] === '') {
        makeMove(bestIndex, 'O');

        const result = checkWinner(board);
        if (result) {
          endGame(result);
        } else {
          currentPlayer = 'X';
          updateTurnUI();
        }
      }
      isAiThinking = false;
    }, delay);
  }

  function getAiMove() {
    const available = board.map((val, idx) => val === '' ? idx : null).filter(val => val !== null);
    if (available.length === 0) return null;

    if (difficulty === 'easy') {
      return available[Math.floor(Math.random() * available.length)];
    }

    if (difficulty === 'medium') {
      if (Math.random() < 0.5) {
        return available[Math.floor(Math.random() * available.length)];
      }
    }

    let bestScore = -Infinity;
    let move = available[0];

    for (const idx of available) {
      board[idx] = 'O';
      let score = minimax(board, 0, false, -Infinity, Infinity);
      board[idx] = '';
      if (score > bestScore) {
        bestScore = score;
        move = idx;
      }
    }
    return move;
  }

  function minimax(currentBoard, depth, isMaximizing, alpha, beta) {
    const res = checkWinner(currentBoard);
    if (res) {
      if (res.winner === 'O') return 10 - depth;
      if (res.winner === 'X') return depth - 10;
      if (res.winner === 'tie') return 0;
    }

    const available = [];
    for (let i = 0; i < 9; i++) {
      if (currentBoard[i] === '') available.push(i);
    }

    if (isMaximizing) {
      let maxEval = -Infinity;
      for (const idx of available) {
        currentBoard[idx] = 'O';
        let evalVal = minimax(currentBoard, depth + 1, false, alpha, beta);
        currentBoard[idx] = '';
        maxEval = Math.max(maxEval, evalVal);
        alpha = Math.max(alpha, evalVal);
        if (beta <= alpha) break;
      }
      return maxEval;
    } else {
      let minEval = Infinity;
      for (const idx of available) {
        currentBoard[idx] = 'X';
        let evalVal = minimax(currentBoard, depth + 1, true, alpha, beta);
        currentBoard[idx] = '';
        minEval = Math.min(minEval, evalVal);
        beta = Math.min(beta, evalVal);
        if (beta <= alpha) break;
      }
      return minEval;
    }
  }

  function endGame(result) {
    isGameActive = false;
    if (result.winner === 'tie') {
      statusText.textContent = '🤝 Hasil Seri! (Draw)';
      turnDot.className = 'turn-dot';
      turnDot.style.background = '#ffd700';
      scores.tie++;
      winStreak = 0;
      playDrawSound();
    } else {
      const winner = result.winner;
      if (result.line) {
        result.line.forEach(idx => cells[idx].classList.add('win-cell'));
      }
      if (gameMode === 'ai') {
        if (winner === 'X') {
          statusText.textContent = '🎉 Kamu Menang!';
          scores.x++;
          winStreak++;
          playWinSound();
          spawnConfetti();
        } else {
          statusText.textContent = '🤖 Bot Menang!';
          scores.o++;
          winStreak = 0;
          playDrawSound();
        }
      } else {
        statusText.textContent = '🎉 Pemain ' + winner + ' Menang!';
        if (winner === 'X') scores.x++;
        else scores.o++;
        playWinSound();
        spawnConfetti();
      }
    }
    updateScoreDisplay();
  }

  function resetBoard() {
    board = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    isAiThinking = false;
    currentPlayer = 'X';
    cells.forEach(cell => {
      cell.innerHTML = '';
      cell.className = 'cell';
    });
    cctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    particles = [];
    updateTurnUI();
    playClickSound();
  }

  cells.forEach(cell => {
    cell.addEventListener('click', () => {
      const idx = parseInt(cell.getAttribute('data-index'), 10);
      handleCellClick(idx);
    });
  });

  btnNewRound.addEventListener('click', resetBoard);

  soundToggle.addEventListener('click', () => {
    isSoundEnabled = !isSoundEnabled;
    updateSoundIcon();
    if (isSoundEnabled) playTone(440, 660, 0.06, 'sine', 0.2);
  });

  resetScoresBtn.addEventListener('click', () => {
    scores = { x: 0, o: 0, tie: 0 };
    winStreak = 0;
    updateScoreDisplay();
    resetBoard();
  });

  modeAiBtn.addEventListener('click', () => {
    if (gameMode === 'ai') return;
    gameMode = 'ai';
    modeAiBtn.classList.add('active');
    modePvpBtn.classList.remove('active');
    diffContainer.style.display = 'flex';
    labelX.textContent = 'X (Kamu)';
    labelO.textContent = 'O (Bot)';
    resetBoard();
  });

  modePvpBtn.addEventListener('click', () => {
    if (gameMode === 'pvp') return;
    gameMode = 'pvp';
    modePvpBtn.classList.add('active');
    modeAiBtn.classList.remove('active');
    diffContainer.style.display = 'none';
    labelX.textContent = 'Pemain X';
    labelO.textContent = 'Pemain O';
    resetBoard();
  });

  diffButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      diffButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      difficulty = btn.getAttribute('data-diff');
      resetBoard();
    });
  });

  updateSoundIcon();
  updateScoreDisplay();
  updateTurnUI();
})();
</script>`;

const handler = async (m, { conn, sock }) => {
	const client = conn || sock;

	try {
		const rich = new AIRich(client);
		rich.addHtml(htmlPayload, { text: '🎮 Tic Tac Toe - Interactive Rich Message' });
		await rich.send(m.chat, { quoted: m });
	} catch (e) {
		console.warn('[TICTACTOE AIRICH FALLBACK TO RELAY]', e?.message || e);
		await client.relayMessage(
			m.chat,
			{
				messageContextInfo: {
					deviceListMetadata: {},
					deviceListMetadataVersion: 2,
					botMetadata: {
						messageDisclaimerText: "",
						botResponseId: "tictactoe-" + Date.now(),
						verificationMetadata: {
							proofs: [
								{
									version: 1,
									useCase: 1,
									signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
									certificateChain: [
										"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
										"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
									]
								}
							]
						}
					}
				},
				botForwardedMessage: {
					message: {
						richResponseMessage: {
							messageType: 1,
							submessages: [
								{
									messageType: 2,
									messageText: "🎮 Tic Tac Toe - Interactive Rich Message"
								}
							],
							unifiedResponse: {
								data: Buffer.from(JSON.stringify({
									"response_id": "tictactoe-" + Date.now(),
									"sections": [
										{
											"view_model": {
												"primitive": {
													"__typename": "GenAIaeacdsnwHtmlPrimitive",
													"payload": htmlPayload,
													"trusted_sources": [
														"hirara.dev", "api.kyzzz.xyz", "kyzzz.xyz", "kyu4me.biz.id"
													]
												},
												"__typename": "GenAISingleLayoutViewModel"
											}
										}
									]
								})).toString('base64')
							},
							contextInfo: {
								forwardingScore: 1,
								isForwarded: true,
								forwardedAiBotMessageInfo: {
									botJid: "867051314767696@bot"
								},
								forwardOrigin: 4
							}
						}
					}
				}
			},
			{}
		);
	}
};

handler.help = ['tictactoc', 'tictactoe', 'ttt'];
handler.tags = ['game'];
handler.category = 'game';
handler.description = 'Main game Tic Tac Toe interaktif rich message HTML (vs Bot Unbeatable & 2 Pemain PvP)';
handler.command = ['tictactoc', 'tictactoe', 'ttt', 'ttchtml', 'tictactoehtml', 'ttthtml', 'gametictactoe'];

export default handler;
