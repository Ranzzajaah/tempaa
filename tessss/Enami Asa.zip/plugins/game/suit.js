/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

global.suit = global.suit || {};

const handler = async (m, { sock, args, command, reply, usedPrefix }) => {
	global.suit = global.suit || {};

	if (!m.isGroup) {
		return reply(global.mess.group);
	}

	const timeout = 60000;

	if (Object.values(global.suit).find(roof => roof.id.startsWith("suit") && [roof.p, roof.p2].includes(m.sender))) {
		return reply("⚠️ Selesaikan game suit kamu sebelumnya terlebih dahulu!");
	}

	const mentioned = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : null);

	if (!mentioned) {
		return reply(`🎮 *SUIT PvP (Gunting Batu Kertas)*\n\nSiapa yang ingin kamu tantang?\nTag atau balas pesan orangnya!\n\n*Contoh:* ${usedPrefix + command} @user`);
	}

	if (mentioned === m.sender) {
		return reply("❌ Tidak bisa bermain suit dengan diri sendiri!");
	}

	if (Object.values(global.suit).find(roof => roof.id.startsWith("suit") && [roof.p, roof.p2].includes(mentioned))) {
		return reply("⚠️ Orang yang kamu tantang sedang bermain suit dengan orang lain :(");
	}

	const id = "suit_" + Date.now();
	const senderTag = m.sender.split("@")[0];
	const targetTag = mentioned.split("@")[0];

	const caption = `╭━━━〔 ⚔️ *SUIT PvP CHALLENGE* 〕━━━╮\n` +
		`┃ 👤 *Penantang :* @${senderTag}\n` +
		`┃ 🎯 *Lawan     :* @${targetTag}\n` +
		`╰━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
		`Hai @${targetTag}, kamu ditantang bermain Suit!\n` +
		`Ketik *accept* untuk menerima atau *reject* untuk menolak.\n` +
		`_Waktu konfirmasi 60 detik._`;

	const sentMsg = await sock.sendMessage(m.chat, {
		text: caption,
		mentions: [m.sender, mentioned]
	}, { quoted: m });

	global.suit[id] = {
		chat: sentMsg,
		id: id,
		p: m.sender,
		p2: mentioned,
		status: "wait",
		waktu: setTimeout(() => {
			if (global.suit[id]) {
				sock.sendMessage(m.chat, { text: "⏳ *Waktu konfirmasi Suit telah habis! Permainan dibatalkan.*" });
				delete global.suit[id];
			}
		}, timeout),
		timeout
	};
};

handler.before = async (m, { sock }) => {
	global.suit = global.suit || {};
	const roof = Object.values(global.suit).find(r => r.id && r.status && [r.p, r.p2].includes(m.sender));
	if (!roof) return;

	const botNumber = (sock.user?.id || "").split(":")[0] + "@s.whatsapp.net";
	const textMsg = (m.text || "").trim();

	if (m.sender === roof.p2 && /^(acc(ept)?|accept|yes|ya|y|terima|reject|tolak|no|n|gamau|later)/i.test(textMsg) && m.isGroup && roof.status === "wait") {
		if (/^(reject|tolak|no|n|gamau|later)/i.test(textMsg)) {
			await sock.sendMessage(m.chat, {
				text: `❌ @${roof.p2.split("@")[0]} menolak tantangan suit, permainan dibatalkan!`,
				mentions: [roof.p2]
			}, { quoted: m });
			clearTimeout(roof.waktu);
			delete global.suit[roof.id];
			return true;
		}

		roof.status = "play";
		roof.asal = m.chat;
		clearTimeout(roof.waktu);

		const botCleanNum = botNumber.split("@")[0];
		const textAjak = `🎮 *Tantangan Suit Diterima!*\n\n` +
			`@${roof.p.split("@")[0]} & @${roof.p2.split("@")[0]}\n` +
			`Silakan pilih pilihan kalian di Private Chat (PC Bot) sekarang!\n\n` +
			`👉 https://wa.me/${botCleanNum}\n\n` +
			`_Pilihan: Batu, Gunting, Kertas_`;

		await sock.sendMessage(m.chat, {
			text: textAjak,
			mentions: [roof.p, roof.p2]
		}, { quoted: m });

		if (!roof.pilih) {
			sock.sendMessage(roof.p, { text: "⚔️ *SUIT PvP*\n\nSilakan ketik pilihanmu:\n• *Batu*\n• *Gunting*\n• *Kertas*" }).catch(() => {});
		}
		if (!roof.pilih2) {
			sock.sendMessage(roof.p2, { text: "⚔️ *SUIT PvP*\n\nSilakan ketik pilihanmu:\n• *Batu*\n• *Gunting*\n• *Kertas*" }).catch(() => {});
		}

		roof.waktu_milih = setTimeout(async () => {
			if (!roof.pilih && !roof.pilih2) {
				await sock.sendMessage(roof.asal, { text: "⏳ Kedua pemain tidak memilih pilihan, permainan Suit dibatalkan." });
			} else if (!roof.pilih || !roof.pilih2) {
				const winner = !roof.pilih ? roof.p2 : roof.p;
				const loser = roof.pilih ? roof.p2 : roof.p;
				await sock.sendMessage(roof.asal, {
					text: `⏳ @${loser.split("@")[0]} tidak memilih suit tepat waktu, Game Over!\nPemenang: @${winner.split("@")[0]} 🎉`,
					mentions: [winner, loser]
				});
			}
			delete global.suit[roof.id];
		}, roof.timeout);
		return true;
	}

	const jwb = m.sender === roof.p;
	const jwb2 = m.sender === roof.p2;
	const reg = /^(gunting|batu|kertas)/i;

	if (jwb && reg.test(textMsg) && !roof.pilih && !m.isGroup && roof.status === "play") {
		roof.pilih = reg.exec(textMsg.toLowerCase())[0];
		roof.text = textMsg;
		m.reply(`✅ Kamu telah memilih *${textMsg}*!${!roof.pilih2 ? "\n\n⌛ Menunggu lawan untuk memilih..." : ""}`);
		if (!roof.pilih2) {
			sock.sendMessage(roof.p2, { text: "⚔️ *Lawan telah memilih!* Sekarang giliranmu untuk memilih (Batu/Gunting/Kertas)." }).catch(() => {});
		}
	}

	if (jwb2 && reg.test(textMsg) && !roof.pilih2 && !m.isGroup && roof.status === "play") {
		roof.pilih2 = reg.exec(textMsg.toLowerCase())[0];
		roof.text2 = textMsg;
		m.reply(`✅ Kamu telah memilih *${textMsg}*!${!roof.pilih ? "\n\n⌛ Menunggu lawan untuk memilih..." : ""}`);
		if (!roof.pilih) {
			sock.sendMessage(roof.p, { text: "⚔️ *Lawan telah memilih!* Sekarang giliranmu untuk memilih (Batu/Gunting/Kertas)." }).catch(() => {});
		}
	}

	if (roof.pilih && roof.pilih2) {
		clearTimeout(roof.waktu_milih);
		const stage = roof.pilih.toLowerCase();
		const stage2 = roof.pilih2.toLowerCase();
		let win = "";
		let tie = false;

		if (stage === "batu" && stage2 === "gunting") win = roof.p;
		else if (stage === "batu" && stage2 === "kertas") win = roof.p2;
		else if (stage === "gunting" && stage2 === "kertas") win = roof.p;
		else if (stage === "gunting" && stage2 === "batu") win = roof.p2;
		else if (stage === "kertas" && stage2 === "batu") win = roof.p;
		else if (stage === "kertas" && stage2 === "gunting") win = roof.p2;
		else if (stage === stage2) tie = true;

		let rewardText = "";
		if (!tie && win) {
			const rewardMoney = Math.floor(Math.random() * 101) + 50; 
			const rewardExp = Math.floor(Math.random() * 51) + 50; 
			const rewardLimit = Math.floor(Math.random() * 5) + 2; 

			try {
				if (typeof global.getUser === "function" && typeof global.updateUser === "function") {
					const winDb = global.getUser(win);
					if (winDb) {
						global.updateUser(win, {
							money: (winDb.money || 0) + rewardMoney,
							exp: (winDb.exp || 0) + rewardExp,
							limit_val: (winDb.limit_val || 0) + rewardLimit
						});
					}
				}
			} catch (e) {}

			rewardText = `\n\n🎁 *Hadiah Pemenang:*\n• 💰 *Money:* +$${rewardMoney.toLocaleString("id-ID")}\n• 🎟️ *Limit:* +${rewardLimit} Limit\n• ✨ *EXP:* +${rewardExp} EXP`;
		}

		const hasilCaption = `╭━━━〔 🏆 *HASIL SUIT PvP* 〕━━━╮\n` +
			(tie ? "┃ 🤝 *STATUS   :* SERI (DRAW)\n" : "┃ 🎉 *STATUS   :* SELESAI\n") +
			`┃ 👤 @${roof.p.split("@")[0]} (${roof.text}) : ${tie ? "🤝 DRAW" : (roof.p === win ? "🎉 MENANG" : "💀 KALAH")}\n` +
			`┃ 👤 @${roof.p2.split("@")[0]} (${roof.text2}) : ${tie ? "🤝 DRAW" : (roof.p2 === win ? "🎉 MENANG" : "💀 KALAH")}\n` +
			"╰━━━━━━━━━━━━━━━━━━━━━━╯" +
			rewardText;

		await sock.sendMessage(roof.asal, {
			text: hasilCaption,
			mentions: [roof.p, roof.p2]
		});

		delete global.suit[roof.id];
		return true;
	}
};

handler.help = ["suit @user", "rps @user"];
handler.tags = ["game"];
handler.command = ["suit", "suitpvp", "rps", "rockpaperscissors"];
handler.group = true;
handler.register = true;

export default handler;