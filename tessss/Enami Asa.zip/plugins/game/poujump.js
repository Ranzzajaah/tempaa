/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

const htmlPayload = `<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; box-sizing: border-box; }
body { margin: 0; background: #09090b; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #fff; touch-action: none; overflow: hidden; }
.game-container { width: 100%; max-width: 420px; margin: auto; padding: 10px; }
.card-wrapper { background: rgba(255,255,255,0.06); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.18); border-radius: 22px; overflow: hidden; box-shadow: 0 12px 40px rgba(0,0,0,0.5); position: relative; }
.header-bar { padding: 14px 18px; border-bottom: 1px solid rgba(255,255,255,0.12); display: flex; justify-content: space-between; align-items: center; background: rgba(0,0,0,0.3); }
.brand-sub { font-size: 9.5px; letter-spacing: 1.5px; color: rgba(255,255,255,0.55); font-weight: 800; text-transform: uppercase; display: flex; align-items: center; gap: 4px; }
.brand-title { font-size: 20px; font-weight: 900; color: #fff; letter-spacing: -0.5px; display: flex; align-items: center; gap: 6px; }
.score-box { text-align: right; }
.score-val { font-size: 20px; font-weight: 900; color: #ffd166; text-shadow: 0 0 12px rgba(255,209,102,0.6); }
.best-val { font-size: 10.5px; color: rgba(255,255,255,0.55); font-weight: 700; margin-top: 1px; }

.canvas-wrapper { position: relative; width: 100%; padding: 10px; }
canvas#game { width: 100%; height: auto; border-radius: 16px; display: block; background: #87ceeb; border: 1px solid rgba(255,255,255,0.18); touch-action: none; box-shadow: inset 0 0 20px rgba(0,0,0,0.2); }

.controls-bar { display: flex; gap: 12px; padding: 10px 12px 14px; }
.ctrl-btn { flex: 1; background: linear-gradient(180deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0.08) 100%); border: 1px solid rgba(255,255,255,0.25); color: #fff; padding: 14px 0; border-radius: 16px; font-size: 16px; font-weight: 900; text-align: center; cursor: pointer; user-select: none; transition: transform 0.08s, background 0.08s; box-shadow: 0 6px 16px rgba(0,0,0,0.25); display: flex; align-items: center; justify-content: center; gap: 6px; }
.ctrl-btn:active { transform: scale(0.95); background: rgba(255,255,255,0.3); }

.overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.88); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); display: flex; flex-direction: column; justify-content: center; align-items: center; gap: 14px; z-index: 50; padding: 20px; text-align: center; border-radius: 16px; pointer-events: auto; }
.overlay.hidden { display: none !important; pointer-events: none !important; visibility: hidden !important; }
.title-main { font-size: 28px; font-weight: 900; color: #ffd166; letter-spacing: -0.5px; text-shadow: 0 4px 16px rgba(255,209,102,0.5); margin: 0; display: flex; align-items: center; gap: 8px; }
.subtitle-main { font-size: 13px; color: rgba(255,255,255,0.75); font-weight: 600; margin-top: -6px; }
.btn-action { background: linear-gradient(180deg, #ffe066 0%, #ffd166 100%); color: #0f172a; border: none; font-size: 15px; font-weight: 900; padding: 13px 36px; border-radius: 26px; cursor: pointer; box-shadow: 0 6px 22px rgba(255,209,102,0.45); transition: transform 0.1s; text-transform: uppercase; letter-spacing: 0.5px; display: flex; align-items: center; gap: 8px; touch-action: manipulation; -webkit-tap-highlight-color: transparent; }
.btn-action:active { transform: scale(0.94); }
.sound-toggle { position: absolute; top: 16px; right: 16px; background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.25); color: #fff; border-radius: 50%; width: 34px; height: 34px; font-size: 15px; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 60; }
</style>

<body>
<div class="game-container">
  <div class="card-wrapper">
    <div class="header-bar">
      <div>
        <div class="brand-sub">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2v20M2 12h20"/></svg>
          DAY / NIGHT SKY ENGINE
        </div>
        <div class="brand-title">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="#ffd166"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
          POU JUMP SKY
        </div>
      </div>
      <div class="score-box">
        <div id="score" class="score-val">0</div>
        <div id="best" class="best-val">BEST 0</div>
      </div>
    </div>

    <div class="canvas-wrapper">
      <canvas id="game" width="360" height="520"></canvas>

      <!-- Start Overlay -->
      <div id="startOverlay" class="overlay">
        <h1 class="title-main">
          <svg width="30" height="30" viewBox="0 0 24 24" fill="#ffd166"><path d="M12 3L2 12h3v8h6v-6h2v6h6v-8h3L12 3z"/></svg>
          POU JUMP SKY
        </h1>
        <div class="subtitle-main">Lompat setinggi mungkin tembus Langit!</div>
        <div id="startBest" style="font-size: 13.5px; color: #ffd166; font-weight: 800;">BEST: 0</div>
        <button id="btnStart" class="btn-action" type="button">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
          PLAY NOW
        </button>
      </div>

      <!-- Game Over Overlay -->
      <div id="gameOverOverlay" class="overlay hidden">
        <h1 class="title-main" style="color: #ef4444;">
          <svg width="30" height="30" viewBox="0 0 24 24" fill="#ef4444"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
          GAME OVER
        </h1>
        <div id="finalScore" style="font-size: 22px; font-weight: 900; color: #fff;">HEIGHT: 0</div>
        <div id="finalBest" style="font-size: 13.5px; color: #ffd166; font-weight: 800;">BEST: 0</div>
        <button id="btnRetry" class="btn-action" type="button">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
          RETRY
        </button>
      </div>

      <button id="btnSound" class="sound-toggle" type="button" title="Mute/Unmute">🔊</button>
    </div>

    <!-- Touch Controls -->
    <div class="controls-bar">
      <div id="btnLeft" class="ctrl-btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
        KIRI
      </div>
      <div id="btnRight" class="ctrl-btn">
        KANAN
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
      </div>
    </div>
  </div>
</div>

<script>
(function() {
  const c = document.getElementById('game');
  const ctx = c.getContext('2d');
  const scoreEl = document.getElementById('score');
  const bestEl = document.getElementById('best');
  const startBestEl = document.getElementById('startBest');
  const finalScoreEl = document.getElementById('finalScore');
  const finalBestEl = document.getElementById('finalBest');
  const startOverlay = document.getElementById('startOverlay');
  const gameOverOverlay = document.getElementById('gameOverOverlay');
  const btnStart = document.getElementById('btnStart');
  const btnRetry = document.getElementById('btnRetry');
  const btnLeft = document.getElementById('btnLeft');
  const btnRight = document.getElementById('btnRight');
  const btnSound = document.getElementById('btnSound');

  const WIDTH = c.width;
  const HEIGHT = c.height;

  // Web Audio API
  let audioCtx = null;
  let isMuted = false;

  function initAudio() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) audioCtx = new AudioContextClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playTone(freq, type, duration, startVol = 0.15) {
    if (isMuted) return;
    initAudio();
    if (!audioCtx) return;
    try {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(startVol, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch(e) {}
  }

  function playSound(type) {
    if (isMuted) return;
    if (type === 'jump') playTone(440, 'sine', 0.15, 0.2);
    else if (type === 'bounce') playTone(720, 'triangle', 0.25, 0.25);
    else if (type === 'land') playTone(240, 'sine', 0.08, 0.1);
    else if (type === 'over') playTone(130, 'sawtooth', 0.4, 0.25);
  }

  btnSound.addEventListener('click', (e) => {
    e.stopPropagation();
    isMuted = !isMuted;
    btnSound.textContent = isMuted ? '🔇' : '🔊';
  });

  // Storage Best Score
  function loadBest() {
    let vals = [];
    try { let v = localStorage.getItem('poujump_best'); if (v) vals.push(parseInt(v, 10)); } catch(e) {}
    try { let v = sessionStorage.getItem('poujump_best'); if (v) vals.push(parseInt(v, 10)); } catch(e) {}
    try { let m = document.cookie.match(/(?:^|;\\s*)poujump_best=(\\d+)/); if (m) vals.push(parseInt(m[1], 10)); } catch(e) {}
    return vals.length ? Math.max(...vals.filter(v => !isNaN(v))) : 0;
  }

  function saveBest(v) {
    let val = String(Math.floor(v));
    try { localStorage.setItem('poujump_best', val); } catch(e) {}
    try { sessionStorage.setItem('poujump_best', val); } catch(e) {}
    try { document.cookie = 'poujump_best=' + val + ';max-age=31536000;path=/'; } catch(e) {}
  }

  let bestScore = loadBest();
  bestEl.textContent = 'BEST ' + bestScore;
  startBestEl.textContent = 'BEST: ' + bestScore;

  // Game Variables
  let pou, platforms, particles, clouds, birds, floatTexts, stars;
  let cameraY = 0;
  let targetCameraY = 0;
  let score = 0;
  let maxScore = 0;
  let isPlaying = false;
  let isGameOver = false;
  let isLeftPressed = false;
  let isRightPressed = false;
  let animId = null;
  let lastTime = 0;
  let timeTotal = 0;

  class PouPlayer {
    constructor() {
      this.w = 38;
      this.h = 38;
      this.x = WIDTH / 2 - this.w / 2;
      this.y = HEIGHT - 120;
      this.vx = 0;
      this.vy = -11.5;
      this.squashX = 1;
      this.squashY = 1;
      this.facing = 1;
      this.blinkTimer = 0;
      this.isBlinking = false;
      this.state = 'jump';
    }

    update(dt) {
      const accel = 0.58 * dt;
      const friction = 0.87;

      if (isLeftPressed) {
        this.vx -= accel;
        this.facing = -1;
      } else if (isRightPressed) {
        this.vx += accel;
        this.facing = 1;
      } else {
        this.vx *= Math.pow(friction, dt);
      }

      this.vx = Math.max(-6.5, Math.min(6.5, this.vx));
      this.x += this.vx * dt;

      // Screen wrap
      if (this.x < -this.w / 2) this.x = WIDTH - this.w / 2;
      if (this.x > WIDTH - this.w / 2) this.x = -this.w / 2;

      // Gravity
      this.vy += 0.42 * dt;
      this.y += this.vy * dt;

      if (this.vy < 0) this.state = 'jump';
      else if (this.vy > 0) this.state = 'fall';

      // Squash/Stretch Decay
      this.squashX += (1 - this.squashX) * 0.16 * dt;
      this.squashY += (1 - this.squashY) * 0.16 * dt;

      // Blinking
      this.blinkTimer += dt;
      if (this.blinkTimer > 150) {
        this.isBlinking = true;
        if (this.blinkTimer > 162) {
          this.isBlinking = false;
          this.blinkTimer = 0;
        }
      }
    }

    jump(force = -11.5, type = 'normal') {
      this.vy = force;
      this.squashX = 0.72;
      this.squashY = 1.38;
      this.state = 'jump';
      if (type === 'bounce') {
        playSound('bounce');
        addParticles(this.x + this.w / 2, this.y + this.h, 14, '#ffd166');
        addFloatText(this.x + this.w / 2, this.y, 'SUPER JUMP! 🚀', '#ffd166');
      } else {
        playSound('jump');
        addParticles(this.x + this.w / 2, this.y + this.h, 7, '#ffffff');
      }
    }

    draw(screenY) {
      ctx.save();
      const cx = this.x + this.w / 2;
      const cy = screenY + this.h / 2;

      ctx.translate(cx, cy);
      ctx.scale(this.squashX, this.squashY);

      // SVG Vector Pou Path Gradient Fill
      const pouGrad = ctx.createLinearGradient(-18, -18, 18, 18);
      pouGrad.addColorStop(0, '#a56729');
      pouGrad.addColorStop(0.6, '#8B5A2B');
      pouGrad.addColorStop(1, '#693c14');
      ctx.fillStyle = pouGrad;

      ctx.beginPath();
      ctx.moveTo(-17, 13);
      ctx.bezierCurveTo(-19, -2, -13, -17, 0, -19);
      ctx.bezierCurveTo(13, -17, 19, -2, 17, 13);
      ctx.bezierCurveTo(14, 19, -14, 19, -17, 13);
      ctx.fill();

      ctx.strokeStyle = 'rgba(40, 20, 5, 0.4)';
      ctx.lineWidth = 1.8;
      ctx.stroke();

      // Shiny Glossy Highlight
      ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
      ctx.beginPath();
      ctx.ellipse(-5, -8, 6, 3, Math.PI / 4, 0, Math.PI * 2);
      ctx.fill();

      // Rosy Cheeks
      ctx.fillStyle = 'rgba(244, 114, 182, 0.45)';
      ctx.beginPath();
      ctx.arc(-11, 4, 3.8, 0, Math.PI * 2);
      ctx.arc(11, 4, 3.8, 0, Math.PI * 2);
      ctx.fill();

      // Eyes
      const eyeDx = this.facing * 2.2;
      const eyeDy = this.state === 'fall' ? 2 : -1;

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-6.5, -3.5, 5.2, 0, Math.PI * 2);
      ctx.arc(6.5, -3.5, 5.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.15)';
      ctx.lineWidth = 1;
      ctx.stroke();

      if (!this.isBlinking) {
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(-6.5 + eyeDx, -3.5 + eyeDy, 2.7, 0, Math.PI * 2);
        ctx.arc(6.5 + eyeDx, -3.5 + eyeDy, 2.7, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-7.5 + eyeDx, -4.5 + eyeDy, 1.1, 0, Math.PI * 2);
        ctx.arc(5.5 + eyeDx, -4.5 + eyeDy, 1.1, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.moveTo(-10, -3.5); ctx.lineTo(-3, -3.5);
        ctx.moveTo(3, -3.5); ctx.lineTo(10, -3.5);
        ctx.stroke();
      }

      // Mouth
      ctx.strokeStyle = '#0f172a';
      ctx.fillStyle = '#ef4444';
      ctx.lineWidth = 1.6;

      if (this.state === 'jump') {
        ctx.beginPath();
        ctx.arc(0, 5, 3.2, 0, Math.PI);
        ctx.fill();
        ctx.stroke();
      } else if (this.state === 'fall') {
        ctx.beginPath();
        ctx.arc(0, 6, 2.2, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(0, 3.5, 4.2, 0.1 * Math.PI, 0.9 * Math.PI);
        ctx.stroke();
      }

      ctx.restore();
    }
  }

  class Bird {
    constructor(x, y) {
      this.x = x;
      this.y = y;
      this.speed = 1.2 + Math.random() * 0.8;
      this.wingPhase = Math.random() * 10;
    }

    update(dt) {
      this.x += this.speed * dt;
      if (this.x > WIDTH + 40) {
        this.x = -40;
        this.y = cameraY + Math.random() * (HEIGHT * 0.7);
      }
    }

    draw(screenY) {
      ctx.save();
      const wingY = Math.sin(timeTotal * 0.2 + this.wingPhase) * 6;

      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(this.x - 10, screenY + wingY);
      ctx.quadraticCurveTo(this.x - 5, screenY - 8, this.x, screenY);
      ctx.quadraticCurveTo(this.x + 5, screenY - 8, this.x + 10, screenY + wingY);
      ctx.stroke();

      ctx.restore();
    }
  }

  class Platform {
    constructor(x, y, type = 'normal') {
      this.x = x;
      this.y = y;
      this.type = type;
      this.w = type === 'narrow' ? 44 : 64;
      this.h = 13;
      this.vx = type === 'moving' ? (Math.random() > 0.5 ? 1.6 : -1.6) : 0;
      this.broken = false;
    }

    update(dt) {
      if (this.type === 'moving') {
        this.x += this.vx * dt;
        if (this.x < 10 || this.x + this.w > WIDTH - 10) {
          this.vx *= -1;
        }
      }
    }

    draw(screenY) {
      if (this.broken) return;

      ctx.save();

      if (this.type === 'normal') {
        const grad = ctx.createLinearGradient(this.x, screenY, this.x, screenY + this.h);
        grad.addColorStop(0, '#4ade80');
        grad.addColorStop(1, '#16a34a');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(this.x, screenY, this.w, this.h, 7);
        ctx.fill();

        ctx.fillStyle = '#86efac';
        ctx.beginPath();
        ctx.roundRect(this.x + 2, screenY, this.w - 4, 3, 2);
        ctx.fill();
      } else if (this.type === 'moving') {
        const grad = ctx.createLinearGradient(this.x, screenY, this.x, screenY + this.h);
        grad.addColorStop(0, '#60a5fa');
        grad.addColorStop(1, '#2563eb');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(this.x, screenY, this.w, this.h, 7);
        ctx.fill();

        ctx.fillStyle = '#93c5fd';
        ctx.fillRect(this.x + 4, screenY + 3, this.w - 8, 2);
      } else if (this.type === 'narrow') {
        const grad = ctx.createLinearGradient(this.x, screenY, this.x, screenY + this.h);
        grad.addColorStop(0, '#c084fc');
        grad.addColorStop(1, '#7e22ce');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(this.x, screenY, this.w, this.h, 7);
        ctx.fill();
      } else if (this.type === 'disappearing') {
        ctx.fillStyle = 'rgba(241, 245, 249, 0.9)';
        ctx.beginPath();
        ctx.roundRect(this.x, screenY, this.w, this.h, 7);
        ctx.fill();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
        ctx.beginPath();
        ctx.arc(this.x + 12, screenY + 2, 6, 0, Math.PI * 2);
        ctx.arc(this.x + this.w - 12, screenY + 2, 6, 0, Math.PI * 2);
        ctx.fill();
      } else if (this.type === 'bounce') {
        const grad = ctx.createLinearGradient(this.x, screenY, this.x, screenY + this.h);
        grad.addColorStop(0, '#fde047');
        grad.addColorStop(1, '#ca8a04');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(this.x, screenY, this.w, this.h, 7);
        ctx.fill();

        ctx.fillStyle = '#ef4444';
        ctx.fillRect(this.x + this.w / 2 - 7, screenY - 5, 14, 5);
        ctx.fillStyle = '#b91c1c';
        ctx.fillRect(this.x + this.w / 2 - 5, screenY - 7, 10, 2);
      }

      ctx.restore();
    }
  }

  function addParticles(x, y, count, color) {
    for (let i = 0; i < count; i++) {
      particles.push({
        x: x,
        y: y,
        vx: (Math.random() - 0.5) * 4.5,
        vy: (Math.random() - 0.5) * 3.5,
        life: 1.0,
        color: color,
        size: 2.5 + Math.random() * 3
      });
    }
  }

  function addFloatText(x, y, text, color) {
    floatTexts.push({
      x: x,
      y: y,
      text: text,
      color: color,
      life: 1.0,
      vy: -1.2
    });
  }

  function initGame() {
    pou = new PouPlayer();
    platforms = [];
    particles = [];
    clouds = [];
    birds = [];
    floatTexts = [];
    stars = [];
    cameraY = 0;
    targetCameraY = 0;
    score = 0;
    maxScore = 0;
    isGameOver = false;

    platforms.push(new Platform(WIDTH / 2 - 32, HEIGHT - 70, 'normal'));

    let currentY = HEIGHT - 140;
    while (currentY > -HEIGHT * 2.5) {
      spawnPlatform(currentY);
      currentY -= 44 + Math.random() * 32;
    }

    // Moving Parallax Clouds
    for (let i = 0; i < 7; i++) {
      clouds.push({
        x: Math.random() * WIDTH,
        y: Math.random() * HEIGHT * 2.5 - HEIGHT,
        w: 50 + Math.random() * 55,
        speed: 0.35 + Math.random() * 0.45
      });
    }

    // Flying Birds
    for (let b = 0; b < 3; b++) {
      birds.push(new Bird(Math.random() * WIDTH, Math.random() * (HEIGHT * 0.8)));
    }

    // Stars
    for (let j = 0; j < 30; j++) {
      stars.push({
        x: Math.random() * WIDTH,
        y: -Math.random() * HEIGHT * 5,
        r: 0.8 + Math.random() * 1.5,
        alpha: 0.3 + Math.random() * 0.7
      });
    }

    scoreEl.textContent = '0';
  }

  function spawnPlatform(y) {
    const minX = 15;
    const maxX = WIDTH - 75;
    const x = minX + Math.random() * (maxX - minX);

    const hLevel = Math.abs(y);
    let type = 'normal';

    const rand = Math.random();
    if (hLevel > 1400 && rand < 0.25) type = 'disappearing';
    else if (hLevel > 750 && rand < 0.35) type = 'moving';
    else if (hLevel > 450 && rand < 0.22) type = 'narrow';
    else if (rand < 0.16) type = 'bounce';

    platforms.push(new Platform(x, y, type));
  }

  function update(dt) {
    if (!isPlaying || isGameOver) return;
    timeTotal += dt;

    pou.update(dt);

    const pouScreenY = pou.y - cameraY;
    if (pouScreenY < HEIGHT * 0.45) {
      targetCameraY = pou.y - HEIGHT * 0.45;
    }
    cameraY += (targetCameraY - cameraY) * 0.13 * dt;

    score = Math.max(0, Math.floor(-cameraY));
    if (score > maxScore) {
      maxScore = score;
      scoreEl.textContent = maxScore;
      if (maxScore > bestScore) {
        bestScore = maxScore;
        bestEl.textContent = 'BEST ' + bestScore;
        saveBest(bestScore);
      }
    }

    // Update Moving Clouds
    clouds.forEach(cl => {
      cl.x += cl.speed * dt;
      if (cl.x > WIDTH + cl.w) cl.x = -cl.w;
    });

    // Update Birds
    birds.forEach(b => b.update(dt));

    platforms.forEach(p => {
      p.update(dt);

      if (pou.vy > 0 &&
          pou.x + pou.w * 0.85 > p.x &&
          pou.x + pou.w * 0.15 < p.x + p.w &&
          pou.y + pou.h >= p.y &&
          pou.y + pou.h <= p.y + p.h + 10 &&
          !p.broken) {

        if (p.type === 'bounce') {
          pou.jump(-15.8, 'bounce');
        } else {
          pou.jump(-11.5, 'normal');
        }

        if (p.type === 'disappearing') {
          p.broken = true;
          addParticles(p.x + p.w / 2, p.y, 12, 'rgba(241,245,249,0.9)');
        }
      }
    });

    platforms = platforms.filter(p => p.y < cameraY + HEIGHT + 50);

    let minY = Math.min(...platforms.map(p => p.y));
    while (minY > cameraY - HEIGHT) {
      minY -= 44 + Math.random() * 35;
      spawnPlatform(minY);
    }

    particles.forEach(p => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.life -= 0.04 * dt;
    });
    particles = particles.filter(p => p.life > 0);

    floatTexts.forEach(ft => {
      ft.y += ft.vy * dt;
      ft.life -= 0.03 * dt;
    });
    floatTexts = floatTexts.filter(ft => ft.life > 0);

    if (pou.y - cameraY > HEIGHT + 60) {
      isGameOver = true;
      playSound('over');
      finalScoreEl.textContent = 'HEIGHT: ' + maxScore;
      finalBestEl.textContent = 'BEST: ' + bestScore;
      gameOverOverlay.classList.remove('hidden');
      stopLoop();
    }
  }

  function draw() {
    const hLevel = maxScore;
    let skyTop = '#38bdf8';
    let skyBottom = '#bae6fd';
    let isDay = true;
    let isSunset = false;
    let isNight = false;

    // Day / Sunset / Night Cycle Thresholds
    if (hLevel > 2500) {
      // Midnight Space
      skyTop = '#090d16'; skyBottom = '#1e1b4b';
      isNight = true; isDay = false;
    } else if (hLevel > 1200) {
      // Twilight / Evening
      skyTop = '#312e81'; skyBottom = '#6366f1';
      isNight = true; isDay = false;
    } else if (hLevel > 500) {
      // Sunset / Golden Hour
      skyTop = '#f97316'; skyBottom = '#e11d48';
      isSunset = true; isDay = false;
    }

    const gradient = ctx.createLinearGradient(0, 0, 0, HEIGHT);
    gradient.addColorStop(0, skyTop);
    gradient.addColorStop(1, skyBottom);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    // Sun / Moon / Celestial Bodies
    ctx.save();
    if (isDay) {
      // Glowing Sunny Sun ☀️
      const sunY = 70;
      ctx.fillStyle = '#fde047';
      ctx.shadowColor = '#fde047';
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(WIDTH - 70, sunY, 26, 0, Math.PI * 2);
      ctx.fill();
    } else if (isSunset) {
      // Setting Sun 🌅
      const sunY = HEIGHT - 90;
      ctx.fillStyle = '#fb923c';
      ctx.shadowColor = '#f43f5e';
      ctx.shadowBlur = 28;
      ctx.beginPath();
      ctx.arc(WIDTH / 2, sunY, 34, 0, Math.PI * 2);
      ctx.fill();
    } else if (isNight) {
      // Crescent Moon 🌙
      const moonY = 70;
      ctx.fillStyle = '#fef08a';
      ctx.shadowColor = '#fef08a';
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.arc(WIDTH - 70, moonY, 22, 0, Math.PI * 2);
      ctx.fill();

      // Shadow Cutout for Crescent
      ctx.fillStyle = skyTop;
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(WIDTH - 62, moonY - 4, 18, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // Twinkling Stars in Evening / Night
    if (isNight) {
      stars.forEach(s => {
        const screenY = s.y - cameraY * 0.15;
        if (screenY > 0 && screenY < HEIGHT) {
          const tw = Math.sin(timeTotal * 0.1 + s.x) * 0.25;
          ctx.fillStyle = \`rgba(255, 255, 255, \${Math.min(1, Math.max(0.1, s.alpha + tw))})\`;
          ctx.beginPath();
          ctx.arc(s.x, screenY, s.r, 0, Math.PI * 2);
          ctx.fill();
        }
      });
    }

    // Moving Clouds
    ctx.fillStyle = isSunset ? 'rgba(253, 164, 175, 0.45)' : (isNight ? 'rgba(199, 210, 254, 0.25)' : 'rgba(255, 255, 255, 0.4)');
    clouds.forEach(cl => {
      const screenY = (cl.y - cameraY * 0.3) % (HEIGHT * 2.5) - HEIGHT * 0.5;
      ctx.beginPath();
      ctx.arc(cl.x, screenY, cl.w * 0.4, 0, Math.PI * 2);
      ctx.arc(cl.x + cl.w * 0.3, screenY - 8, cl.w * 0.35, 0, Math.PI * 2);
      ctx.arc(cl.x + cl.w * 0.6, screenY, cl.w * 0.3, 0, Math.PI * 2);
      ctx.fill();
    });

    // Flying Birds (during Day / Sunset)
    if (!isNight) {
      birds.forEach(b => {
        const screenY = b.y - cameraY * 0.2;
        if (screenY > -20 && screenY < HEIGHT + 20) {
          b.draw(screenY);
        }
      });
    }

    // Platforms
    platforms.forEach(p => {
      const screenY = p.y - cameraY;
      if (screenY > -20 && screenY < HEIGHT + 20) {
        p.draw(screenY);
      }
    });

    // Particles
    particles.forEach(p => {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.beginPath();
      ctx.arc(p.x, p.y - cameraY, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1.0;
    });

    // Float Texts
    floatTexts.forEach(ft => {
      ctx.save();
      ctx.font = '900 13px -apple-system, sans-serif';
      ctx.fillStyle = ft.color;
      ctx.globalAlpha = Math.max(0, ft.life);
      ctx.textAlign = 'center';
      ctx.fillText(ft.text, ft.x, ft.y - cameraY);
      ctx.restore();
    });

    // Pou
    const pouScreenY = pou.y - cameraY;
    pou.draw(pouScreenY);
  }

  let isLoopRunning = false;

  function stopLoop() {
    if (animId) {
      cancelAnimationFrame(animId);
      animId = null;
    }
    isLoopRunning = false;
  }

  function startLoop() {
    if (!isLoopRunning && !isGameOver) {
      isLoopRunning = true;
      lastTime = 0;
      animId = requestAnimationFrame(loop);
    }
  }

  function loop(timestamp) {
    if (!isLoopRunning) return;
    if (!lastTime) lastTime = timestamp;
    const dt = Math.min((timestamp - lastTime) / 16.67, 2.5);
    lastTime = timestamp;

    update(dt);
    draw();

    if (!isGameOver) {
      animId = requestAnimationFrame(loop);
    }
  }

  function bindTouch(element, onPress, onRelease) {
    const start = (e) => {
      e.preventDefault();
      e.stopPropagation();
      onPress();
    };
    const end = (e) => {
      e.preventDefault();
      e.stopPropagation();
      onRelease();
    };
    element.addEventListener('pointerdown', start);
    element.addEventListener('pointerup', end);
    element.addEventListener('pointercancel', end);
    element.addEventListener('touchstart', start, { passive: false });
    element.addEventListener('touchend', end, { passive: false });
  }

  bindTouch(btnLeft, () => { isLeftPressed = true; }, () => { isLeftPressed = false; });
  bindTouch(btnRight, () => { isRightPressed = true; }, () => { isRightPressed = false; });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') isLeftPressed = true;
    if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') isRightPressed = true;
  });
  document.addEventListener('keyup', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') isLeftPressed = false;
    if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') isRightPressed = false;
  });

  function handleStart(e) {
    if (e) {
      if (e.preventDefault) e.preventDefault();
      if (e.stopPropagation) e.stopPropagation();
    }
    initAudio();
    startOverlay.classList.add('hidden');
    gameOverOverlay.classList.add('hidden');
    isPlaying = true;
    initGame();
    startLoop();
  }

  btnStart.addEventListener('pointerdown', handleStart);
  btnStart.addEventListener('touchstart', handleStart, { passive: false });
  btnStart.addEventListener('click', handleStart);

  btnRetry.addEventListener('pointerdown', handleStart);
  btnRetry.addEventListener('touchstart', handleStart, { passive: false });
  btnRetry.addEventListener('click', handleStart);

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopLoop();
    else if (isPlaying && !isGameOver) startLoop();
  });

  initGame();
  draw();
})();
</script></body>`;

const handler = async (m, { conn, hirara }) => {
	const client = conn || hirara;

	await client.relayMessage(
		m.chat,
		{
			messageContextInfo: {
				deviceListMetadata: {},
				deviceListMetadataVersion: 2,
				botMetadata: {
					messageDisclaimerText: "",
					botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
					verificationMetadata: {
						proofs: [
							{
								version: 1,
								useCase: 1,
								signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
								certificateChain: [
									"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
									"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
								]
							}
						]
					}
				}
			},
			botForwardedMessage: {
				message: {
					richResponseMessage: {
						messageType: 1,
						submessages: [
							{
								messageType: 2,
								messageText: "Pou Jump Sky Game"
							}
						],
						unifiedResponse: {
							data: Buffer.from(JSON.stringify({
								"response_id": "4db57b2c-8393-484d-8b9a-8e6d1a14b349",
								"sections": [
									{
										"view_model": {
											"primitive": {
												"__typename": "GenAIaeacdsnwHtmlPrimitive",
												"payload": htmlPayload,
												"trusted_sources": [
													"hirara.dev"
												]
											},
											"__typename": "GenAISingleLayoutViewModel"
										}
									}
								]
							})).toString('base64')
						},
						contextInfo: {
							forwardingScore: 1,
							isForwarded: true,
							forwardedAiBotMessageInfo: {
								botJid: "867051314767696@bot"
							},
							forwardOrigin: 4
						}
					}
				}
			}
		},
		{}
	);
};

handler.help = ['poujump', 'poujumpsky', 'pougame'];
handler.tags = ['game'];
handler.category = 'game';
handler.description = 'Main game Pou Jump Sky interaktif via Hirara Rich Message';
handler.command = ['poujump'];
handler.limit = true;
handler.register = true;

export default handler;
