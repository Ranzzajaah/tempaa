import { sKata, cKata } from '../../lib/sambungkata.js';
import { db } from '../../lib/database.js';

global.sambungkata = global.sambungkata || {};

function getLastSyllableOrLetter(word) {
    word = word.toLowerCase().trim();
    if (word.length >= 2) {
        const last2 = word.slice(-2);
        if (['ng', 'ny'].includes(last2)) return last2;
    }
    return word.slice(-1);
}

function renderLobbyText(session, usedPrefix) {
    let text = `🎮 *LOBBY GAME SAMBUNG KATA* 🎮\n`;
    text += `------------------------------------\n`;
    text += `📌 *Status:* Menunggu Pemain...\n`;
    text += `👥 *Total Pemain:* ${session.players.length} Pemain\n\n`;
    text += `📋 *Daftar Pemain:*\n`;

    session.players.forEach((p, idx) => {
        const icon = idx === 0 ? '👑' : '👤';
        text += `${idx + 1}. ${icon} *${p.name}* (@${p.id.split('@')[0]})\n`;
    });

    text += `\n------------------------------------\n`;
    text += `👉 *Perintah Lobby:*\n`;
    text += `• *${usedPrefix}skata join* : Ikut pendaftaran\n`;
    text += `• *${usedPrefix}skata out* : Batal ikut\n`;
    text += `• *${usedPrefix}skata start*: Mulai permainan (Min 1)\n`;
    text += `• *${usedPrefix}skata stop* : Batalkan lobby`;

    return text;
}

const handler = async (m, { sock, usedPrefix, command, args }) => {
    const chatId = m.chat;
    const subCommand = args[0]?.toLowerCase();
    const userId = m.sender;
    const userName = m.pushName || 'Player';

    if (!subCommand || subCommand === 'create' || subCommand === 'buat') {
        if (global.sambungkata[chatId]) {
            const session = global.sambungkata[chatId];
            if (session.status === 'WAITING') {
                return sock.sendMessage(m.chat, { 
                    text: renderLobbyText(session, usedPrefix),
                    mentions: session.players.map(p => p.id)
                }, { quoted: m });
            } else {
                return sock.sendMessage(m.chat, { 
                    text: `❌ Game Sambung Kata sedang berlangsung!\n\nKata saat ini: *${session.currentWord.toUpperCase()}*\nHuruf Awalan Berikutnya: *${session.nextPrefix.toUpperCase()}*\nGiliran: @${session.players[session.turnIndex].id.split('@')[0]}`,
                    mentions: [session.players[session.turnIndex].id]
                }, { quoted: m });
            }
        }

        global.sambungkata[chatId] = {
            status: 'WAITING',
            host: userId,
            players: [{ id: userId, name: userName }],
            turnIndex: 0,
            currentWord: '',
            nextPrefix: '',
            usedWords: [],
            timer: null
        };

        const session = global.sambungkata[chatId];
        await sock.sendMessage(m.chat, { react: { text: '🎮', key: m.key } });
        return sock.sendMessage(m.chat, { 
            text: renderLobbyText(session, usedPrefix),
            mentions: [userId]
        }, { quoted: m });
    }

    if (subCommand === 'join' || subCommand === 'ikut') {
        if (!global.sambungkata[chatId]) {
            return sock.sendMessage(m.chat, { 
                text: `❌ Belum ada room game! Ketik *${usedPrefix}${command}* untuk membuka room baru.` 
            }, { quoted: m });
        }

        const session = global.sambungkata[chatId];

        if (session.status !== 'WAITING') {
            return sock.sendMessage(m.chat, { text: `❌ Permainan sudah dimulai!` }, { quoted: m });
        }

        if (session.players.some(p => p.id === userId)) {
            return sock.sendMessage(m.chat, { text: `⚠️ Kamu sudah terdaftar di dalam lobby!` }, { quoted: m });
        }

        session.players.push({ id: userId, name: userName });
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        return sock.sendMessage(m.chat, { 
            text: `✅ *${userName}* berhasil bergabung!\n\n` + renderLobbyText(session, usedPrefix),
            mentions: session.players.map(p => p.id)
        }, { quoted: m });
    }

    if (subCommand === 'out' || subCommand === 'keluar') {
        if (!global.sambungkata[chatId]) return sock.sendMessage(m.chat, { text: `❌ Tidak ada room yang terbuka.` }, { quoted: m });

        const session = global.sambungkata[chatId];
        if (session.status !== 'WAITING') return sock.sendMessage(m.chat, { text: `❌ Permainan sudah berjalan!` }, { quoted: m });

        const playerIndex = session.players.findIndex(p => p.id === userId);
        if (playerIndex === -1) return sock.sendMessage(m.chat, { text: `⚠️ Kamu belum bergabung di lobby ini.` }, { quoted: m });

        session.players.splice(playerIndex, 1);

        if (session.players.length === 0) {
            delete global.sambungkata[chatId];
            return sock.sendMessage(m.chat, { text: `🚪 Semua pemain keluar. Lobby dibatalkan!` }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '👋', key: m.key } });
        return sock.sendMessage(m.chat, { 
            text: `👋 *${userName}* keluar dari lobby.\n\n` + renderLobbyText(session, usedPrefix),
            mentions: session.players.map(p => p.id)
        }, { quoted: m });
    }

    if (subCommand === 'start' || subCommand === 'mulai') {
        if (!global.sambungkata[chatId]) return sock.sendMessage(m.chat, { text: `❌ Belum ada room yang dibuat!` }, { quoted: m });

        const session = global.sambungkata[chatId];
        if (session.status !== 'WAITING') return sock.sendMessage(m.chat, { text: `❌ Permainan sudah berjalan!` }, { quoted: m });

        const dataKata = await sKata();
        const startWord = dataKata?.kata || 'makan';
        const nextPrefix = getLastSyllableOrLetter(startWord);

        session.status = 'PLAYING';
        session.currentWord = startWord;
        session.nextPrefix = nextPrefix;
        session.usedWords = [startWord];
        session.turnIndex = 0;

        const currentTurnPlayer = session.players[0];

        session.timer = setTimeout(() => {
            if (global.sambungkata[chatId]) {
                sock.sendMessage(m.chat, { 
                    text: `⏳ *WAKTU HABIS!*\n\n@${currentTurnPlayer.id.split('@')[0]} tidak menjawab tepat waktu.\nTotal Kata Terkumpul: *${session.usedWords.length} Kata*\nGame Dihentikan!`,
                    mentions: [currentTurnPlayer.id]
                });
                delete global.sambungkata[chatId];
            }
        }, 45000);

        let startMsg = `🔤 *PERMAINAN SAMBUNG KATA DIMULAI!* 🔤\n` +
            `----------------------------------\n` +
            `Kata Awal: *${startWord.toUpperCase()}*\n` +
            `Awalan Kata Berikutnya: *${nextPrefix.toUpperCase()}*\n\n` +
            `🎯 *Giliran Pertama:* @${currentTurnPlayer.id.split('@')[0]}\n` +
            `⏰ *Waktu:* 45 Detik\n` +
            `----------------------------------\n` +
            `_Ketik langsung kata balasanmu di obrolan!_`;

        return sock.sendMessage(m.chat, { 
            text: startMsg,
            mentions: [currentTurnPlayer.id]
        }, { quoted: m });
    }

    if (subCommand === 'stop' || subCommand === 'nyerah') {
        if (!global.sambungkata[chatId]) return sock.sendMessage(m.chat, { text: `❌ Tidak ada permainan yang aktif.` }, { quoted: m });

        const session = global.sambungkata[chatId];
        if (session.timer) clearTimeout(session.timer);

        delete global.sambungkata[chatId];
        return sock.sendMessage(m.chat, { text: `🛑 *GAME SAMBUNG KATA DIBATALKAN/DIHENTIKAN!*` }, { quoted: m });
    }
};

handler.before = async (m, { sock }) => {
    if (m.isBot || m.fromMe) return;

    const chatId = m.chat;
    const session = global.sambungkata[chatId];

    if (!session || session.status !== 'PLAYING') return;

    const text = m.text?.toLowerCase().trim();
    if (!text || text.includes(' ') || !/^[a-z]+$/.test(text)) return;

    const currentTurnPlayer = session.players[session.turnIndex];
    if (m.sender !== currentTurnPlayer.id) return;

    if (!text.startsWith(session.nextPrefix)) return;

    if (session.usedWords.includes(text)) {
        await sock.sendMessage(m.chat, { 
            text: `⚠️ Kata *${text.toUpperCase()}* sudah pernah digunakan! Cari kata lain berawalan *${session.nextPrefix.toUpperCase()}*.` 
        }, { quoted: m });
        return;
    }

    const checkResult = await cKata(text);
    if (!checkResult || !checkResult.status) {
        await sock.sendMessage(m.chat, { 
            text: `❌ Kata *${text.toUpperCase()}* tidak ditemukan dalam KBBI!` 
        }, { quoted: m });
        return;
    }

    clearTimeout(session.timer);

    const newNextPrefix = getLastSyllableOrLetter(text);
    session.currentWord = text;
    session.nextPrefix = newNextPrefix;
    session.usedWords.push(text);

    session.turnIndex = (session.turnIndex + 1) % session.players.length;
    const nextTurnPlayer = session.players[session.turnIndex];

    session.timer = setTimeout(() => {
        if (global.sambungkata[chatId]) {
            sock.sendMessage(m.chat, { 
                text: `⏳ *WAKTU HABIS!*\n\n@${nextTurnPlayer.id.split('@')[0]} tidak menjawab kata berawalan *${newNextPrefix.toUpperCase()}*.\nTotal Kata Terkumpul: *${session.usedWords.length} Kata*\nGame Berakhir!`,
                mentions: [nextTurnPlayer.id]
            });
            delete global.sambungkata[chatId];
        }
    }, 45000);

    try {
        let user = db.prepare('SELECT * FROM users WHERE id = ?').get(m.sender);
        if (!user) {
            db.prepare('INSERT INTO users (id, name, level, exp, health, money, limit_val) VALUES (?, ?, 1, 0, 100, 50, 20)').run(m.sender, m.pushName || 'Player');
        }
        db.prepare('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?').run(35, 15, m.sender);
    } catch (dbErr) {
        console.error('[DB ERROR]', dbErr.message);
    }

    let msg = `✅ *BENAR!* (+$35 💵 | +15 ✨)\n` +
        `👤 *${currentTurnPlayer.name}:* ${text.toUpperCase()}\n` +
        `----------------------------------\n` +
        `👉 Awalan Kata Berikutnya: *${newNextPrefix.toUpperCase()}*\n` +
        `🎯 *Giliran:* @${nextTurnPlayer.id.split('@')[0]}`;

    await sock.sendMessage(m.chat, { 
        text: msg,
        mentions: [nextTurnPlayer.id]
    }, { quoted: m });
};

handler.help = ['sambungkata'];
handler.tags = ['game'];
handler.command = ['sambungkata', 'skata', 'sk'];

export default handler;