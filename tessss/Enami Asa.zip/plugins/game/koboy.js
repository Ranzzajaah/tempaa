/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import { addExp } from "../../lib/rpg.js";

global.koboyGame = global.koboyGame || {};

function random(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}

const handler = async (m, { sock, user, text, command, reply, usedPrefix, updateUser }) => {
	const fnUpdateUser = updateUser || global.updateUser;

	if (!m.isGroup) {
		return reply(global.mess.group);
	}

	const chatId = m.chat;
	global.koboyGame[chatId] = global.koboyGame[chatId] || null;

	const cleanText = (text || "").toLowerCase().trim();

	const trackKiri = [
		["🤠", "-", "-", "-", "-"],
		["-", "🤠", "-", "-", "-"],
		["-", "-", "🤠", "-", "-"],
		["-", "-", "-", "🤠", "-"],
		["-", "-", "-", "-", "🤠"]
	];

	const trackKanan = [
		["🤠", "-", "-", "-", "-"],
		["-", "🤠", "-", "-", "-"],
		["-", "-", "🤠", "-", "-"],
		["-", "-", "-", "🤠", "-"],
		["-", "-", "-", "-", "🤠"]
	];

	if (cleanText === "kiri" && global.koboyGame[chatId]) {
		const session = global.koboyGame[chatId];
		const currentPos = session.tembak.indexOf("🤠");
		const nextPos = Math.max(0, currentPos - 1);
		session.tembak = trackKiri[nextPos];

		const posDisplay = session.musuh.join(" ") + "\n\n\n" + session.tembak.join(" ");

		if (session.musuh.indexOf("🥷") === session.tembak.indexOf("🤠")) {
			return reply(`🎯 *KOBONG DUEL (POSISI PAS!)*\n\n${posDisplay}\n\n👉 Ketik: *${usedPrefix + command} tembak*`);
		}
		return reply(`🤠 *KOBONG DUEL*\n\n${posDisplay}\n\n👉 Ketik: *${usedPrefix + command} kiri* atau *${usedPrefix + command} kanan*`);
	}

	if (cleanText === "kanan" && global.koboyGame[chatId]) {
		const session = global.koboyGame[chatId];
		const currentPos = session.tembak.indexOf("🤠");
		const nextPos = Math.min(4, currentPos + 1);
		session.tembak = trackKanan[nextPos];

		const posDisplay = session.musuh.join(" ") + "\n\n\n" + session.tembak.join(" ");

		if (session.musuh.indexOf("🥷") === session.tembak.indexOf("🤠")) {
			return reply(`🎯 *KOBONG DUEL (POSISI PAS!)*\n\n${posDisplay}\n\n👉 Ketik: *${usedPrefix + command} tembak*`);
		}
		return reply(`🤠 *KOBONG DUEL*\n\n${posDisplay}\n\n👉 Ketik: *${usedPrefix + command} kiri* atau *${usedPrefix + command} kanan*`);
	}

	if (cleanText === "tembak" && global.koboyGame[chatId]) {
		const session = global.koboyGame[chatId];
		if (session.musuh.indexOf("🥷") === session.tembak.indexOf("🤠")) {
			delete global.koboyGame[chatId];
			const rewardMoney = Math.floor(Math.random() * 101) + 50; 
			const rewardExp = Math.floor(Math.random() * 51) + 50; 
			const rewardLimit = Math.floor(Math.random() * 5) + 2; 
			user.money = (user.money || 0) + rewardMoney;
			user.exp = (user.exp || 0) + rewardExp;
			user.limit_val = (user.limit_val || 0) + rewardLimit;
			addExp(user, 0);

			if (typeof fnUpdateUser === "function") {
				await fnUpdateUser(m.sender, { money: user.money, exp: user.exp, limit_val: user.limit_val }).catch(() => null);
			}

			return reply(`💥 *DORRR! TEPAT SASARAN!* 🎯\n\n🤠 Kamu berhasil menembak penjahat 🥷!\n💰 *Hadiah:* +$${rewardMoney.toLocaleString("id-ID")}\n🎟️ *Limit:* +${rewardLimit} Limit\n✨ *EXP:* +${rewardExp} EXP`);
		} else {
			return reply(`❌ *Tembakan Meleset!* Penjahat tidak berada tepat di depanmu.\nGeser posisi dengan *${usedPrefix + command} kiri* atau *${usedPrefix + command} kanan*`);
		}
	}

	const randMusuh = [
		["🥷", "-", "-", "-", "-"],
		["-", "🥷", "-", "-", "-"],
		["-", "-", "🥷", "-", "-"],
		["-", "-", "-", "🥷", "-"],
		["-", "-", "-", "-", "🥷"]
	];

	const randAku = [
		["🤠", "-", "-", "-", "-"],
		["-", "🤠", "-", "-", "-"],
		["-", "-", "🤠", "-", "-"],
		["-", "-", "-", "🤠", "-"],
		["-", "-", "-", "-", "🤠"]
	];

	const musuh = random(randMusuh);
	const aku = random(randAku);

	global.koboyGame[chatId] = {
		musuh,
		tembak: aku,
		time: Date.now()
	};

	const posDisplay = musuh.join(" ") + "\n\n\n" + aku.join(" ");

	const petunjuk = musuh.indexOf("🥷") === aku.indexOf("🤠")
		? `👉 Ketik: *${usedPrefix + command} tembak*`
		: `👉 Ketik: *${usedPrefix + command} kiri* atau *${usedPrefix + command} kanan*`;

	reply(`🤠 *GAME KOBONG (COWBOY SHOOT)*\n\n${posDisplay}\n\n${petunjuk}`);
};

handler.help = ["koboy", "koboy kiri/kanan/tembak"];
handler.tags = ["game", "rpg"];
handler.command = ["koboy", "cowboy"];
handler.group = true;
handler.register = true;

export default handler;