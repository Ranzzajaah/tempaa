/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import fs from "fs";
import path from "path";
import { createQuizCanvas } from "../../canvas/canvasQuiz.js";

const GAME_TYPE = "matematika";
global.quizTimers = global.quizTimers || {};

function getSession(chatId) {
  if (typeof global.getGameSession === "function") {
    return global.getGameSession(GAME_TYPE, chatId);
  }
  return null;
}

function saveSession(chatId, session) {
  if (typeof global.saveGameSession === "function") {
    const cleanSession = { ...session };
    delete cleanSession.timer;
    global.saveGameSession(GAME_TYPE, chatId, cleanSession);
  }
}

function deleteSession(chatId) {
  if (typeof global.deleteGameSession === "function") {
    global.deleteGameSession(GAME_TYPE, chatId);
  }
  const timerKey = `${GAME_TYPE}_${chatId}`;
  if (global.quizTimers[timerKey]) {
    clearTimeout(global.quizTimers[timerKey]);
    delete global.quizTimers[timerKey];
  }
}

function hasAnyActiveQuizInChat(chatId) {
  if (typeof global.getAllActiveGameSessions === "function") {
    const all = global.getAllActiveGameSessions();
    return all.find(s => s.chatId === chatId);
  }
  return null;
}

function loadQuestions() {
    try {
        const filePath = path.join(process.cwd(), "json", "kuis_matematika.json");
        if (fs.existsSync(filePath)) {
            return JSON.parse(fs.readFileSync(filePath, "utf-8"));
        }
    } catch (e) {
        console.error("[LOAD MATH ERROR]", e);
    }
    return null;
}

function shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

function generateQuiz(level = "easy") {
    const data = loadQuestions();
    if (!data || !data[level]) return [];

    const total = level === "easy" ? 10 : level === "normal" ? 15 : 20;
    const shuffled = shuffle(data[level]);
    const selected = [];

    for (let i = 0; i < Math.min(total, shuffled.length); i++) {
        const q = shuffled[i];
        selected.push({
            number: i + 1,
            question: q.q,
            answer: q.a.toLowerCase().trim(),
            points: level === "easy" ? 10 : level === "normal" ? 20 : 30,
            rewardLimit: level === "easy" ? 1 : level === "normal" ? 2 : 3,
            rewardExp: level === "easy" ? 50 : level === "normal" ? 100 : 200
        });
    }
    return selected;
}

async function sendQuestion(chatId, session, client) {
    const current = session.currentQuestion;
    const total = session.questions.length;
    const q = session.questions[current];

    let txt = `🎲 *KUIS MATEMATIKA (${session.level.toUpperCase()})*\n\n` +
        `📝 *Soal ${current + 1}/${total}*\n` +
        `❓ *${q.question}*\n\n` +
        `🎯 *Hadiah Tiap Soal:*\n` +
        `• Limit: *+${q.rewardLimit} Limit* 🎟️\n` +
        `• Poin: *+${q.points} Poin*\n` +
        `• EXP: *+${q.rewardExp} EXP* ⭐\n\n` +
        `⏱️ Waktu: *45 detik*\n` +
        `💬 *Reply / balas pesan soal ini untuk menjawab!*`;

    let thumbBuf = null;
    try {
        thumbBuf = await createQuizCanvas({
            title: "KUIS MATEMATIKA",
            level: session.level,
            questionNum: current + 1,
            totalQuestion: total,
            points: q.points,
            limit: q.rewardLimit,
            exp: q.rewardExp
        });
    } catch (errCanvas) {
        console.error("[CANVAS GEN ERROR]", errCanvas.message);
    }

    let sentMsg = null;

    if (global.Button) {
        try {
            const btn = new global.Button(client);
            if (thumbBuf) {
                btn.setImage(thumbBuf);
            }
            btn.setBody(txt);
            btn.setFooter("© Hirara AI • Tekan tombol di bawah untuk berhenti");
            btn.addReply("🛑 Berhenti Kuis", `.stopkuismath`);
            sentMsg = await btn.send(chatId);
        } catch (e) {
            console.error("[KUIS BUTTON ERROR]", e.message);
        }
    }

    if (!sentMsg) {
        if (thumbBuf) {
            sentMsg = await client.sendMessage(chatId, { image: thumbBuf, caption: txt });
        } else {
            sentMsg = await client.sendMessage(chatId, { text: txt });
        }
    }

    if (sentMsg && sentMsg.key) {
        session.lastMsgId = sentMsg.key.id;
    }

    session.startTime = Date.now();
    saveSession(chatId, session);

    const timerKey = `${GAME_TYPE}_${chatId}`;
    if (global.quizTimers[timerKey]) clearTimeout(global.quizTimers[timerKey]);

    global.quizTimers[timerKey] = setTimeout(async () => {
        const liveSession = getSession(chatId);
        if (!liveSession || liveSession.currentQuestion !== current) return;

        const curQ = liveSession.questions[liveSession.currentQuestion];
        await client.sendMessage(chatId, {
            text: `⏰ *WAKTU HABIS!*\nJawaban benar: *${curQ.answer}*`
        });

        liveSession.currentQuestion++;
        if (liveSession.currentQuestion < liveSession.questions.length) {
            saveSession(chatId, liveSession);
            await new Promise(r => setTimeout(r, 1500));
            sendQuestion(chatId, liveSession, client);
        } else {
            finishQuiz(chatId, liveSession, client);
        }
    }, 45000);
}

async function finishQuiz(chatId, session, client) {
    const timerKey = `${GAME_TYPE}_${chatId}`;
    if (global.quizTimers[timerKey]) {
      clearTimeout(global.quizTimers[timerKey]);
      delete global.quizTimers[timerKey];
    }

    let summary = `🏆 *KUIS MATEMATIKA SELESAI!*\n\n` +
        `• Level: ${session.level.toUpperCase()}\n` +
        `• Benar: ${session.score.correct}/${session.questions.length} Soal\n` +
        `• Total Skor: *${session.score.points} Poin*\n` +
        `• Total Hadiah Limit: *+${session.score.limit} Limit* 🎟️\n` +
        `• Total EXP: *+${session.score.exp} EXP* ⭐\n\n` +
        `Semua reward telah otomatis masuk ke akun pemain! 🎉`;

    deleteSession(chatId);
    await client.sendMessage(chatId, { text: summary });
}

const handler = async (m, { hirara, conn, args, usedPrefix, command, reply }) => {
    const client = hirara || conn;
    const chatId = m.chat;

    if (args[0] === "stop") {
        const curSession = getSession(chatId);
        if (curSession) {
            return finishQuiz(chatId, curSession, client);
        }
        return reply(`❌ Tidak ada kuis KUIS MATEMATIKA yang sedang berjalan di grup ini.`);
    }

    const activeOther = hasAnyActiveQuizInChat(chatId);
    if (activeOther) {
        return reply(`⚠️ Masih ada sesi kuis (${activeOther.gameType.toUpperCase()}) yang aktif di chat ini! Selesaikan dulu atau ketik ${usedPrefix}stop untuk berhenti.`);
    }

    const level = (args[0] || "").toLowerCase();
    if (!["easy", "normal", "hard"].includes(level)) {
        return reply(
            `🎲 *KUIS MATEMATIKA*\n\n` +
            `Silakan pilih level kuis:\n` +
            `• \`${usedPrefix + command} easy\` (10 soal | +1 Limit/soal)\n` +
            `• \`${usedPrefix + command} normal\` (15 soal | +2 Limit/soal)\n` +
            `• \`${usedPrefix + command} hard\` (20 soal | +3 Limit/soal)\n\n` +
            `Contoh: \`${usedPrefix + command} easy\``
        );
    }

    const questions = generateQuiz(level);
    if (!questions.length) return reply(`❌ Database soal belum tersedia.`);

    const newSession = {
        chatId,
        level,
        questions,
        currentQuestion: 0,
        score: { correct: 0, points: 0, limit: 0, exp: 0 },
        lastMsgId: null
    };

    saveSession(chatId, newSession);

    await reply(`🚀 *KUIS MATEMATIKA (${level.toUpperCase()}) Dimulai!* Siap-siap...\n👥 *Semua member di grup bisa ikut menjawab!*\n💬 Balas / reply pesan soal dengan jawaban kamu.`);
    await new Promise(r => setTimeout(r, 1200));
    await sendQuestion(chatId, newSession, client);
};

handler.before = async (m, { hirara, conn }) => {
    const client = hirara || conn;
    const chatId = m.chat;

    const rawText = (m.body || m.text || "").trim();
    const text = rawText.toLowerCase();
    if (!text) return;

    const isStopAction = (
        text === ".stopkuismath" || 
        text === "stopkuismath" ||
        text === ".stop" ||
        text === "stop" ||
        rawText === "🛑 Berhenti Kuis" ||
        text === "🛑 berhenti kuis" ||
        text === "berhenti kuis" ||
        (m.msg?.selectedButtonId && m.msg.selectedButtonId.includes("stop")) ||
        (m.msg?.selectedDisplayText && m.msg.selectedDisplayText.includes("Berhenti"))
    );

    if (isStopAction) {
        const session = getSession(chatId);
        if (session) {
            await finishQuiz(chatId, session, client);
            return true;
        }
        return;
    }

    const session = getSession(chatId);
    if (!session) return;

    if (text.startsWith(".") || text.startsWith("/") || text.startsWith("#")) return;

    const isReplyToBot = m.quoted && (
        m.quoted.fromMe || 
        (session.lastMsgId && m.quoted.id === session.lastMsgId) ||
        (m.quoted.text && (m.quoted.text.includes("Soal ") || m.quoted.text.includes("KUIS")))
    );

    if (!isReplyToBot) return;

    const currentQ = session.questions[session.currentQuestion];
    if (!currentQ) return;

    const isMatch = text === currentQ.answer || (currentQ.answer.length > 3 && text.includes(currentQ.answer));

    const timerKey = `${GAME_TYPE}_${chatId}`;
    if (global.quizTimers[timerKey]) clearTimeout(global.quizTimers[timerKey]);

    if (isMatch) {
        session.score.correct++;
        session.score.points += currentQ.points;
        session.score.limit += currentQ.rewardLimit;
        session.score.exp += currentQ.rewardExp;

        try {
            if (typeof global.getUser === "function" && typeof global.updateUser === "function") {
                const userDb = global.getUser(m.sender);
                if (userDb) {
                    global.updateUser(m.sender, {
                        limit_val: (userDb.limit_val || 0) + currentQ.rewardLimit,
                        exp: (userDb.exp || 0) + currentQ.rewardExp
                    });
                }
            }
        } catch (e) {}

        await client.sendMessage(chatId, {
            text: `✅ *BENAR!*\nJawaban: *${currentQ.answer}*\nReward: *+${currentQ.rewardLimit} Limit* 🎟️ | *+${currentQ.rewardExp} EXP* ⭐\nPemenang: @${m.sender.split("@")[0]}`,
            mentions: [m.sender]
        }, { quoted: m });
    } else {
        await client.sendMessage(chatId, {
            text: `❌ *SALAH!*\nJawaban benar: *${currentQ.answer}*\nDijawab oleh: @${m.sender.split("@")[0]}`,
            mentions: [m.sender]
        }, { quoted: m });
    }

    session.currentQuestion++;
    if (session.currentQuestion < session.questions.length) {
        saveSession(chatId, session);
        await new Promise(r => setTimeout(r, 1500));
        sendQuestion(chatId, session, client);
    } else {
        finishQuiz(chatId, session, client);
    }
};

handler.help = ["kuismath <easy/normal/hard>", "kuismatematika <easy/normal/hard>", "mathquiz <easy/normal/hard>"];
handler.tags = ["game"];
handler.command = /^(kuismath|kuismatematika|mathquiz)$/i;
handler.game = true;

export default handler;
