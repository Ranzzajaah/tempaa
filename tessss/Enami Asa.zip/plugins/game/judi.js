import { db } from '../../lib/database.js';

const emojis = ['🍒', '🍋', '🍉', '🔔', '💎'];

const handler = async (m, { sock, usedPrefix, args, command }) => {
    try {
        const userId = m.sender;
        let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);

        if (!user) {
            return sock.sendMessage(m.chat, { text: `❌ Karakter belum dibuat! Ketik *${usedPrefix}profile* dulu.` }, { quoted: m });
        }

        const userMoney = user.money || 0;

        let bet = parseInt(args[0]);
        if (!bet || isNaN(bet) || bet < 10) {
            return sock.sendMessage(m.chat, { 
                text: `⚠️ Masukkan jumlah taruhan yang valid!\n\n*Contoh:* ${usedPrefix}${command} 50\n_(Minimal taruhan: 10 Money)_` 
            }, { quoted: m });
        }

        if (userMoney < bet) {
            return sock.sendMessage(m.chat, { 
                text: `❌ *Money* kamu tidak cukup untuk taruhan ini!\nUangmu saat ini: 💵 $${userMoney.toLocaleString('id-ID')} Money.` 
            }, { quoted: m });
        }

        await sock.sendMessage(m.chat, { react: { text: '🎰', key: m.key } });

        let currentMoney = userMoney - bet;

        const slot1 = emojis[Math.floor(Math.random() * emojis.length)];
        const slot2 = emojis[Math.floor(Math.random() * emojis.length)];
        const slot3 = emojis[Math.floor(Math.random() * emojis.length)];

        let winAmount = 0;
        let resultText = '';

        if (slot1 === slot2 && slot2 === slot3) {
            winAmount = bet * 10;
            resultText = `🎉 *JACKPOT!* 🎉\nKamu mendapatkan 3 gambar yang sama!\n*+💵 $${winAmount.toLocaleString('id-ID')} Money*`;
        } else if (slot1 === slot2 || slot1 === slot3 || slot2 === slot3) {
            winAmount = bet * 2;
            resultText = `🎊 *MENANG!* 🎊\nKamu mendapatkan 2 gambar yang sama!\n*+💵 $${winAmount.toLocaleString('id-ID')} Money*`;
        } else {
            resultText = `💥 *KALAH!* 💥\nSemoga beruntung di lain waktu!\n*-💵 $${bet.toLocaleString('id-ID')} Money*`;
        }

        currentMoney += winAmount;
        db.prepare('UPDATE users SET money = ? WHERE id = ?').run(currentMoney, userId);

        const uiText = `*🎰 MESIN SLOT 🎰*\n\n` +
                       `    [  ${slot1} | ${slot2} | ${slot3}  ]\n\n` +
                       `${resultText}\n\n` +
                       `💵 *Sisa Money:* $${currentMoney.toLocaleString('id-ID')}`;

        await sock.sendMessage(m.chat, {
            text: uiText,
            footer: global.namaBot || 'Hirara Casino',
            buttons: [
                { displayText: '🎰 Main Lagi (Sama)', id: `${usedPrefix}${command} ${bet}` },
                { displayText: '👤 Cek Profil', id: `${usedPrefix}profile` }
            ]
        }, { quoted: m });

    } catch (error) {
        console.error('[GAME SLOT ERROR]', error);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
};

handler.help = ['slot <taruhan>'];
handler.tags = ['game'];
handler.command = ['slot', 'judi'];

export default handler;