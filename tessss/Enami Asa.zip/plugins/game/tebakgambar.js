import axios from 'axios';
import { db } from '../../lib/database.js';

global.tebakgambar = global.tebakgambar || {};

const handler = async (m, { sock, usedPrefix, command, args }) => {
    const chatId = m.chat;

    if (global.tebakgambar[chatId]) {
        const session = global.tebakgambar[chatId];

        if (args[0] === 'nyerah') {
            clearTimeout(session.timer);
            await sock.sendMessage(m.chat, { 
                text: `🏳️ *KAMU MENYERAH!*\n\nJawaban yang benar adalah: *${session.jawaban.toUpperCase()}*\n_Deskripsi: ${session.deskripsi}_` 
            }, { quoted: m });
            delete global.tebakgambar[chatId];
            return;
        }

        if (args[0] === 'hint' || args[0] === 'bantuan') {
            let hintText = session.jawaban.replace(/[a-zA-Z]/g, (c, idx) => {
                return idx % 2 === 0 ? c.toUpperCase() + ' ' : '_ ';
            });

            return sock.sendMessage(m.chat, { 
                text: `*💡 HINT TEBAK GAMBAR*\n\n${hintText.trim()}` 
            }, { quoted: m });
        }

        return sock.sendMessage(m.chat, { 
            text: `❌ Masih ada soal Tebak Gambar yang belum terjawab di grup ini!\n\nKetik *${usedPrefix}${command} hint* untuk bantuan.\nKetik *${usedPrefix}${command} nyerah* untuk mengakhiri.` 
        }, { quoted: m });
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const { data } = await axios.get('https://api.siputzx.my.id/api/games/tebakgambar', { timeout: 10000 });
        
        if (!data || !data.status || !data.data) throw new Error('Gagal mengambil data dari API');

        const { img, jawaban, deskripsi } = data.data;
        const jawabanKecil = jawaban.toLowerCase().trim();

        global.tebakgambar[chatId] = {
            jawaban: jawabanKecil,
            deskripsi: deskripsi || '-',
            timer: setTimeout(() => {
                if (global.tebakgambar[chatId]) {
                    sock.sendMessage(m.chat, { 
                        text: `⏳ *WAKTU HABIS!*\n\nSayang sekali tidak ada yang berhasil menebak.\nJawaban yang benar adalah: *${jawaban.toUpperCase()}*` 
                    });
                    delete global.tebakgambar[chatId];
                }
            }, 120000)
        };

        let caption = `*🖼️ TEBAK GAMBAR 🖼️*\n\n` +
            `Silakan tebak maksud dari gambar di atas!\n\n` +
            `_⏰ Waktu: 2 Menit_\n` +
            `_💡 Ketik jawaban langsung di obrolan!_\n` +
            `_🔍 Ketik *${usedPrefix}${command} hint* jika kesulitan._\n` +
            `_🏳️ Ketik *${usedPrefix}${command} nyerah* untuk menyerah._`;

        await sock.sendMessage(m.chat, { image: { url: img }, caption: caption }, { quoted: m });
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[TEBAK GAMBAR ERROR]', e.message);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await sock.sendMessage(m.chat, { text: '❌ Gagal memulai game Tebak Gambar. Coba lagi nanti.' }, { quoted: m });
    }
};

handler.before = async (m, { sock }) => {
    if (m.isBot || m.fromMe) return;

    const chatId = m.chat;
    const session = global.tebakgambar[chatId];
    if (!session) return;

    const text = m.text?.toLowerCase().trim();
    if (!text) return;

    if (text === session.jawaban) {
        const userId = m.sender;
        const playerName = m.pushName || 'Player';

        try {
            let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
            if (!user) {
                db.prepare('INSERT INTO users (id, name, level, exp, health, money, limit_val) VALUES (?, ?, 1, 0, 100, 50, 20)').run(userId, playerName);
            }
            db.prepare('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?').run(50, 20, userId);
        } catch (dbErr) {
            console.error('[DB ERROR]', dbErr.message);
        }

        clearTimeout(session.timer);

        let board = `🎉 *BENAR SEKALI!* 🎉\n\n` +
            `👤 *Penebak:* ${playerName}\n` +
            `📝 *Jawaban:* ${session.jawaban.toUpperCase()}\n` +
            `🎁 *Hadiah:* 💵 +$50 Money | ✨ +20 EXP\n\n` +
            `_Penjelasan: ${session.deskripsi}_`;

        await sock.sendMessage(m.chat, { text: board }, { quoted: m });
        delete global.tebakgambar[chatId];
    }
};

handler.help = ['tebakgambar'];
handler.tags = ['game'];
handler.command = ['tebakgambar', 'tg'];

export default handler;