import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Crypto from 'crypto';
import ff from 'fluent-ffmpeg';
import { db } from '../../lib/database.js';

global.tebakheroml = global.tebakheroml || {};

async function convertToVoiceNote(buffer) {
    const tmpIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.bin`);
    const tmpOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.ogg`);

    fs.writeFileSync(tmpIn, buffer);

    await new Promise((resolve, reject) => {
        ff(tmpIn)
            .audioCodec('libopus')
            .toFormat('ogg')
            .on('error', (err) => {
                try { fs.unlinkSync(tmpIn); } catch {}
                reject(err);
            })
            .on('end', () => {
                resolve(true);
            })
            .save(tmpOut);
    });

    const resultBuffer = fs.readFileSync(tmpOut);
    try {
        fs.unlinkSync(tmpIn);
        fs.unlinkSync(tmpOut);
    } catch {}

    return resultBuffer;
}

const handler = async (m, { sock, usedPrefix, command, args }) => {
    const chatId = m.chat;

    if (global.tebakheroml[chatId]) {
        const session = global.tebakheroml[chatId];

        if (args[0] === 'nyerah') {
            clearTimeout(session.timer);
            await sock.sendMessage(m.chat, { 
                text: `🏳️ *KAMU MENYERAH!*\n\nHero yang benar adalah: *${session.jawabanAsli}*` 
            }, { quoted: m });
            delete global.tebakheroml[chatId];
            return;
        }

        if (args[0] === 'hint' || args[0] === 'bantuan') {
            let hintText = session.jawabanAsli.replace(/[a-zA-Z]/g, (c, idx) => {
                return idx % 2 === 0 ? c.toUpperCase() + ' ' : '_ ';
            });

            return sock.sendMessage(m.chat, { 
                text: `*💡 HINT TEBAK HERO ML*\n\n${hintText.trim()}` 
            }, { quoted: m });
        }

        return sock.sendMessage(m.chat, { 
            text: `❌ Masih ada sesi Tebak Hero ML di grup ini yang belum terjawab!\n\nKetik *${usedPrefix}${command} hint* untuk bantuan.\nKetik *${usedPrefix}${command} nyerah* untuk mengakhiri.` 
        }, { quoted: m });
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const { data } = await axios.get('https://api.siputzx.my.id/api/games/tebakheroml', { timeout: 10000 });
        
        if (!data || !data.status || !data.data) {
            throw new Error('Server API sedang mengalami gangguan.');
        }

        const heroName = data.data.name;
        const audioUrl = data.data.audio;
        const jawabanKecil = heroName.toLowerCase().trim();

        global.tebakheroml[chatId] = {
            jawaban: jawabanKecil,
            jawabanAsli: heroName,
            timer: setTimeout(() => {
                if (global.tebakheroml[chatId]) {
                    sock.sendMessage(m.chat, { 
                        text: `⏳ *WAKTU HABIS!*\n\nSayang sekali tidak ada yang berhasil menebak.\nSuara hero tersebut adalah: *${heroName}*` 
                    });
                    delete global.tebakheroml[chatId];
                }
            }, 120000)
        };

        const resAudio = await axios.get(audioUrl, { responseType: 'arraybuffer', timeout: 10000 });
        const rawBuffer = Buffer.from(resAudio.data);
        const vnBuffer = await convertToVoiceNote(rawBuffer);

        await sock.sendMessage(m.chat, { 
            audio: vnBuffer, 
            mimetype: 'audio/ogg; codecs=opus', 
            ptt: true 
        }, { quoted: m });

        let caption = `*🔊 TEBAK HERO MOBILE LEGENDS 🔊*\n\n` +
            `Dengarkan Voice Note di atas dan tebak siapa nama heronya!\n\n` +
            `_⏰ Waktu: 2 Menit_\n` +
            `_💡 Ketik jawaban langsung di obrolan!_\n` +
            `_🔍 Ketik *${usedPrefix}${command} hint* jika kesulitan._\n` +
            `_🏳️ Ketik *${usedPrefix}${command} nyerah* untuk menyerah._`;

        await sock.sendMessage(m.chat, { text: caption });
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[TEBAK HERO ML ERROR]', e.message);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        if (e.response?.status === 503 || /503/i.test(e.message)) {
            await sock.sendMessage(m.chat, { text: '⚠️ Server penyedia game sedang down/sibuk (Error 503). Silakan coba lagi nanti.' }, { quoted: m });
        } else {
            await sock.sendMessage(m.chat, { text: `❌ Gagal memuat game: ${e.message}` }, { quoted: m });
        }
    }
};

handler.before = async (m, { sock }) => {
    if (m.isBot || m.fromMe) return;

    const chatId = m.chat;
    const session = global.tebakheroml[chatId];
    if (!session) return;

    const text = m.text?.toLowerCase().trim();
    if (!text) return;

    if (text === session.jawaban) {
        const userId = m.sender;
        const playerName = m.pushName || 'Player';

        try {
            let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
            if (!user) {
                db.prepare('INSERT INTO users (id, name, level, exp, health, money, limit_val) VALUES (?, ?, 1, 0, 100, 50, 20)').run(userId, playerName);
            }
            db.prepare('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?').run(50, 20, userId);
        } catch (dbErr) {
            console.error('[DB ERROR]', dbErr.message);
        }

        clearTimeout(session.timer);

        let board = `🎉 *BENAR SEKALI!* 🎉\n\n` +
            `👤 *Penebak:* ${playerName}\n` +
            `⚔️ *Hero:* ${session.jawabanAsli}\n` +
            `🎁 *Hadiah:* 💵 +$50 Money | ✨ +20 EXP\n`;

        await sock.sendMessage(m.chat, { text: board }, { quoted: m });
        delete global.tebakheroml[chatId];
    }
};

handler.help = ['tebakhero'];
handler.tags = ['game'];
handler.command = ['tebakhero', 'tebakheroml', 'thml'];

export default handler;