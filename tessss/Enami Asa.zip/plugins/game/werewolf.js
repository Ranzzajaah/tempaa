/**

* Hirara AI — WhatsApp Bot
* 
* Library      : @wishkeysocket/baileys
* Type         : Plugins | ESM Modules
* Creator      : Mommy Kyu
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VbDO8tI2phHLTSN2ed0U
* • https://whatsapp.com/channel/0029VbCKm3I5EjxsUbvmVf33
* 
* Thanks To:
* • Allah SWT. — The Creator of Everything
* • Mother & Father — My Greatest Support
* • Kyu — Developer of Hirara AI
* • Hilman — Developer of Ryo Yamada MD
* • Kano — femboy jing
* • Rennz — pemboy nya akuu
* • Raynold — penyopng Ourin jir 😹
* • Fahri — Developer of Jssslyn MD
* • Amane Offc — orng belok
* • All Buyers
* • All Users & Contributors
* 
* Documentation:
* [ID]  Baca README.md untuk melihat panduan.
* [EN]  Read README.md untuk melihat panduan.
* 
* Distribution Notice:
* Dilarang menyebarkan source code ini secara gratis
* tanpa izin dari creator.
* 
* Pelanggaran terhadap ketentuan ini dapat menyebabkan
* penghentian update dan dukungan terhadap source code.
* 
* Copyright © Mommy Kyu 2026
* All Rights Reserved.
  */

import {
	emoji_role,
	sesi,
	playerOnGame,
	playerOnRoom,
	playerExit,
	dataPlayer,
	getPlayerById,
	getPlayerById2,
	killWerewolf,
	dreamySeer,
	sorcerer,
	protectGuardian,
	roleGenerator,
	addTimer,
	startGame,
	playerHidup,
	playerMati,
	vote,
	clearAllVote,
	run,
	run_vote,
	run_malam,
	run_pagi
} from '../../lib/www.js';

global.werewolf = global.werewolf || {};

const handler = async (m, { sock, args, command, reply, usedPrefix }) => {
	const ww = global.werewolf;
	const chat = m.chat;
	const sender = m.sender;
	const value = (args[0] || '').toLowerCase();
	const target = args[1];

	if (command === 'wwpc') {
		if (playerOnGame(sender, ww) === false) {
			return reply('Kamu tidak dalam sesi game');
		}
		const pData = dataPlayer(sender, ww);
		if (pData.status === true) {
			return reply('Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam');
		}
		if (pData.isdead === true) {
			return reply('Kamu sudah mati');
		}
		if (!target || isNaN(target)) {
			return reply('Gunakan nomor player yang valid! Contoh: `.wwpc kill 2`');
		}

		const targetNum = parseInt(target);
		const byId = getPlayerById2(sender, targetNum, ww);
		if (!byId || !byId.db) {
			return reply('Player tidak terdaftar!');
		}
		if (byId.db.isdead === true) {
			return reply('Player sudah mati');
		}
		if (byId.db.id === sender) {
			return reply('Tidak bisa menggunakan skill untuk diri sendiri');
		}

		if (value === 'kill') {
			if (pData.role !== 'werewolf') return reply('Peran ini bukan untuk kamu');
			if (byId.db.role === 'sorcerer') return reply('Tidak bisa menggunakan skill untuk teman');
			pData.status = true;
			killWerewolf(sender, targetNum, ww);
			return reply(`🐺 Target player *${targetNum}* telah dipilih untuk dimangsa malam ini.`);
		} else if (value === 'dreamy') {
			if (pData.role !== 'seer') return reply('Peran ini bukan untuk kamu');
			const dreamy = dreamySeer(sender, targetNum, ww);
			pData.status = true;
			return reply(`🔮 Penerawangan selesai: Identitas Player *${targetNum}* adalah *${dreamy}*`);
		} else if (value === 'deff') {
			if (pData.role !== 'guardian') return reply('Peran ini bukan untuk kamu');
			protectGuardian(sender, targetNum, ww);
			pData.status = true;
			return reply(`🛡️ Berhasil melindungi Player *${targetNum}* dari serangan malam ini.`);
		} else if (value === 'sorcerer') {
			if (pData.role !== 'sorcerer') return reply('Peran ini bukan untuk kamu');
			const roomObj = ww[byId.room];
			const sorker = sorcerer(roomObj, targetNum);
			pData.status = true;
			return reply(`🧙‍♂️ Mantra tersingkap: Player *${targetNum}* adalah *${sorker}*`);
		}
		return;
	}

	if (value === 'create') {
		if (!m.isGroup) return reply('Game Werewolf hanya bisa dimainkan di dalam grup!');
		if (chat in ww) return reply('Group masih dalam sesi permainan');
		if (playerOnGame(sender, ww) === true) return reply('Kamu masih dalam sesi game di room lain');

		ww[chat] = {
			room: chat,
			owner: sender,
			status: false,
			iswin: null,
			cooldown: null,
			day: 0,
			time: 'malem',
			player: [],
			dead: [],
			voting: false,
			seer: false,
			guardian: []
		};
		return reply('🐺 *ROOM WEREWOLF BERHASIL DIBUAT!*\n\nKetik `.ww join` untuk bergabung ke dalam permainan.');
	} else if (value === 'join') {
		if (!ww[chat]) return reply('Belum ada sesi permainan, ketik `.ww create`');
		if (ww[chat].status === true) return reply('Sesi permainan sudah dimulai');
		if (ww[chat].player.length >= 15) return reply('Maaf jumlah player telah penuh (maks 15)');
		if (playerOnRoom(sender, chat, ww) === true) return reply('Kamu sudah join dalam room ini');
		if (playerOnGame(sender, ww) === true) return reply('Kamu masih dalam sesi game');

		const newPlayer = {
			id: sender,
			number: ww[chat].player.length + 1,
			sesi: chat,
			status: false,
			role: false,
			effect: [],
			vote: 0,
			isdead: false,
			isvote: false
		};
		ww[chat].player.push(newPlayer);

		let textList = `*⌂ W E R E W O L F - P L A Y E R*\n\n`;
		const players = [];
		for (const p of ww[chat].player) {
			textList += `${p.number}) @${p.id.split('@')[0]}\n`;
			players.push(p.id);
		}
		textList += `\n_Total: ${ww[chat].player.length}/15 Player (Min 5 player untuk memulai)_`;

		return sock.sendMessage(m.chat, { text: textList, mentions: players }, { quoted: m });
	} else if (value === 'start') {
		if (!ww[chat]) return reply('Belum ada sesi permainan');
		if (ww[chat].player.length < 5) return reply(`Jumlah player belum cukup (${ww[chat].player.length}/5 player)`);
		if (ww[chat].status === true) return reply('Sesi permainan telah dimulai');
		if (ww[chat].owner !== sender) return reply(`Hanya pembuat room @${ww[chat].owner.split('@')[0]} yang dapat memulai permainan!`);

		roleGenerator(chat, ww);
		addTimer(chat, ww);
		startGame(chat, ww);

		const players = ww[chat].player.map(p => p.id);
		let listSemua = ``;
		for (const p of ww[chat].player) {
			listSemua += `(${p.number}) @${p.id.split('@')[0]}\n`;
		}

		for (const p of ww[chat].player) {
			let roleMsg = `*⌂ W E R E W O L F - R O L E*\n\n`;
			roleMsg += `Halo @${p.id.split('@')[0]}! Peranmu adalah: *${emoji_role(p.role)}*\n\n`;
			roleMsg += `*LIST PLAYER:*\n${listSemua}\n\n`;

			if (p.role === 'werewolf') {
				roleMsg += `Ketik \`.wwpc kill <nomor>\` untuk memilih mangsamu malam ini!`;
			} else if (p.role === 'seer') {
				roleMsg += `Ketik \`.wwpc dreamy <nomor>\` untuk menerawang peran pemain lain!`;
			} else if (p.role === 'guardian') {
				roleMsg += `Ketik \`.wwpc deff <nomor>\` untuk melindungi pemain dari serangan!`;
			} else if (p.role === 'sorcerer') {
				roleMsg += `Ketik \`.wwpc sorcerer <nomor>\` untuk mengintip peran pemain!`;
			} else {
				roleMsg += `Kamu adalah warga desa biasa. Masuklah ke rumah dan waspadai serangan Werewolf malam ini!`;
			}

			await sock.sendMessage(p.id, { text: roleMsg, mentions: players }).catch(() => null);
		}

		await sock.sendMessage(m.chat, {
			text: `🐺 *WEREWOLF GAME DIMULAI!*\n\nSeluruh pemain telah dibagikan kartu perannya ke private chat bot masing-masing.\n\nPeriksa chat pribadi kalian sekarang! Malam hari segera tiba...`,
			mentions: players
		});

		return await run(sock, chat, ww);
	} else if (value === 'vote') {
		if (!ww[chat]) return reply('Belum ada sesi permainan');
		if (ww[chat].status === false) return reply('Sesi permainan belum dimulai');
		if (ww[chat].time !== 'voting') return reply('Sesi voting belum dibuka');
		if (playerOnRoom(sender, chat, ww) === false) return reply('Kamu bukan pemain di room ini');

		const pSender = dataPlayer(sender, ww);
		if (pSender.isdead === true) return reply('Kamu sudah mati, tidak bisa memberikan suara');
		if (pSender.isvote === true) return reply('Kamu sudah memberikan suara voting');
		if (!target || isNaN(target)) return reply('Masukkan nomor target vote!');

		const targetNum = parseInt(target);
		const pTarget = getPlayerById(chat, sender, targetNum, ww);
		if (!pTarget) return reply('Nomor player tidak ditemukan');
		if (pTarget.db.isdead === true) return reply('Player tersebut sudah mati');

		vote(chat, targetNum, sender, ww);
		return reply(`✅ Berhasil vote Player *${targetNum}* (@${pTarget.db.id.split('@')[0]})`);
	} else if (value === 'exit') {
		if (!ww[chat]) return reply('Tidak ada sesi permainan');
		if (playerOnRoom(sender, chat, ww) === false) return reply('Kamu tidak dalam sesi permainan');
		if (ww[chat].status === true) return reply('Permainan sudah dimulai, kamu tidak bisa keluar');

		playerExit(chat, sender, ww);
		return reply(`@${sender.split('@')[0]} telah keluar dari room.`);
	} else if (value === 'delete') {
		if (!ww[chat]) return reply('Tidak ada sesi permainan');
		if (ww[chat].owner !== sender) return reply(`Hanya owner room @${ww[chat].owner.split('@')[0]} yang bisa menghapus room!`);

		delete ww[chat];
		return reply('Sesi permainan berhasil dihapus.');
	} else if (value === 'player') {
		if (!ww[chat]) return reply('Tidak ada sesi permainan');
		const players = [];
		let text = `*⌂ W E R E W O L F - L I S T P L A Y E R*\n\n`;
		for (const p of ww[chat].player) {
			text += `(${p.number}) @${p.id.split('@')[0]} ${p.isdead ? '☠️ [MATI]' : '❤️ [HIDUP]'}\n`;
			players.push(p.id);
		}
		return sock.sendMessage(m.chat, { text, mentions: players }, { quoted: m });
	} else {
		let helpText = `🐺 *W E R E W O L F - G A M E*\n\n` +
			`Permainan strategi dan deduksi sosial. Cari penjahat Werewolf yang bersembunyi di antara warga desa!\n\n` +
			`*Commands:*\n` +
			`• \`${usedPrefix}ww create\` — Membuat room baru\n` +
			`• \`${usedPrefix}ww join\` — Bergabung ke room\n` +
			`• \`${usedPrefix}ww start\` — Memulai permainan\n` +
			`• \`${usedPrefix}ww vote <nomor>\` — Voting tersangka di pagi hari\n` +
			`• \`${usedPrefix}ww player\` — Melihat daftar pemain\n` +
			`• \`${usedPrefix}ww exit\` — Keluar dari room\n` +
			`• \`${usedPrefix}ww delete\` — Menghapus room\n\n` +
			`_Bisa dimainkan oleh 5 hingga 15 orang._`;

		return reply(helpText);
	}
};

handler.help = ['ww', 'werewolf', 'wwpc'];
handler.tags = ['game'];
handler.command = ['ww', 'werewolf', 'wwpc'];
handler.register = true;

export default handler;
