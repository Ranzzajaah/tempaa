import axios from 'axios';
import { db } from '../../lib/database.js';

global.family100 = global.family100 || {};

const handler = async (m, { sock, usedPrefix, command, args }) => {
    const chatId = m.chat;

    if (global.family100[chatId]) {
        const session = global.family100[chatId];

        if (args[0] === 'nyerah') {
            clearTimeout(session.timer);
            const ans = session.jawaban.join('\n- ');
            await sock.sendMessage(m.chat, { 
                text: `🏳️ *KAMU MENYERAH!*\n\nJawaban yang benar adalah:\n- ${ans}` 
            }, { quoted: m });
            delete global.family100[chatId];
            return;
        }

        if (args[0] === 'hint' || args[0] === 'bantuan') {
            let hintText = `*💡 HINT FAMILY 100*\n\n*Soal:* ${session.soal}\n\n`;
            for (let i = 0; i < session.jawaban.length; i++) {
                let ans = session.jawaban[i];
                if (session.terjawab.includes(ans)) {
                    hintText += `${i + 1}. ${ans.toUpperCase()} ✅\n`;
                } else {
                    let masked = ans.replace(/[a-zA-Z]/g, (c, idx) => {
                        return idx < Math.ceil(ans.length / 2) ? c.toUpperCase() + ' ' : '_ ';
                    });
                    hintText += `${i + 1}. ${masked.trim()}\n`;
                }
            }
            return sock.sendMessage(m.chat, { text: hintText }, { quoted: m });
        }

        return sock.sendMessage(m.chat, { 
            text: `❌ Masih ada sesi permainan di grup ini!\n\nKetik *${usedPrefix}${command} hint* untuk bantuan.\nKetik *${usedPrefix}${command} nyerah* untuk mengakhiri.` 
        }, { quoted: m });
    }

    await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const { data } = await axios.get('https://api.siputzx.my.id/api/games/family100');
        
        if (!data || !data.status) throw new Error('Gagal mengambil data dari API');

        const soal = data.data.soal;
        const jawaban = data.data.jawaban.map(v => v.toLowerCase().trim());

        global.family100[chatId] = {
            soal: soal,
            jawaban: jawaban,
            terjawab: [], 
            answeredBy: {}, 
            timer: setTimeout(() => {
                if (global.family100[chatId]) {
                    const ans = jawaban.join('\n- ');
                    sock.sendMessage(m.chat, { 
                        text: `⏳ *WAKTU HABIS!*\n\nSesi Family 100 dihentikan.\nJawaban yang benar adalah:\n- ${ans}` 
                    });
                    delete global.family100[chatId];
                }
            }, 180000)
        };

        let board = `*🎯 FAMILY 100 🎯*\n\n`;
        board += `*Soal:* ${soal}\n`;
        board += `Terdapat *${jawaban.length}* jawaban teratas.\n\n`;
        
        for (let i = 0; i < jawaban.length; i++) {
            board += `${i + 1}. ⬛⬛⬛⬛⬛\n`;
        }
        
        board += `\n_💡 Ketik jawaban langsung di obrolan!_`;
        board += `\n_Ketik *${usedPrefix}${command} hint* jika kesulitan._`;

        await sock.sendMessage(m.chat, { text: board }, { quoted: m });
        await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error('[FAMILY 100 ERROR]', e.message);
        await sock.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await sock.sendMessage(m.chat, { text: '❌ Gagal memulai game. Coba lagi nanti.' }, { quoted: m });
    }
};

handler.before = async (m, { sock }) => {
    if (m.isBot || m.fromMe) return;

    const chatId = m.chat;
    const session = global.family100[chatId];
    if (!session) return;

    const text = m.text?.toLowerCase().trim();
    if (!text) return;

    const answerIndex = session.jawaban.indexOf(text);
    
    if (answerIndex !== -1 && !session.terjawab.includes(text)) {
        const userId = m.sender;
        const playerName = m.pushName || 'Player';

        try {
            let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
            if (!user) {
                db.prepare('INSERT INTO users (id, name, level, exp, health, money, limit_val) VALUES (?, ?, 1, 0, 100, 50, 20)').run(userId, playerName);
            }
            db.prepare('UPDATE users SET money = money + ?, exp = exp + ? WHERE id = ?').run(50, 20, userId);
        } catch (dbErr) {
            console.error('[DB ERROR]', dbErr.message);
        }

        session.terjawab.push(text);
        session.answeredBy[text] = playerName;

        const isWin = session.terjawab.length === session.jawaban.length;
        let board = `*🎯 FAMILY 100 🎯*\n\n`;
        board += `*Soal:* ${session.soal}\n\n`;
        
        for (let i = 0; i < session.jawaban.length; i++) {
            let ans = session.jawaban[i];
            if (session.terjawab.includes(ans)) {
                board += `${i + 1}. ${ans.toUpperCase()} (${session.answeredBy[ans]}) [+$50 💵]\n`;
            } else {
                board += `${i + 1}. ⬛⬛⬛⬛⬛\n`;
            }
        }

        if (isWin) {
            clearTimeout(session.timer);
            board += `\n🎉 *SELAMAT!* Semua jawaban telah ditebak!`;
            await sock.sendMessage(m.chat, { text: board }, { quoted: m });
            delete global.family100[chatId];
        } else {
            board += `\n_💡 Lanjut! Ketik .f100 hint untuk bantuan._`;
            await sock.sendMessage(m.chat, { text: board }, { quoted: m });
        }
    }
};

handler.help = ['family100'];
handler.tags = ['game'];
handler.command = ['family100', 'f100'];

export default handler;